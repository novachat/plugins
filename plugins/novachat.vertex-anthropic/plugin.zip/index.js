// src/index.ts
import * as novachat from "@novachat/plugin";

// src/utils/base64.ts
function arrayBufferToBase64(buffer) {
  let binary = "";
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}
async function getImageAsBase64(imageUrl) {
  if (imageUrl.startsWith("data:")) {
    const [header, data] = imageUrl.split(",");
    const media_type = header.split(":")[1].split(";")[0];
    return { media_type, data };
  }
  const response = await fetch(imageUrl);
  const arrayBuffer = await response.arrayBuffer();
  const base64 = arrayBufferToBase64(arrayBuffer);
  return {
    media_type: response.headers.get("content-type") || "image/jpeg",
    data: base64
  };
}

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/version.mjs
var VERSION = "0.28.0";

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/_shims/registry.mjs
var auto = false;
var kind = void 0;
var fetch2 = void 0;
var Request2 = void 0;
var Response2 = void 0;
var Headers2 = void 0;
var FormData2 = void 0;
var Blob2 = void 0;
var File2 = void 0;
var ReadableStream2 = void 0;
var getMultipartRequestOptions = void 0;
var getDefaultAgent = void 0;
var fileFromPath = void 0;
var isFsReadStream = void 0;
function setShims(shims, options = { auto: false }) {
  if (auto) {
    throw new Error(`you must \`import '@anthropic-ai/sdk/shims/${shims.kind}'\` before importing anything else from @anthropic-ai/sdk`);
  }
  if (kind) {
    throw new Error(`can't \`import '@anthropic-ai/sdk/shims/${shims.kind}'\` after \`import '@anthropic-ai/sdk/shims/${kind}'\``);
  }
  auto = options.auto;
  kind = shims.kind;
  fetch2 = shims.fetch;
  Request2 = shims.Request;
  Response2 = shims.Response;
  Headers2 = shims.Headers;
  FormData2 = shims.FormData;
  Blob2 = shims.Blob;
  File2 = shims.File;
  ReadableStream2 = shims.ReadableStream;
  getMultipartRequestOptions = shims.getMultipartRequestOptions;
  getDefaultAgent = shims.getDefaultAgent;
  fileFromPath = shims.fileFromPath;
  isFsReadStream = shims.isFsReadStream;
}

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/_shims/MultipartBody.mjs
var MultipartBody = class {
  constructor(body) {
    this.body = body;
  }
  get [Symbol.toStringTag]() {
    return "MultipartBody";
  }
};

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/_shims/web-runtime.mjs
function getRuntime({ manuallyImported } = {}) {
  const recommendation = manuallyImported ? `You may need to use polyfills` : `Add one of these imports before your first \`import \u2026 from '@anthropic-ai/sdk'\`:
- \`import '@anthropic-ai/sdk/shims/node'\` (if you're running on Node)
- \`import '@anthropic-ai/sdk/shims/web'\` (otherwise)
`;
  let _fetch, _Request, _Response, _Headers;
  try {
    _fetch = fetch;
    _Request = Request;
    _Response = Response;
    _Headers = Headers;
  } catch (error) {
    throw new Error(`this environment is missing the following Web Fetch API type: ${error.message}. ${recommendation}`);
  }
  return {
    kind: "web",
    fetch: _fetch,
    Request: _Request,
    Response: _Response,
    Headers: _Headers,
    FormData: (
      // @ts-ignore
      typeof FormData !== "undefined" ? FormData : class FormData {
        // @ts-ignore
        constructor() {
          throw new Error(`file uploads aren't supported in this environment yet as 'FormData' is undefined. ${recommendation}`);
        }
      }
    ),
    Blob: typeof Blob !== "undefined" ? Blob : class Blob {
      constructor() {
        throw new Error(`file uploads aren't supported in this environment yet as 'Blob' is undefined. ${recommendation}`);
      }
    },
    File: (
      // @ts-ignore
      typeof File !== "undefined" ? File : class File {
        // @ts-ignore
        constructor() {
          throw new Error(`file uploads aren't supported in this environment yet as 'File' is undefined. ${recommendation}`);
        }
      }
    ),
    ReadableStream: (
      // @ts-ignore
      typeof ReadableStream !== "undefined" ? ReadableStream : class ReadableStream {
        // @ts-ignore
        constructor() {
          throw new Error(`streaming isn't supported in this environment yet as 'ReadableStream' is undefined. ${recommendation}`);
        }
      }
    ),
    getMultipartRequestOptions: async (form, opts) => ({
      ...opts,
      body: new MultipartBody(form)
    }),
    getDefaultAgent: (url) => void 0,
    fileFromPath: () => {
      throw new Error("The `fileFromPath` function is only supported in Node. See the README for more details: https://www.github.com/anthropics/anthropic-sdk-typescript#file-uploads");
    },
    isFsReadStream: (value) => false
  };
}

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/_shims/index.mjs
if (!kind) setShims(getRuntime(), { auto: true });

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/error.mjs
var AnthropicError = class extends Error {
};
var APIError = class _APIError extends AnthropicError {
  constructor(status, error, message2, headers) {
    super(`${_APIError.makeMessage(status, error, message2)}`);
    this.status = status;
    this.headers = headers;
    this.request_id = headers?.["request-id"];
    this.error = error;
  }
  static makeMessage(status, error, message2) {
    const msg = error?.message ? typeof error.message === "string" ? error.message : JSON.stringify(error.message) : error ? JSON.stringify(error) : message2;
    if (status && msg) {
      return `${status} ${msg}`;
    }
    if (status) {
      return `${status} status code (no body)`;
    }
    if (msg) {
      return msg;
    }
    return "(no status code or body)";
  }
  static generate(status, errorResponse, message2, headers) {
    if (!status) {
      return new APIConnectionError({ message: message2, cause: castToError(errorResponse) });
    }
    const error = errorResponse;
    if (status === 400) {
      return new BadRequestError(status, error, message2, headers);
    }
    if (status === 401) {
      return new AuthenticationError(status, error, message2, headers);
    }
    if (status === 403) {
      return new PermissionDeniedError(status, error, message2, headers);
    }
    if (status === 404) {
      return new NotFoundError(status, error, message2, headers);
    }
    if (status === 409) {
      return new ConflictError(status, error, message2, headers);
    }
    if (status === 422) {
      return new UnprocessableEntityError(status, error, message2, headers);
    }
    if (status === 429) {
      return new RateLimitError(status, error, message2, headers);
    }
    if (status >= 500) {
      return new InternalServerError(status, error, message2, headers);
    }
    return new _APIError(status, error, message2, headers);
  }
};
var APIUserAbortError = class extends APIError {
  constructor({ message: message2 } = {}) {
    super(void 0, void 0, message2 || "Request was aborted.", void 0);
    this.status = void 0;
  }
};
var APIConnectionError = class extends APIError {
  constructor({ message: message2, cause }) {
    super(void 0, void 0, message2 || "Connection error.", void 0);
    this.status = void 0;
    if (cause)
      this.cause = cause;
  }
};
var APIConnectionTimeoutError = class extends APIConnectionError {
  constructor({ message: message2 } = {}) {
    super({ message: message2 ?? "Request timed out." });
  }
};
var BadRequestError = class extends APIError {
  constructor() {
    super(...arguments);
    this.status = 400;
  }
};
var AuthenticationError = class extends APIError {
  constructor() {
    super(...arguments);
    this.status = 401;
  }
};
var PermissionDeniedError = class extends APIError {
  constructor() {
    super(...arguments);
    this.status = 403;
  }
};
var NotFoundError = class extends APIError {
  constructor() {
    super(...arguments);
    this.status = 404;
  }
};
var ConflictError = class extends APIError {
  constructor() {
    super(...arguments);
    this.status = 409;
  }
};
var UnprocessableEntityError = class extends APIError {
  constructor() {
    super(...arguments);
    this.status = 422;
  }
};
var RateLimitError = class extends APIError {
  constructor() {
    super(...arguments);
    this.status = 429;
  }
};
var InternalServerError = class extends APIError {
};

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/streaming.mjs
var Stream = class _Stream {
  constructor(iterator, controller) {
    this.iterator = iterator;
    this.controller = controller;
  }
  static fromSSEResponse(response, controller) {
    let consumed = false;
    async function* iterator() {
      if (consumed) {
        throw new Error("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");
      }
      consumed = true;
      let done = false;
      try {
        for await (const sse of _iterSSEMessages(response, controller)) {
          if (sse.event === "completion") {
            try {
              yield JSON.parse(sse.data);
            } catch (e) {
              console.error(`Could not parse message into JSON:`, sse.data);
              console.error(`From chunk:`, sse.raw);
              throw e;
            }
          }
          if (sse.event === "message_start" || sse.event === "message_delta" || sse.event === "message_stop" || sse.event === "content_block_start" || sse.event === "content_block_delta" || sse.event === "content_block_stop") {
            try {
              yield JSON.parse(sse.data);
            } catch (e) {
              console.error(`Could not parse message into JSON:`, sse.data);
              console.error(`From chunk:`, sse.raw);
              throw e;
            }
          }
          if (sse.event === "ping") {
            continue;
          }
          if (sse.event === "error") {
            throw APIError.generate(void 0, `SSE Error: ${sse.data}`, sse.data, createResponseHeaders(response.headers));
          }
        }
        done = true;
      } catch (e) {
        if (e instanceof Error && e.name === "AbortError")
          return;
        throw e;
      } finally {
        if (!done)
          controller.abort();
      }
    }
    return new _Stream(iterator, controller);
  }
  /**
   * Generates a Stream from a newline-separated ReadableStream
   * where each item is a JSON value.
   */
  static fromReadableStream(readableStream, controller) {
    let consumed = false;
    async function* iterLines() {
      const lineDecoder = new LineDecoder();
      const iter = readableStreamAsyncIterable(readableStream);
      for await (const chunk of iter) {
        for (const line of lineDecoder.decode(chunk)) {
          yield line;
        }
      }
      for (const line of lineDecoder.flush()) {
        yield line;
      }
    }
    async function* iterator() {
      if (consumed) {
        throw new Error("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");
      }
      consumed = true;
      let done = false;
      try {
        for await (const line of iterLines()) {
          if (done)
            continue;
          if (line)
            yield JSON.parse(line);
        }
        done = true;
      } catch (e) {
        if (e instanceof Error && e.name === "AbortError")
          return;
        throw e;
      } finally {
        if (!done)
          controller.abort();
      }
    }
    return new _Stream(iterator, controller);
  }
  [Symbol.asyncIterator]() {
    return this.iterator();
  }
  /**
   * Splits the stream into two streams which can be
   * independently read from at different speeds.
   */
  tee() {
    const left = [];
    const right = [];
    const iterator = this.iterator();
    const teeIterator = (queue) => {
      return {
        next: () => {
          if (queue.length === 0) {
            const result = iterator.next();
            left.push(result);
            right.push(result);
          }
          return queue.shift();
        }
      };
    };
    return [
      new _Stream(() => teeIterator(left), this.controller),
      new _Stream(() => teeIterator(right), this.controller)
    ];
  }
  /**
   * Converts this stream to a newline-separated ReadableStream of
   * JSON stringified values in the stream
   * which can be turned back into a Stream with `Stream.fromReadableStream()`.
   */
  toReadableStream() {
    const self = this;
    let iter;
    const encoder2 = new TextEncoder();
    return new ReadableStream2({
      async start() {
        iter = self[Symbol.asyncIterator]();
      },
      async pull(ctrl) {
        try {
          const { value, done } = await iter.next();
          if (done)
            return ctrl.close();
          const bytes = encoder2.encode(JSON.stringify(value) + "\n");
          ctrl.enqueue(bytes);
        } catch (err) {
          ctrl.error(err);
        }
      },
      async cancel() {
        await iter.return?.();
      }
    });
  }
};
async function* _iterSSEMessages(response, controller) {
  if (!response.body) {
    controller.abort();
    throw new AnthropicError(`Attempted to iterate over a response with no body`);
  }
  const sseDecoder = new SSEDecoder();
  const lineDecoder = new LineDecoder();
  const iter = readableStreamAsyncIterable(response.body);
  for await (const sseChunk of iterSSEChunks(iter)) {
    for (const line of lineDecoder.decode(sseChunk)) {
      const sse = sseDecoder.decode(line);
      if (sse)
        yield sse;
    }
  }
  for (const line of lineDecoder.flush()) {
    const sse = sseDecoder.decode(line);
    if (sse)
      yield sse;
  }
}
async function* iterSSEChunks(iterator) {
  let data = new Uint8Array();
  for await (const chunk of iterator) {
    if (chunk == null) {
      continue;
    }
    const binaryChunk = chunk instanceof ArrayBuffer ? new Uint8Array(chunk) : typeof chunk === "string" ? new TextEncoder().encode(chunk) : chunk;
    let newData = new Uint8Array(data.length + binaryChunk.length);
    newData.set(data);
    newData.set(binaryChunk, data.length);
    data = newData;
    let patternIndex;
    while ((patternIndex = findDoubleNewlineIndex(data)) !== -1) {
      yield data.slice(0, patternIndex);
      data = data.slice(patternIndex);
    }
  }
  if (data.length > 0) {
    yield data;
  }
}
function findDoubleNewlineIndex(buffer) {
  const newline = 10;
  const carriage = 13;
  for (let i = 0; i < buffer.length - 2; i++) {
    if (buffer[i] === newline && buffer[i + 1] === newline) {
      return i + 2;
    }
    if (buffer[i] === carriage && buffer[i + 1] === carriage) {
      return i + 2;
    }
    if (buffer[i] === carriage && buffer[i + 1] === newline && i + 3 < buffer.length && buffer[i + 2] === carriage && buffer[i + 3] === newline) {
      return i + 4;
    }
  }
  return -1;
}
var SSEDecoder = class {
  constructor() {
    this.event = null;
    this.data = [];
    this.chunks = [];
  }
  decode(line) {
    if (line.endsWith("\r")) {
      line = line.substring(0, line.length - 1);
    }
    if (!line) {
      if (!this.event && !this.data.length)
        return null;
      const sse = {
        event: this.event,
        data: this.data.join("\n"),
        raw: this.chunks
      };
      this.event = null;
      this.data = [];
      this.chunks = [];
      return sse;
    }
    this.chunks.push(line);
    if (line.startsWith(":")) {
      return null;
    }
    let [fieldname, _, value] = partition(line, ":");
    if (value.startsWith(" ")) {
      value = value.substring(1);
    }
    if (fieldname === "event") {
      this.event = value;
    } else if (fieldname === "data") {
      this.data.push(value);
    }
    return null;
  }
};
var LineDecoder = class _LineDecoder {
  constructor() {
    this.buffer = [];
    this.trailingCR = false;
  }
  decode(chunk) {
    let text = this.decodeText(chunk);
    if (this.trailingCR) {
      text = "\r" + text;
      this.trailingCR = false;
    }
    if (text.endsWith("\r")) {
      this.trailingCR = true;
      text = text.slice(0, -1);
    }
    if (!text) {
      return [];
    }
    const trailingNewline = _LineDecoder.NEWLINE_CHARS.has(text[text.length - 1] || "");
    let lines = text.split(_LineDecoder.NEWLINE_REGEXP);
    if (trailingNewline) {
      lines.pop();
    }
    if (lines.length === 1 && !trailingNewline) {
      this.buffer.push(lines[0]);
      return [];
    }
    if (this.buffer.length > 0) {
      lines = [this.buffer.join("") + lines[0], ...lines.slice(1)];
      this.buffer = [];
    }
    if (!trailingNewline) {
      this.buffer = [lines.pop() || ""];
    }
    return lines;
  }
  decodeText(bytes) {
    if (bytes == null)
      return "";
    if (typeof bytes === "string")
      return bytes;
    if (typeof Buffer !== "undefined") {
      if (bytes instanceof Buffer) {
        return bytes.toString();
      }
      if (bytes instanceof Uint8Array) {
        return Buffer.from(bytes).toString();
      }
      throw new AnthropicError(`Unexpected: received non-Uint8Array (${bytes.constructor.name}) stream chunk in an environment with a global "Buffer" defined, which this library assumes to be Node. Please report this error.`);
    }
    if (typeof TextDecoder !== "undefined") {
      if (bytes instanceof Uint8Array || bytes instanceof ArrayBuffer) {
        this.textDecoder ?? (this.textDecoder = new TextDecoder("utf8"));
        return this.textDecoder.decode(bytes);
      }
      throw new AnthropicError(`Unexpected: received non-Uint8Array/ArrayBuffer (${bytes.constructor.name}) in a web platform. Please report this error.`);
    }
    throw new AnthropicError(`Unexpected: neither Buffer nor TextDecoder are available as globals. Please report this error.`);
  }
  flush() {
    if (!this.buffer.length && !this.trailingCR) {
      return [];
    }
    const lines = [this.buffer.join("")];
    this.buffer = [];
    this.trailingCR = false;
    return lines;
  }
};
LineDecoder.NEWLINE_CHARS = /* @__PURE__ */ new Set(["\n", "\r"]);
LineDecoder.NEWLINE_REGEXP = /\r\n|[\n\r]/g;
function partition(str, delimiter) {
  const index = str.indexOf(delimiter);
  if (index !== -1) {
    return [str.substring(0, index), delimiter, str.substring(index + delimiter.length)];
  }
  return [str, "", ""];
}
function readableStreamAsyncIterable(stream) {
  if (stream[Symbol.asyncIterator])
    return stream;
  const reader = stream.getReader();
  return {
    async next() {
      try {
        const result = await reader.read();
        if (result?.done)
          reader.releaseLock();
        return result;
      } catch (e) {
        reader.releaseLock();
        throw e;
      }
    },
    async return() {
      const cancelPromise = reader.cancel();
      reader.releaseLock();
      await cancelPromise;
      return { done: true, value: void 0 };
    },
    [Symbol.asyncIterator]() {
      return this;
    }
  };
}

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/uploads.mjs
var isBlobLike = (value) => value != null && typeof value === "object" && typeof value.size === "number" && typeof value.type === "string" && typeof value.text === "function" && typeof value.slice === "function" && typeof value.arrayBuffer === "function";
var isMultipartBody = (body) => body && typeof body === "object" && body.body && body[Symbol.toStringTag] === "MultipartBody";

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/core.mjs
var __classPrivateFieldSet = function(receiver, state, value, kind2, f) {
  if (kind2 === "m") throw new TypeError("Private method is not writable");
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return kind2 === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
};
var __classPrivateFieldGet = function(receiver, state, kind2, f) {
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind2 === "m" ? f : kind2 === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _AbstractPage_client;
async function defaultParseResponse(props) {
  const { response } = props;
  if (props.options.stream) {
    debug("response", response.status, response.url, response.headers, response.body);
    if (props.options.__streamClass) {
      return props.options.__streamClass.fromSSEResponse(response, props.controller);
    }
    return Stream.fromSSEResponse(response, props.controller);
  }
  if (response.status === 204) {
    return null;
  }
  if (props.options.__binaryResponse) {
    return response;
  }
  const contentType = response.headers.get("content-type");
  const isJSON = contentType?.includes("application/json") || contentType?.includes("application/vnd.api+json");
  if (isJSON) {
    const json = await response.json();
    debug("response", response.status, response.url, response.headers, json);
    return json;
  }
  const text = await response.text();
  debug("response", response.status, response.url, response.headers, text);
  return text;
}
var APIPromise = class _APIPromise extends Promise {
  constructor(responsePromise, parseResponse2 = defaultParseResponse) {
    super((resolve) => {
      resolve(null);
    });
    this.responsePromise = responsePromise;
    this.parseResponse = parseResponse2;
  }
  _thenUnwrap(transform) {
    return new _APIPromise(this.responsePromise, async (props) => transform(await this.parseResponse(props)));
  }
  /**
   * Gets the raw `Response` instance instead of parsing the response
   * data.
   *
   * If you want to parse the response body but still get the `Response`
   * instance, you can use {@link withResponse()}.
   *
   * 👋 Getting the wrong TypeScript type for `Response`?
   * Try setting `"moduleResolution": "NodeNext"` if you can,
   * or add one of these imports before your first `import … from '@anthropic-ai/sdk'`:
   * - `import '@anthropic-ai/sdk/shims/node'` (if you're running on Node)
   * - `import '@anthropic-ai/sdk/shims/web'` (otherwise)
   */
  asResponse() {
    return this.responsePromise.then((p) => p.response);
  }
  /**
   * Gets the parsed response data and the raw `Response` instance.
   *
   * If you just want to get the raw `Response` instance without parsing it,
   * you can use {@link asResponse()}.
   *
   *
   * 👋 Getting the wrong TypeScript type for `Response`?
   * Try setting `"moduleResolution": "NodeNext"` if you can,
   * or add one of these imports before your first `import … from '@anthropic-ai/sdk'`:
   * - `import '@anthropic-ai/sdk/shims/node'` (if you're running on Node)
   * - `import '@anthropic-ai/sdk/shims/web'` (otherwise)
   */
  async withResponse() {
    const [data, response] = await Promise.all([this.parse(), this.asResponse()]);
    return { data, response };
  }
  parse() {
    if (!this.parsedPromise) {
      this.parsedPromise = this.responsePromise.then(this.parseResponse);
    }
    return this.parsedPromise;
  }
  then(onfulfilled, onrejected) {
    return this.parse().then(onfulfilled, onrejected);
  }
  catch(onrejected) {
    return this.parse().catch(onrejected);
  }
  finally(onfinally) {
    return this.parse().finally(onfinally);
  }
};
var APIClient = class {
  constructor({
    baseURL,
    maxRetries = 2,
    timeout = 6e5,
    // 10 minutes
    httpAgent,
    fetch: overridenFetch
  }) {
    this.baseURL = baseURL;
    this.maxRetries = validatePositiveInteger("maxRetries", maxRetries);
    this.timeout = validatePositiveInteger("timeout", timeout);
    this.httpAgent = httpAgent;
    this.fetch = overridenFetch ?? fetch2;
  }
  authHeaders(opts) {
    return {};
  }
  /**
   * Override this to add your own default headers, for example:
   *
   *  {
   *    ...super.defaultHeaders(),
   *    Authorization: 'Bearer 123',
   *  }
   */
  defaultHeaders(opts) {
    return {
      Accept: "application/json",
      "Content-Type": "application/json",
      "User-Agent": this.getUserAgent(),
      ...getPlatformHeaders(),
      ...this.authHeaders(opts)
    };
  }
  /**
   * Override this to add your own headers validation:
   */
  validateHeaders(headers, customHeaders) {
  }
  defaultIdempotencyKey() {
    return `stainless-node-retry-${uuid4()}`;
  }
  get(path, opts) {
    return this.methodRequest("get", path, opts);
  }
  post(path, opts) {
    return this.methodRequest("post", path, opts);
  }
  patch(path, opts) {
    return this.methodRequest("patch", path, opts);
  }
  put(path, opts) {
    return this.methodRequest("put", path, opts);
  }
  delete(path, opts) {
    return this.methodRequest("delete", path, opts);
  }
  methodRequest(method, path, opts) {
    return this.request(Promise.resolve(opts).then(async (opts2) => {
      const body = opts2 && isBlobLike(opts2?.body) ? new DataView(await opts2.body.arrayBuffer()) : opts2?.body instanceof DataView ? opts2.body : opts2?.body instanceof ArrayBuffer ? new DataView(opts2.body) : opts2 && ArrayBuffer.isView(opts2?.body) ? new DataView(opts2.body.buffer) : opts2?.body;
      return { method, path, ...opts2, body };
    }));
  }
  getAPIList(path, Page, opts) {
    return this.requestAPIList(Page, { method: "get", path, ...opts });
  }
  calculateContentLength(body) {
    if (typeof body === "string") {
      if (typeof Buffer !== "undefined") {
        return Buffer.byteLength(body, "utf8").toString();
      }
      if (typeof TextEncoder !== "undefined") {
        const encoder2 = new TextEncoder();
        const encoded = encoder2.encode(body);
        return encoded.length.toString();
      }
    } else if (ArrayBuffer.isView(body)) {
      return body.byteLength.toString();
    }
    return null;
  }
  buildRequest(options, { retryCount = 0 } = {}) {
    const { method, path, query, headers = {} } = options;
    const body = ArrayBuffer.isView(options.body) || options.__binaryRequest && typeof options.body === "string" ? options.body : isMultipartBody(options.body) ? options.body.body : options.body ? JSON.stringify(options.body, null, 2) : null;
    const contentLength = this.calculateContentLength(body);
    const url = this.buildURL(path, query);
    if ("timeout" in options)
      validatePositiveInteger("timeout", options.timeout);
    const timeout = options.timeout ?? this.timeout;
    const httpAgent = options.httpAgent ?? this.httpAgent ?? getDefaultAgent(url);
    const minAgentTimeout = timeout + 1e3;
    if (typeof httpAgent?.options?.timeout === "number" && minAgentTimeout > (httpAgent.options.timeout ?? 0)) {
      httpAgent.options.timeout = minAgentTimeout;
    }
    if (this.idempotencyHeader && method !== "get") {
      if (!options.idempotencyKey)
        options.idempotencyKey = this.defaultIdempotencyKey();
      headers[this.idempotencyHeader] = options.idempotencyKey;
    }
    const reqHeaders = this.buildHeaders({ options, headers, contentLength, retryCount });
    const req = {
      method,
      ...body && { body },
      headers: reqHeaders,
      ...httpAgent && { agent: httpAgent },
      // @ts-ignore node-fetch uses a custom AbortSignal type that is
      // not compatible with standard web types
      signal: options.signal ?? null
    };
    return { req, url, timeout };
  }
  buildHeaders({ options, headers, contentLength, retryCount }) {
    const reqHeaders = {};
    if (contentLength) {
      reqHeaders["content-length"] = contentLength;
    }
    const defaultHeaders = this.defaultHeaders(options);
    applyHeadersMut(reqHeaders, defaultHeaders);
    applyHeadersMut(reqHeaders, headers);
    if (isMultipartBody(options.body) && kind !== "node") {
      delete reqHeaders["content-type"];
    }
    if (getHeader(headers, "x-stainless-retry-count") === void 0) {
      reqHeaders["x-stainless-retry-count"] = String(retryCount);
    }
    this.validateHeaders(reqHeaders, headers);
    return reqHeaders;
  }
  /**
   * Used as a callback for mutating the given `FinalRequestOptions` object.
   */
  async prepareOptions(options) {
  }
  /**
   * Used as a callback for mutating the given `RequestInit` object.
   *
   * This is useful for cases where you want to add certain headers based off of
   * the request properties, e.g. `method` or `url`.
   */
  async prepareRequest(request, { url, options }) {
  }
  parseHeaders(headers) {
    return !headers ? {} : Symbol.iterator in headers ? Object.fromEntries(Array.from(headers).map((header) => [...header])) : { ...headers };
  }
  makeStatusError(status, error, message2, headers) {
    return APIError.generate(status, error, message2, headers);
  }
  request(options, remainingRetries = null) {
    return new APIPromise(this.makeRequest(options, remainingRetries));
  }
  async makeRequest(optionsInput, retriesRemaining) {
    const options = await optionsInput;
    const maxRetries = options.maxRetries ?? this.maxRetries;
    if (retriesRemaining == null) {
      retriesRemaining = maxRetries;
    }
    await this.prepareOptions(options);
    const { req, url, timeout } = this.buildRequest(options, { retryCount: maxRetries - retriesRemaining });
    await this.prepareRequest(req, { url, options });
    debug("request", url, options, req.headers);
    if (options.signal?.aborted) {
      throw new APIUserAbortError();
    }
    const controller = new AbortController();
    const response = await this.fetchWithTimeout(url, req, timeout, controller).catch(castToError);
    if (response instanceof Error) {
      if (options.signal?.aborted) {
        throw new APIUserAbortError();
      }
      if (retriesRemaining) {
        return this.retryRequest(options, retriesRemaining);
      }
      if (response.name === "AbortError") {
        throw new APIConnectionTimeoutError();
      }
      throw new APIConnectionError({ cause: response });
    }
    const responseHeaders = createResponseHeaders(response.headers);
    if (!response.ok) {
      if (retriesRemaining && this.shouldRetry(response)) {
        const retryMessage2 = `retrying, ${retriesRemaining} attempts remaining`;
        debug(`response (error; ${retryMessage2})`, response.status, url, responseHeaders);
        return this.retryRequest(options, retriesRemaining, responseHeaders);
      }
      const errText = await response.text().catch((e) => castToError(e).message);
      const errJSON = safeJSON(errText);
      const errMessage = errJSON ? void 0 : errText;
      const retryMessage = retriesRemaining ? `(error; no more retries left)` : `(error; not retryable)`;
      debug(`response (error; ${retryMessage})`, response.status, url, responseHeaders, errMessage);
      const err = this.makeStatusError(response.status, errJSON, errMessage, responseHeaders);
      throw err;
    }
    return { response, options, controller };
  }
  requestAPIList(Page, options) {
    const request = this.makeRequest(options, null);
    return new PagePromise(this, request, Page);
  }
  buildURL(path, query) {
    const url = isAbsoluteURL(path) ? new URL(path) : new URL(this.baseURL + (this.baseURL.endsWith("/") && path.startsWith("/") ? path.slice(1) : path));
    const defaultQuery = this.defaultQuery();
    if (!isEmptyObj(defaultQuery)) {
      query = { ...defaultQuery, ...query };
    }
    if (typeof query === "object" && query && !Array.isArray(query)) {
      url.search = this.stringifyQuery(query);
    }
    return url.toString();
  }
  stringifyQuery(query) {
    return Object.entries(query).filter(([_, value]) => typeof value !== "undefined").map(([key, value]) => {
      if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
        return `${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
      }
      if (value === null) {
        return `${encodeURIComponent(key)}=`;
      }
      throw new AnthropicError(`Cannot stringify type ${typeof value}; Expected string, number, boolean, or null. If you need to pass nested query parameters, you can manually encode them, e.g. { query: { 'foo[key1]': value1, 'foo[key2]': value2 } }, and please open a GitHub issue requesting better support for your use case.`);
    }).join("&");
  }
  async fetchWithTimeout(url, init, ms, controller) {
    const { signal, ...options } = init || {};
    if (signal)
      signal.addEventListener("abort", () => controller.abort());
    const timeout = setTimeout(() => controller.abort(), ms);
    return this.getRequestClient().fetch.call(void 0, url, { signal: controller.signal, ...options }).finally(() => {
      clearTimeout(timeout);
    });
  }
  getRequestClient() {
    return { fetch: this.fetch };
  }
  shouldRetry(response) {
    const shouldRetryHeader = response.headers.get("x-should-retry");
    if (shouldRetryHeader === "true")
      return true;
    if (shouldRetryHeader === "false")
      return false;
    if (response.status === 408)
      return true;
    if (response.status === 409)
      return true;
    if (response.status === 429)
      return true;
    if (response.status >= 500)
      return true;
    return false;
  }
  async retryRequest(options, retriesRemaining, responseHeaders) {
    let timeoutMillis;
    const retryAfterMillisHeader = responseHeaders?.["retry-after-ms"];
    if (retryAfterMillisHeader) {
      const timeoutMs = parseFloat(retryAfterMillisHeader);
      if (!Number.isNaN(timeoutMs)) {
        timeoutMillis = timeoutMs;
      }
    }
    const retryAfterHeader = responseHeaders?.["retry-after"];
    if (retryAfterHeader && !timeoutMillis) {
      const timeoutSeconds = parseFloat(retryAfterHeader);
      if (!Number.isNaN(timeoutSeconds)) {
        timeoutMillis = timeoutSeconds * 1e3;
      } else {
        timeoutMillis = Date.parse(retryAfterHeader) - Date.now();
      }
    }
    if (!(timeoutMillis && 0 <= timeoutMillis && timeoutMillis < 60 * 1e3)) {
      const maxRetries = options.maxRetries ?? this.maxRetries;
      timeoutMillis = this.calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries);
    }
    await sleep(timeoutMillis);
    return this.makeRequest(options, retriesRemaining - 1);
  }
  calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries) {
    const initialRetryDelay = 0.5;
    const maxRetryDelay = 8;
    const numRetries = maxRetries - retriesRemaining;
    const sleepSeconds = Math.min(initialRetryDelay * Math.pow(2, numRetries), maxRetryDelay);
    const jitter = 1 - Math.random() * 0.25;
    return sleepSeconds * jitter * 1e3;
  }
  getUserAgent() {
    return `${this.constructor.name}/JS ${VERSION}`;
  }
};
var AbstractPage = class {
  constructor(client, response, body, options) {
    _AbstractPage_client.set(this, void 0);
    __classPrivateFieldSet(this, _AbstractPage_client, client, "f");
    this.options = options;
    this.response = response;
    this.body = body;
  }
  hasNextPage() {
    const items = this.getPaginatedItems();
    if (!items.length)
      return false;
    return this.nextPageInfo() != null;
  }
  async getNextPage() {
    const nextInfo = this.nextPageInfo();
    if (!nextInfo) {
      throw new AnthropicError("No next page expected; please check `.hasNextPage()` before calling `.getNextPage()`.");
    }
    const nextOptions = { ...this.options };
    if ("params" in nextInfo && typeof nextOptions.query === "object") {
      nextOptions.query = { ...nextOptions.query, ...nextInfo.params };
    } else if ("url" in nextInfo) {
      const params = [...Object.entries(nextOptions.query || {}), ...nextInfo.url.searchParams.entries()];
      for (const [key, value] of params) {
        nextInfo.url.searchParams.set(key, value);
      }
      nextOptions.query = void 0;
      nextOptions.path = nextInfo.url.toString();
    }
    return await __classPrivateFieldGet(this, _AbstractPage_client, "f").requestAPIList(this.constructor, nextOptions);
  }
  async *iterPages() {
    let page = this;
    yield page;
    while (page.hasNextPage()) {
      page = await page.getNextPage();
      yield page;
    }
  }
  async *[(_AbstractPage_client = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
    for await (const page of this.iterPages()) {
      for (const item of page.getPaginatedItems()) {
        yield item;
      }
    }
  }
};
var PagePromise = class extends APIPromise {
  constructor(client, request, Page) {
    super(request, async (props) => new Page(client, props.response, await defaultParseResponse(props), props.options));
  }
  /**
   * Allow auto-paginating iteration on an unawaited list call, eg:
   *
   *    for await (const item of client.items.list()) {
   *      console.log(item)
   *    }
   */
  async *[Symbol.asyncIterator]() {
    const page = await this;
    for await (const item of page) {
      yield item;
    }
  }
};
var createResponseHeaders = (headers) => {
  return new Proxy(Object.fromEntries(
    // @ts-ignore
    headers.entries()
  ), {
    get(target, name) {
      const key = name.toString();
      return target[key.toLowerCase()] || target[key];
    }
  });
};
var getPlatformProperties = () => {
  if (typeof Deno !== "undefined" && Deno.build != null) {
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": VERSION,
      "X-Stainless-OS": normalizePlatform(Deno.build.os),
      "X-Stainless-Arch": normalizeArch(Deno.build.arch),
      "X-Stainless-Runtime": "deno",
      "X-Stainless-Runtime-Version": typeof Deno.version === "string" ? Deno.version : Deno.version?.deno ?? "unknown"
    };
  }
  if (typeof EdgeRuntime !== "undefined") {
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": VERSION,
      "X-Stainless-OS": "Unknown",
      "X-Stainless-Arch": `other:${EdgeRuntime}`,
      "X-Stainless-Runtime": "edge",
      "X-Stainless-Runtime-Version": process.version
    };
  }
  if (Object.prototype.toString.call(typeof process !== "undefined" ? process : 0) === "[object process]") {
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": VERSION,
      "X-Stainless-OS": normalizePlatform(process.platform),
      "X-Stainless-Arch": normalizeArch(process.arch),
      "X-Stainless-Runtime": "node",
      "X-Stainless-Runtime-Version": process.version
    };
  }
  const browserInfo = getBrowserInfo();
  if (browserInfo) {
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": VERSION,
      "X-Stainless-OS": "Unknown",
      "X-Stainless-Arch": "unknown",
      "X-Stainless-Runtime": `browser:${browserInfo.browser}`,
      "X-Stainless-Runtime-Version": browserInfo.version
    };
  }
  return {
    "X-Stainless-Lang": "js",
    "X-Stainless-Package-Version": VERSION,
    "X-Stainless-OS": "Unknown",
    "X-Stainless-Arch": "unknown",
    "X-Stainless-Runtime": "unknown",
    "X-Stainless-Runtime-Version": "unknown"
  };
};
function getBrowserInfo() {
  if (typeof navigator === "undefined" || !navigator) {
    return null;
  }
  const browserPatterns = [
    { key: "edge", pattern: /Edge(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "ie", pattern: /MSIE(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "ie", pattern: /Trident(?:.*rv\:(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "chrome", pattern: /Chrome(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "firefox", pattern: /Firefox(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "safari", pattern: /(?:Version\W+(\d+)\.(\d+)(?:\.(\d+))?)?(?:\W+Mobile\S*)?\W+Safari/ }
  ];
  for (const { key, pattern } of browserPatterns) {
    const match = pattern.exec(navigator.userAgent);
    if (match) {
      const major = match[1] || 0;
      const minor = match[2] || 0;
      const patch = match[3] || 0;
      return { browser: key, version: `${major}.${minor}.${patch}` };
    }
  }
  return null;
}
var normalizeArch = (arch) => {
  if (arch === "x32")
    return "x32";
  if (arch === "x86_64" || arch === "x64")
    return "x64";
  if (arch === "arm")
    return "arm";
  if (arch === "aarch64" || arch === "arm64")
    return "arm64";
  if (arch)
    return `other:${arch}`;
  return "unknown";
};
var normalizePlatform = (platform) => {
  platform = platform.toLowerCase();
  if (platform.includes("ios"))
    return "iOS";
  if (platform === "android")
    return "Android";
  if (platform === "darwin")
    return "MacOS";
  if (platform === "win32")
    return "Windows";
  if (platform === "freebsd")
    return "FreeBSD";
  if (platform === "openbsd")
    return "OpenBSD";
  if (platform === "linux")
    return "Linux";
  if (platform)
    return `Other:${platform}`;
  return "Unknown";
};
var _platformHeaders;
var getPlatformHeaders = () => {
  return _platformHeaders ?? (_platformHeaders = getPlatformProperties());
};
var safeJSON = (text) => {
  try {
    return JSON.parse(text);
  } catch (err) {
    return void 0;
  }
};
var startsWithSchemeRegexp = new RegExp("^(?:[a-z]+:)?//", "i");
var isAbsoluteURL = (url) => {
  return startsWithSchemeRegexp.test(url);
};
var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
var validatePositiveInteger = (name, n) => {
  if (typeof n !== "number" || !Number.isInteger(n)) {
    throw new AnthropicError(`${name} must be an integer`);
  }
  if (n < 0) {
    throw new AnthropicError(`${name} must be a positive integer`);
  }
  return n;
};
var castToError = (err) => {
  if (err instanceof Error)
    return err;
  if (typeof err === "object" && err !== null) {
    try {
      return new Error(JSON.stringify(err));
    } catch {
    }
  }
  return new Error(String(err));
};
var readEnv = (env) => {
  if (typeof process !== "undefined") {
    return process.env?.[env]?.trim() ?? void 0;
  }
  if (typeof Deno !== "undefined") {
    return Deno.env?.get?.(env)?.trim();
  }
  return void 0;
};
function isEmptyObj(obj) {
  if (!obj)
    return true;
  for (const _k in obj)
    return false;
  return true;
}
function hasOwn(obj, key) {
  return Object.prototype.hasOwnProperty.call(obj, key);
}
function applyHeadersMut(targetHeaders, newHeaders) {
  for (const k in newHeaders) {
    if (!hasOwn(newHeaders, k))
      continue;
    const lowerKey = k.toLowerCase();
    if (!lowerKey)
      continue;
    const val = newHeaders[k];
    if (val === null) {
      delete targetHeaders[lowerKey];
    } else if (val !== void 0) {
      targetHeaders[lowerKey] = val;
    }
  }
}
function debug(action, ...args) {
  if (typeof process !== "undefined" && process?.env?.["DEBUG"] === "true") {
    console.log(`Anthropic:DEBUG:${action}`, ...args);
  }
}
var uuid4 = () => {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === "x" ? r : r & 3 | 8;
    return v.toString(16);
  });
};
var isHeadersProtocol = (headers) => {
  return typeof headers?.get === "function";
};
var getHeader = (headers, header) => {
  const lowerCasedHeader = header.toLowerCase();
  if (isHeadersProtocol(headers)) {
    const intercapsHeader = header[0]?.toUpperCase() + header.substring(1).replace(/([^\w])(\w)/g, (_m, g1, g2) => g1 + g2.toUpperCase());
    for (const key of [header, lowerCasedHeader, header.toUpperCase(), intercapsHeader]) {
      const value = headers.get(key);
      if (value) {
        return value;
      }
    }
  }
  for (const [key, value] of Object.entries(headers)) {
    if (key.toLowerCase() === lowerCasedHeader) {
      if (Array.isArray(value)) {
        if (value.length <= 1)
          return value[0];
        console.warn(`Received ${value.length} entries for the ${header} header, using the first entry.`);
        return value[0];
      }
      return value;
    }
  }
  return void 0;
};
function isObj(obj) {
  return obj != null && typeof obj === "object" && !Array.isArray(obj);
}

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/resource.mjs
var APIResource = class {
  constructor(client) {
    this._client = client;
  }
};

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/_vendor/partial-json-parser/parser.mjs
var tokenize = (input) => {
  let current = 0;
  let tokens = [];
  while (current < input.length) {
    let char = input[current];
    if (char === "\\") {
      current++;
      continue;
    }
    if (char === "{") {
      tokens.push({
        type: "brace",
        value: "{"
      });
      current++;
      continue;
    }
    if (char === "}") {
      tokens.push({
        type: "brace",
        value: "}"
      });
      current++;
      continue;
    }
    if (char === "[") {
      tokens.push({
        type: "paren",
        value: "["
      });
      current++;
      continue;
    }
    if (char === "]") {
      tokens.push({
        type: "paren",
        value: "]"
      });
      current++;
      continue;
    }
    if (char === ":") {
      tokens.push({
        type: "separator",
        value: ":"
      });
      current++;
      continue;
    }
    if (char === ",") {
      tokens.push({
        type: "delimiter",
        value: ","
      });
      current++;
      continue;
    }
    if (char === '"') {
      let value = "";
      let danglingQuote = false;
      char = input[++current];
      while (char !== '"') {
        if (current === input.length) {
          danglingQuote = true;
          break;
        }
        if (char === "\\") {
          current++;
          if (current === input.length) {
            danglingQuote = true;
            break;
          }
          value += char + input[current];
          char = input[++current];
        } else {
          value += char;
          char = input[++current];
        }
      }
      char = input[++current];
      if (!danglingQuote) {
        tokens.push({
          type: "string",
          value
        });
      }
      continue;
    }
    let WHITESPACE = /\s/;
    if (char && WHITESPACE.test(char)) {
      current++;
      continue;
    }
    let NUMBERS = /[0-9]/;
    if (char && NUMBERS.test(char) || char === "-" || char === ".") {
      let value = "";
      if (char === "-") {
        value += char;
        char = input[++current];
      }
      while (char && NUMBERS.test(char) || char === ".") {
        value += char;
        char = input[++current];
      }
      tokens.push({
        type: "number",
        value
      });
      continue;
    }
    let LETTERS = /[a-z]/i;
    if (char && LETTERS.test(char)) {
      let value = "";
      while (char && LETTERS.test(char)) {
        if (current === input.length) {
          break;
        }
        value += char;
        char = input[++current];
      }
      if (value == "true" || value == "false" || value === "null") {
        tokens.push({
          type: "name",
          value
        });
      } else {
        current++;
        continue;
      }
      continue;
    }
    current++;
  }
  return tokens;
};
var strip = (tokens) => {
  if (tokens.length === 0) {
    return tokens;
  }
  let lastToken = tokens[tokens.length - 1];
  switch (lastToken.type) {
    case "separator":
      tokens = tokens.slice(0, tokens.length - 1);
      return strip(tokens);
      break;
    case "number":
      let lastCharacterOfLastToken = lastToken.value[lastToken.value.length - 1];
      if (lastCharacterOfLastToken === "." || lastCharacterOfLastToken === "-") {
        tokens = tokens.slice(0, tokens.length - 1);
        return strip(tokens);
      }
    case "string":
      let tokenBeforeTheLastToken = tokens[tokens.length - 2];
      if (tokenBeforeTheLastToken?.type === "delimiter") {
        tokens = tokens.slice(0, tokens.length - 1);
        return strip(tokens);
      } else if (tokenBeforeTheLastToken?.type === "brace" && tokenBeforeTheLastToken.value === "{") {
        tokens = tokens.slice(0, tokens.length - 1);
        return strip(tokens);
      }
      break;
    case "delimiter":
      tokens = tokens.slice(0, tokens.length - 1);
      return strip(tokens);
      break;
  }
  return tokens;
};
var unstrip = (tokens) => {
  let tail = [];
  tokens.map((token2) => {
    if (token2.type === "brace") {
      if (token2.value === "{") {
        tail.push("}");
      } else {
        tail.splice(tail.lastIndexOf("}"), 1);
      }
    }
    if (token2.type === "paren") {
      if (token2.value === "[") {
        tail.push("]");
      } else {
        tail.splice(tail.lastIndexOf("]"), 1);
      }
    }
  });
  if (tail.length > 0) {
    tail.reverse().map((item) => {
      if (item === "}") {
        tokens.push({
          type: "brace",
          value: "}"
        });
      } else if (item === "]") {
        tokens.push({
          type: "paren",
          value: "]"
        });
      }
    });
  }
  return tokens;
};
var generate = (tokens) => {
  let output = "";
  tokens.map((token2) => {
    switch (token2.type) {
      case "string":
        output += '"' + token2.value + '"';
        break;
      default:
        output += token2.value;
        break;
    }
  });
  return output;
};
var partialParse = (input) => JSON.parse(generate(unstrip(strip(tokenize(input)))));

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/lib/MessageStream.mjs
var __classPrivateFieldSet2 = function(receiver, state, value, kind2, f) {
  if (kind2 === "m") throw new TypeError("Private method is not writable");
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return kind2 === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
};
var __classPrivateFieldGet2 = function(receiver, state, kind2, f) {
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind2 === "m" ? f : kind2 === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _MessageStream_instances;
var _MessageStream_currentMessageSnapshot;
var _MessageStream_connectedPromise;
var _MessageStream_resolveConnectedPromise;
var _MessageStream_rejectConnectedPromise;
var _MessageStream_endPromise;
var _MessageStream_resolveEndPromise;
var _MessageStream_rejectEndPromise;
var _MessageStream_listeners;
var _MessageStream_ended;
var _MessageStream_errored;
var _MessageStream_aborted;
var _MessageStream_catchingPromiseCreated;
var _MessageStream_getFinalMessage;
var _MessageStream_getFinalText;
var _MessageStream_handleError;
var _MessageStream_beginRequest;
var _MessageStream_addStreamEvent;
var _MessageStream_endRequest;
var _MessageStream_accumulateMessage;
var JSON_BUF_PROPERTY = "__json_buf";
var MessageStream = class _MessageStream {
  constructor() {
    _MessageStream_instances.add(this);
    this.messages = [];
    this.receivedMessages = [];
    _MessageStream_currentMessageSnapshot.set(this, void 0);
    this.controller = new AbortController();
    _MessageStream_connectedPromise.set(this, void 0);
    _MessageStream_resolveConnectedPromise.set(this, () => {
    });
    _MessageStream_rejectConnectedPromise.set(this, () => {
    });
    _MessageStream_endPromise.set(this, void 0);
    _MessageStream_resolveEndPromise.set(this, () => {
    });
    _MessageStream_rejectEndPromise.set(this, () => {
    });
    _MessageStream_listeners.set(this, {});
    _MessageStream_ended.set(this, false);
    _MessageStream_errored.set(this, false);
    _MessageStream_aborted.set(this, false);
    _MessageStream_catchingPromiseCreated.set(this, false);
    _MessageStream_handleError.set(this, (error) => {
      __classPrivateFieldSet2(this, _MessageStream_errored, true, "f");
      if (error instanceof Error && error.name === "AbortError") {
        error = new APIUserAbortError();
      }
      if (error instanceof APIUserAbortError) {
        __classPrivateFieldSet2(this, _MessageStream_aborted, true, "f");
        return this._emit("abort", error);
      }
      if (error instanceof AnthropicError) {
        return this._emit("error", error);
      }
      if (error instanceof Error) {
        const anthropicError = new AnthropicError(error.message);
        anthropicError.cause = error;
        return this._emit("error", anthropicError);
      }
      return this._emit("error", new AnthropicError(String(error)));
    });
    __classPrivateFieldSet2(this, _MessageStream_connectedPromise, new Promise((resolve, reject) => {
      __classPrivateFieldSet2(this, _MessageStream_resolveConnectedPromise, resolve, "f");
      __classPrivateFieldSet2(this, _MessageStream_rejectConnectedPromise, reject, "f");
    }), "f");
    __classPrivateFieldSet2(this, _MessageStream_endPromise, new Promise((resolve, reject) => {
      __classPrivateFieldSet2(this, _MessageStream_resolveEndPromise, resolve, "f");
      __classPrivateFieldSet2(this, _MessageStream_rejectEndPromise, reject, "f");
    }), "f");
    __classPrivateFieldGet2(this, _MessageStream_connectedPromise, "f").catch(() => {
    });
    __classPrivateFieldGet2(this, _MessageStream_endPromise, "f").catch(() => {
    });
  }
  /**
   * Intended for use on the frontend, consuming a stream produced with
   * `.toReadableStream()` on the backend.
   *
   * Note that messages sent to the model do not appear in `.on('message')`
   * in this context.
   */
  static fromReadableStream(stream) {
    const runner = new _MessageStream();
    runner._run(() => runner._fromReadableStream(stream));
    return runner;
  }
  static createMessage(messages, params, options) {
    const runner = new _MessageStream();
    for (const message2 of params.messages) {
      runner._addMessageParam(message2);
    }
    runner._run(() => runner._createMessage(messages, { ...params, stream: true }, { ...options, headers: { ...options?.headers, "X-Stainless-Helper-Method": "stream" } }));
    return runner;
  }
  _run(executor) {
    executor().then(() => {
      this._emitFinal();
      this._emit("end");
    }, __classPrivateFieldGet2(this, _MessageStream_handleError, "f"));
  }
  _addMessageParam(message2) {
    this.messages.push(message2);
  }
  _addMessage(message2, emit = true) {
    this.receivedMessages.push(message2);
    if (emit) {
      this._emit("message", message2);
    }
  }
  async _createMessage(messages, params, options) {
    const signal = options?.signal;
    if (signal) {
      if (signal.aborted)
        this.controller.abort();
      signal.addEventListener("abort", () => this.controller.abort());
    }
    __classPrivateFieldGet2(this, _MessageStream_instances, "m", _MessageStream_beginRequest).call(this);
    const stream = await messages.create({ ...params, stream: true }, { ...options, signal: this.controller.signal });
    this._connected();
    for await (const event of stream) {
      __classPrivateFieldGet2(this, _MessageStream_instances, "m", _MessageStream_addStreamEvent).call(this, event);
    }
    if (stream.controller.signal?.aborted) {
      throw new APIUserAbortError();
    }
    __classPrivateFieldGet2(this, _MessageStream_instances, "m", _MessageStream_endRequest).call(this);
  }
  _connected() {
    if (this.ended)
      return;
    __classPrivateFieldGet2(this, _MessageStream_resolveConnectedPromise, "f").call(this);
    this._emit("connect");
  }
  get ended() {
    return __classPrivateFieldGet2(this, _MessageStream_ended, "f");
  }
  get errored() {
    return __classPrivateFieldGet2(this, _MessageStream_errored, "f");
  }
  get aborted() {
    return __classPrivateFieldGet2(this, _MessageStream_aborted, "f");
  }
  abort() {
    this.controller.abort();
  }
  /**
   * Adds the listener function to the end of the listeners array for the event.
   * No checks are made to see if the listener has already been added. Multiple calls passing
   * the same combination of event and listener will result in the listener being added, and
   * called, multiple times.
   * @returns this MessageStream, so that calls can be chained
   */
  on(event, listener) {
    const listeners = __classPrivateFieldGet2(this, _MessageStream_listeners, "f")[event] || (__classPrivateFieldGet2(this, _MessageStream_listeners, "f")[event] = []);
    listeners.push({ listener });
    return this;
  }
  /**
   * Removes the specified listener from the listener array for the event.
   * off() will remove, at most, one instance of a listener from the listener array. If any single
   * listener has been added multiple times to the listener array for the specified event, then
   * off() must be called multiple times to remove each instance.
   * @returns this MessageStream, so that calls can be chained
   */
  off(event, listener) {
    const listeners = __classPrivateFieldGet2(this, _MessageStream_listeners, "f")[event];
    if (!listeners)
      return this;
    const index = listeners.findIndex((l) => l.listener === listener);
    if (index >= 0)
      listeners.splice(index, 1);
    return this;
  }
  /**
   * Adds a one-time listener function for the event. The next time the event is triggered,
   * this listener is removed and then invoked.
   * @returns this MessageStream, so that calls can be chained
   */
  once(event, listener) {
    const listeners = __classPrivateFieldGet2(this, _MessageStream_listeners, "f")[event] || (__classPrivateFieldGet2(this, _MessageStream_listeners, "f")[event] = []);
    listeners.push({ listener, once: true });
    return this;
  }
  /**
   * This is similar to `.once()`, but returns a Promise that resolves the next time
   * the event is triggered, instead of calling a listener callback.
   * @returns a Promise that resolves the next time given event is triggered,
   * or rejects if an error is emitted.  (If you request the 'error' event,
   * returns a promise that resolves with the error).
   *
   * Example:
   *
   *   const message = await stream.emitted('message') // rejects if the stream errors
   */
  emitted(event) {
    return new Promise((resolve, reject) => {
      __classPrivateFieldSet2(this, _MessageStream_catchingPromiseCreated, true, "f");
      if (event !== "error")
        this.once("error", reject);
      this.once(event, resolve);
    });
  }
  async done() {
    __classPrivateFieldSet2(this, _MessageStream_catchingPromiseCreated, true, "f");
    await __classPrivateFieldGet2(this, _MessageStream_endPromise, "f");
  }
  get currentMessage() {
    return __classPrivateFieldGet2(this, _MessageStream_currentMessageSnapshot, "f");
  }
  /**
   * @returns a promise that resolves with the the final assistant Message response,
   * or rejects if an error occurred or the stream ended prematurely without producing a Message.
   */
  async finalMessage() {
    await this.done();
    return __classPrivateFieldGet2(this, _MessageStream_instances, "m", _MessageStream_getFinalMessage).call(this);
  }
  /**
   * @returns a promise that resolves with the the final assistant Message's text response, concatenated
   * together if there are more than one text blocks.
   * Rejects if an error occurred or the stream ended prematurely without producing a Message.
   */
  async finalText() {
    await this.done();
    return __classPrivateFieldGet2(this, _MessageStream_instances, "m", _MessageStream_getFinalText).call(this);
  }
  _emit(event, ...args) {
    if (__classPrivateFieldGet2(this, _MessageStream_ended, "f"))
      return;
    if (event === "end") {
      __classPrivateFieldSet2(this, _MessageStream_ended, true, "f");
      __classPrivateFieldGet2(this, _MessageStream_resolveEndPromise, "f").call(this);
    }
    const listeners = __classPrivateFieldGet2(this, _MessageStream_listeners, "f")[event];
    if (listeners) {
      __classPrivateFieldGet2(this, _MessageStream_listeners, "f")[event] = listeners.filter((l) => !l.once);
      listeners.forEach(({ listener }) => listener(...args));
    }
    if (event === "abort") {
      const error = args[0];
      if (!__classPrivateFieldGet2(this, _MessageStream_catchingPromiseCreated, "f") && !listeners?.length) {
        Promise.reject(error);
      }
      __classPrivateFieldGet2(this, _MessageStream_rejectConnectedPromise, "f").call(this, error);
      __classPrivateFieldGet2(this, _MessageStream_rejectEndPromise, "f").call(this, error);
      this._emit("end");
      return;
    }
    if (event === "error") {
      const error = args[0];
      if (!__classPrivateFieldGet2(this, _MessageStream_catchingPromiseCreated, "f") && !listeners?.length) {
        Promise.reject(error);
      }
      __classPrivateFieldGet2(this, _MessageStream_rejectConnectedPromise, "f").call(this, error);
      __classPrivateFieldGet2(this, _MessageStream_rejectEndPromise, "f").call(this, error);
      this._emit("end");
    }
  }
  _emitFinal() {
    const finalMessage = this.receivedMessages.at(-1);
    if (finalMessage) {
      this._emit("finalMessage", __classPrivateFieldGet2(this, _MessageStream_instances, "m", _MessageStream_getFinalMessage).call(this));
    }
  }
  async _fromReadableStream(readableStream, options) {
    const signal = options?.signal;
    if (signal) {
      if (signal.aborted)
        this.controller.abort();
      signal.addEventListener("abort", () => this.controller.abort());
    }
    __classPrivateFieldGet2(this, _MessageStream_instances, "m", _MessageStream_beginRequest).call(this);
    this._connected();
    const stream = Stream.fromReadableStream(readableStream, this.controller);
    for await (const event of stream) {
      __classPrivateFieldGet2(this, _MessageStream_instances, "m", _MessageStream_addStreamEvent).call(this, event);
    }
    if (stream.controller.signal?.aborted) {
      throw new APIUserAbortError();
    }
    __classPrivateFieldGet2(this, _MessageStream_instances, "m", _MessageStream_endRequest).call(this);
  }
  [(_MessageStream_currentMessageSnapshot = /* @__PURE__ */ new WeakMap(), _MessageStream_connectedPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_resolveConnectedPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_rejectConnectedPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_endPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_resolveEndPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_rejectEndPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_listeners = /* @__PURE__ */ new WeakMap(), _MessageStream_ended = /* @__PURE__ */ new WeakMap(), _MessageStream_errored = /* @__PURE__ */ new WeakMap(), _MessageStream_aborted = /* @__PURE__ */ new WeakMap(), _MessageStream_catchingPromiseCreated = /* @__PURE__ */ new WeakMap(), _MessageStream_handleError = /* @__PURE__ */ new WeakMap(), _MessageStream_instances = /* @__PURE__ */ new WeakSet(), _MessageStream_getFinalMessage = function _MessageStream_getFinalMessage2() {
    if (this.receivedMessages.length === 0) {
      throw new AnthropicError("stream ended without producing a Message with role=assistant");
    }
    return this.receivedMessages.at(-1);
  }, _MessageStream_getFinalText = function _MessageStream_getFinalText2() {
    if (this.receivedMessages.length === 0) {
      throw new AnthropicError("stream ended without producing a Message with role=assistant");
    }
    const textBlocks = this.receivedMessages.at(-1).content.filter((block) => block.type === "text").map((block) => block.text);
    if (textBlocks.length === 0) {
      throw new AnthropicError("stream ended without producing a content block with type=text");
    }
    return textBlocks.join(" ");
  }, _MessageStream_beginRequest = function _MessageStream_beginRequest2() {
    if (this.ended)
      return;
    __classPrivateFieldSet2(this, _MessageStream_currentMessageSnapshot, void 0, "f");
  }, _MessageStream_addStreamEvent = function _MessageStream_addStreamEvent2(event) {
    if (this.ended)
      return;
    const messageSnapshot = __classPrivateFieldGet2(this, _MessageStream_instances, "m", _MessageStream_accumulateMessage).call(this, event);
    this._emit("streamEvent", event, messageSnapshot);
    switch (event.type) {
      case "content_block_delta": {
        const content = messageSnapshot.content.at(-1);
        if (event.delta.type === "text_delta" && content.type === "text") {
          this._emit("text", event.delta.text, content.text || "");
        } else if (event.delta.type === "input_json_delta" && content.type === "tool_use") {
          if (content.input) {
            this._emit("inputJson", event.delta.partial_json, content.input);
          }
        }
        break;
      }
      case "message_stop": {
        this._addMessageParam(messageSnapshot);
        this._addMessage(messageSnapshot, true);
        break;
      }
      case "content_block_stop": {
        this._emit("contentBlock", messageSnapshot.content.at(-1));
        break;
      }
      case "message_start": {
        __classPrivateFieldSet2(this, _MessageStream_currentMessageSnapshot, messageSnapshot, "f");
        break;
      }
      case "content_block_start":
      case "message_delta":
        break;
    }
  }, _MessageStream_endRequest = function _MessageStream_endRequest2() {
    if (this.ended) {
      throw new AnthropicError(`stream has ended, this shouldn't happen`);
    }
    const snapshot = __classPrivateFieldGet2(this, _MessageStream_currentMessageSnapshot, "f");
    if (!snapshot) {
      throw new AnthropicError(`request ended without sending any chunks`);
    }
    __classPrivateFieldSet2(this, _MessageStream_currentMessageSnapshot, void 0, "f");
    return snapshot;
  }, _MessageStream_accumulateMessage = function _MessageStream_accumulateMessage2(event) {
    let snapshot = __classPrivateFieldGet2(this, _MessageStream_currentMessageSnapshot, "f");
    if (event.type === "message_start") {
      if (snapshot) {
        throw new AnthropicError(`Unexpected event order, got ${event.type} before receiving "message_stop"`);
      }
      return event.message;
    }
    if (!snapshot) {
      throw new AnthropicError(`Unexpected event order, got ${event.type} before "message_start"`);
    }
    switch (event.type) {
      case "message_stop":
        return snapshot;
      case "message_delta":
        snapshot.stop_reason = event.delta.stop_reason;
        snapshot.stop_sequence = event.delta.stop_sequence;
        snapshot.usage.output_tokens = event.usage.output_tokens;
        return snapshot;
      case "content_block_start":
        snapshot.content.push(event.content_block);
        return snapshot;
      case "content_block_delta": {
        const snapshotContent = snapshot.content.at(event.index);
        if (snapshotContent?.type === "text" && event.delta.type === "text_delta") {
          snapshotContent.text += event.delta.text;
        } else if (snapshotContent?.type === "tool_use" && event.delta.type === "input_json_delta") {
          let jsonBuf = snapshotContent[JSON_BUF_PROPERTY] || "";
          jsonBuf += event.delta.partial_json;
          Object.defineProperty(snapshotContent, JSON_BUF_PROPERTY, {
            value: jsonBuf,
            enumerable: false,
            writable: true
          });
          if (jsonBuf) {
            snapshotContent.input = partialParse(jsonBuf);
          }
        }
        return snapshot;
      }
      case "content_block_stop":
        return snapshot;
    }
  }, Symbol.asyncIterator)]() {
    const pushQueue = [];
    const readQueue = [];
    let done = false;
    this.on("streamEvent", (event) => {
      const reader = readQueue.shift();
      if (reader) {
        reader.resolve(event);
      } else {
        pushQueue.push(event);
      }
    });
    this.on("end", () => {
      done = true;
      for (const reader of readQueue) {
        reader.resolve(void 0);
      }
      readQueue.length = 0;
    });
    this.on("abort", (err) => {
      done = true;
      for (const reader of readQueue) {
        reader.reject(err);
      }
      readQueue.length = 0;
    });
    this.on("error", (err) => {
      done = true;
      for (const reader of readQueue) {
        reader.reject(err);
      }
      readQueue.length = 0;
    });
    return {
      next: async () => {
        if (!pushQueue.length) {
          if (done) {
            return { value: void 0, done: true };
          }
          return new Promise((resolve, reject) => readQueue.push({ resolve, reject })).then((chunk2) => chunk2 ? { value: chunk2, done: false } : { value: void 0, done: true });
        }
        const chunk = pushQueue.shift();
        return { value: chunk, done: false };
      },
      return: async () => {
        this.abort();
        return { value: void 0, done: true };
      }
    };
  }
  toReadableStream() {
    const stream = new Stream(this[Symbol.asyncIterator].bind(this), this.controller);
    return stream.toReadableStream();
  }
};

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/resources/messages.mjs
var Messages = class extends APIResource {
  create(body, options) {
    if (body.model in DEPRECATED_MODELS) {
      console.warn(`The model '${body.model}' is deprecated and will reach end-of-life on ${DEPRECATED_MODELS[body.model]}
Please migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.`);
    }
    return this._client.post("/v1/messages", {
      body,
      timeout: this._client._options.timeout ?? 6e5,
      ...options,
      stream: body.stream ?? false
    });
  }
  /**
   * Create a Message stream
   */
  stream(body, options) {
    return MessageStream.createMessage(this, body, options);
  }
};
var DEPRECATED_MODELS = {
  "claude-1.3": "November 6th, 2024",
  "claude-1.3-100k": "November 6th, 2024",
  "claude-instant-1.1": "November 6th, 2024",
  "claude-instant-1.1-100k": "November 6th, 2024",
  "claude-instant-1.2": "November 6th, 2024"
};
/* @__PURE__ */ (function(Messages2) {
})(Messages || (Messages = {}));

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/runtime/webcrypto.js
var webcrypto_default = crypto;
var isCryptoKey = (key) => key instanceof CryptoKey;

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/lib/buffer_utils.js
var encoder = new TextEncoder();
var decoder = new TextDecoder();
var MAX_INT32 = 2 ** 32;
function concat(...buffers) {
  const size = buffers.reduce((acc, { length }) => acc + length, 0);
  const buf = new Uint8Array(size);
  let i = 0;
  for (const buffer of buffers) {
    buf.set(buffer, i);
    i += buffer.length;
  }
  return buf;
}

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/runtime/base64url.js
var encodeBase64 = (input) => {
  let unencoded = input;
  if (typeof unencoded === "string") {
    unencoded = encoder.encode(unencoded);
  }
  const CHUNK_SIZE = 32768;
  const arr = [];
  for (let i = 0; i < unencoded.length; i += CHUNK_SIZE) {
    arr.push(String.fromCharCode.apply(null, unencoded.subarray(i, i + CHUNK_SIZE)));
  }
  return btoa(arr.join(""));
};
var encode = (input) => {
  return encodeBase64(input).replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
};
var decodeBase64 = (encoded) => {
  const binary = atob(encoded);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) {
    bytes[i] = binary.charCodeAt(i);
  }
  return bytes;
};
var decode = (input) => {
  let encoded = input;
  if (encoded instanceof Uint8Array) {
    encoded = decoder.decode(encoded);
  }
  encoded = encoded.replace(/-/g, "+").replace(/_/g, "/").replace(/\s/g, "");
  try {
    return decodeBase64(encoded);
  } catch {
    throw new TypeError("The input to be decoded is not correctly encoded.");
  }
};

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/util/errors.js
var JOSEError = class extends Error {
  static get code() {
    return "ERR_JOSE_GENERIC";
  }
  constructor(message2) {
    super(message2);
    this.code = "ERR_JOSE_GENERIC";
    this.name = this.constructor.name;
    Error.captureStackTrace?.(this, this.constructor);
  }
};
var JOSENotSupported = class extends JOSEError {
  constructor() {
    super(...arguments);
    this.code = "ERR_JOSE_NOT_SUPPORTED";
  }
  static get code() {
    return "ERR_JOSE_NOT_SUPPORTED";
  }
};
var JWSInvalid = class extends JOSEError {
  constructor() {
    super(...arguments);
    this.code = "ERR_JWS_INVALID";
  }
  static get code() {
    return "ERR_JWS_INVALID";
  }
};
var JWTInvalid = class extends JOSEError {
  constructor() {
    super(...arguments);
    this.code = "ERR_JWT_INVALID";
  }
  static get code() {
    return "ERR_JWT_INVALID";
  }
};

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/lib/crypto_key.js
function unusable(name, prop = "algorithm.name") {
  return new TypeError(`CryptoKey does not support this operation, its ${prop} must be ${name}`);
}
function isAlgorithm(algorithm, name) {
  return algorithm.name === name;
}
function getHashLength(hash) {
  return parseInt(hash.name.slice(4), 10);
}
function getNamedCurve(alg) {
  switch (alg) {
    case "ES256":
      return "P-256";
    case "ES384":
      return "P-384";
    case "ES512":
      return "P-521";
    default:
      throw new Error("unreachable");
  }
}
function checkUsage(key, usages) {
  if (usages.length && !usages.some((expected) => key.usages.includes(expected))) {
    let msg = "CryptoKey does not support this operation, its usages must include ";
    if (usages.length > 2) {
      const last = usages.pop();
      msg += `one of ${usages.join(", ")}, or ${last}.`;
    } else if (usages.length === 2) {
      msg += `one of ${usages[0]} or ${usages[1]}.`;
    } else {
      msg += `${usages[0]}.`;
    }
    throw new TypeError(msg);
  }
}
function checkSigCryptoKey(key, alg, ...usages) {
  switch (alg) {
    case "HS256":
    case "HS384":
    case "HS512": {
      if (!isAlgorithm(key.algorithm, "HMAC"))
        throw unusable("HMAC");
      const expected = parseInt(alg.slice(2), 10);
      const actual = getHashLength(key.algorithm.hash);
      if (actual !== expected)
        throw unusable(`SHA-${expected}`, "algorithm.hash");
      break;
    }
    case "RS256":
    case "RS384":
    case "RS512": {
      if (!isAlgorithm(key.algorithm, "RSASSA-PKCS1-v1_5"))
        throw unusable("RSASSA-PKCS1-v1_5");
      const expected = parseInt(alg.slice(2), 10);
      const actual = getHashLength(key.algorithm.hash);
      if (actual !== expected)
        throw unusable(`SHA-${expected}`, "algorithm.hash");
      break;
    }
    case "PS256":
    case "PS384":
    case "PS512": {
      if (!isAlgorithm(key.algorithm, "RSA-PSS"))
        throw unusable("RSA-PSS");
      const expected = parseInt(alg.slice(2), 10);
      const actual = getHashLength(key.algorithm.hash);
      if (actual !== expected)
        throw unusable(`SHA-${expected}`, "algorithm.hash");
      break;
    }
    case "EdDSA": {
      if (key.algorithm.name !== "Ed25519" && key.algorithm.name !== "Ed448") {
        throw unusable("Ed25519 or Ed448");
      }
      break;
    }
    case "ES256":
    case "ES384":
    case "ES512": {
      if (!isAlgorithm(key.algorithm, "ECDSA"))
        throw unusable("ECDSA");
      const expected = getNamedCurve(alg);
      const actual = key.algorithm.namedCurve;
      if (actual !== expected)
        throw unusable(expected, "algorithm.namedCurve");
      break;
    }
    default:
      throw new TypeError("CryptoKey does not support this operation");
  }
  checkUsage(key, usages);
}

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/lib/invalid_key_input.js
function message(msg, actual, ...types2) {
  types2 = types2.filter(Boolean);
  if (types2.length > 2) {
    const last = types2.pop();
    msg += `one of type ${types2.join(", ")}, or ${last}.`;
  } else if (types2.length === 2) {
    msg += `one of type ${types2[0]} or ${types2[1]}.`;
  } else {
    msg += `of type ${types2[0]}.`;
  }
  if (actual == null) {
    msg += ` Received ${actual}`;
  } else if (typeof actual === "function" && actual.name) {
    msg += ` Received function ${actual.name}`;
  } else if (typeof actual === "object" && actual != null) {
    if (actual.constructor?.name) {
      msg += ` Received an instance of ${actual.constructor.name}`;
    }
  }
  return msg;
}
var invalid_key_input_default = (actual, ...types2) => {
  return message("Key must be ", actual, ...types2);
};
function withAlg(alg, actual, ...types2) {
  return message(`Key for the ${alg} algorithm must be `, actual, ...types2);
}

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/runtime/is_key_like.js
var is_key_like_default = (key) => {
  if (isCryptoKey(key)) {
    return true;
  }
  return key?.[Symbol.toStringTag] === "KeyObject";
};
var types = ["CryptoKey"];

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/lib/is_disjoint.js
var isDisjoint = (...headers) => {
  const sources = headers.filter(Boolean);
  if (sources.length === 0 || sources.length === 1) {
    return true;
  }
  let acc;
  for (const header of sources) {
    const parameters = Object.keys(header);
    if (!acc || acc.size === 0) {
      acc = new Set(parameters);
      continue;
    }
    for (const parameter of parameters) {
      if (acc.has(parameter)) {
        return false;
      }
      acc.add(parameter);
    }
  }
  return true;
};
var is_disjoint_default = isDisjoint;

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/lib/is_object.js
function isObjectLike(value) {
  return typeof value === "object" && value !== null;
}
function isObject(input) {
  if (!isObjectLike(input) || Object.prototype.toString.call(input) !== "[object Object]") {
    return false;
  }
  if (Object.getPrototypeOf(input) === null) {
    return true;
  }
  let proto = input;
  while (Object.getPrototypeOf(proto) !== null) {
    proto = Object.getPrototypeOf(proto);
  }
  return Object.getPrototypeOf(input) === proto;
}

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/runtime/check_key_length.js
var check_key_length_default = (alg, key) => {
  if (alg.startsWith("RS") || alg.startsWith("PS")) {
    const { modulusLength } = key.algorithm;
    if (typeof modulusLength !== "number" || modulusLength < 2048) {
      throw new TypeError(`${alg} requires key modulusLength to be 2048 bits or larger`);
    }
  }
};

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/lib/is_jwk.js
function isJWK(key) {
  return isObject(key) && typeof key.kty === "string";
}
function isPrivateJWK(key) {
  return key.kty !== "oct" && typeof key.d === "string";
}
function isPublicJWK(key) {
  return key.kty !== "oct" && typeof key.d === "undefined";
}
function isSecretJWK(key) {
  return isJWK(key) && key.kty === "oct" && typeof key.k === "string";
}

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/runtime/jwk_to_key.js
function subtleMapping(jwk) {
  let algorithm;
  let keyUsages;
  switch (jwk.kty) {
    case "RSA": {
      switch (jwk.alg) {
        case "PS256":
        case "PS384":
        case "PS512":
          algorithm = { name: "RSA-PSS", hash: `SHA-${jwk.alg.slice(-3)}` };
          keyUsages = jwk.d ? ["sign"] : ["verify"];
          break;
        case "RS256":
        case "RS384":
        case "RS512":
          algorithm = { name: "RSASSA-PKCS1-v1_5", hash: `SHA-${jwk.alg.slice(-3)}` };
          keyUsages = jwk.d ? ["sign"] : ["verify"];
          break;
        case "RSA-OAEP":
        case "RSA-OAEP-256":
        case "RSA-OAEP-384":
        case "RSA-OAEP-512":
          algorithm = {
            name: "RSA-OAEP",
            hash: `SHA-${parseInt(jwk.alg.slice(-3), 10) || 1}`
          };
          keyUsages = jwk.d ? ["decrypt", "unwrapKey"] : ["encrypt", "wrapKey"];
          break;
        default:
          throw new JOSENotSupported('Invalid or unsupported JWK "alg" (Algorithm) Parameter value');
      }
      break;
    }
    case "EC": {
      switch (jwk.alg) {
        case "ES256":
          algorithm = { name: "ECDSA", namedCurve: "P-256" };
          keyUsages = jwk.d ? ["sign"] : ["verify"];
          break;
        case "ES384":
          algorithm = { name: "ECDSA", namedCurve: "P-384" };
          keyUsages = jwk.d ? ["sign"] : ["verify"];
          break;
        case "ES512":
          algorithm = { name: "ECDSA", namedCurve: "P-521" };
          keyUsages = jwk.d ? ["sign"] : ["verify"];
          break;
        case "ECDH-ES":
        case "ECDH-ES+A128KW":
        case "ECDH-ES+A192KW":
        case "ECDH-ES+A256KW":
          algorithm = { name: "ECDH", namedCurve: jwk.crv };
          keyUsages = jwk.d ? ["deriveBits"] : [];
          break;
        default:
          throw new JOSENotSupported('Invalid or unsupported JWK "alg" (Algorithm) Parameter value');
      }
      break;
    }
    case "OKP": {
      switch (jwk.alg) {
        case "EdDSA":
          algorithm = { name: jwk.crv };
          keyUsages = jwk.d ? ["sign"] : ["verify"];
          break;
        case "ECDH-ES":
        case "ECDH-ES+A128KW":
        case "ECDH-ES+A192KW":
        case "ECDH-ES+A256KW":
          algorithm = { name: jwk.crv };
          keyUsages = jwk.d ? ["deriveBits"] : [];
          break;
        default:
          throw new JOSENotSupported('Invalid or unsupported JWK "alg" (Algorithm) Parameter value');
      }
      break;
    }
    default:
      throw new JOSENotSupported('Invalid or unsupported JWK "kty" (Key Type) Parameter value');
  }
  return { algorithm, keyUsages };
}
var parse = async (jwk) => {
  if (!jwk.alg) {
    throw new TypeError('"alg" argument is required when "jwk.alg" is not present');
  }
  const { algorithm, keyUsages } = subtleMapping(jwk);
  const rest = [
    algorithm,
    jwk.ext ?? false,
    jwk.key_ops ?? keyUsages
  ];
  const keyData = { ...jwk };
  delete keyData.alg;
  delete keyData.use;
  return webcrypto_default.subtle.importKey("jwk", keyData, ...rest);
};
var jwk_to_key_default = parse;

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/runtime/normalize_key.js
var exportKeyValue = (k) => decode(k);
var privCache;
var pubCache;
var isKeyObject = (key) => {
  return key?.[Symbol.toStringTag] === "KeyObject";
};
var importAndCache = async (cache, key, jwk, alg, freeze = false) => {
  let cached = cache.get(key);
  if (cached?.[alg]) {
    return cached[alg];
  }
  const cryptoKey = await jwk_to_key_default({ ...jwk, alg });
  if (freeze)
    Object.freeze(key);
  if (!cached) {
    cache.set(key, { [alg]: cryptoKey });
  } else {
    cached[alg] = cryptoKey;
  }
  return cryptoKey;
};
var normalizePublicKey = (key, alg) => {
  if (isKeyObject(key)) {
    let jwk = key.export({ format: "jwk" });
    delete jwk.d;
    delete jwk.dp;
    delete jwk.dq;
    delete jwk.p;
    delete jwk.q;
    delete jwk.qi;
    if (jwk.k) {
      return exportKeyValue(jwk.k);
    }
    pubCache || (pubCache = /* @__PURE__ */ new WeakMap());
    return importAndCache(pubCache, key, jwk, alg);
  }
  if (isJWK(key)) {
    if (key.k)
      return decode(key.k);
    pubCache || (pubCache = /* @__PURE__ */ new WeakMap());
    const cryptoKey = importAndCache(pubCache, key, key, alg, true);
    return cryptoKey;
  }
  return key;
};
var normalizePrivateKey = (key, alg) => {
  if (isKeyObject(key)) {
    let jwk = key.export({ format: "jwk" });
    if (jwk.k) {
      return exportKeyValue(jwk.k);
    }
    privCache || (privCache = /* @__PURE__ */ new WeakMap());
    return importAndCache(privCache, key, jwk, alg);
  }
  if (isJWK(key)) {
    if (key.k)
      return decode(key.k);
    privCache || (privCache = /* @__PURE__ */ new WeakMap());
    const cryptoKey = importAndCache(privCache, key, key, alg, true);
    return cryptoKey;
  }
  return key;
};
var normalize_key_default = { normalizePublicKey, normalizePrivateKey };

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/runtime/asn1.js
var findOid = (keyData, oid, from = 0) => {
  if (from === 0) {
    oid.unshift(oid.length);
    oid.unshift(6);
  }
  const i = keyData.indexOf(oid[0], from);
  if (i === -1)
    return false;
  const sub = keyData.subarray(i, i + oid.length);
  if (sub.length !== oid.length)
    return false;
  return sub.every((value, index) => value === oid[index]) || findOid(keyData, oid, i + 1);
};
var getNamedCurve2 = (keyData) => {
  switch (true) {
    case findOid(keyData, [42, 134, 72, 206, 61, 3, 1, 7]):
      return "P-256";
    case findOid(keyData, [43, 129, 4, 0, 34]):
      return "P-384";
    case findOid(keyData, [43, 129, 4, 0, 35]):
      return "P-521";
    case findOid(keyData, [43, 101, 110]):
      return "X25519";
    case findOid(keyData, [43, 101, 111]):
      return "X448";
    case findOid(keyData, [43, 101, 112]):
      return "Ed25519";
    case findOid(keyData, [43, 101, 113]):
      return "Ed448";
    default:
      throw new JOSENotSupported("Invalid or unsupported EC Key Curve or OKP Key Sub Type");
  }
};
var genericImport = async (replace, keyFormat, pem, alg, options) => {
  let algorithm;
  let keyUsages;
  const keyData = new Uint8Array(atob(pem.replace(replace, "")).split("").map((c) => c.charCodeAt(0)));
  const isPublic = keyFormat === "spki";
  switch (alg) {
    case "PS256":
    case "PS384":
    case "PS512":
      algorithm = { name: "RSA-PSS", hash: `SHA-${alg.slice(-3)}` };
      keyUsages = isPublic ? ["verify"] : ["sign"];
      break;
    case "RS256":
    case "RS384":
    case "RS512":
      algorithm = { name: "RSASSA-PKCS1-v1_5", hash: `SHA-${alg.slice(-3)}` };
      keyUsages = isPublic ? ["verify"] : ["sign"];
      break;
    case "RSA-OAEP":
    case "RSA-OAEP-256":
    case "RSA-OAEP-384":
    case "RSA-OAEP-512":
      algorithm = {
        name: "RSA-OAEP",
        hash: `SHA-${parseInt(alg.slice(-3), 10) || 1}`
      };
      keyUsages = isPublic ? ["encrypt", "wrapKey"] : ["decrypt", "unwrapKey"];
      break;
    case "ES256":
      algorithm = { name: "ECDSA", namedCurve: "P-256" };
      keyUsages = isPublic ? ["verify"] : ["sign"];
      break;
    case "ES384":
      algorithm = { name: "ECDSA", namedCurve: "P-384" };
      keyUsages = isPublic ? ["verify"] : ["sign"];
      break;
    case "ES512":
      algorithm = { name: "ECDSA", namedCurve: "P-521" };
      keyUsages = isPublic ? ["verify"] : ["sign"];
      break;
    case "ECDH-ES":
    case "ECDH-ES+A128KW":
    case "ECDH-ES+A192KW":
    case "ECDH-ES+A256KW": {
      const namedCurve = getNamedCurve2(keyData);
      algorithm = namedCurve.startsWith("P-") ? { name: "ECDH", namedCurve } : { name: namedCurve };
      keyUsages = isPublic ? [] : ["deriveBits"];
      break;
    }
    case "EdDSA":
      algorithm = { name: getNamedCurve2(keyData) };
      keyUsages = isPublic ? ["verify"] : ["sign"];
      break;
    default:
      throw new JOSENotSupported('Invalid or unsupported "alg" (Algorithm) value');
  }
  return webcrypto_default.subtle.importKey(keyFormat, keyData, algorithm, options?.extractable ?? false, keyUsages);
};
var fromPKCS8 = (pem, alg, options) => {
  return genericImport(/(?:-----(?:BEGIN|END) PRIVATE KEY-----|\s)/g, "pkcs8", pem, alg, options);
};

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/key/import.js
async function importPKCS8(pkcs8, alg, options) {
  if (typeof pkcs8 !== "string" || pkcs8.indexOf("-----BEGIN PRIVATE KEY-----") !== 0) {
    throw new TypeError('"pkcs8" must be PKCS#8 formatted string');
  }
  return fromPKCS8(pkcs8, alg, options);
}

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/lib/check_key_type.js
var tag = (key) => key?.[Symbol.toStringTag];
var jwkMatchesOp = (alg, key, usage) => {
  if (key.use !== void 0 && key.use !== "sig") {
    throw new TypeError("Invalid key for this operation, when present its use must be sig");
  }
  if (key.key_ops !== void 0 && key.key_ops.includes?.(usage) !== true) {
    throw new TypeError(`Invalid key for this operation, when present its key_ops must include ${usage}`);
  }
  if (key.alg !== void 0 && key.alg !== alg) {
    throw new TypeError(`Invalid key for this operation, when present its alg must be ${alg}`);
  }
  return true;
};
var symmetricTypeCheck = (alg, key, usage, allowJwk) => {
  if (key instanceof Uint8Array)
    return;
  if (allowJwk && isJWK(key)) {
    if (isSecretJWK(key) && jwkMatchesOp(alg, key, usage))
      return;
    throw new TypeError(`JSON Web Key for symmetric algorithms must have JWK "kty" (Key Type) equal to "oct" and the JWK "k" (Key Value) present`);
  }
  if (!is_key_like_default(key)) {
    throw new TypeError(withAlg(alg, key, ...types, "Uint8Array", allowJwk ? "JSON Web Key" : null));
  }
  if (key.type !== "secret") {
    throw new TypeError(`${tag(key)} instances for symmetric algorithms must be of type "secret"`);
  }
};
var asymmetricTypeCheck = (alg, key, usage, allowJwk) => {
  if (allowJwk && isJWK(key)) {
    switch (usage) {
      case "sign":
        if (isPrivateJWK(key) && jwkMatchesOp(alg, key, usage))
          return;
        throw new TypeError(`JSON Web Key for this operation be a private JWK`);
      case "verify":
        if (isPublicJWK(key) && jwkMatchesOp(alg, key, usage))
          return;
        throw new TypeError(`JSON Web Key for this operation be a public JWK`);
    }
  }
  if (!is_key_like_default(key)) {
    throw new TypeError(withAlg(alg, key, ...types, allowJwk ? "JSON Web Key" : null));
  }
  if (key.type === "secret") {
    throw new TypeError(`${tag(key)} instances for asymmetric algorithms must not be of type "secret"`);
  }
  if (usage === "sign" && key.type === "public") {
    throw new TypeError(`${tag(key)} instances for asymmetric algorithm signing must be of type "private"`);
  }
  if (usage === "decrypt" && key.type === "public") {
    throw new TypeError(`${tag(key)} instances for asymmetric algorithm decryption must be of type "private"`);
  }
  if (key.algorithm && usage === "verify" && key.type === "private") {
    throw new TypeError(`${tag(key)} instances for asymmetric algorithm verifying must be of type "public"`);
  }
  if (key.algorithm && usage === "encrypt" && key.type === "private") {
    throw new TypeError(`${tag(key)} instances for asymmetric algorithm encryption must be of type "public"`);
  }
};
function checkKeyType(allowJwk, alg, key, usage) {
  const symmetric = alg.startsWith("HS") || alg === "dir" || alg.startsWith("PBES2") || /^A\d{3}(?:GCM)?KW$/.test(alg);
  if (symmetric) {
    symmetricTypeCheck(alg, key, usage, allowJwk);
  } else {
    asymmetricTypeCheck(alg, key, usage, allowJwk);
  }
}
var check_key_type_default = checkKeyType.bind(void 0, false);
var checkKeyTypeWithJwk = checkKeyType.bind(void 0, true);

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/lib/validate_crit.js
function validateCrit(Err, recognizedDefault, recognizedOption, protectedHeader, joseHeader) {
  if (joseHeader.crit !== void 0 && protectedHeader?.crit === void 0) {
    throw new Err('"crit" (Critical) Header Parameter MUST be integrity protected');
  }
  if (!protectedHeader || protectedHeader.crit === void 0) {
    return /* @__PURE__ */ new Set();
  }
  if (!Array.isArray(protectedHeader.crit) || protectedHeader.crit.length === 0 || protectedHeader.crit.some((input) => typeof input !== "string" || input.length === 0)) {
    throw new Err('"crit" (Critical) Header Parameter MUST be an array of non-empty strings when present');
  }
  let recognized;
  if (recognizedOption !== void 0) {
    recognized = new Map([...Object.entries(recognizedOption), ...recognizedDefault.entries()]);
  } else {
    recognized = recognizedDefault;
  }
  for (const parameter of protectedHeader.crit) {
    if (!recognized.has(parameter)) {
      throw new JOSENotSupported(`Extension Header Parameter "${parameter}" is not recognized`);
    }
    if (joseHeader[parameter] === void 0) {
      throw new Err(`Extension Header Parameter "${parameter}" is missing`);
    }
    if (recognized.get(parameter) && protectedHeader[parameter] === void 0) {
      throw new Err(`Extension Header Parameter "${parameter}" MUST be integrity protected`);
    }
  }
  return new Set(protectedHeader.crit);
}
var validate_crit_default = validateCrit;

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/runtime/subtle_dsa.js
function subtleDsa(alg, algorithm) {
  const hash = `SHA-${alg.slice(-3)}`;
  switch (alg) {
    case "HS256":
    case "HS384":
    case "HS512":
      return { hash, name: "HMAC" };
    case "PS256":
    case "PS384":
    case "PS512":
      return { hash, name: "RSA-PSS", saltLength: alg.slice(-3) >> 3 };
    case "RS256":
    case "RS384":
    case "RS512":
      return { hash, name: "RSASSA-PKCS1-v1_5" };
    case "ES256":
    case "ES384":
    case "ES512":
      return { hash, name: "ECDSA", namedCurve: algorithm.namedCurve };
    case "EdDSA":
      return { name: algorithm.name };
    default:
      throw new JOSENotSupported(`alg ${alg} is not supported either by JOSE or your javascript runtime`);
  }
}

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/runtime/get_sign_verify_key.js
async function getCryptoKey(alg, key, usage) {
  if (usage === "sign") {
    key = await normalize_key_default.normalizePrivateKey(key, alg);
  }
  if (usage === "verify") {
    key = await normalize_key_default.normalizePublicKey(key, alg);
  }
  if (isCryptoKey(key)) {
    checkSigCryptoKey(key, alg, usage);
    return key;
  }
  if (key instanceof Uint8Array) {
    if (!alg.startsWith("HS")) {
      throw new TypeError(invalid_key_input_default(key, ...types));
    }
    return webcrypto_default.subtle.importKey("raw", key, { hash: `SHA-${alg.slice(-3)}`, name: "HMAC" }, false, [usage]);
  }
  throw new TypeError(invalid_key_input_default(key, ...types, "Uint8Array", "JSON Web Key"));
}

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/lib/epoch.js
var epoch_default = (date) => Math.floor(date.getTime() / 1e3);

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/lib/secs.js
var minute = 60;
var hour = minute * 60;
var day = hour * 24;
var week = day * 7;
var year = day * 365.25;
var REGEX = /^(\+|\-)? ?(\d+|\d+\.\d+) ?(seconds?|secs?|s|minutes?|mins?|m|hours?|hrs?|h|days?|d|weeks?|w|years?|yrs?|y)(?: (ago|from now))?$/i;
var secs_default = (str) => {
  const matched = REGEX.exec(str);
  if (!matched || matched[4] && matched[1]) {
    throw new TypeError("Invalid time period format");
  }
  const value = parseFloat(matched[2]);
  const unit = matched[3].toLowerCase();
  let numericDate;
  switch (unit) {
    case "sec":
    case "secs":
    case "second":
    case "seconds":
    case "s":
      numericDate = Math.round(value);
      break;
    case "minute":
    case "minutes":
    case "min":
    case "mins":
    case "m":
      numericDate = Math.round(value * minute);
      break;
    case "hour":
    case "hours":
    case "hr":
    case "hrs":
    case "h":
      numericDate = Math.round(value * hour);
      break;
    case "day":
    case "days":
    case "d":
      numericDate = Math.round(value * day);
      break;
    case "week":
    case "weeks":
    case "w":
      numericDate = Math.round(value * week);
      break;
    default:
      numericDate = Math.round(value * year);
      break;
  }
  if (matched[1] === "-" || matched[4] === "ago") {
    return -numericDate;
  }
  return numericDate;
};

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/runtime/sign.js
var sign = async (alg, key, data) => {
  const cryptoKey = await getCryptoKey(alg, key, "sign");
  check_key_length_default(alg, cryptoKey);
  const signature = await webcrypto_default.subtle.sign(subtleDsa(alg, cryptoKey.algorithm), cryptoKey, data);
  return new Uint8Array(signature);
};
var sign_default = sign;

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/jws/flattened/sign.js
var FlattenedSign = class {
  constructor(payload) {
    if (!(payload instanceof Uint8Array)) {
      throw new TypeError("payload must be an instance of Uint8Array");
    }
    this._payload = payload;
  }
  setProtectedHeader(protectedHeader) {
    if (this._protectedHeader) {
      throw new TypeError("setProtectedHeader can only be called once");
    }
    this._protectedHeader = protectedHeader;
    return this;
  }
  setUnprotectedHeader(unprotectedHeader) {
    if (this._unprotectedHeader) {
      throw new TypeError("setUnprotectedHeader can only be called once");
    }
    this._unprotectedHeader = unprotectedHeader;
    return this;
  }
  async sign(key, options) {
    if (!this._protectedHeader && !this._unprotectedHeader) {
      throw new JWSInvalid("either setProtectedHeader or setUnprotectedHeader must be called before #sign()");
    }
    if (!is_disjoint_default(this._protectedHeader, this._unprotectedHeader)) {
      throw new JWSInvalid("JWS Protected and JWS Unprotected Header Parameter names must be disjoint");
    }
    const joseHeader = {
      ...this._protectedHeader,
      ...this._unprotectedHeader
    };
    const extensions = validate_crit_default(JWSInvalid, /* @__PURE__ */ new Map([["b64", true]]), options?.crit, this._protectedHeader, joseHeader);
    let b64 = true;
    if (extensions.has("b64")) {
      b64 = this._protectedHeader.b64;
      if (typeof b64 !== "boolean") {
        throw new JWSInvalid('The "b64" (base64url-encode payload) Header Parameter must be a boolean');
      }
    }
    const { alg } = joseHeader;
    if (typeof alg !== "string" || !alg) {
      throw new JWSInvalid('JWS "alg" (Algorithm) Header Parameter missing or invalid');
    }
    checkKeyTypeWithJwk(alg, key, "sign");
    let payload = this._payload;
    if (b64) {
      payload = encoder.encode(encode(payload));
    }
    let protectedHeader;
    if (this._protectedHeader) {
      protectedHeader = encoder.encode(encode(JSON.stringify(this._protectedHeader)));
    } else {
      protectedHeader = encoder.encode("");
    }
    const data = concat(protectedHeader, encoder.encode("."), payload);
    const signature = await sign_default(alg, key, data);
    const jws = {
      signature: encode(signature),
      payload: ""
    };
    if (b64) {
      jws.payload = decoder.decode(payload);
    }
    if (this._unprotectedHeader) {
      jws.header = this._unprotectedHeader;
    }
    if (this._protectedHeader) {
      jws.protected = decoder.decode(protectedHeader);
    }
    return jws;
  }
};

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/jws/compact/sign.js
var CompactSign = class {
  constructor(payload) {
    this._flattened = new FlattenedSign(payload);
  }
  setProtectedHeader(protectedHeader) {
    this._flattened.setProtectedHeader(protectedHeader);
    return this;
  }
  async sign(key, options) {
    const jws = await this._flattened.sign(key, options);
    if (jws.payload === void 0) {
      throw new TypeError("use the flattened module for creating JWS with b64: false");
    }
    return `${jws.protected}.${jws.payload}.${jws.signature}`;
  }
};

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/jwt/produce.js
function validateInput(label, input) {
  if (!Number.isFinite(input)) {
    throw new TypeError(`Invalid ${label} input`);
  }
  return input;
}
var ProduceJWT = class {
  constructor(payload = {}) {
    if (!isObject(payload)) {
      throw new TypeError("JWT Claims Set MUST be an object");
    }
    this._payload = payload;
  }
  setIssuer(issuer) {
    this._payload = { ...this._payload, iss: issuer };
    return this;
  }
  setSubject(subject) {
    this._payload = { ...this._payload, sub: subject };
    return this;
  }
  setAudience(audience) {
    this._payload = { ...this._payload, aud: audience };
    return this;
  }
  setJti(jwtId) {
    this._payload = { ...this._payload, jti: jwtId };
    return this;
  }
  setNotBefore(input) {
    if (typeof input === "number") {
      this._payload = { ...this._payload, nbf: validateInput("setNotBefore", input) };
    } else if (input instanceof Date) {
      this._payload = { ...this._payload, nbf: validateInput("setNotBefore", epoch_default(input)) };
    } else {
      this._payload = { ...this._payload, nbf: epoch_default(/* @__PURE__ */ new Date()) + secs_default(input) };
    }
    return this;
  }
  setExpirationTime(input) {
    if (typeof input === "number") {
      this._payload = { ...this._payload, exp: validateInput("setExpirationTime", input) };
    } else if (input instanceof Date) {
      this._payload = { ...this._payload, exp: validateInput("setExpirationTime", epoch_default(input)) };
    } else {
      this._payload = { ...this._payload, exp: epoch_default(/* @__PURE__ */ new Date()) + secs_default(input) };
    }
    return this;
  }
  setIssuedAt(input) {
    if (typeof input === "undefined") {
      this._payload = { ...this._payload, iat: epoch_default(/* @__PURE__ */ new Date()) };
    } else if (input instanceof Date) {
      this._payload = { ...this._payload, iat: validateInput("setIssuedAt", epoch_default(input)) };
    } else if (typeof input === "string") {
      this._payload = {
        ...this._payload,
        iat: validateInput("setIssuedAt", epoch_default(/* @__PURE__ */ new Date()) + secs_default(input))
      };
    } else {
      this._payload = { ...this._payload, iat: validateInput("setIssuedAt", input) };
    }
    return this;
  }
};

// ../../node_modules/.pnpm/jose@5.9.3/node_modules/jose/dist/browser/jwt/sign.js
var SignJWT = class extends ProduceJWT {
  setProtectedHeader(protectedHeader) {
    this._protectedHeader = protectedHeader;
    return this;
  }
  async sign(key, options) {
    const sig = new CompactSign(encoder.encode(JSON.stringify(this._payload)));
    sig.setProtectedHeader(this._protectedHeader);
    if (Array.isArray(this._protectedHeader?.crit) && this._protectedHeader.crit.includes("b64") && this._protectedHeader.b64 === false) {
      throw new JWTInvalid("JWTs MUST NOT use unencoded payload");
    }
    return sig.sign(key, options);
  }
};

// src/authenticate.ts
var token = null;
async function createToken(options) {
  const rawPrivateKey = options.privateKey.replace(/\\n/g, "\n");
  const privateKey = await importPKCS8(rawPrivateKey, "RS256");
  const payload = {
    iss: options.clientEmail,
    scope: "https://www.googleapis.com/auth/cloud-platform",
    aud: "https://www.googleapis.com/oauth2/v4/token",
    exp: Math.floor(Date.now() / 1e3) + 60 * 60,
    iat: Math.floor(Date.now() / 1e3)
  };
  const token2 = await new SignJWT(payload).setProtectedHeader({ alg: "RS256" }).setIssuedAt().setIssuer(options.clientEmail).setAudience("https://www.googleapis.com/oauth2/v4/token").setExpirationTime("1h").sign(privateKey);
  const form = {
    grant_type: "urn:ietf:params:oauth:grant-type:jwt-bearer",
    assertion: token2
  };
  const tokenResponse = await fetch(
    "https://www.googleapis.com/oauth2/v4/token",
    {
      method: "POST",
      body: JSON.stringify(form),
      headers: { "Content-Type": "application/json" }
    }
  );
  const json = await tokenResponse.json();
  return {
    ...json,
    expires_at: Math.floor(Date.now() / 1e3) + json.expires_in
  };
}
async function authenticate(options) {
  if (!options.clientEmail || !options.privateKey) {
    throw new Error("clientEmail and privateKey are required");
  }
  if (token === null) {
    token = await createToken(options);
  } else if (token.expires_at < Math.floor(Date.now() / 1e3)) {
    token = await createToken(options);
  }
  return token;
}

// src/web.ts
var DEFAULT_VERSION = "vertex-2023-10-16";
var AnthropicVertexWeb = class extends APIClient {
  region;
  projectId;
  accessToken;
  _options;
  constructor({
    baseURL = readEnv("ANTHROPIC_VERTEX_BASE_URL"),
    region = readEnv("CLOUD_ML_REGION") ?? null,
    projectId = readEnv("ANTHROPIC_VERTEX_PROJECT_ID") ?? null,
    accessToken = readEnv("ANTHROPIC_VERTEX_ACCESS_TOKEN") ?? null,
    clientEmail = readEnv("ANTHROPIC_VERTEX_CLIENT_EMAIL") ?? null,
    privateKey = readEnv("ANTHROPIC_VERTEX_PRIVATE_KEY") ?? null,
    ...opts
  } = {}) {
    if (!region) {
      throw new Error(
        "No region was given. The client should be instantiated with the `region` option or the `CLOUD_ML_REGION` environment variable should be set."
      );
    }
    const options = {
      ...opts,
      baseURL: baseURL || `https://${region}-aiplatform.googleapis.com/v1`,
      clientEmail,
      privateKey
    };
    super({
      baseURL: options.baseURL,
      timeout: options.timeout ?? 6e5,
      httpAgent: options.httpAgent,
      maxRetries: options.maxRetries,
      fetch: options.fetch
    });
    this._options = options;
    this.region = region;
    this.projectId = projectId;
    this.accessToken = accessToken;
  }
  messages = new Messages(this);
  defaultQuery() {
    return this._options.defaultQuery;
  }
  defaultHeaders(opts) {
    return {
      ...super.defaultHeaders(opts),
      ...this._options.defaultHeaders
    };
  }
  async prepareOptions(options) {
    if (!this.accessToken) {
      if (!this._options.clientEmail || !this._options.privateKey) {
        throw new Error(
          "No clientEmail or privateKey was provided. Set it in the constructor or use the ANTHROPIC_VERTEX_CLIENT_EMAIL and ANTHROPIC_VERTEX_PRIVATE_KEY environment variables."
        );
      }
      this.accessToken = (await authenticate({
        clientEmail: this._options.clientEmail,
        privateKey: this._options.privateKey
      })).access_token;
    }
    options.headers = {
      ...options.headers,
      Authorization: `Bearer ${this.accessToken}`,
      "x-goog-user-project": this.projectId
    };
  }
  buildRequest(options) {
    if (isObj(options.body)) {
      if (!options.body["anthropic_version"]) {
        options.body["anthropic_version"] = DEFAULT_VERSION;
      }
    }
    if (options.path === "/v1/messages" && options.method === "post") {
      if (!this.projectId) {
        throw new Error(
          "No projectId was given and it could not be resolved from credentials. The client should be instantiated with the `projectId` option or the `ANTHROPIC_VERTEX_PROJECT_ID` environment variable should be set."
        );
      }
      if (!isObj(options.body)) {
        throw new Error(
          "Expected request body to be an object for post /v1/messages"
        );
      }
      const model2 = options.body["model"];
      options.body["model"] = void 0;
      const stream = options.body["stream"] ?? false;
      const specifier = stream ? "streamRawPredict" : "rawPredict";
      options.path = `/projects/${this.projectId}/locations/${this.region}/publishers/anthropic/models/${model2}:${specifier}`;
    }
    return super.buildRequest(options);
  }
};

// src/index.ts
async function convertMessages(messages) {
  return Promise.all(
    messages.map(async (it) => {
      if (!it.content) {
        throw new Error("content is required");
      }
      if (!it.attachments) {
        return {
          role: it.role,
          content: it.content
        };
      }
      return {
        role: it.role,
        content: [
          {
            type: "text",
            text: it.content
          },
          ...await Promise.all(
            it.attachments.map(async (it2) => {
              return {
                type: "image",
                source: {
                  type: "base64",
                  ...await getImageAsBase64(it2.url)
                }
              };
            })
          )
        ]
      };
    })
  );
}
function getModelMaxTokens(model2) {
  if (model2.startsWith("claude-3-5")) {
    return 4096;
  }
  return 8192;
}
async function parseReq(req, stream) {
  return {
    messages: await convertMessages(
      req.messages.filter(
        (it) => [
          "user",
          "assistant"
        ].includes(it.role)
      )
    ),
    max_tokens: getModelMaxTokens(req.model),
    stream,
    model: req.model,
    system: req.messages.find((it) => it.role === "system")?.content
  };
}
function parseResponse(resp) {
  if (resp.content.length !== 1) {
    console.error("Unsupported response", resp.content);
    throw new Error("Unsupported response");
  }
  return {
    content: resp.content[0].text
  };
}
async function activate(context) {
  const createClient = async () => {
    const [clientEmail, privateKey, region, projectId] = await Promise.all([
      novachat.setting.get("vertexAnthropic.googleSaClientEmail"),
      novachat.setting.get("vertexAnthropic.googleSaPrivateKey"),
      novachat.setting.get("vertexAnthropic.region"),
      novachat.setting.get("vertexAnthropic.projectId")
    ]);
    return new AnthropicVertexWeb({
      clientEmail,
      privateKey,
      region,
      projectId
    });
  };
  await novachat.model.registerProvider({
    name: "VertexAnthropic",
    models: [
      { id: "claude-3-5-sonnet-v2@20241022", name: "Claude 3.5 Sonnet v2" },
      { id: "claude-3-5-sonnet@20240620", name: "Claude 3.5 Sonnet" },
      { id: "claude-3-haiku@20240307", name: "Claude 3 Haiku" },
      { id: "claude-3-opus@20240229", name: "Claude 3 Opus" },
      { id: "claude-3-sonnet@20240229", name: "Claude 3 Sonnet" }
    ],
    async invoke(query) {
      const client = await createClient();
      return parseResponse(
        await client.messages.create(
          await parseReq(
            query,
            false
          )
        )
      );
    },
    async *stream(query) {
      const client = await createClient();
      const stream = await client.messages.create(
        await parseReq(
          query,
          true
        )
      );
      for await (const it of stream) {
        if (it.type === "content_block_delta") {
          if (it.delta.type !== "text_delta") {
            throw new Error("Unsupported delta type");
          }
          yield {
            content: it.delta.text
          };
        }
      }
    }
  });
}
export {
  activate
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2luZGV4LnRzIiwgIi4uL3NyYy91dGlscy9iYXNlNjQudHMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BhbnRocm9waWMtYWkrc2RrQDAuMjguMC9ub2RlX21vZHVsZXMvQGFudGhyb3BpYy1haS9zZGsvc3JjL3ZlcnNpb24udHMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BhbnRocm9waWMtYWkrc2RrQDAuMjguMC9ub2RlX21vZHVsZXMvQGFudGhyb3BpYy1haS9zZGsvc3JjL19zaGltcy9yZWdpc3RyeS50cyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGFudGhyb3BpYy1haStzZGtAMC4yOC4wL25vZGVfbW9kdWxlcy9AYW50aHJvcGljLWFpL3Nkay9zcmMvX3NoaW1zL011bHRpcGFydEJvZHkudHMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BhbnRocm9waWMtYWkrc2RrQDAuMjguMC9ub2RlX21vZHVsZXMvQGFudGhyb3BpYy1haS9zZGsvc3JjL19zaGltcy93ZWItcnVudGltZS50cyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGFudGhyb3BpYy1haStzZGtAMC4yOC4wL25vZGVfbW9kdWxlcy9AYW50aHJvcGljLWFpL3Nkay9fc2hpbXMvaW5kZXgubWpzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AYW50aHJvcGljLWFpK3Nka0AwLjI4LjAvbm9kZV9tb2R1bGVzL0BhbnRocm9waWMtYWkvc2RrL3NyYy9lcnJvci50cyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGFudGhyb3BpYy1haStzZGtAMC4yOC4wL25vZGVfbW9kdWxlcy9AYW50aHJvcGljLWFpL3Nkay9zcmMvc3RyZWFtaW5nLnRzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AYW50aHJvcGljLWFpK3Nka0AwLjI4LjAvbm9kZV9tb2R1bGVzL0BhbnRocm9waWMtYWkvc2RrL3NyYy91cGxvYWRzLnRzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AYW50aHJvcGljLWFpK3Nka0AwLjI4LjAvbm9kZV9tb2R1bGVzL0BhbnRocm9waWMtYWkvc2RrL3NyYy9jb3JlLnRzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AYW50aHJvcGljLWFpK3Nka0AwLjI4LjAvbm9kZV9tb2R1bGVzL0BhbnRocm9waWMtYWkvc2RrL3NyYy9yZXNvdXJjZS50cyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGFudGhyb3BpYy1haStzZGtAMC4yOC4wL25vZGVfbW9kdWxlcy9AYW50aHJvcGljLWFpL3Nkay9zcmMvX3ZlbmRvci9wYXJ0aWFsLWpzb24tcGFyc2VyL3BhcnNlci50cyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGFudGhyb3BpYy1haStzZGtAMC4yOC4wL25vZGVfbW9kdWxlcy9AYW50aHJvcGljLWFpL3Nkay9zcmMvbGliL01lc3NhZ2VTdHJlYW0udHMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BhbnRocm9waWMtYWkrc2RrQDAuMjguMC9ub2RlX21vZHVsZXMvQGFudGhyb3BpYy1haS9zZGsvc3JjL3Jlc291cmNlcy9tZXNzYWdlcy50cyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vam9zZUA1LjkuMy9ub2RlX21vZHVsZXMvam9zZS9kaXN0L2Jyb3dzZXIvcnVudGltZS93ZWJjcnlwdG8uanMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2pvc2VANS45LjMvbm9kZV9tb2R1bGVzL2pvc2UvZGlzdC9icm93c2VyL2xpYi9idWZmZXJfdXRpbHMuanMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2pvc2VANS45LjMvbm9kZV9tb2R1bGVzL2pvc2UvZGlzdC9icm93c2VyL3J1bnRpbWUvYmFzZTY0dXJsLmpzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9qb3NlQDUuOS4zL25vZGVfbW9kdWxlcy9qb3NlL2Rpc3QvYnJvd3Nlci91dGlsL2Vycm9ycy5qcyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vam9zZUA1LjkuMy9ub2RlX21vZHVsZXMvam9zZS9kaXN0L2Jyb3dzZXIvbGliL2NyeXB0b19rZXkuanMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2pvc2VANS45LjMvbm9kZV9tb2R1bGVzL2pvc2UvZGlzdC9icm93c2VyL2xpYi9pbnZhbGlkX2tleV9pbnB1dC5qcyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vam9zZUA1LjkuMy9ub2RlX21vZHVsZXMvam9zZS9kaXN0L2Jyb3dzZXIvcnVudGltZS9pc19rZXlfbGlrZS5qcyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vam9zZUA1LjkuMy9ub2RlX21vZHVsZXMvam9zZS9kaXN0L2Jyb3dzZXIvbGliL2lzX2Rpc2pvaW50LmpzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9qb3NlQDUuOS4zL25vZGVfbW9kdWxlcy9qb3NlL2Rpc3QvYnJvd3Nlci9saWIvaXNfb2JqZWN0LmpzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9qb3NlQDUuOS4zL25vZGVfbW9kdWxlcy9qb3NlL2Rpc3QvYnJvd3Nlci9ydW50aW1lL2NoZWNrX2tleV9sZW5ndGguanMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2pvc2VANS45LjMvbm9kZV9tb2R1bGVzL2pvc2UvZGlzdC9icm93c2VyL2xpYi9pc19qd2suanMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2pvc2VANS45LjMvbm9kZV9tb2R1bGVzL2pvc2UvZGlzdC9icm93c2VyL3J1bnRpbWUvandrX3RvX2tleS5qcyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vam9zZUA1LjkuMy9ub2RlX21vZHVsZXMvam9zZS9kaXN0L2Jyb3dzZXIvcnVudGltZS9ub3JtYWxpemVfa2V5LmpzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9qb3NlQDUuOS4zL25vZGVfbW9kdWxlcy9qb3NlL2Rpc3QvYnJvd3Nlci9ydW50aW1lL2FzbjEuanMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2pvc2VANS45LjMvbm9kZV9tb2R1bGVzL2pvc2UvZGlzdC9icm93c2VyL2tleS9pbXBvcnQuanMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2pvc2VANS45LjMvbm9kZV9tb2R1bGVzL2pvc2UvZGlzdC9icm93c2VyL2xpYi9jaGVja19rZXlfdHlwZS5qcyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vam9zZUA1LjkuMy9ub2RlX21vZHVsZXMvam9zZS9kaXN0L2Jyb3dzZXIvbGliL3ZhbGlkYXRlX2NyaXQuanMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2pvc2VANS45LjMvbm9kZV9tb2R1bGVzL2pvc2UvZGlzdC9icm93c2VyL3J1bnRpbWUvc3VidGxlX2RzYS5qcyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vam9zZUA1LjkuMy9ub2RlX21vZHVsZXMvam9zZS9kaXN0L2Jyb3dzZXIvcnVudGltZS9nZXRfc2lnbl92ZXJpZnlfa2V5LmpzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9qb3NlQDUuOS4zL25vZGVfbW9kdWxlcy9qb3NlL2Rpc3QvYnJvd3Nlci9saWIvZXBvY2guanMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2pvc2VANS45LjMvbm9kZV9tb2R1bGVzL2pvc2UvZGlzdC9icm93c2VyL2xpYi9zZWNzLmpzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9qb3NlQDUuOS4zL25vZGVfbW9kdWxlcy9qb3NlL2Rpc3QvYnJvd3Nlci9ydW50aW1lL3NpZ24uanMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2pvc2VANS45LjMvbm9kZV9tb2R1bGVzL2pvc2UvZGlzdC9icm93c2VyL2p3cy9mbGF0dGVuZWQvc2lnbi5qcyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vam9zZUA1LjkuMy9ub2RlX21vZHVsZXMvam9zZS9kaXN0L2Jyb3dzZXIvandzL2NvbXBhY3Qvc2lnbi5qcyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vam9zZUA1LjkuMy9ub2RlX21vZHVsZXMvam9zZS9kaXN0L2Jyb3dzZXIvand0L3Byb2R1Y2UuanMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2pvc2VANS45LjMvbm9kZV9tb2R1bGVzL2pvc2UvZGlzdC9icm93c2VyL2p3dC9zaWduLmpzIiwgIi4uL3NyYy9hdXRoZW50aWNhdGUudHMiLCAiLi4vc3JjL3dlYi50cyJdLAogICJzb3VyY2VzQ29udGVudCI6IFsiaW1wb3J0ICogYXMgbm92YWNoYXQgZnJvbSAnQG5vdmFjaGF0L3BsdWdpbidcbmltcG9ydCB0eXBlIEFudGhyb3BpY1R5cGVzIGZyb20gJ0BhbnRocm9waWMtYWkvc2RrJ1xuaW1wb3J0IHsgZ2V0SW1hZ2VBc0Jhc2U2NCB9IGZyb20gJy4vdXRpbHMvYmFzZTY0J1xuaW1wb3J0IHsgQW50aHJvcGljVmVydGV4V2ViIH0gZnJvbSAnLi93ZWInXG5cbmFzeW5jIGZ1bmN0aW9uIGNvbnZlcnRNZXNzYWdlcyhcbiAgbWVzc2FnZXM6IG5vdmFjaGF0LlF1ZXJ5UmVxdWVzdFsnbWVzc2FnZXMnXSxcbik6IFByb21pc2U8QW50aHJvcGljVHlwZXMuTWVzc2FnZUNyZWF0ZVBhcmFtc05vblN0cmVhbWluZ1snbWVzc2FnZXMnXT4ge1xuICByZXR1cm4gUHJvbWlzZS5hbGwoXG4gICAgbWVzc2FnZXMubWFwKGFzeW5jIChpdCkgPT4ge1xuICAgICAgaWYgKCFpdC5jb250ZW50KSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignY29udGVudCBpcyByZXF1aXJlZCcpXG4gICAgICB9XG4gICAgICBpZiAoIWl0LmF0dGFjaG1lbnRzKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgcm9sZTogaXQucm9sZSxcbiAgICAgICAgICBjb250ZW50OiBpdC5jb250ZW50LFxuICAgICAgICB9IGFzIEFudGhyb3BpY1R5cGVzLk1lc3NhZ2VQYXJhbVxuICAgICAgfVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgcm9sZTogaXQucm9sZSxcbiAgICAgICAgY29udGVudDogW1xuICAgICAgICAgIHtcbiAgICAgICAgICAgIHR5cGU6ICd0ZXh0JyxcbiAgICAgICAgICAgIHRleHQ6IGl0LmNvbnRlbnQsXG4gICAgICAgICAgfSxcbiAgICAgICAgICAuLi4oYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgICAgICAgICBpdC5hdHRhY2htZW50cy5tYXAoYXN5bmMgKGl0KSA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgdHlwZTogJ2ltYWdlJyxcbiAgICAgICAgICAgICAgICBzb3VyY2U6IHtcbiAgICAgICAgICAgICAgICAgIHR5cGU6ICdiYXNlNjQnLFxuICAgICAgICAgICAgICAgICAgLi4uKGF3YWl0IGdldEltYWdlQXNCYXNlNjQoaXQudXJsKSksXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSBhcyBBbnRocm9waWNUeXBlcy5JbWFnZUJsb2NrUGFyYW1cbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgICkpLFxuICAgICAgICBdLFxuICAgICAgfSBhcyBBbnRocm9waWNUeXBlcy5NZXNzYWdlUGFyYW1cbiAgICB9KSxcbiAgKVxufVxuXG5mdW5jdGlvbiBnZXRNb2RlbE1heFRva2Vucyhtb2RlbDogc3RyaW5nKTogbnVtYmVyIHtcbiAgaWYgKG1vZGVsLnN0YXJ0c1dpdGgoJ2NsYXVkZS0zLTUnKSkge1xuICAgIHJldHVybiA0MDk2XG4gIH1cbiAgcmV0dXJuIDgxOTJcbn1cblxuYXN5bmMgZnVuY3Rpb24gcGFyc2VSZXEoXG4gIHJlcTogbm92YWNoYXQuUXVlcnlSZXF1ZXN0LFxuICBzdHJlYW06IGJvb2xlYW4sXG4pOiBQcm9taXNlPEFudGhyb3BpY1R5cGVzLk1lc3NhZ2VDcmVhdGVQYXJhbXM+IHtcbiAgcmV0dXJuIHtcbiAgICBtZXNzYWdlczogYXdhaXQgY29udmVydE1lc3NhZ2VzKFxuICAgICAgcmVxLm1lc3NhZ2VzLmZpbHRlcigoaXQpID0+XG4gICAgICAgIChcbiAgICAgICAgICBbXG4gICAgICAgICAgICAndXNlcicsXG4gICAgICAgICAgICAnYXNzaXN0YW50JyxcbiAgICAgICAgICBdIGFzIG5vdmFjaGF0LlF1ZXJ5UmVxdWVzdFsnbWVzc2FnZXMnXVtudW1iZXJdWydyb2xlJ11bXVxuICAgICAgICApLmluY2x1ZGVzKGl0LnJvbGUpLFxuICAgICAgKSxcbiAgICApLFxuICAgIG1heF90b2tlbnM6IGdldE1vZGVsTWF4VG9rZW5zKHJlcS5tb2RlbCksXG4gICAgc3RyZWFtLFxuICAgIG1vZGVsOiByZXEubW9kZWwsXG4gICAgc3lzdGVtOiByZXEubWVzc2FnZXMuZmluZCgoaXQpID0+IGl0LnJvbGUgPT09ICdzeXN0ZW0nKT8uY29udGVudCxcbiAgfSBhcyBBbnRocm9waWNUeXBlcy5NZXNzYWdlQ3JlYXRlUGFyYW1zTm9uU3RyZWFtaW5nXG59XG5cbmZ1bmN0aW9uIHBhcnNlUmVzcG9uc2UoXG4gIHJlc3A6IEFudGhyb3BpY1R5cGVzLk1lc3NhZ2VzLk1lc3NhZ2UsXG4pOiBub3ZhY2hhdC5RdWVyeVJlc3BvbnNlIHtcbiAgaWYgKHJlc3AuY29udGVudC5sZW5ndGggIT09IDEpIHtcbiAgICBjb25zb2xlLmVycm9yKCdVbnN1cHBvcnRlZCByZXNwb25zZScsIHJlc3AuY29udGVudClcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ1Vuc3VwcG9ydGVkIHJlc3BvbnNlJylcbiAgfVxuICByZXR1cm4ge1xuICAgIGNvbnRlbnQ6IChyZXNwLmNvbnRlbnRbMF0gYXMgQW50aHJvcGljVHlwZXMuVGV4dEJsb2NrKS50ZXh0LFxuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhY3RpdmF0ZShjb250ZXh0OiBub3ZhY2hhdC5QbHVnaW5Db250ZXh0KSB7XG4gIGNvbnN0IGNyZWF0ZUNsaWVudCA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBbY2xpZW50RW1haWwsIHByaXZhdGVLZXksIHJlZ2lvbiwgcHJvamVjdElkXSA9IGF3YWl0IFByb21pc2UuYWxsKFtcbiAgICAgIG5vdmFjaGF0LnNldHRpbmcuZ2V0KCd2ZXJ0ZXhBbnRocm9waWMuZ29vZ2xlU2FDbGllbnRFbWFpbCcpLFxuICAgICAgbm92YWNoYXQuc2V0dGluZy5nZXQoJ3ZlcnRleEFudGhyb3BpYy5nb29nbGVTYVByaXZhdGVLZXknKSxcbiAgICAgIG5vdmFjaGF0LnNldHRpbmcuZ2V0KCd2ZXJ0ZXhBbnRocm9waWMucmVnaW9uJyksXG4gICAgICBub3ZhY2hhdC5zZXR0aW5nLmdldCgndmVydGV4QW50aHJvcGljLnByb2plY3RJZCcpLFxuICAgIF0pXG4gICAgcmV0dXJuIG5ldyBBbnRocm9waWNWZXJ0ZXhXZWIoe1xuICAgICAgY2xpZW50RW1haWwsXG4gICAgICBwcml2YXRlS2V5LFxuICAgICAgcmVnaW9uLFxuICAgICAgcHJvamVjdElkLFxuICAgIH0pXG4gIH1cbiAgYXdhaXQgbm92YWNoYXQubW9kZWwucmVnaXN0ZXJQcm92aWRlcih7XG4gICAgbmFtZTogJ1ZlcnRleEFudGhyb3BpYycsXG4gICAgbW9kZWxzOiBbXG4gICAgICB7IGlkOiAnY2xhdWRlLTMtNS1zb25uZXQtdjJAMjAyNDEwMjInLCBuYW1lOiAnQ2xhdWRlIDMuNSBTb25uZXQgdjInIH0sXG4gICAgICB7IGlkOiAnY2xhdWRlLTMtNS1zb25uZXRAMjAyNDA2MjAnLCBuYW1lOiAnQ2xhdWRlIDMuNSBTb25uZXQnIH0sXG4gICAgICB7IGlkOiAnY2xhdWRlLTMtaGFpa3VAMjAyNDAzMDcnLCBuYW1lOiAnQ2xhdWRlIDMgSGFpa3UnIH0sXG4gICAgICB7IGlkOiAnY2xhdWRlLTMtb3B1c0AyMDI0MDIyOScsIG5hbWU6ICdDbGF1ZGUgMyBPcHVzJyB9LFxuICAgICAgeyBpZDogJ2NsYXVkZS0zLXNvbm5ldEAyMDI0MDIyOScsIG5hbWU6ICdDbGF1ZGUgMyBTb25uZXQnIH0sXG4gICAgXSxcbiAgICBhc3luYyBpbnZva2UocXVlcnkpIHtcbiAgICAgIGNvbnN0IGNsaWVudCA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpXG4gICAgICByZXR1cm4gcGFyc2VSZXNwb25zZShcbiAgICAgICAgYXdhaXQgY2xpZW50Lm1lc3NhZ2VzLmNyZWF0ZShcbiAgICAgICAgICAoYXdhaXQgcGFyc2VSZXEoXG4gICAgICAgICAgICBxdWVyeSxcbiAgICAgICAgICAgIGZhbHNlLFxuICAgICAgICAgICkpIGFzIEFudGhyb3BpY1R5cGVzLk1lc3NhZ2VDcmVhdGVQYXJhbXNOb25TdHJlYW1pbmcsXG4gICAgICAgICksXG4gICAgICApXG4gICAgfSxcbiAgICBhc3luYyAqc3RyZWFtKHF1ZXJ5KSB7XG4gICAgICBjb25zdCBjbGllbnQgPSBhd2FpdCBjcmVhdGVDbGllbnQoKVxuICAgICAgY29uc3Qgc3RyZWFtID0gYXdhaXQgY2xpZW50Lm1lc3NhZ2VzLmNyZWF0ZShcbiAgICAgICAgKGF3YWl0IHBhcnNlUmVxKFxuICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICAgIHRydWUsXG4gICAgICAgICkpIGFzIEFudGhyb3BpY1R5cGVzLk1lc3NhZ2VDcmVhdGVQYXJhbXNTdHJlYW1pbmcsXG4gICAgICApXG4gICAgICBmb3IgYXdhaXQgKGNvbnN0IGl0IG9mIHN0cmVhbSkge1xuICAgICAgICBpZiAoaXQudHlwZSA9PT0gJ2NvbnRlbnRfYmxvY2tfZGVsdGEnKSB7XG4gICAgICAgICAgaWYgKGl0LmRlbHRhLnR5cGUgIT09ICd0ZXh0X2RlbHRhJykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdVbnN1cHBvcnRlZCBkZWx0YSB0eXBlJylcbiAgICAgICAgICB9XG4gICAgICAgICAgeWllbGQge1xuICAgICAgICAgICAgY29udGVudDogaXQuZGVsdGEudGV4dCxcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9LFxuICB9KVxufVxuIiwgImZ1bmN0aW9uIGFycmF5QnVmZmVyVG9CYXNlNjQoYnVmZmVyOiBBcnJheUJ1ZmZlcik6IHN0cmluZyB7XG4gIGxldCBiaW5hcnkgPSAnJ1xuICBjb25zdCBieXRlcyA9IG5ldyBVaW50OEFycmF5KGJ1ZmZlcilcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBieXRlcy5ieXRlTGVuZ3RoOyBpKyspIHtcbiAgICBiaW5hcnkgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShieXRlc1tpXSlcbiAgfVxuICByZXR1cm4gYnRvYShiaW5hcnkpXG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRJbWFnZUFzQmFzZTY0KGltYWdlVXJsOiBzdHJpbmcpOiBQcm9taXNlPHtcbiAgbWVkaWFfdHlwZTogc3RyaW5nXG4gIGRhdGE6IHN0cmluZ1xufT4ge1xuICAvLyBcdTY4QzBcdTY3RTVcdTY2MkZcdTU0MjZcdTVERjJcdTdFQ0ZcdTY2MkYgZGF0YSBVUkxcbiAgaWYgKGltYWdlVXJsLnN0YXJ0c1dpdGgoJ2RhdGE6JykpIHtcbiAgICBjb25zdCBbaGVhZGVyLCBkYXRhXSA9IGltYWdlVXJsLnNwbGl0KCcsJylcbiAgICBjb25zdCBtZWRpYV90eXBlID0gaGVhZGVyLnNwbGl0KCc6JylbMV0uc3BsaXQoJzsnKVswXVxuICAgIHJldHVybiB7IG1lZGlhX3R5cGUsIGRhdGEgfVxuICB9XG4gIC8vIFx1NTk4Mlx1Njc5Q1x1NEUwRFx1NjYyRiBkYXRhIFVSTFx1RkYwQ1x1NTIxOVx1NjMwOVx1NTM5Rlx1NjVCOVx1NkNENVx1NTkwNFx1NzQwNlxuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGltYWdlVXJsKVxuICBjb25zdCBhcnJheUJ1ZmZlciA9IGF3YWl0IHJlc3BvbnNlLmFycmF5QnVmZmVyKClcbiAgLy8gXHU1QzA2IEFycmF5QnVmZmVyIFx1OEY2Q1x1NjM2Mlx1NEUzQSBiYXNlNjRcbiAgY29uc3QgYmFzZTY0ID0gYXJyYXlCdWZmZXJUb0Jhc2U2NChhcnJheUJ1ZmZlcilcbiAgcmV0dXJuIHtcbiAgICBtZWRpYV90eXBlOiByZXNwb25zZS5oZWFkZXJzLmdldCgnY29udGVudC10eXBlJykgfHwgJ2ltYWdlL2pwZWcnLFxuICAgIGRhdGE6IGJhc2U2NCxcbiAgfVxufVxuIiwgImV4cG9ydCBjb25zdCBWRVJTSU9OID0gJzAuMjguMCc7IC8vIHgtcmVsZWFzZS1wbGVhc2UtdmVyc2lvblxuIiwgIi8qKlxuICogRGlzY2xhaW1lcjogbW9kdWxlcyBpbiBfc2hpbXMgYXJlbid0IGludGVuZGVkIHRvIGJlIGltcG9ydGVkIGJ5IFNESyB1c2Vycy5cbiAqL1xuaW1wb3J0IHsgdHlwZSBSZXF1ZXN0T3B0aW9ucyB9IGZyb20gXCIuLi9jb3JlLmpzXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgU2hpbXMge1xuICBraW5kOiBzdHJpbmc7XG4gIGZldGNoOiBhbnk7XG4gIFJlcXVlc3Q6IGFueTtcbiAgUmVzcG9uc2U6IGFueTtcbiAgSGVhZGVyczogYW55O1xuICBGb3JtRGF0YTogYW55O1xuICBCbG9iOiBhbnk7XG4gIEZpbGU6IGFueTtcbiAgUmVhZGFibGVTdHJlYW06IGFueTtcbiAgZ2V0TXVsdGlwYXJ0UmVxdWVzdE9wdGlvbnM6IDxUID0gUmVjb3JkPHN0cmluZywgdW5rbm93bj4+KFxuICAgIGZvcm06IFNoaW1zWydGb3JtRGF0YSddLFxuICAgIG9wdHM6IFJlcXVlc3RPcHRpb25zPFQ+LFxuICApID0+IFByb21pc2U8UmVxdWVzdE9wdGlvbnM8VD4+O1xuICBnZXREZWZhdWx0QWdlbnQ6ICh1cmw6IHN0cmluZykgPT4gYW55O1xuICBmaWxlRnJvbVBhdGg6XG4gICAgfCAoKHBhdGg6IHN0cmluZywgZmlsZW5hbWU/OiBzdHJpbmcsIG9wdGlvbnM/OiB7fSkgPT4gUHJvbWlzZTxTaGltc1snRmlsZSddPilcbiAgICB8ICgocGF0aDogc3RyaW5nLCBvcHRpb25zPzoge30pID0+IFByb21pc2U8U2hpbXNbJ0ZpbGUnXT4pO1xuICBpc0ZzUmVhZFN0cmVhbTogKHZhbHVlOiBhbnkpID0+IGJvb2xlYW47XG59XG5cbmV4cG9ydCBsZXQgYXV0byA9IGZhbHNlO1xuZXhwb3J0IGxldCBraW5kOiBTaGltc1sna2luZCddIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuZXhwb3J0IGxldCBmZXRjaDogU2hpbXNbJ2ZldGNoJ10gfCB1bmRlZmluZWQgPSB1bmRlZmluZWQ7XG5leHBvcnQgbGV0IFJlcXVlc3Q6IFNoaW1zWydSZXF1ZXN0J10gfCB1bmRlZmluZWQgPSB1bmRlZmluZWQ7XG5leHBvcnQgbGV0IFJlc3BvbnNlOiBTaGltc1snUmVzcG9uc2UnXSB8IHVuZGVmaW5lZCA9IHVuZGVmaW5lZDtcbmV4cG9ydCBsZXQgSGVhZGVyczogU2hpbXNbJ0hlYWRlcnMnXSB8IHVuZGVmaW5lZCA9IHVuZGVmaW5lZDtcbmV4cG9ydCBsZXQgRm9ybURhdGE6IFNoaW1zWydGb3JtRGF0YSddIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuZXhwb3J0IGxldCBCbG9iOiBTaGltc1snQmxvYiddIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuZXhwb3J0IGxldCBGaWxlOiBTaGltc1snRmlsZSddIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuZXhwb3J0IGxldCBSZWFkYWJsZVN0cmVhbTogU2hpbXNbJ1JlYWRhYmxlU3RyZWFtJ10gfCB1bmRlZmluZWQgPSB1bmRlZmluZWQ7XG5leHBvcnQgbGV0IGdldE11bHRpcGFydFJlcXVlc3RPcHRpb25zOiBTaGltc1snZ2V0TXVsdGlwYXJ0UmVxdWVzdE9wdGlvbnMnXSB8IHVuZGVmaW5lZCA9IHVuZGVmaW5lZDtcbmV4cG9ydCBsZXQgZ2V0RGVmYXVsdEFnZW50OiBTaGltc1snZ2V0RGVmYXVsdEFnZW50J10gfCB1bmRlZmluZWQgPSB1bmRlZmluZWQ7XG5leHBvcnQgbGV0IGZpbGVGcm9tUGF0aDogU2hpbXNbJ2ZpbGVGcm9tUGF0aCddIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuZXhwb3J0IGxldCBpc0ZzUmVhZFN0cmVhbTogU2hpbXNbJ2lzRnNSZWFkU3RyZWFtJ10gfCB1bmRlZmluZWQgPSB1bmRlZmluZWQ7XG5cbmV4cG9ydCBmdW5jdGlvbiBzZXRTaGltcyhzaGltczogU2hpbXMsIG9wdGlvbnM6IHsgYXV0bzogYm9vbGVhbiB9ID0geyBhdXRvOiBmYWxzZSB9KSB7XG4gIGlmIChhdXRvKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgYHlvdSBtdXN0IFxcYGltcG9ydCAnQGFudGhyb3BpYy1haS9zZGsvc2hpbXMvJHtzaGltcy5raW5kfSdcXGAgYmVmb3JlIGltcG9ydGluZyBhbnl0aGluZyBlbHNlIGZyb20gQGFudGhyb3BpYy1haS9zZGtgLFxuICAgICk7XG4gIH1cbiAgaWYgKGtpbmQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICBgY2FuJ3QgXFxgaW1wb3J0ICdAYW50aHJvcGljLWFpL3Nkay9zaGltcy8ke3NoaW1zLmtpbmR9J1xcYCBhZnRlciBcXGBpbXBvcnQgJ0BhbnRocm9waWMtYWkvc2RrL3NoaW1zLyR7a2luZH0nXFxgYCxcbiAgICApO1xuICB9XG4gIGF1dG8gPSBvcHRpb25zLmF1dG87XG4gIGtpbmQgPSBzaGltcy5raW5kO1xuICBmZXRjaCA9IHNoaW1zLmZldGNoO1xuICBSZXF1ZXN0ID0gc2hpbXMuUmVxdWVzdDtcbiAgUmVzcG9uc2UgPSBzaGltcy5SZXNwb25zZTtcbiAgSGVhZGVycyA9IHNoaW1zLkhlYWRlcnM7XG4gIEZvcm1EYXRhID0gc2hpbXMuRm9ybURhdGE7XG4gIEJsb2IgPSBzaGltcy5CbG9iO1xuICBGaWxlID0gc2hpbXMuRmlsZTtcbiAgUmVhZGFibGVTdHJlYW0gPSBzaGltcy5SZWFkYWJsZVN0cmVhbTtcbiAgZ2V0TXVsdGlwYXJ0UmVxdWVzdE9wdGlvbnMgPSBzaGltcy5nZXRNdWx0aXBhcnRSZXF1ZXN0T3B0aW9ucztcbiAgZ2V0RGVmYXVsdEFnZW50ID0gc2hpbXMuZ2V0RGVmYXVsdEFnZW50O1xuICBmaWxlRnJvbVBhdGggPSBzaGltcy5maWxlRnJvbVBhdGg7XG4gIGlzRnNSZWFkU3RyZWFtID0gc2hpbXMuaXNGc1JlYWRTdHJlYW07XG59XG4iLCAiLyoqXG4gKiBEaXNjbGFpbWVyOiBtb2R1bGVzIGluIF9zaGltcyBhcmVuJ3QgaW50ZW5kZWQgdG8gYmUgaW1wb3J0ZWQgYnkgU0RLIHVzZXJzLlxuICovXG5leHBvcnQgY2xhc3MgTXVsdGlwYXJ0Qm9keSB7XG4gIGNvbnN0cnVjdG9yKHB1YmxpYyBib2R5OiBhbnkpIHt9XG4gIGdldCBbU3ltYm9sLnRvU3RyaW5nVGFnXSgpOiBzdHJpbmcge1xuICAgIHJldHVybiAnTXVsdGlwYXJ0Qm9keSc7XG4gIH1cbn1cbiIsICIvKipcbiAqIERpc2NsYWltZXI6IG1vZHVsZXMgaW4gX3NoaW1zIGFyZW4ndCBpbnRlbmRlZCB0byBiZSBpbXBvcnRlZCBieSBTREsgdXNlcnMuXG4gKi9cbmltcG9ydCB7IE11bHRpcGFydEJvZHkgfSBmcm9tIFwiLi9NdWx0aXBhcnRCb2R5LmpzXCI7XG5pbXBvcnQgeyB0eXBlIFJlcXVlc3RPcHRpb25zIH0gZnJvbSBcIi4uL2NvcmUuanNcIjtcbmltcG9ydCB7IHR5cGUgU2hpbXMgfSBmcm9tIFwiLi9yZWdpc3RyeS5qc1wiO1xuXG5leHBvcnQgZnVuY3Rpb24gZ2V0UnVudGltZSh7IG1hbnVhbGx5SW1wb3J0ZWQgfTogeyBtYW51YWxseUltcG9ydGVkPzogYm9vbGVhbiB9ID0ge30pOiBTaGltcyB7XG4gIGNvbnN0IHJlY29tbWVuZGF0aW9uID1cbiAgICBtYW51YWxseUltcG9ydGVkID9cbiAgICAgIGBZb3UgbWF5IG5lZWQgdG8gdXNlIHBvbHlmaWxsc2BcbiAgICA6IGBBZGQgb25lIG9mIHRoZXNlIGltcG9ydHMgYmVmb3JlIHlvdXIgZmlyc3QgXFxgaW1wb3J0IFx1MjAyNiBmcm9tICdAYW50aHJvcGljLWFpL3NkaydcXGA6XG4tIFxcYGltcG9ydCAnQGFudGhyb3BpYy1haS9zZGsvc2hpbXMvbm9kZSdcXGAgKGlmIHlvdSdyZSBydW5uaW5nIG9uIE5vZGUpXG4tIFxcYGltcG9ydCAnQGFudGhyb3BpYy1haS9zZGsvc2hpbXMvd2ViJ1xcYCAob3RoZXJ3aXNlKVxuYDtcblxuICBsZXQgX2ZldGNoLCBfUmVxdWVzdCwgX1Jlc3BvbnNlLCBfSGVhZGVycztcbiAgdHJ5IHtcbiAgICAvLyBAdHMtaWdub3JlXG4gICAgX2ZldGNoID0gZmV0Y2g7XG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIF9SZXF1ZXN0ID0gUmVxdWVzdDtcbiAgICAvLyBAdHMtaWdub3JlXG4gICAgX1Jlc3BvbnNlID0gUmVzcG9uc2U7XG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIF9IZWFkZXJzID0gSGVhZGVycztcbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICBgdGhpcyBlbnZpcm9ubWVudCBpcyBtaXNzaW5nIHRoZSBmb2xsb3dpbmcgV2ViIEZldGNoIEFQSSB0eXBlOiAke1xuICAgICAgICAoZXJyb3IgYXMgYW55KS5tZXNzYWdlXG4gICAgICB9LiAke3JlY29tbWVuZGF0aW9ufWAsXG4gICAgKTtcbiAgfVxuXG4gIHJldHVybiB7XG4gICAga2luZDogJ3dlYicsXG4gICAgZmV0Y2g6IF9mZXRjaCxcbiAgICBSZXF1ZXN0OiBfUmVxdWVzdCxcbiAgICBSZXNwb25zZTogX1Jlc3BvbnNlLFxuICAgIEhlYWRlcnM6IF9IZWFkZXJzLFxuICAgIEZvcm1EYXRhOlxuICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgdHlwZW9mIEZvcm1EYXRhICE9PSAndW5kZWZpbmVkJyA/IEZvcm1EYXRhIDogKFxuICAgICAgICBjbGFzcyBGb3JtRGF0YSB7XG4gICAgICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgICBgZmlsZSB1cGxvYWRzIGFyZW4ndCBzdXBwb3J0ZWQgaW4gdGhpcyBlbnZpcm9ubWVudCB5ZXQgYXMgJ0Zvcm1EYXRhJyBpcyB1bmRlZmluZWQuICR7cmVjb21tZW5kYXRpb259YCxcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICApLFxuICAgIEJsb2I6XG4gICAgICB0eXBlb2YgQmxvYiAhPT0gJ3VuZGVmaW5lZCcgPyBCbG9iIDogKFxuICAgICAgICBjbGFzcyBCbG9iIHtcbiAgICAgICAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAgICAgYGZpbGUgdXBsb2FkcyBhcmVuJ3Qgc3VwcG9ydGVkIGluIHRoaXMgZW52aXJvbm1lbnQgeWV0IGFzICdCbG9iJyBpcyB1bmRlZmluZWQuICR7cmVjb21tZW5kYXRpb259YCxcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICApLFxuICAgIEZpbGU6XG4gICAgICAvLyBAdHMtaWdub3JlXG4gICAgICB0eXBlb2YgRmlsZSAhPT0gJ3VuZGVmaW5lZCcgPyBGaWxlIDogKFxuICAgICAgICBjbGFzcyBGaWxlIHtcbiAgICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgICAgIGBmaWxlIHVwbG9hZHMgYXJlbid0IHN1cHBvcnRlZCBpbiB0aGlzIGVudmlyb25tZW50IHlldCBhcyAnRmlsZScgaXMgdW5kZWZpbmVkLiAke3JlY29tbWVuZGF0aW9ufWAsXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgKSxcbiAgICBSZWFkYWJsZVN0cmVhbTpcbiAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgIHR5cGVvZiBSZWFkYWJsZVN0cmVhbSAhPT0gJ3VuZGVmaW5lZCcgPyBSZWFkYWJsZVN0cmVhbSA6IChcbiAgICAgICAgY2xhc3MgUmVhZGFibGVTdHJlYW0ge1xuICAgICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAgICAgYHN0cmVhbWluZyBpc24ndCBzdXBwb3J0ZWQgaW4gdGhpcyBlbnZpcm9ubWVudCB5ZXQgYXMgJ1JlYWRhYmxlU3RyZWFtJyBpcyB1bmRlZmluZWQuICR7cmVjb21tZW5kYXRpb259YCxcbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICApLFxuICAgIGdldE11bHRpcGFydFJlcXVlc3RPcHRpb25zOiBhc3luYyA8VCA9IFJlY29yZDxzdHJpbmcsIHVua25vd24+PihcbiAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgIGZvcm06IEZvcm1EYXRhLFxuICAgICAgb3B0czogUmVxdWVzdE9wdGlvbnM8VD4sXG4gICAgKTogUHJvbWlzZTxSZXF1ZXN0T3B0aW9uczxUPj4gPT4gKHtcbiAgICAgIC4uLm9wdHMsXG4gICAgICBib2R5OiBuZXcgTXVsdGlwYXJ0Qm9keShmb3JtKSBhcyBhbnksXG4gICAgfSksXG4gICAgZ2V0RGVmYXVsdEFnZW50OiAodXJsOiBzdHJpbmcpID0+IHVuZGVmaW5lZCxcbiAgICBmaWxlRnJvbVBhdGg6ICgpID0+IHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgJ1RoZSBgZmlsZUZyb21QYXRoYCBmdW5jdGlvbiBpcyBvbmx5IHN1cHBvcnRlZCBpbiBOb2RlLiBTZWUgdGhlIFJFQURNRSBmb3IgbW9yZSBkZXRhaWxzOiBodHRwczovL3d3dy5naXRodWIuY29tL2FudGhyb3BpY3MvYW50aHJvcGljLXNkay10eXBlc2NyaXB0I2ZpbGUtdXBsb2FkcycsXG4gICAgICApO1xuICAgIH0sXG4gICAgaXNGc1JlYWRTdHJlYW06ICh2YWx1ZTogYW55KSA9PiBmYWxzZSxcbiAgfTtcbn1cbiIsICIvKipcbiAqIERpc2NsYWltZXI6IG1vZHVsZXMgaW4gX3NoaW1zIGFyZW4ndCBpbnRlbmRlZCB0byBiZSBpbXBvcnRlZCBieSBTREsgdXNlcnMuXG4gKi9cbmltcG9ydCAqIGFzIHNoaW1zIGZyb20gJy4vcmVnaXN0cnkubWpzJztcbmltcG9ydCAqIGFzIGF1dG8gZnJvbSAnQGFudGhyb3BpYy1haS9zZGsvX3NoaW1zL2F1dG8vcnVudGltZSc7XG5pZiAoIXNoaW1zLmtpbmQpIHNoaW1zLnNldFNoaW1zKGF1dG8uZ2V0UnVudGltZSgpLCB7IGF1dG86IHRydWUgfSk7XG5leHBvcnQgKiBmcm9tICcuL3JlZ2lzdHJ5Lm1qcyc7XG4iLCAiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cblxuaW1wb3J0IHsgY2FzdFRvRXJyb3IsIEhlYWRlcnMgfSBmcm9tIFwiLi9jb3JlLmpzXCI7XG5cbmV4cG9ydCBjbGFzcyBBbnRocm9waWNFcnJvciBleHRlbmRzIEVycm9yIHt9XG5cbmV4cG9ydCBjbGFzcyBBUElFcnJvciBleHRlbmRzIEFudGhyb3BpY0Vycm9yIHtcbiAgcmVhZG9ubHkgc3RhdHVzOiBudW1iZXIgfCB1bmRlZmluZWQ7XG4gIHJlYWRvbmx5IGhlYWRlcnM6IEhlYWRlcnMgfCB1bmRlZmluZWQ7XG4gIHJlYWRvbmx5IGVycm9yOiBPYmplY3QgfCB1bmRlZmluZWQ7XG5cbiAgcmVhZG9ubHkgcmVxdWVzdF9pZDogc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZDtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBzdGF0dXM6IG51bWJlciB8IHVuZGVmaW5lZCxcbiAgICBlcnJvcjogT2JqZWN0IHwgdW5kZWZpbmVkLFxuICAgIG1lc3NhZ2U6IHN0cmluZyB8IHVuZGVmaW5lZCxcbiAgICBoZWFkZXJzOiBIZWFkZXJzIHwgdW5kZWZpbmVkLFxuICApIHtcbiAgICBzdXBlcihgJHtBUElFcnJvci5tYWtlTWVzc2FnZShzdGF0dXMsIGVycm9yLCBtZXNzYWdlKX1gKTtcbiAgICB0aGlzLnN0YXR1cyA9IHN0YXR1cztcbiAgICB0aGlzLmhlYWRlcnMgPSBoZWFkZXJzO1xuICAgIHRoaXMucmVxdWVzdF9pZCA9IGhlYWRlcnM/LlsncmVxdWVzdC1pZCddO1xuICAgIHRoaXMuZXJyb3IgPSBlcnJvcjtcbiAgfVxuXG4gIHByaXZhdGUgc3RhdGljIG1ha2VNZXNzYWdlKHN0YXR1czogbnVtYmVyIHwgdW5kZWZpbmVkLCBlcnJvcjogYW55LCBtZXNzYWdlOiBzdHJpbmcgfCB1bmRlZmluZWQpIHtcbiAgICBjb25zdCBtc2cgPVxuICAgICAgZXJyb3I/Lm1lc3NhZ2UgP1xuICAgICAgICB0eXBlb2YgZXJyb3IubWVzc2FnZSA9PT0gJ3N0cmluZycgP1xuICAgICAgICAgIGVycm9yLm1lc3NhZ2VcbiAgICAgICAgOiBKU09OLnN0cmluZ2lmeShlcnJvci5tZXNzYWdlKVxuICAgICAgOiBlcnJvciA/IEpTT04uc3RyaW5naWZ5KGVycm9yKVxuICAgICAgOiBtZXNzYWdlO1xuXG4gICAgaWYgKHN0YXR1cyAmJiBtc2cpIHtcbiAgICAgIHJldHVybiBgJHtzdGF0dXN9ICR7bXNnfWA7XG4gICAgfVxuICAgIGlmIChzdGF0dXMpIHtcbiAgICAgIHJldHVybiBgJHtzdGF0dXN9IHN0YXR1cyBjb2RlIChubyBib2R5KWA7XG4gICAgfVxuICAgIGlmIChtc2cpIHtcbiAgICAgIHJldHVybiBtc2c7XG4gICAgfVxuICAgIHJldHVybiAnKG5vIHN0YXR1cyBjb2RlIG9yIGJvZHkpJztcbiAgfVxuXG4gIHN0YXRpYyBnZW5lcmF0ZShcbiAgICBzdGF0dXM6IG51bWJlciB8IHVuZGVmaW5lZCxcbiAgICBlcnJvclJlc3BvbnNlOiBPYmplY3QgfCB1bmRlZmluZWQsXG4gICAgbWVzc2FnZTogc3RyaW5nIHwgdW5kZWZpbmVkLFxuICAgIGhlYWRlcnM6IEhlYWRlcnMgfCB1bmRlZmluZWQsXG4gICkge1xuICAgIGlmICghc3RhdHVzKSB7XG4gICAgICByZXR1cm4gbmV3IEFQSUNvbm5lY3Rpb25FcnJvcih7IG1lc3NhZ2UsIGNhdXNlOiBjYXN0VG9FcnJvcihlcnJvclJlc3BvbnNlKSB9KTtcbiAgICB9XG5cbiAgICBjb25zdCBlcnJvciA9IGVycm9yUmVzcG9uc2UgYXMgUmVjb3JkPHN0cmluZywgYW55PjtcblxuICAgIGlmIChzdGF0dXMgPT09IDQwMCkge1xuICAgICAgcmV0dXJuIG5ldyBCYWRSZXF1ZXN0RXJyb3Ioc3RhdHVzLCBlcnJvciwgbWVzc2FnZSwgaGVhZGVycyk7XG4gICAgfVxuXG4gICAgaWYgKHN0YXR1cyA9PT0gNDAxKSB7XG4gICAgICByZXR1cm4gbmV3IEF1dGhlbnRpY2F0aW9uRXJyb3Ioc3RhdHVzLCBlcnJvciwgbWVzc2FnZSwgaGVhZGVycyk7XG4gICAgfVxuXG4gICAgaWYgKHN0YXR1cyA9PT0gNDAzKSB7XG4gICAgICByZXR1cm4gbmV3IFBlcm1pc3Npb25EZW5pZWRFcnJvcihzdGF0dXMsIGVycm9yLCBtZXNzYWdlLCBoZWFkZXJzKTtcbiAgICB9XG5cbiAgICBpZiAoc3RhdHVzID09PSA0MDQpIHtcbiAgICAgIHJldHVybiBuZXcgTm90Rm91bmRFcnJvcihzdGF0dXMsIGVycm9yLCBtZXNzYWdlLCBoZWFkZXJzKTtcbiAgICB9XG5cbiAgICBpZiAoc3RhdHVzID09PSA0MDkpIHtcbiAgICAgIHJldHVybiBuZXcgQ29uZmxpY3RFcnJvcihzdGF0dXMsIGVycm9yLCBtZXNzYWdlLCBoZWFkZXJzKTtcbiAgICB9XG5cbiAgICBpZiAoc3RhdHVzID09PSA0MjIpIHtcbiAgICAgIHJldHVybiBuZXcgVW5wcm9jZXNzYWJsZUVudGl0eUVycm9yKHN0YXR1cywgZXJyb3IsIG1lc3NhZ2UsIGhlYWRlcnMpO1xuICAgIH1cblxuICAgIGlmIChzdGF0dXMgPT09IDQyOSkge1xuICAgICAgcmV0dXJuIG5ldyBSYXRlTGltaXRFcnJvcihzdGF0dXMsIGVycm9yLCBtZXNzYWdlLCBoZWFkZXJzKTtcbiAgICB9XG5cbiAgICBpZiAoc3RhdHVzID49IDUwMCkge1xuICAgICAgcmV0dXJuIG5ldyBJbnRlcm5hbFNlcnZlckVycm9yKHN0YXR1cywgZXJyb3IsIG1lc3NhZ2UsIGhlYWRlcnMpO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgQVBJRXJyb3Ioc3RhdHVzLCBlcnJvciwgbWVzc2FnZSwgaGVhZGVycyk7XG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIEFQSVVzZXJBYm9ydEVycm9yIGV4dGVuZHMgQVBJRXJyb3Ige1xuICBvdmVycmlkZSByZWFkb25seSBzdGF0dXM6IHVuZGVmaW5lZCA9IHVuZGVmaW5lZDtcblxuICBjb25zdHJ1Y3Rvcih7IG1lc3NhZ2UgfTogeyBtZXNzYWdlPzogc3RyaW5nIH0gPSB7fSkge1xuICAgIHN1cGVyKHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBtZXNzYWdlIHx8ICdSZXF1ZXN0IHdhcyBhYm9ydGVkLicsIHVuZGVmaW5lZCk7XG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIEFQSUNvbm5lY3Rpb25FcnJvciBleHRlbmRzIEFQSUVycm9yIHtcbiAgb3ZlcnJpZGUgcmVhZG9ubHkgc3RhdHVzOiB1bmRlZmluZWQgPSB1bmRlZmluZWQ7XG5cbiAgY29uc3RydWN0b3IoeyBtZXNzYWdlLCBjYXVzZSB9OiB7IG1lc3NhZ2U/OiBzdHJpbmcgfCB1bmRlZmluZWQ7IGNhdXNlPzogRXJyb3IgfCB1bmRlZmluZWQgfSkge1xuICAgIHN1cGVyKHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBtZXNzYWdlIHx8ICdDb25uZWN0aW9uIGVycm9yLicsIHVuZGVmaW5lZCk7XG4gICAgLy8gaW4gc29tZSBlbnZpcm9ubWVudHMgdGhlICdjYXVzZScgcHJvcGVydHkgaXMgYWxyZWFkeSBkZWNsYXJlZFxuICAgIC8vIEB0cy1pZ25vcmVcbiAgICBpZiAoY2F1c2UpIHRoaXMuY2F1c2UgPSBjYXVzZTtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgQVBJQ29ubmVjdGlvblRpbWVvdXRFcnJvciBleHRlbmRzIEFQSUNvbm5lY3Rpb25FcnJvciB7XG4gIGNvbnN0cnVjdG9yKHsgbWVzc2FnZSB9OiB7IG1lc3NhZ2U/OiBzdHJpbmcgfSA9IHt9KSB7XG4gICAgc3VwZXIoeyBtZXNzYWdlOiBtZXNzYWdlID8/ICdSZXF1ZXN0IHRpbWVkIG91dC4nIH0pO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBCYWRSZXF1ZXN0RXJyb3IgZXh0ZW5kcyBBUElFcnJvciB7XG4gIG92ZXJyaWRlIHJlYWRvbmx5IHN0YXR1czogNDAwID0gNDAwO1xufVxuXG5leHBvcnQgY2xhc3MgQXV0aGVudGljYXRpb25FcnJvciBleHRlbmRzIEFQSUVycm9yIHtcbiAgb3ZlcnJpZGUgcmVhZG9ubHkgc3RhdHVzOiA0MDEgPSA0MDE7XG59XG5cbmV4cG9ydCBjbGFzcyBQZXJtaXNzaW9uRGVuaWVkRXJyb3IgZXh0ZW5kcyBBUElFcnJvciB7XG4gIG92ZXJyaWRlIHJlYWRvbmx5IHN0YXR1czogNDAzID0gNDAzO1xufVxuXG5leHBvcnQgY2xhc3MgTm90Rm91bmRFcnJvciBleHRlbmRzIEFQSUVycm9yIHtcbiAgb3ZlcnJpZGUgcmVhZG9ubHkgc3RhdHVzOiA0MDQgPSA0MDQ7XG59XG5cbmV4cG9ydCBjbGFzcyBDb25mbGljdEVycm9yIGV4dGVuZHMgQVBJRXJyb3Ige1xuICBvdmVycmlkZSByZWFkb25seSBzdGF0dXM6IDQwOSA9IDQwOTtcbn1cblxuZXhwb3J0IGNsYXNzIFVucHJvY2Vzc2FibGVFbnRpdHlFcnJvciBleHRlbmRzIEFQSUVycm9yIHtcbiAgb3ZlcnJpZGUgcmVhZG9ubHkgc3RhdHVzOiA0MjIgPSA0MjI7XG59XG5cbmV4cG9ydCBjbGFzcyBSYXRlTGltaXRFcnJvciBleHRlbmRzIEFQSUVycm9yIHtcbiAgb3ZlcnJpZGUgcmVhZG9ubHkgc3RhdHVzOiA0MjkgPSA0Mjk7XG59XG5cbmV4cG9ydCBjbGFzcyBJbnRlcm5hbFNlcnZlckVycm9yIGV4dGVuZHMgQVBJRXJyb3Ige31cbiIsICJpbXBvcnQgeyBSZWFkYWJsZVN0cmVhbSwgdHlwZSBSZXNwb25zZSB9IGZyb20gXCIuL19zaGltcy9pbmRleC5qc1wiO1xuaW1wb3J0IHsgQW50aHJvcGljRXJyb3IgfSBmcm9tIFwiLi9lcnJvci5qc1wiO1xuXG5pbXBvcnQgeyBjcmVhdGVSZXNwb25zZUhlYWRlcnMgfSBmcm9tIFwiLi9jb3JlLmpzXCI7XG5pbXBvcnQgeyBBUElFcnJvciB9IGZyb20gXCIuL2Vycm9yLmpzXCI7XG5cbnR5cGUgQnl0ZXMgPSBzdHJpbmcgfCBBcnJheUJ1ZmZlciB8IFVpbnQ4QXJyYXkgfCBCdWZmZXIgfCBudWxsIHwgdW5kZWZpbmVkO1xuXG5leHBvcnQgdHlwZSBTZXJ2ZXJTZW50RXZlbnQgPSB7XG4gIGV2ZW50OiBzdHJpbmcgfCBudWxsO1xuICBkYXRhOiBzdHJpbmc7XG4gIHJhdzogc3RyaW5nW107XG59O1xuXG5leHBvcnQgY2xhc3MgU3RyZWFtPEl0ZW0+IGltcGxlbWVudHMgQXN5bmNJdGVyYWJsZTxJdGVtPiB7XG4gIGNvbnRyb2xsZXI6IEFib3J0Q29udHJvbGxlcjtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIGl0ZXJhdG9yOiAoKSA9PiBBc3luY0l0ZXJhdG9yPEl0ZW0+LFxuICAgIGNvbnRyb2xsZXI6IEFib3J0Q29udHJvbGxlcixcbiAgKSB7XG4gICAgdGhpcy5jb250cm9sbGVyID0gY29udHJvbGxlcjtcbiAgfVxuXG4gIHN0YXRpYyBmcm9tU1NFUmVzcG9uc2U8SXRlbT4ocmVzcG9uc2U6IFJlc3BvbnNlLCBjb250cm9sbGVyOiBBYm9ydENvbnRyb2xsZXIpIHtcbiAgICBsZXQgY29uc3VtZWQgPSBmYWxzZTtcblxuICAgIGFzeW5jIGZ1bmN0aW9uKiBpdGVyYXRvcigpOiBBc3luY0l0ZXJhdG9yPEl0ZW0sIGFueSwgdW5kZWZpbmVkPiB7XG4gICAgICBpZiAoY29uc3VtZWQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdDYW5ub3QgaXRlcmF0ZSBvdmVyIGEgY29uc3VtZWQgc3RyZWFtLCB1c2UgYC50ZWUoKWAgdG8gc3BsaXQgdGhlIHN0cmVhbS4nKTtcbiAgICAgIH1cbiAgICAgIGNvbnN1bWVkID0gdHJ1ZTtcbiAgICAgIGxldCBkb25lID0gZmFsc2U7XG4gICAgICB0cnkge1xuICAgICAgICBmb3IgYXdhaXQgKGNvbnN0IHNzZSBvZiBfaXRlclNTRU1lc3NhZ2VzKHJlc3BvbnNlLCBjb250cm9sbGVyKSkge1xuICAgICAgICAgIGlmIChzc2UuZXZlbnQgPT09ICdjb21wbGV0aW9uJykge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgeWllbGQgSlNPTi5wYXJzZShzc2UuZGF0YSk7XG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYENvdWxkIG5vdCBwYXJzZSBtZXNzYWdlIGludG8gSlNPTjpgLCBzc2UuZGF0YSk7XG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEZyb20gY2h1bms6YCwgc3NlLnJhdyk7XG4gICAgICAgICAgICAgIHRocm93IGU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKFxuICAgICAgICAgICAgc3NlLmV2ZW50ID09PSAnbWVzc2FnZV9zdGFydCcgfHxcbiAgICAgICAgICAgIHNzZS5ldmVudCA9PT0gJ21lc3NhZ2VfZGVsdGEnIHx8XG4gICAgICAgICAgICBzc2UuZXZlbnQgPT09ICdtZXNzYWdlX3N0b3AnIHx8XG4gICAgICAgICAgICBzc2UuZXZlbnQgPT09ICdjb250ZW50X2Jsb2NrX3N0YXJ0JyB8fFxuICAgICAgICAgICAgc3NlLmV2ZW50ID09PSAnY29udGVudF9ibG9ja19kZWx0YScgfHxcbiAgICAgICAgICAgIHNzZS5ldmVudCA9PT0gJ2NvbnRlbnRfYmxvY2tfc3RvcCdcbiAgICAgICAgICApIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIHlpZWxkIEpTT04ucGFyc2Uoc3NlLmRhdGEpO1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGBDb3VsZCBub3QgcGFyc2UgbWVzc2FnZSBpbnRvIEpTT046YCwgc3NlLmRhdGEpO1xuICAgICAgICAgICAgICBjb25zb2xlLmVycm9yKGBGcm9tIGNodW5rOmAsIHNzZS5yYXcpO1xuICAgICAgICAgICAgICB0aHJvdyBlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmIChzc2UuZXZlbnQgPT09ICdwaW5nJykge1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKHNzZS5ldmVudCA9PT0gJ2Vycm9yJykge1xuICAgICAgICAgICAgdGhyb3cgQVBJRXJyb3IuZ2VuZXJhdGUoXG4gICAgICAgICAgICAgIHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgYFNTRSBFcnJvcjogJHtzc2UuZGF0YX1gLFxuICAgICAgICAgICAgICBzc2UuZGF0YSxcbiAgICAgICAgICAgICAgY3JlYXRlUmVzcG9uc2VIZWFkZXJzKHJlc3BvbnNlLmhlYWRlcnMpLFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZG9uZSA9IHRydWU7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIElmIHRoZSB1c2VyIGNhbGxzIGBzdHJlYW0uY29udHJvbGxlci5hYm9ydCgpYCwgd2Ugc2hvdWxkIGV4aXQgd2l0aG91dCB0aHJvd2luZy5cbiAgICAgICAgaWYgKGUgaW5zdGFuY2VvZiBFcnJvciAmJiBlLm5hbWUgPT09ICdBYm9ydEVycm9yJykgcmV0dXJuO1xuICAgICAgICB0aHJvdyBlO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgLy8gSWYgdGhlIHVzZXIgYGJyZWFrYHMsIGFib3J0IHRoZSBvbmdvaW5nIHJlcXVlc3QuXG4gICAgICAgIGlmICghZG9uZSkgY29udHJvbGxlci5hYm9ydCgpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBuZXcgU3RyZWFtKGl0ZXJhdG9yLCBjb250cm9sbGVyKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZW5lcmF0ZXMgYSBTdHJlYW0gZnJvbSBhIG5ld2xpbmUtc2VwYXJhdGVkIFJlYWRhYmxlU3RyZWFtXG4gICAqIHdoZXJlIGVhY2ggaXRlbSBpcyBhIEpTT04gdmFsdWUuXG4gICAqL1xuICBzdGF0aWMgZnJvbVJlYWRhYmxlU3RyZWFtPEl0ZW0+KHJlYWRhYmxlU3RyZWFtOiBSZWFkYWJsZVN0cmVhbSwgY29udHJvbGxlcjogQWJvcnRDb250cm9sbGVyKSB7XG4gICAgbGV0IGNvbnN1bWVkID0gZmFsc2U7XG5cbiAgICBhc3luYyBmdW5jdGlvbiogaXRlckxpbmVzKCk6IEFzeW5jR2VuZXJhdG9yPHN0cmluZywgdm9pZCwgdW5rbm93bj4ge1xuICAgICAgY29uc3QgbGluZURlY29kZXIgPSBuZXcgTGluZURlY29kZXIoKTtcblxuICAgICAgY29uc3QgaXRlciA9IHJlYWRhYmxlU3RyZWFtQXN5bmNJdGVyYWJsZTxCeXRlcz4ocmVhZGFibGVTdHJlYW0pO1xuICAgICAgZm9yIGF3YWl0IChjb25zdCBjaHVuayBvZiBpdGVyKSB7XG4gICAgICAgIGZvciAoY29uc3QgbGluZSBvZiBsaW5lRGVjb2Rlci5kZWNvZGUoY2h1bmspKSB7XG4gICAgICAgICAgeWllbGQgbGluZTtcbiAgICAgICAgfVxuICAgICAgfVxuXG4gICAgICBmb3IgKGNvbnN0IGxpbmUgb2YgbGluZURlY29kZXIuZmx1c2goKSkge1xuICAgICAgICB5aWVsZCBsaW5lO1xuICAgICAgfVxuICAgIH1cblxuICAgIGFzeW5jIGZ1bmN0aW9uKiBpdGVyYXRvcigpOiBBc3luY0l0ZXJhdG9yPEl0ZW0sIGFueSwgdW5kZWZpbmVkPiB7XG4gICAgICBpZiAoY29uc3VtZWQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdDYW5ub3QgaXRlcmF0ZSBvdmVyIGEgY29uc3VtZWQgc3RyZWFtLCB1c2UgYC50ZWUoKWAgdG8gc3BsaXQgdGhlIHN0cmVhbS4nKTtcbiAgICAgIH1cbiAgICAgIGNvbnN1bWVkID0gdHJ1ZTtcbiAgICAgIGxldCBkb25lID0gZmFsc2U7XG4gICAgICB0cnkge1xuICAgICAgICBmb3IgYXdhaXQgKGNvbnN0IGxpbmUgb2YgaXRlckxpbmVzKCkpIHtcbiAgICAgICAgICBpZiAoZG9uZSkgY29udGludWU7XG4gICAgICAgICAgaWYgKGxpbmUpIHlpZWxkIEpTT04ucGFyc2UobGluZSk7XG4gICAgICAgIH1cbiAgICAgICAgZG9uZSA9IHRydWU7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIC8vIElmIHRoZSB1c2VyIGNhbGxzIGBzdHJlYW0uY29udHJvbGxlci5hYm9ydCgpYCwgd2Ugc2hvdWxkIGV4aXQgd2l0aG91dCB0aHJvd2luZy5cbiAgICAgICAgaWYgKGUgaW5zdGFuY2VvZiBFcnJvciAmJiBlLm5hbWUgPT09ICdBYm9ydEVycm9yJykgcmV0dXJuO1xuICAgICAgICB0aHJvdyBlO1xuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgLy8gSWYgdGhlIHVzZXIgYGJyZWFrYHMsIGFib3J0IHRoZSBvbmdvaW5nIHJlcXVlc3QuXG4gICAgICAgIGlmICghZG9uZSkgY29udHJvbGxlci5hYm9ydCgpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiBuZXcgU3RyZWFtKGl0ZXJhdG9yLCBjb250cm9sbGVyKTtcbiAgfVxuXG4gIFtTeW1ib2wuYXN5bmNJdGVyYXRvcl0oKTogQXN5bmNJdGVyYXRvcjxJdGVtPiB7XG4gICAgcmV0dXJuIHRoaXMuaXRlcmF0b3IoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTcGxpdHMgdGhlIHN0cmVhbSBpbnRvIHR3byBzdHJlYW1zIHdoaWNoIGNhbiBiZVxuICAgKiBpbmRlcGVuZGVudGx5IHJlYWQgZnJvbSBhdCBkaWZmZXJlbnQgc3BlZWRzLlxuICAgKi9cbiAgdGVlKCk6IFtTdHJlYW08SXRlbT4sIFN0cmVhbTxJdGVtPl0ge1xuICAgIGNvbnN0IGxlZnQ6IEFycmF5PFByb21pc2U8SXRlcmF0b3JSZXN1bHQ8SXRlbT4+PiA9IFtdO1xuICAgIGNvbnN0IHJpZ2h0OiBBcnJheTxQcm9taXNlPEl0ZXJhdG9yUmVzdWx0PEl0ZW0+Pj4gPSBbXTtcbiAgICBjb25zdCBpdGVyYXRvciA9IHRoaXMuaXRlcmF0b3IoKTtcblxuICAgIGNvbnN0IHRlZUl0ZXJhdG9yID0gKHF1ZXVlOiBBcnJheTxQcm9taXNlPEl0ZXJhdG9yUmVzdWx0PEl0ZW0+Pj4pOiBBc3luY0l0ZXJhdG9yPEl0ZW0+ID0+IHtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIG5leHQ6ICgpID0+IHtcbiAgICAgICAgICBpZiAocXVldWUubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBpdGVyYXRvci5uZXh0KCk7XG4gICAgICAgICAgICBsZWZ0LnB1c2gocmVzdWx0KTtcbiAgICAgICAgICAgIHJpZ2h0LnB1c2gocmVzdWx0KTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIHF1ZXVlLnNoaWZ0KCkhO1xuICAgICAgICB9LFxuICAgICAgfTtcbiAgICB9O1xuXG4gICAgcmV0dXJuIFtcbiAgICAgIG5ldyBTdHJlYW0oKCkgPT4gdGVlSXRlcmF0b3IobGVmdCksIHRoaXMuY29udHJvbGxlciksXG4gICAgICBuZXcgU3RyZWFtKCgpID0+IHRlZUl0ZXJhdG9yKHJpZ2h0KSwgdGhpcy5jb250cm9sbGVyKSxcbiAgICBdO1xuICB9XG5cbiAgLyoqXG4gICAqIENvbnZlcnRzIHRoaXMgc3RyZWFtIHRvIGEgbmV3bGluZS1zZXBhcmF0ZWQgUmVhZGFibGVTdHJlYW0gb2ZcbiAgICogSlNPTiBzdHJpbmdpZmllZCB2YWx1ZXMgaW4gdGhlIHN0cmVhbVxuICAgKiB3aGljaCBjYW4gYmUgdHVybmVkIGJhY2sgaW50byBhIFN0cmVhbSB3aXRoIGBTdHJlYW0uZnJvbVJlYWRhYmxlU3RyZWFtKClgLlxuICAgKi9cbiAgdG9SZWFkYWJsZVN0cmVhbSgpOiBSZWFkYWJsZVN0cmVhbSB7XG4gICAgY29uc3Qgc2VsZiA9IHRoaXM7XG4gICAgbGV0IGl0ZXI6IEFzeW5jSXRlcmF0b3I8SXRlbT47XG4gICAgY29uc3QgZW5jb2RlciA9IG5ldyBUZXh0RW5jb2RlcigpO1xuXG4gICAgcmV0dXJuIG5ldyBSZWFkYWJsZVN0cmVhbSh7XG4gICAgICBhc3luYyBzdGFydCgpIHtcbiAgICAgICAgaXRlciA9IHNlbGZbU3ltYm9sLmFzeW5jSXRlcmF0b3JdKCk7XG4gICAgICB9LFxuICAgICAgYXN5bmMgcHVsbChjdHJsOiBhbnkpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBjb25zdCB7IHZhbHVlLCBkb25lIH0gPSBhd2FpdCBpdGVyLm5leHQoKTtcbiAgICAgICAgICBpZiAoZG9uZSkgcmV0dXJuIGN0cmwuY2xvc2UoKTtcblxuICAgICAgICAgIGNvbnN0IGJ5dGVzID0gZW5jb2Rlci5lbmNvZGUoSlNPTi5zdHJpbmdpZnkodmFsdWUpICsgJ1xcbicpO1xuXG4gICAgICAgICAgY3RybC5lbnF1ZXVlKGJ5dGVzKTtcbiAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgY3RybC5lcnJvcihlcnIpO1xuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgYXN5bmMgY2FuY2VsKCkge1xuICAgICAgICBhd2FpdCBpdGVyLnJldHVybj8uKCk7XG4gICAgICB9LFxuICAgIH0pO1xuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiogX2l0ZXJTU0VNZXNzYWdlcyhcbiAgcmVzcG9uc2U6IFJlc3BvbnNlLFxuICBjb250cm9sbGVyOiBBYm9ydENvbnRyb2xsZXIsXG4pOiBBc3luY0dlbmVyYXRvcjxTZXJ2ZXJTZW50RXZlbnQsIHZvaWQsIHVua25vd24+IHtcbiAgaWYgKCFyZXNwb25zZS5ib2R5KSB7XG4gICAgY29udHJvbGxlci5hYm9ydCgpO1xuICAgIHRocm93IG5ldyBBbnRocm9waWNFcnJvcihgQXR0ZW1wdGVkIHRvIGl0ZXJhdGUgb3ZlciBhIHJlc3BvbnNlIHdpdGggbm8gYm9keWApO1xuICB9XG5cbiAgY29uc3Qgc3NlRGVjb2RlciA9IG5ldyBTU0VEZWNvZGVyKCk7XG4gIGNvbnN0IGxpbmVEZWNvZGVyID0gbmV3IExpbmVEZWNvZGVyKCk7XG5cbiAgY29uc3QgaXRlciA9IHJlYWRhYmxlU3RyZWFtQXN5bmNJdGVyYWJsZTxCeXRlcz4ocmVzcG9uc2UuYm9keSk7XG4gIGZvciBhd2FpdCAoY29uc3Qgc3NlQ2h1bmsgb2YgaXRlclNTRUNodW5rcyhpdGVyKSkge1xuICAgIGZvciAoY29uc3QgbGluZSBvZiBsaW5lRGVjb2Rlci5kZWNvZGUoc3NlQ2h1bmspKSB7XG4gICAgICBjb25zdCBzc2UgPSBzc2VEZWNvZGVyLmRlY29kZShsaW5lKTtcbiAgICAgIGlmIChzc2UpIHlpZWxkIHNzZTtcbiAgICB9XG4gIH1cblxuICBmb3IgKGNvbnN0IGxpbmUgb2YgbGluZURlY29kZXIuZmx1c2goKSkge1xuICAgIGNvbnN0IHNzZSA9IHNzZURlY29kZXIuZGVjb2RlKGxpbmUpO1xuICAgIGlmIChzc2UpIHlpZWxkIHNzZTtcbiAgfVxufVxuXG4vKipcbiAqIEdpdmVuIGFuIGFzeW5jIGl0ZXJhYmxlIGl0ZXJhdG9yLCBpdGVyYXRlcyBvdmVyIGl0IGFuZCB5aWVsZHMgZnVsbFxuICogU1NFIGNodW5rcywgaS5lLiB5aWVsZHMgd2hlbiBhIGRvdWJsZSBuZXctbGluZSBpcyBlbmNvdW50ZXJlZC5cbiAqL1xuYXN5bmMgZnVuY3Rpb24qIGl0ZXJTU0VDaHVua3MoaXRlcmF0b3I6IEFzeW5jSXRlcmFibGVJdGVyYXRvcjxCeXRlcz4pOiBBc3luY0dlbmVyYXRvcjxVaW50OEFycmF5PiB7XG4gIGxldCBkYXRhID0gbmV3IFVpbnQ4QXJyYXkoKTtcblxuICBmb3IgYXdhaXQgKGNvbnN0IGNodW5rIG9mIGl0ZXJhdG9yKSB7XG4gICAgaWYgKGNodW5rID09IG51bGwpIHtcbiAgICAgIGNvbnRpbnVlO1xuICAgIH1cblxuICAgIGNvbnN0IGJpbmFyeUNodW5rID1cbiAgICAgIGNodW5rIGluc3RhbmNlb2YgQXJyYXlCdWZmZXIgPyBuZXcgVWludDhBcnJheShjaHVuaylcbiAgICAgIDogdHlwZW9mIGNodW5rID09PSAnc3RyaW5nJyA/IG5ldyBUZXh0RW5jb2RlcigpLmVuY29kZShjaHVuaylcbiAgICAgIDogY2h1bms7XG5cbiAgICBsZXQgbmV3RGF0YSA9IG5ldyBVaW50OEFycmF5KGRhdGEubGVuZ3RoICsgYmluYXJ5Q2h1bmsubGVuZ3RoKTtcbiAgICBuZXdEYXRhLnNldChkYXRhKTtcbiAgICBuZXdEYXRhLnNldChiaW5hcnlDaHVuaywgZGF0YS5sZW5ndGgpO1xuICAgIGRhdGEgPSBuZXdEYXRhO1xuXG4gICAgbGV0IHBhdHRlcm5JbmRleDtcbiAgICB3aGlsZSAoKHBhdHRlcm5JbmRleCA9IGZpbmREb3VibGVOZXdsaW5lSW5kZXgoZGF0YSkpICE9PSAtMSkge1xuICAgICAgeWllbGQgZGF0YS5zbGljZSgwLCBwYXR0ZXJuSW5kZXgpO1xuICAgICAgZGF0YSA9IGRhdGEuc2xpY2UocGF0dGVybkluZGV4KTtcbiAgICB9XG4gIH1cblxuICBpZiAoZGF0YS5sZW5ndGggPiAwKSB7XG4gICAgeWllbGQgZGF0YTtcbiAgfVxufVxuXG5mdW5jdGlvbiBmaW5kRG91YmxlTmV3bGluZUluZGV4KGJ1ZmZlcjogVWludDhBcnJheSk6IG51bWJlciB7XG4gIC8vIFRoaXMgZnVuY3Rpb24gc2VhcmNoZXMgdGhlIGJ1ZmZlciBmb3IgdGhlIGVuZCBwYXR0ZXJucyAoXFxyXFxyLCBcXG5cXG4sIFxcclxcblxcclxcbilcbiAgLy8gYW5kIHJldHVybnMgdGhlIGluZGV4IHJpZ2h0IGFmdGVyIHRoZSBmaXJzdCBvY2N1cnJlbmNlIG9mIGFueSBwYXR0ZXJuLFxuICAvLyBvciAtMSBpZiBub25lIG9mIHRoZSBwYXR0ZXJucyBhcmUgZm91bmQuXG4gIGNvbnN0IG5ld2xpbmUgPSAweDBhOyAvLyBcXG5cbiAgY29uc3QgY2FycmlhZ2UgPSAweDBkOyAvLyBcXHJcblxuICBmb3IgKGxldCBpID0gMDsgaSA8IGJ1ZmZlci5sZW5ndGggLSAyOyBpKyspIHtcbiAgICBpZiAoYnVmZmVyW2ldID09PSBuZXdsaW5lICYmIGJ1ZmZlcltpICsgMV0gPT09IG5ld2xpbmUpIHtcbiAgICAgIC8vIFxcblxcblxuICAgICAgcmV0dXJuIGkgKyAyO1xuICAgIH1cbiAgICBpZiAoYnVmZmVyW2ldID09PSBjYXJyaWFnZSAmJiBidWZmZXJbaSArIDFdID09PSBjYXJyaWFnZSkge1xuICAgICAgLy8gXFxyXFxyXG4gICAgICByZXR1cm4gaSArIDI7XG4gICAgfVxuICAgIGlmIChcbiAgICAgIGJ1ZmZlcltpXSA9PT0gY2FycmlhZ2UgJiZcbiAgICAgIGJ1ZmZlcltpICsgMV0gPT09IG5ld2xpbmUgJiZcbiAgICAgIGkgKyAzIDwgYnVmZmVyLmxlbmd0aCAmJlxuICAgICAgYnVmZmVyW2kgKyAyXSA9PT0gY2FycmlhZ2UgJiZcbiAgICAgIGJ1ZmZlcltpICsgM10gPT09IG5ld2xpbmVcbiAgICApIHtcbiAgICAgIC8vIFxcclxcblxcclxcblxuICAgICAgcmV0dXJuIGkgKyA0O1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiAtMTtcbn1cblxuY2xhc3MgU1NFRGVjb2RlciB7XG4gIHByaXZhdGUgZGF0YTogc3RyaW5nW107XG4gIHByaXZhdGUgZXZlbnQ6IHN0cmluZyB8IG51bGw7XG4gIHByaXZhdGUgY2h1bmtzOiBzdHJpbmdbXTtcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLmV2ZW50ID0gbnVsbDtcbiAgICB0aGlzLmRhdGEgPSBbXTtcbiAgICB0aGlzLmNodW5rcyA9IFtdO1xuICB9XG5cbiAgZGVjb2RlKGxpbmU6IHN0cmluZykge1xuICAgIGlmIChsaW5lLmVuZHNXaXRoKCdcXHInKSkge1xuICAgICAgbGluZSA9IGxpbmUuc3Vic3RyaW5nKDAsIGxpbmUubGVuZ3RoIC0gMSk7XG4gICAgfVxuXG4gICAgaWYgKCFsaW5lKSB7XG4gICAgICAvLyBlbXB0eSBsaW5lIGFuZCB3ZSBkaWRuJ3QgcHJldmlvdXNseSBlbmNvdW50ZXIgYW55IG1lc3NhZ2VzXG4gICAgICBpZiAoIXRoaXMuZXZlbnQgJiYgIXRoaXMuZGF0YS5sZW5ndGgpIHJldHVybiBudWxsO1xuXG4gICAgICBjb25zdCBzc2U6IFNlcnZlclNlbnRFdmVudCA9IHtcbiAgICAgICAgZXZlbnQ6IHRoaXMuZXZlbnQsXG4gICAgICAgIGRhdGE6IHRoaXMuZGF0YS5qb2luKCdcXG4nKSxcbiAgICAgICAgcmF3OiB0aGlzLmNodW5rcyxcbiAgICAgIH07XG5cbiAgICAgIHRoaXMuZXZlbnQgPSBudWxsO1xuICAgICAgdGhpcy5kYXRhID0gW107XG4gICAgICB0aGlzLmNodW5rcyA9IFtdO1xuXG4gICAgICByZXR1cm4gc3NlO1xuICAgIH1cblxuICAgIHRoaXMuY2h1bmtzLnB1c2gobGluZSk7XG5cbiAgICBpZiAobGluZS5zdGFydHNXaXRoKCc6JykpIHtcbiAgICAgIHJldHVybiBudWxsO1xuICAgIH1cblxuICAgIGxldCBbZmllbGRuYW1lLCBfLCB2YWx1ZV0gPSBwYXJ0aXRpb24obGluZSwgJzonKTtcblxuICAgIGlmICh2YWx1ZS5zdGFydHNXaXRoKCcgJykpIHtcbiAgICAgIHZhbHVlID0gdmFsdWUuc3Vic3RyaW5nKDEpO1xuICAgIH1cblxuICAgIGlmIChmaWVsZG5hbWUgPT09ICdldmVudCcpIHtcbiAgICAgIHRoaXMuZXZlbnQgPSB2YWx1ZTtcbiAgICB9IGVsc2UgaWYgKGZpZWxkbmFtZSA9PT0gJ2RhdGEnKSB7XG4gICAgICB0aGlzLmRhdGEucHVzaCh2YWx1ZSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIG51bGw7XG4gIH1cbn1cblxuLyoqXG4gKiBBIHJlLWltcGxlbWVudGF0aW9uIG9mIGh0dHB4J3MgYExpbmVEZWNvZGVyYCBpbiBQeXRob24gdGhhdCBoYW5kbGVzIGluY3JlbWVudGFsbHlcbiAqIHJlYWRpbmcgbGluZXMgZnJvbSB0ZXh0LlxuICpcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9lbmNvZGUvaHR0cHgvYmxvYi85MjAzMzNlYTk4MTE4ZTljZjYxN2YyNDY5MDVkN2IyMDI1MTA5NDFjL2h0dHB4L19kZWNvZGVycy5weSNMMjU4XG4gKi9cbmNsYXNzIExpbmVEZWNvZGVyIHtcbiAgLy8gcHJldHRpZXItaWdub3JlXG4gIHN0YXRpYyBORVdMSU5FX0NIQVJTID0gbmV3IFNldChbJ1xcbicsICdcXHInXSk7XG4gIHN0YXRpYyBORVdMSU5FX1JFR0VYUCA9IC9cXHJcXG58W1xcblxccl0vZztcblxuICBidWZmZXI6IHN0cmluZ1tdO1xuICB0cmFpbGluZ0NSOiBib29sZWFuO1xuICB0ZXh0RGVjb2RlcjogYW55OyAvLyBUZXh0RGVjb2RlciBmb3VuZCBpbiBicm93c2Vyczsgbm90IHR5cGVkIHRvIGF2b2lkIHB1bGxpbmcgaW4gZWl0aGVyIFwiZG9tXCIgb3IgXCJub2RlXCIgdHlwZXMuXG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy5idWZmZXIgPSBbXTtcbiAgICB0aGlzLnRyYWlsaW5nQ1IgPSBmYWxzZTtcbiAgfVxuXG4gIGRlY29kZShjaHVuazogQnl0ZXMpOiBzdHJpbmdbXSB7XG4gICAgbGV0IHRleHQgPSB0aGlzLmRlY29kZVRleHQoY2h1bmspO1xuXG4gICAgaWYgKHRoaXMudHJhaWxpbmdDUikge1xuICAgICAgdGV4dCA9ICdcXHInICsgdGV4dDtcbiAgICAgIHRoaXMudHJhaWxpbmdDUiA9IGZhbHNlO1xuICAgIH1cbiAgICBpZiAodGV4dC5lbmRzV2l0aCgnXFxyJykpIHtcbiAgICAgIHRoaXMudHJhaWxpbmdDUiA9IHRydWU7XG4gICAgICB0ZXh0ID0gdGV4dC5zbGljZSgwLCAtMSk7XG4gICAgfVxuXG4gICAgaWYgKCF0ZXh0KSB7XG4gICAgICByZXR1cm4gW107XG4gICAgfVxuXG4gICAgY29uc3QgdHJhaWxpbmdOZXdsaW5lID0gTGluZURlY29kZXIuTkVXTElORV9DSEFSUy5oYXModGV4dFt0ZXh0Lmxlbmd0aCAtIDFdIHx8ICcnKTtcbiAgICBsZXQgbGluZXMgPSB0ZXh0LnNwbGl0KExpbmVEZWNvZGVyLk5FV0xJTkVfUkVHRVhQKTtcblxuICAgIC8vIGlmIHRoZXJlIGlzIGEgdHJhaWxpbmcgbmV3IGxpbmUgdGhlbiB0aGUgbGFzdCBlbnRyeSB3aWxsIGJlIGFuIGVtcHR5XG4gICAgLy8gc3RyaW5nIHdoaWNoIHdlIGRvbid0IGNhcmUgYWJvdXRcbiAgICBpZiAodHJhaWxpbmdOZXdsaW5lKSB7XG4gICAgICBsaW5lcy5wb3AoKTtcbiAgICB9XG5cbiAgICBpZiAobGluZXMubGVuZ3RoID09PSAxICYmICF0cmFpbGluZ05ld2xpbmUpIHtcbiAgICAgIHRoaXMuYnVmZmVyLnB1c2gobGluZXNbMF0hKTtcbiAgICAgIHJldHVybiBbXTtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5idWZmZXIubGVuZ3RoID4gMCkge1xuICAgICAgbGluZXMgPSBbdGhpcy5idWZmZXIuam9pbignJykgKyBsaW5lc1swXSwgLi4ubGluZXMuc2xpY2UoMSldO1xuICAgICAgdGhpcy5idWZmZXIgPSBbXTtcbiAgICB9XG5cbiAgICBpZiAoIXRyYWlsaW5nTmV3bGluZSkge1xuICAgICAgdGhpcy5idWZmZXIgPSBbbGluZXMucG9wKCkgfHwgJyddO1xuICAgIH1cblxuICAgIHJldHVybiBsaW5lcztcbiAgfVxuXG4gIGRlY29kZVRleHQoYnl0ZXM6IEJ5dGVzKTogc3RyaW5nIHtcbiAgICBpZiAoYnl0ZXMgPT0gbnVsbCkgcmV0dXJuICcnO1xuICAgIGlmICh0eXBlb2YgYnl0ZXMgPT09ICdzdHJpbmcnKSByZXR1cm4gYnl0ZXM7XG5cbiAgICAvLyBOb2RlOlxuICAgIGlmICh0eXBlb2YgQnVmZmVyICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgaWYgKGJ5dGVzIGluc3RhbmNlb2YgQnVmZmVyKSB7XG4gICAgICAgIHJldHVybiBieXRlcy50b1N0cmluZygpO1xuICAgICAgfVxuICAgICAgaWYgKGJ5dGVzIGluc3RhbmNlb2YgVWludDhBcnJheSkge1xuICAgICAgICByZXR1cm4gQnVmZmVyLmZyb20oYnl0ZXMpLnRvU3RyaW5nKCk7XG4gICAgICB9XG5cbiAgICAgIHRocm93IG5ldyBBbnRocm9waWNFcnJvcihcbiAgICAgICAgYFVuZXhwZWN0ZWQ6IHJlY2VpdmVkIG5vbi1VaW50OEFycmF5ICgke2J5dGVzLmNvbnN0cnVjdG9yLm5hbWV9KSBzdHJlYW0gY2h1bmsgaW4gYW4gZW52aXJvbm1lbnQgd2l0aCBhIGdsb2JhbCBcIkJ1ZmZlclwiIGRlZmluZWQsIHdoaWNoIHRoaXMgbGlicmFyeSBhc3N1bWVzIHRvIGJlIE5vZGUuIFBsZWFzZSByZXBvcnQgdGhpcyBlcnJvci5gLFxuICAgICAgKTtcbiAgICB9XG5cbiAgICAvLyBCcm93c2VyXG4gICAgaWYgKHR5cGVvZiBUZXh0RGVjb2RlciAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgIGlmIChieXRlcyBpbnN0YW5jZW9mIFVpbnQ4QXJyYXkgfHwgYnl0ZXMgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlcikge1xuICAgICAgICB0aGlzLnRleHREZWNvZGVyID8/PSBuZXcgVGV4dERlY29kZXIoJ3V0ZjgnKTtcbiAgICAgICAgcmV0dXJuIHRoaXMudGV4dERlY29kZXIuZGVjb2RlKGJ5dGVzKTtcbiAgICAgIH1cblxuICAgICAgdGhyb3cgbmV3IEFudGhyb3BpY0Vycm9yKFxuICAgICAgICBgVW5leHBlY3RlZDogcmVjZWl2ZWQgbm9uLVVpbnQ4QXJyYXkvQXJyYXlCdWZmZXIgKCR7XG4gICAgICAgICAgKGJ5dGVzIGFzIGFueSkuY29uc3RydWN0b3IubmFtZVxuICAgICAgICB9KSBpbiBhIHdlYiBwbGF0Zm9ybS4gUGxlYXNlIHJlcG9ydCB0aGlzIGVycm9yLmAsXG4gICAgICApO1xuICAgIH1cblxuICAgIHRocm93IG5ldyBBbnRocm9waWNFcnJvcihcbiAgICAgIGBVbmV4cGVjdGVkOiBuZWl0aGVyIEJ1ZmZlciBub3IgVGV4dERlY29kZXIgYXJlIGF2YWlsYWJsZSBhcyBnbG9iYWxzLiBQbGVhc2UgcmVwb3J0IHRoaXMgZXJyb3IuYCxcbiAgICApO1xuICB9XG5cbiAgZmx1c2goKTogc3RyaW5nW10ge1xuICAgIGlmICghdGhpcy5idWZmZXIubGVuZ3RoICYmICF0aGlzLnRyYWlsaW5nQ1IpIHtcbiAgICAgIHJldHVybiBbXTtcbiAgICB9XG5cbiAgICBjb25zdCBsaW5lcyA9IFt0aGlzLmJ1ZmZlci5qb2luKCcnKV07XG4gICAgdGhpcy5idWZmZXIgPSBbXTtcbiAgICB0aGlzLnRyYWlsaW5nQ1IgPSBmYWxzZTtcbiAgICByZXR1cm4gbGluZXM7XG4gIH1cbn1cblxuLyoqIFRoaXMgaXMgYW4gaW50ZXJuYWwgaGVscGVyIGZ1bmN0aW9uIHRoYXQncyBqdXN0IHVzZWQgZm9yIHRlc3RpbmcgKi9cbmV4cG9ydCBmdW5jdGlvbiBfZGVjb2RlQ2h1bmtzKGNodW5rczogc3RyaW5nW10pOiBzdHJpbmdbXSB7XG4gIGNvbnN0IGRlY29kZXIgPSBuZXcgTGluZURlY29kZXIoKTtcbiAgY29uc3QgbGluZXM6IHN0cmluZ1tdID0gW107XG4gIGZvciAoY29uc3QgY2h1bmsgb2YgY2h1bmtzKSB7XG4gICAgbGluZXMucHVzaCguLi5kZWNvZGVyLmRlY29kZShjaHVuaykpO1xuICB9XG5cbiAgcmV0dXJuIGxpbmVzO1xufVxuXG5mdW5jdGlvbiBwYXJ0aXRpb24oc3RyOiBzdHJpbmcsIGRlbGltaXRlcjogc3RyaW5nKTogW3N0cmluZywgc3RyaW5nLCBzdHJpbmddIHtcbiAgY29uc3QgaW5kZXggPSBzdHIuaW5kZXhPZihkZWxpbWl0ZXIpO1xuICBpZiAoaW5kZXggIT09IC0xKSB7XG4gICAgcmV0dXJuIFtzdHIuc3Vic3RyaW5nKDAsIGluZGV4KSwgZGVsaW1pdGVyLCBzdHIuc3Vic3RyaW5nKGluZGV4ICsgZGVsaW1pdGVyLmxlbmd0aCldO1xuICB9XG5cbiAgcmV0dXJuIFtzdHIsICcnLCAnJ107XG59XG5cbi8qKlxuICogTW9zdCBicm93c2VycyBkb24ndCB5ZXQgaGF2ZSBhc3luYyBpdGVyYWJsZSBzdXBwb3J0IGZvciBSZWFkYWJsZVN0cmVhbSxcbiAqIGFuZCBOb2RlIGhhcyBhIHZlcnkgZGlmZmVyZW50IHdheSBvZiByZWFkaW5nIGJ5dGVzIGZyb20gaXRzIFwiUmVhZGFibGVTdHJlYW1cIi5cbiAqXG4gKiBUaGlzIHBvbHlmaWxsIHdhcyBwdWxsZWQgZnJvbSBodHRwczovL2dpdGh1Yi5jb20vTWF0dGlhc0J1ZWxlbnMvd2ViLXN0cmVhbXMtcG9seWZpbGwvcHVsbC8xMjIjaXNzdWVjb21tZW50LTE2MjczNTQ0OTBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHJlYWRhYmxlU3RyZWFtQXN5bmNJdGVyYWJsZTxUPihzdHJlYW06IGFueSk6IEFzeW5jSXRlcmFibGVJdGVyYXRvcjxUPiB7XG4gIGlmIChzdHJlYW1bU3ltYm9sLmFzeW5jSXRlcmF0b3JdKSByZXR1cm4gc3RyZWFtO1xuXG4gIGNvbnN0IHJlYWRlciA9IHN0cmVhbS5nZXRSZWFkZXIoKTtcbiAgcmV0dXJuIHtcbiAgICBhc3luYyBuZXh0KCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgcmVhZGVyLnJlYWQoKTtcbiAgICAgICAgaWYgKHJlc3VsdD8uZG9uZSkgcmVhZGVyLnJlbGVhc2VMb2NrKCk7IC8vIHJlbGVhc2UgbG9jayB3aGVuIHN0cmVhbSBiZWNvbWVzIGNsb3NlZFxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICByZWFkZXIucmVsZWFzZUxvY2soKTsgLy8gcmVsZWFzZSBsb2NrIHdoZW4gc3RyZWFtIGJlY29tZXMgZXJyb3JlZFxuICAgICAgICB0aHJvdyBlO1xuICAgICAgfVxuICAgIH0sXG4gICAgYXN5bmMgcmV0dXJuKCkge1xuICAgICAgY29uc3QgY2FuY2VsUHJvbWlzZSA9IHJlYWRlci5jYW5jZWwoKTtcbiAgICAgIHJlYWRlci5yZWxlYXNlTG9jaygpO1xuICAgICAgYXdhaXQgY2FuY2VsUHJvbWlzZTtcbiAgICAgIHJldHVybiB7IGRvbmU6IHRydWUsIHZhbHVlOiB1bmRlZmluZWQgfTtcbiAgICB9LFxuICAgIFtTeW1ib2wuYXN5bmNJdGVyYXRvcl0oKSB7XG4gICAgICByZXR1cm4gdGhpcztcbiAgICB9LFxuICB9O1xufVxuIiwgImltcG9ydCB7IHR5cGUgUmVxdWVzdE9wdGlvbnMgfSBmcm9tIFwiLi9jb3JlLmpzXCI7XG5pbXBvcnQge1xuICBGb3JtRGF0YSxcbiAgRmlsZSxcbiAgdHlwZSBCbG9iLFxuICB0eXBlIEZpbGVQcm9wZXJ0eUJhZyxcbiAgZ2V0TXVsdGlwYXJ0UmVxdWVzdE9wdGlvbnMsXG4gIHR5cGUgRnNSZWFkU3RyZWFtLFxuICBpc0ZzUmVhZFN0cmVhbSxcbn0gZnJvbSBcIi4vX3NoaW1zL2luZGV4LmpzXCI7XG5pbXBvcnQgeyBNdWx0aXBhcnRCb2R5IH0gZnJvbSBcIi4vX3NoaW1zL011bHRpcGFydEJvZHkuanNcIjtcbmV4cG9ydCB7IGZpbGVGcm9tUGF0aCB9IGZyb20gXCIuL19zaGltcy9pbmRleC5qc1wiO1xuXG50eXBlIEJsb2JMaWtlUGFydCA9IHN0cmluZyB8IEFycmF5QnVmZmVyIHwgQXJyYXlCdWZmZXJWaWV3IHwgQmxvYkxpa2UgfCBVaW50OEFycmF5IHwgRGF0YVZpZXc7XG5leHBvcnQgdHlwZSBCbG9iUGFydCA9IHN0cmluZyB8IEFycmF5QnVmZmVyIHwgQXJyYXlCdWZmZXJWaWV3IHwgQmxvYiB8IFVpbnQ4QXJyYXkgfCBEYXRhVmlldztcblxuLyoqXG4gKiBUeXBpY2FsbHksIHRoaXMgaXMgYSBuYXRpdmUgXCJGaWxlXCIgY2xhc3MuXG4gKlxuICogV2UgcHJvdmlkZSB0aGUge0BsaW5rIHRvRmlsZX0gdXRpbGl0eSB0byBjb252ZXJ0IGEgdmFyaWV0eSBvZiBvYmplY3RzXG4gKiBpbnRvIHRoZSBGaWxlIGNsYXNzLlxuICpcbiAqIEZvciBjb252ZW5pZW5jZSwgeW91IGNhbiBhbHNvIHBhc3MgYSBmZXRjaCBSZXNwb25zZSwgb3IgaW4gTm9kZSxcbiAqIHRoZSByZXN1bHQgb2YgZnMuY3JlYXRlUmVhZFN0cmVhbSgpLlxuICovXG5leHBvcnQgdHlwZSBVcGxvYWRhYmxlID0gRmlsZUxpa2UgfCBSZXNwb25zZUxpa2UgfCBGc1JlYWRTdHJlYW07XG5cbi8qKlxuICogSW50ZW5kZWQgdG8gbWF0Y2ggd2ViLkJsb2IsIG5vZGUuQmxvYiwgbm9kZS1mZXRjaC5CbG9iLCBldGMuXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgQmxvYkxpa2Uge1xuICAvKiogW01ETiBSZWZlcmVuY2VdKGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2RvY3MvV2ViL0FQSS9CbG9iL3NpemUpICovXG4gIHJlYWRvbmx5IHNpemU6IG51bWJlcjtcbiAgLyoqIFtNRE4gUmVmZXJlbmNlXShodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9kb2NzL1dlYi9BUEkvQmxvYi90eXBlKSAqL1xuICByZWFkb25seSB0eXBlOiBzdHJpbmc7XG4gIC8qKiBbTUROIFJlZmVyZW5jZV0oaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZG9jcy9XZWIvQVBJL0Jsb2IvdGV4dCkgKi9cbiAgdGV4dCgpOiBQcm9taXNlPHN0cmluZz47XG4gIC8qKiBbTUROIFJlZmVyZW5jZV0oaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZG9jcy9XZWIvQVBJL0Jsb2Ivc2xpY2UpICovXG4gIHNsaWNlKHN0YXJ0PzogbnVtYmVyLCBlbmQ/OiBudW1iZXIpOiBCbG9iTGlrZTtcbiAgLy8gdW5mb3J0dW5hdGVseSBAdHlwZXMvbm9kZS1mZXRjaEBeMi42LjQgZG9lc24ndCB0eXBlIHRoZSBhcnJheUJ1ZmZlciBtZXRob2Rcbn1cblxuLyoqXG4gKiBJbnRlbmRlZCB0byBtYXRjaCB3ZWIuRmlsZSwgbm9kZS5GaWxlLCBub2RlLWZldGNoLkZpbGUsIGV0Yy5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBGaWxlTGlrZSBleHRlbmRzIEJsb2JMaWtlIHtcbiAgLyoqIFtNRE4gUmVmZXJlbmNlXShodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9kb2NzL1dlYi9BUEkvRmlsZS9sYXN0TW9kaWZpZWQpICovXG4gIHJlYWRvbmx5IGxhc3RNb2RpZmllZDogbnVtYmVyO1xuICAvKiogW01ETiBSZWZlcmVuY2VdKGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2RvY3MvV2ViL0FQSS9GaWxlL25hbWUpICovXG4gIHJlYWRvbmx5IG5hbWU6IHN0cmluZztcbn1cblxuLyoqXG4gKiBJbnRlbmRlZCB0byBtYXRjaCB3ZWIuUmVzcG9uc2UsIG5vZGUuUmVzcG9uc2UsIG5vZGUtZmV0Y2guUmVzcG9uc2UsIGV0Yy5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBSZXNwb25zZUxpa2Uge1xuICB1cmw6IHN0cmluZztcbiAgYmxvYigpOiBQcm9taXNlPEJsb2JMaWtlPjtcbn1cblxuZXhwb3J0IGNvbnN0IGlzUmVzcG9uc2VMaWtlID0gKHZhbHVlOiBhbnkpOiB2YWx1ZSBpcyBSZXNwb25zZUxpa2UgPT5cbiAgdmFsdWUgIT0gbnVsbCAmJlxuICB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmXG4gIHR5cGVvZiB2YWx1ZS51cmwgPT09ICdzdHJpbmcnICYmXG4gIHR5cGVvZiB2YWx1ZS5ibG9iID09PSAnZnVuY3Rpb24nO1xuXG5leHBvcnQgY29uc3QgaXNGaWxlTGlrZSA9ICh2YWx1ZTogYW55KTogdmFsdWUgaXMgRmlsZUxpa2UgPT5cbiAgdmFsdWUgIT0gbnVsbCAmJlxuICB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmXG4gIHR5cGVvZiB2YWx1ZS5uYW1lID09PSAnc3RyaW5nJyAmJlxuICB0eXBlb2YgdmFsdWUubGFzdE1vZGlmaWVkID09PSAnbnVtYmVyJyAmJlxuICBpc0Jsb2JMaWtlKHZhbHVlKTtcblxuLyoqXG4gKiBUaGUgQmxvYkxpa2UgdHlwZSBvbWl0cyBhcnJheUJ1ZmZlcigpIGJlY2F1c2UgQHR5cGVzL25vZGUtZmV0Y2hAXjIuNi40IGxhY2tzIGl0OyBidXQgdGhpcyBjaGVja1xuICogYWRkcyB0aGUgYXJyYXlCdWZmZXIoKSBtZXRob2QgdHlwZSBiZWNhdXNlIGl0IGlzIGF2YWlsYWJsZSBhbmQgdXNlZCBhdCBydW50aW1lXG4gKi9cbmV4cG9ydCBjb25zdCBpc0Jsb2JMaWtlID0gKHZhbHVlOiBhbnkpOiB2YWx1ZSBpcyBCbG9iTGlrZSAmIHsgYXJyYXlCdWZmZXIoKTogUHJvbWlzZTxBcnJheUJ1ZmZlcj4gfSA9PlxuICB2YWx1ZSAhPSBudWxsICYmXG4gIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiZcbiAgdHlwZW9mIHZhbHVlLnNpemUgPT09ICdudW1iZXInICYmXG4gIHR5cGVvZiB2YWx1ZS50eXBlID09PSAnc3RyaW5nJyAmJlxuICB0eXBlb2YgdmFsdWUudGV4dCA9PT0gJ2Z1bmN0aW9uJyAmJlxuICB0eXBlb2YgdmFsdWUuc2xpY2UgPT09ICdmdW5jdGlvbicgJiZcbiAgdHlwZW9mIHZhbHVlLmFycmF5QnVmZmVyID09PSAnZnVuY3Rpb24nO1xuXG5leHBvcnQgY29uc3QgaXNVcGxvYWRhYmxlID0gKHZhbHVlOiBhbnkpOiB2YWx1ZSBpcyBVcGxvYWRhYmxlID0+IHtcbiAgcmV0dXJuIGlzRmlsZUxpa2UodmFsdWUpIHx8IGlzUmVzcG9uc2VMaWtlKHZhbHVlKSB8fCBpc0ZzUmVhZFN0cmVhbSh2YWx1ZSk7XG59O1xuXG5leHBvcnQgdHlwZSBUb0ZpbGVJbnB1dCA9IFVwbG9hZGFibGUgfCBFeGNsdWRlPEJsb2JMaWtlUGFydCwgc3RyaW5nPiB8IEFzeW5jSXRlcmFibGU8QmxvYkxpa2VQYXJ0PjtcblxuLyoqXG4gKiBIZWxwZXIgZm9yIGNyZWF0aW5nIGEge0BsaW5rIEZpbGV9IHRvIHBhc3MgdG8gYW4gU0RLIHVwbG9hZCBtZXRob2QgZnJvbSBhIHZhcmlldHkgb2YgZGlmZmVyZW50IGRhdGEgZm9ybWF0c1xuICogQHBhcmFtIHZhbHVlIHRoZSByYXcgY29udGVudCBvZiB0aGUgZmlsZS4gIENhbiBiZSBhbiB7QGxpbmsgVXBsb2FkYWJsZX0sIHtAbGluayBCbG9iTGlrZVBhcnR9LCBvciB7QGxpbmsgQXN5bmNJdGVyYWJsZX0gb2Yge0BsaW5rIEJsb2JMaWtlUGFydH1zXG4gKiBAcGFyYW0ge3N0cmluZz19IG5hbWUgdGhlIG5hbWUgb2YgdGhlIGZpbGUuIElmIG9taXR0ZWQsIHRvRmlsZSB3aWxsIHRyeSB0byBkZXRlcm1pbmUgYSBmaWxlIG5hbWUgZnJvbSBiaXRzIGlmIHBvc3NpYmxlXG4gKiBAcGFyYW0ge09iamVjdD19IG9wdGlvbnMgYWRkaXRpb25hbCBwcm9wZXJ0aWVzXG4gKiBAcGFyYW0ge3N0cmluZz19IG9wdGlvbnMudHlwZSB0aGUgTUlNRSB0eXBlIG9mIHRoZSBjb250ZW50XG4gKiBAcGFyYW0ge251bWJlcj19IG9wdGlvbnMubGFzdE1vZGlmaWVkIHRoZSBsYXN0IG1vZGlmaWVkIHRpbWVzdGFtcFxuICogQHJldHVybnMgYSB7QGxpbmsgRmlsZX0gd2l0aCB0aGUgZ2l2ZW4gcHJvcGVydGllc1xuICovXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gdG9GaWxlKFxuICB2YWx1ZTogVG9GaWxlSW5wdXQgfCBQcm9taXNlTGlrZTxUb0ZpbGVJbnB1dD4sXG4gIG5hbWU/OiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkLFxuICBvcHRpb25zPzogRmlsZVByb3BlcnR5QmFnIHwgdW5kZWZpbmVkLFxuKTogUHJvbWlzZTxGaWxlTGlrZT4ge1xuICAvLyBJZiBpdCdzIGEgcHJvbWlzZSwgcmVzb2x2ZSBpdC5cbiAgdmFsdWUgPSBhd2FpdCB2YWx1ZTtcblxuICAvLyBJZiB3ZSd2ZSBiZWVuIGdpdmVuIGEgYEZpbGVgIHdlIGRvbid0IG5lZWQgdG8gZG8gYW55dGhpbmdcbiAgaWYgKGlzRmlsZUxpa2UodmFsdWUpKSB7XG4gICAgcmV0dXJuIHZhbHVlO1xuICB9XG5cbiAgaWYgKGlzUmVzcG9uc2VMaWtlKHZhbHVlKSkge1xuICAgIGNvbnN0IGJsb2IgPSBhd2FpdCB2YWx1ZS5ibG9iKCk7XG4gICAgbmFtZSB8fD0gbmV3IFVSTCh2YWx1ZS51cmwpLnBhdGhuYW1lLnNwbGl0KC9bXFxcXC9dLykucG9wKCkgPz8gJ3Vua25vd25fZmlsZSc7XG5cbiAgICAvLyB3ZSBuZWVkIHRvIGNvbnZlcnQgdGhlIGBCbG9iYCBpbnRvIGFuIGFycmF5IGJ1ZmZlciBiZWNhdXNlIHRoZSBgQmxvYmAgY2xhc3NcbiAgICAvLyB0aGF0IGBub2RlLWZldGNoYCBkZWZpbmVzIGlzIGluY29tcGF0aWJsZSB3aXRoIHRoZSB3ZWIgc3RhbmRhcmQgd2hpY2ggcmVzdWx0c1xuICAgIC8vIGluIGBuZXcgRmlsZWAgaW50ZXJwcmV0aW5nIGl0IGFzIGEgc3RyaW5nIGluc3RlYWQgb2YgYmluYXJ5IGRhdGEuXG4gICAgY29uc3QgZGF0YSA9IGlzQmxvYkxpa2UoYmxvYikgPyBbKGF3YWl0IGJsb2IuYXJyYXlCdWZmZXIoKSkgYXMgYW55XSA6IFtibG9iXTtcblxuICAgIHJldHVybiBuZXcgRmlsZShkYXRhLCBuYW1lLCBvcHRpb25zKTtcbiAgfVxuXG4gIGNvbnN0IGJpdHMgPSBhd2FpdCBnZXRCeXRlcyh2YWx1ZSk7XG5cbiAgbmFtZSB8fD0gZ2V0TmFtZSh2YWx1ZSkgPz8gJ3Vua25vd25fZmlsZSc7XG5cbiAgaWYgKCFvcHRpb25zPy50eXBlKSB7XG4gICAgY29uc3QgdHlwZSA9IChiaXRzWzBdIGFzIGFueSk/LnR5cGU7XG4gICAgaWYgKHR5cGVvZiB0eXBlID09PSAnc3RyaW5nJykge1xuICAgICAgb3B0aW9ucyA9IHsgLi4ub3B0aW9ucywgdHlwZSB9O1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiBuZXcgRmlsZShiaXRzLCBuYW1lLCBvcHRpb25zKTtcbn1cblxuYXN5bmMgZnVuY3Rpb24gZ2V0Qnl0ZXModmFsdWU6IFRvRmlsZUlucHV0KTogUHJvbWlzZTxBcnJheTxCbG9iUGFydD4+IHtcbiAgbGV0IHBhcnRzOiBBcnJheTxCbG9iUGFydD4gPSBbXTtcbiAgaWYgKFxuICAgIHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgfHxcbiAgICBBcnJheUJ1ZmZlci5pc1ZpZXcodmFsdWUpIHx8IC8vIGluY2x1ZGVzIFVpbnQ4QXJyYXksIEJ1ZmZlciwgZXRjLlxuICAgIHZhbHVlIGluc3RhbmNlb2YgQXJyYXlCdWZmZXJcbiAgKSB7XG4gICAgcGFydHMucHVzaCh2YWx1ZSk7XG4gIH0gZWxzZSBpZiAoaXNCbG9iTGlrZSh2YWx1ZSkpIHtcbiAgICBwYXJ0cy5wdXNoKGF3YWl0IHZhbHVlLmFycmF5QnVmZmVyKCkpO1xuICB9IGVsc2UgaWYgKFxuICAgIGlzQXN5bmNJdGVyYWJsZUl0ZXJhdG9yKHZhbHVlKSAvLyBpbmNsdWRlcyBSZWFkYWJsZSwgUmVhZGFibGVTdHJlYW0sIGV0Yy5cbiAgKSB7XG4gICAgZm9yIGF3YWl0IChjb25zdCBjaHVuayBvZiB2YWx1ZSkge1xuICAgICAgcGFydHMucHVzaChjaHVuayBhcyBCbG9iUGFydCk7IC8vIFRPRE8sIGNvbnNpZGVyIHZhbGlkYXRpbmc/XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgIGBVbmV4cGVjdGVkIGRhdGEgdHlwZTogJHt0eXBlb2YgdmFsdWV9OyBjb25zdHJ1Y3RvcjogJHt2YWx1ZT8uY29uc3RydWN0b3JcbiAgICAgICAgPy5uYW1lfTsgcHJvcHM6ICR7cHJvcHNGb3JFcnJvcih2YWx1ZSl9YCxcbiAgICApO1xuICB9XG5cbiAgcmV0dXJuIHBhcnRzO1xufVxuXG5mdW5jdGlvbiBwcm9wc0ZvckVycm9yKHZhbHVlOiBhbnkpOiBzdHJpbmcge1xuICBjb25zdCBwcm9wcyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKHZhbHVlKTtcbiAgcmV0dXJuIGBbJHtwcm9wcy5tYXAoKHApID0+IGBcIiR7cH1cImApLmpvaW4oJywgJyl9XWA7XG59XG5cbmZ1bmN0aW9uIGdldE5hbWUodmFsdWU6IGFueSk6IHN0cmluZyB8IHVuZGVmaW5lZCB7XG4gIHJldHVybiAoXG4gICAgZ2V0U3RyaW5nRnJvbU1heWJlQnVmZmVyKHZhbHVlLm5hbWUpIHx8XG4gICAgZ2V0U3RyaW5nRnJvbU1heWJlQnVmZmVyKHZhbHVlLmZpbGVuYW1lKSB8fFxuICAgIC8vIEZvciBmcy5SZWFkU3RyZWFtXG4gICAgZ2V0U3RyaW5nRnJvbU1heWJlQnVmZmVyKHZhbHVlLnBhdGgpPy5zcGxpdCgvW1xcXFwvXS8pLnBvcCgpXG4gICk7XG59XG5cbmNvbnN0IGdldFN0cmluZ0Zyb21NYXliZUJ1ZmZlciA9ICh4OiBzdHJpbmcgfCBCdWZmZXIgfCB1bmtub3duKTogc3RyaW5nIHwgdW5kZWZpbmVkID0+IHtcbiAgaWYgKHR5cGVvZiB4ID09PSAnc3RyaW5nJykgcmV0dXJuIHg7XG4gIGlmICh0eXBlb2YgQnVmZmVyICE9PSAndW5kZWZpbmVkJyAmJiB4IGluc3RhbmNlb2YgQnVmZmVyKSByZXR1cm4gU3RyaW5nKHgpO1xuICByZXR1cm4gdW5kZWZpbmVkO1xufTtcblxuY29uc3QgaXNBc3luY0l0ZXJhYmxlSXRlcmF0b3IgPSAodmFsdWU6IGFueSk6IHZhbHVlIGlzIEFzeW5jSXRlcmFibGVJdGVyYXRvcjx1bmtub3duPiA9PlxuICB2YWx1ZSAhPSBudWxsICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgdHlwZW9mIHZhbHVlW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSA9PT0gJ2Z1bmN0aW9uJztcblxuZXhwb3J0IGNvbnN0IGlzTXVsdGlwYXJ0Qm9keSA9IChib2R5OiBhbnkpOiBib2R5IGlzIE11bHRpcGFydEJvZHkgPT5cbiAgYm9keSAmJiB0eXBlb2YgYm9keSA9PT0gJ29iamVjdCcgJiYgYm9keS5ib2R5ICYmIGJvZHlbU3ltYm9sLnRvU3RyaW5nVGFnXSA9PT0gJ011bHRpcGFydEJvZHknO1xuXG4vKipcbiAqIFJldHVybnMgYSBtdWx0aXBhcnQvZm9ybS1kYXRhIHJlcXVlc3QgaWYgYW55IHBhcnQgb2YgdGhlIGdpdmVuIHJlcXVlc3QgYm9keSBjb250YWlucyBhIEZpbGUgLyBCbG9iIHZhbHVlLlxuICogT3RoZXJ3aXNlIHJldHVybnMgdGhlIHJlcXVlc3QgYXMgaXMuXG4gKi9cbmV4cG9ydCBjb25zdCBtYXliZU11bHRpcGFydEZvcm1SZXF1ZXN0T3B0aW9ucyA9IGFzeW5jIDxUID0gUmVjb3JkPHN0cmluZywgdW5rbm93bj4+KFxuICBvcHRzOiBSZXF1ZXN0T3B0aW9uczxUPixcbik6IFByb21pc2U8UmVxdWVzdE9wdGlvbnM8VCB8IE11bHRpcGFydEJvZHk+PiA9PiB7XG4gIGlmICghaGFzVXBsb2FkYWJsZVZhbHVlKG9wdHMuYm9keSkpIHJldHVybiBvcHRzO1xuXG4gIGNvbnN0IGZvcm0gPSBhd2FpdCBjcmVhdGVGb3JtKG9wdHMuYm9keSk7XG4gIHJldHVybiBnZXRNdWx0aXBhcnRSZXF1ZXN0T3B0aW9ucyhmb3JtLCBvcHRzKTtcbn07XG5cbmV4cG9ydCBjb25zdCBtdWx0aXBhcnRGb3JtUmVxdWVzdE9wdGlvbnMgPSBhc3luYyA8VCA9IFJlY29yZDxzdHJpbmcsIHVua25vd24+PihcbiAgb3B0czogUmVxdWVzdE9wdGlvbnM8VD4sXG4pOiBQcm9taXNlPFJlcXVlc3RPcHRpb25zPFQgfCBNdWx0aXBhcnRCb2R5Pj4gPT4ge1xuICBjb25zdCBmb3JtID0gYXdhaXQgY3JlYXRlRm9ybShvcHRzLmJvZHkpO1xuICByZXR1cm4gZ2V0TXVsdGlwYXJ0UmVxdWVzdE9wdGlvbnMoZm9ybSwgb3B0cyk7XG59O1xuXG5leHBvcnQgY29uc3QgY3JlYXRlRm9ybSA9IGFzeW5jIDxUID0gUmVjb3JkPHN0cmluZywgdW5rbm93bj4+KGJvZHk6IFQgfCB1bmRlZmluZWQpOiBQcm9taXNlPEZvcm1EYXRhPiA9PiB7XG4gIGNvbnN0IGZvcm0gPSBuZXcgRm9ybURhdGEoKTtcbiAgYXdhaXQgUHJvbWlzZS5hbGwoT2JqZWN0LmVudHJpZXMoYm9keSB8fCB7fSkubWFwKChba2V5LCB2YWx1ZV0pID0+IGFkZEZvcm1WYWx1ZShmb3JtLCBrZXksIHZhbHVlKSkpO1xuICByZXR1cm4gZm9ybTtcbn07XG5cbmNvbnN0IGhhc1VwbG9hZGFibGVWYWx1ZSA9ICh2YWx1ZTogdW5rbm93bik6IGJvb2xlYW4gPT4ge1xuICBpZiAoaXNVcGxvYWRhYmxlKHZhbHVlKSkgcmV0dXJuIHRydWU7XG4gIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkgcmV0dXJuIHZhbHVlLnNvbWUoaGFzVXBsb2FkYWJsZVZhbHVlKTtcbiAgaWYgKHZhbHVlICYmIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcpIHtcbiAgICBmb3IgKGNvbnN0IGsgaW4gdmFsdWUpIHtcbiAgICAgIGlmIChoYXNVcGxvYWRhYmxlVmFsdWUoKHZhbHVlIGFzIGFueSlba10pKSByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gIH1cbiAgcmV0dXJuIGZhbHNlO1xufTtcblxuY29uc3QgYWRkRm9ybVZhbHVlID0gYXN5bmMgKGZvcm06IEZvcm1EYXRhLCBrZXk6IHN0cmluZywgdmFsdWU6IHVua25vd24pOiBQcm9taXNlPHZvaWQ+ID0+IHtcbiAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHJldHVybjtcbiAgaWYgKHZhbHVlID09IG51bGwpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFxuICAgICAgYFJlY2VpdmVkIG51bGwgZm9yIFwiJHtrZXl9XCI7IHRvIHBhc3MgbnVsbCBpbiBGb3JtRGF0YSwgeW91IG11c3QgdXNlIHRoZSBzdHJpbmcgJ251bGwnYCxcbiAgICApO1xuICB9XG5cbiAgLy8gVE9ETzogbWFrZSBuZXN0ZWQgZm9ybWF0cyBjb25maWd1cmFibGVcbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycgfHwgdHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJyB8fCB0eXBlb2YgdmFsdWUgPT09ICdib29sZWFuJykge1xuICAgIGZvcm0uYXBwZW5kKGtleSwgU3RyaW5nKHZhbHVlKSk7XG4gIH0gZWxzZSBpZiAoaXNVcGxvYWRhYmxlKHZhbHVlKSkge1xuICAgIGNvbnN0IGZpbGUgPSBhd2FpdCB0b0ZpbGUodmFsdWUpO1xuICAgIGZvcm0uYXBwZW5kKGtleSwgZmlsZSBhcyBGaWxlKTtcbiAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSkge1xuICAgIGF3YWl0IFByb21pc2UuYWxsKHZhbHVlLm1hcCgoZW50cnkpID0+IGFkZEZvcm1WYWx1ZShmb3JtLCBrZXkgKyAnW10nLCBlbnRyeSkpKTtcbiAgfSBlbHNlIGlmICh0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnKSB7XG4gICAgYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgICBPYmplY3QuZW50cmllcyh2YWx1ZSkubWFwKChbbmFtZSwgcHJvcF0pID0+IGFkZEZvcm1WYWx1ZShmb3JtLCBgJHtrZXl9WyR7bmFtZX1dYCwgcHJvcCkpLFxuICAgICk7XG4gIH0gZWxzZSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcbiAgICAgIGBJbnZhbGlkIHZhbHVlIGdpdmVuIHRvIGZvcm0sIGV4cGVjdGVkIGEgc3RyaW5nLCBudW1iZXIsIGJvb2xlYW4sIG9iamVjdCwgQXJyYXksIEZpbGUgb3IgQmxvYiBidXQgZ290ICR7dmFsdWV9IGluc3RlYWRgLFxuICAgICk7XG4gIH1cbn07XG4iLCAiaW1wb3J0IHsgVkVSU0lPTiB9IGZyb20gXCIuL3ZlcnNpb24uanNcIjtcbmltcG9ydCB7IFN0cmVhbSB9IGZyb20gXCIuL3N0cmVhbWluZy5qc1wiO1xuaW1wb3J0IHtcbiAgQW50aHJvcGljRXJyb3IsXG4gIEFQSUVycm9yLFxuICBBUElDb25uZWN0aW9uRXJyb3IsXG4gIEFQSUNvbm5lY3Rpb25UaW1lb3V0RXJyb3IsXG4gIEFQSVVzZXJBYm9ydEVycm9yLFxufSBmcm9tIFwiLi9lcnJvci5qc1wiO1xuaW1wb3J0IHtcbiAga2luZCBhcyBzaGltc0tpbmQsXG4gIHR5cGUgUmVhZGFibGUsXG4gIGdldERlZmF1bHRBZ2VudCxcbiAgdHlwZSBBZ2VudCxcbiAgZmV0Y2gsXG4gIHR5cGUgUmVxdWVzdEluZm8sXG4gIHR5cGUgUmVxdWVzdEluaXQsXG4gIHR5cGUgUmVzcG9uc2UsXG4gIHR5cGUgSGVhZGVyc0luaXQsXG59IGZyb20gXCIuL19zaGltcy9pbmRleC5qc1wiO1xuZXhwb3J0IHsgdHlwZSBSZXNwb25zZSB9O1xuaW1wb3J0IHsgQmxvYkxpa2UsIGlzQmxvYkxpa2UsIGlzTXVsdGlwYXJ0Qm9keSB9IGZyb20gXCIuL3VwbG9hZHMuanNcIjtcbmV4cG9ydCB7XG4gIG1heWJlTXVsdGlwYXJ0Rm9ybVJlcXVlc3RPcHRpb25zLFxuICBtdWx0aXBhcnRGb3JtUmVxdWVzdE9wdGlvbnMsXG4gIGNyZWF0ZUZvcm0sXG4gIHR5cGUgVXBsb2FkYWJsZSxcbn0gZnJvbSBcIi4vdXBsb2Fkcy5qc1wiO1xuXG5leHBvcnQgdHlwZSBGZXRjaCA9ICh1cmw6IFJlcXVlc3RJbmZvLCBpbml0PzogUmVxdWVzdEluaXQpID0+IFByb21pc2U8UmVzcG9uc2U+O1xuXG50eXBlIFByb21pc2VPclZhbHVlPFQ+ID0gVCB8IFByb21pc2U8VD47XG5cbnR5cGUgQVBJUmVzcG9uc2VQcm9wcyA9IHtcbiAgcmVzcG9uc2U6IFJlc3BvbnNlO1xuICBvcHRpb25zOiBGaW5hbFJlcXVlc3RPcHRpb25zO1xuICBjb250cm9sbGVyOiBBYm9ydENvbnRyb2xsZXI7XG59O1xuXG5hc3luYyBmdW5jdGlvbiBkZWZhdWx0UGFyc2VSZXNwb25zZTxUPihwcm9wczogQVBJUmVzcG9uc2VQcm9wcyk6IFByb21pc2U8VD4ge1xuICBjb25zdCB7IHJlc3BvbnNlIH0gPSBwcm9wcztcbiAgaWYgKHByb3BzLm9wdGlvbnMuc3RyZWFtKSB7XG4gICAgZGVidWcoJ3Jlc3BvbnNlJywgcmVzcG9uc2Uuc3RhdHVzLCByZXNwb25zZS51cmwsIHJlc3BvbnNlLmhlYWRlcnMsIHJlc3BvbnNlLmJvZHkpO1xuXG4gICAgLy8gTm90ZTogdGhlcmUgaXMgYW4gaW52YXJpYW50IGhlcmUgdGhhdCBpc24ndCByZXByZXNlbnRlZCBpbiB0aGUgdHlwZSBzeXN0ZW1cbiAgICAvLyB0aGF0IGlmIHlvdSBzZXQgYHN0cmVhbTogdHJ1ZWAgdGhlIHJlc3BvbnNlIHR5cGUgbXVzdCBhbHNvIGJlIGBTdHJlYW08VD5gXG5cbiAgICBpZiAocHJvcHMub3B0aW9ucy5fX3N0cmVhbUNsYXNzKSB7XG4gICAgICByZXR1cm4gcHJvcHMub3B0aW9ucy5fX3N0cmVhbUNsYXNzLmZyb21TU0VSZXNwb25zZShyZXNwb25zZSwgcHJvcHMuY29udHJvbGxlcikgYXMgYW55O1xuICAgIH1cblxuICAgIHJldHVybiBTdHJlYW0uZnJvbVNTRVJlc3BvbnNlKHJlc3BvbnNlLCBwcm9wcy5jb250cm9sbGVyKSBhcyBhbnk7XG4gIH1cblxuICAvLyBmZXRjaCByZWZ1c2VzIHRvIHJlYWQgdGhlIGJvZHkgd2hlbiB0aGUgc3RhdHVzIGNvZGUgaXMgMjA0LlxuICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSAyMDQpIHtcbiAgICByZXR1cm4gbnVsbCBhcyBUO1xuICB9XG5cbiAgaWYgKHByb3BzLm9wdGlvbnMuX19iaW5hcnlSZXNwb25zZSkge1xuICAgIHJldHVybiByZXNwb25zZSBhcyB1bmtub3duIGFzIFQ7XG4gIH1cblxuICBjb25zdCBjb250ZW50VHlwZSA9IHJlc3BvbnNlLmhlYWRlcnMuZ2V0KCdjb250ZW50LXR5cGUnKTtcbiAgY29uc3QgaXNKU09OID1cbiAgICBjb250ZW50VHlwZT8uaW5jbHVkZXMoJ2FwcGxpY2F0aW9uL2pzb24nKSB8fCBjb250ZW50VHlwZT8uaW5jbHVkZXMoJ2FwcGxpY2F0aW9uL3ZuZC5hcGkranNvbicpO1xuICBpZiAoaXNKU09OKSB7XG4gICAgY29uc3QganNvbiA9IGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcblxuICAgIGRlYnVnKCdyZXNwb25zZScsIHJlc3BvbnNlLnN0YXR1cywgcmVzcG9uc2UudXJsLCByZXNwb25zZS5oZWFkZXJzLCBqc29uKTtcblxuICAgIHJldHVybiBqc29uIGFzIFQ7XG4gIH1cblxuICBjb25zdCB0ZXh0ID0gYXdhaXQgcmVzcG9uc2UudGV4dCgpO1xuICBkZWJ1ZygncmVzcG9uc2UnLCByZXNwb25zZS5zdGF0dXMsIHJlc3BvbnNlLnVybCwgcmVzcG9uc2UuaGVhZGVycywgdGV4dCk7XG5cbiAgLy8gVE9ETyBoYW5kbGUgYmxvYiwgYXJyYXlidWZmZXIsIG90aGVyIGNvbnRlbnQgdHlwZXMsIGV0Yy5cbiAgcmV0dXJuIHRleHQgYXMgdW5rbm93biBhcyBUO1xufVxuXG4vKipcbiAqIEEgc3ViY2xhc3Mgb2YgYFByb21pc2VgIHByb3ZpZGluZyBhZGRpdGlvbmFsIGhlbHBlciBtZXRob2RzXG4gKiBmb3IgaW50ZXJhY3Rpbmcgd2l0aCB0aGUgU0RLLlxuICovXG5leHBvcnQgY2xhc3MgQVBJUHJvbWlzZTxUPiBleHRlbmRzIFByb21pc2U8VD4ge1xuICBwcml2YXRlIHBhcnNlZFByb21pc2U6IFByb21pc2U8VD4gfCB1bmRlZmluZWQ7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgcHJpdmF0ZSByZXNwb25zZVByb21pc2U6IFByb21pc2U8QVBJUmVzcG9uc2VQcm9wcz4sXG4gICAgcHJpdmF0ZSBwYXJzZVJlc3BvbnNlOiAocHJvcHM6IEFQSVJlc3BvbnNlUHJvcHMpID0+IFByb21pc2VPclZhbHVlPFQ+ID0gZGVmYXVsdFBhcnNlUmVzcG9uc2UsXG4gICkge1xuICAgIHN1cGVyKChyZXNvbHZlKSA9PiB7XG4gICAgICAvLyB0aGlzIGlzIG1heWJlIGEgYml0IHdlaXJkIGJ1dCB0aGlzIGhhcyB0byBiZSBhIG5vLW9wIHRvIG5vdCBpbXBsaWNpdGx5XG4gICAgICAvLyBwYXJzZSB0aGUgcmVzcG9uc2UgYm9keTsgaW5zdGVhZCAudGhlbiwgLmNhdGNoLCAuZmluYWxseSBhcmUgb3ZlcnJpZGRlblxuICAgICAgLy8gdG8gcGFyc2UgdGhlIHJlc3BvbnNlXG4gICAgICByZXNvbHZlKG51bGwgYXMgYW55KTtcbiAgICB9KTtcbiAgfVxuXG4gIF90aGVuVW53cmFwPFU+KHRyYW5zZm9ybTogKGRhdGE6IFQpID0+IFUpOiBBUElQcm9taXNlPFU+IHtcbiAgICByZXR1cm4gbmV3IEFQSVByb21pc2UodGhpcy5yZXNwb25zZVByb21pc2UsIGFzeW5jIChwcm9wcykgPT4gdHJhbnNmb3JtKGF3YWl0IHRoaXMucGFyc2VSZXNwb25zZShwcm9wcykpKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXRzIHRoZSByYXcgYFJlc3BvbnNlYCBpbnN0YW5jZSBpbnN0ZWFkIG9mIHBhcnNpbmcgdGhlIHJlc3BvbnNlXG4gICAqIGRhdGEuXG4gICAqXG4gICAqIElmIHlvdSB3YW50IHRvIHBhcnNlIHRoZSByZXNwb25zZSBib2R5IGJ1dCBzdGlsbCBnZXQgdGhlIGBSZXNwb25zZWBcbiAgICogaW5zdGFuY2UsIHlvdSBjYW4gdXNlIHtAbGluayB3aXRoUmVzcG9uc2UoKX0uXG4gICAqXG4gICAqIFx1RDgzRFx1REM0QiBHZXR0aW5nIHRoZSB3cm9uZyBUeXBlU2NyaXB0IHR5cGUgZm9yIGBSZXNwb25zZWA/XG4gICAqIFRyeSBzZXR0aW5nIGBcIm1vZHVsZVJlc29sdXRpb25cIjogXCJOb2RlTmV4dFwiYCBpZiB5b3UgY2FuLFxuICAgKiBvciBhZGQgb25lIG9mIHRoZXNlIGltcG9ydHMgYmVmb3JlIHlvdXIgZmlyc3QgYGltcG9ydCBcdTIwMjYgZnJvbSAnQGFudGhyb3BpYy1haS9zZGsnYDpcbiAgICogLSBgaW1wb3J0ICdAYW50aHJvcGljLWFpL3Nkay9zaGltcy9ub2RlJ2AgKGlmIHlvdSdyZSBydW5uaW5nIG9uIE5vZGUpXG4gICAqIC0gYGltcG9ydCAnQGFudGhyb3BpYy1haS9zZGsvc2hpbXMvd2ViJ2AgKG90aGVyd2lzZSlcbiAgICovXG4gIGFzUmVzcG9uc2UoKTogUHJvbWlzZTxSZXNwb25zZT4ge1xuICAgIHJldHVybiB0aGlzLnJlc3BvbnNlUHJvbWlzZS50aGVuKChwKSA9PiBwLnJlc3BvbnNlKTtcbiAgfVxuICAvKipcbiAgICogR2V0cyB0aGUgcGFyc2VkIHJlc3BvbnNlIGRhdGEgYW5kIHRoZSByYXcgYFJlc3BvbnNlYCBpbnN0YW5jZS5cbiAgICpcbiAgICogSWYgeW91IGp1c3Qgd2FudCB0byBnZXQgdGhlIHJhdyBgUmVzcG9uc2VgIGluc3RhbmNlIHdpdGhvdXQgcGFyc2luZyBpdCxcbiAgICogeW91IGNhbiB1c2Uge0BsaW5rIGFzUmVzcG9uc2UoKX0uXG4gICAqXG4gICAqXG4gICAqIFx1RDgzRFx1REM0QiBHZXR0aW5nIHRoZSB3cm9uZyBUeXBlU2NyaXB0IHR5cGUgZm9yIGBSZXNwb25zZWA/XG4gICAqIFRyeSBzZXR0aW5nIGBcIm1vZHVsZVJlc29sdXRpb25cIjogXCJOb2RlTmV4dFwiYCBpZiB5b3UgY2FuLFxuICAgKiBvciBhZGQgb25lIG9mIHRoZXNlIGltcG9ydHMgYmVmb3JlIHlvdXIgZmlyc3QgYGltcG9ydCBcdTIwMjYgZnJvbSAnQGFudGhyb3BpYy1haS9zZGsnYDpcbiAgICogLSBgaW1wb3J0ICdAYW50aHJvcGljLWFpL3Nkay9zaGltcy9ub2RlJ2AgKGlmIHlvdSdyZSBydW5uaW5nIG9uIE5vZGUpXG4gICAqIC0gYGltcG9ydCAnQGFudGhyb3BpYy1haS9zZGsvc2hpbXMvd2ViJ2AgKG90aGVyd2lzZSlcbiAgICovXG4gIGFzeW5jIHdpdGhSZXNwb25zZSgpOiBQcm9taXNlPHsgZGF0YTogVDsgcmVzcG9uc2U6IFJlc3BvbnNlIH0+IHtcbiAgICBjb25zdCBbZGF0YSwgcmVzcG9uc2VdID0gYXdhaXQgUHJvbWlzZS5hbGwoW3RoaXMucGFyc2UoKSwgdGhpcy5hc1Jlc3BvbnNlKCldKTtcbiAgICByZXR1cm4geyBkYXRhLCByZXNwb25zZSB9O1xuICB9XG5cbiAgcHJpdmF0ZSBwYXJzZSgpOiBQcm9taXNlPFQ+IHtcbiAgICBpZiAoIXRoaXMucGFyc2VkUHJvbWlzZSkge1xuICAgICAgdGhpcy5wYXJzZWRQcm9taXNlID0gdGhpcy5yZXNwb25zZVByb21pc2UudGhlbih0aGlzLnBhcnNlUmVzcG9uc2UpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5wYXJzZWRQcm9taXNlO1xuICB9XG5cbiAgb3ZlcnJpZGUgdGhlbjxUUmVzdWx0MSA9IFQsIFRSZXN1bHQyID0gbmV2ZXI+KFxuICAgIG9uZnVsZmlsbGVkPzogKCh2YWx1ZTogVCkgPT4gVFJlc3VsdDEgfCBQcm9taXNlTGlrZTxUUmVzdWx0MT4pIHwgdW5kZWZpbmVkIHwgbnVsbCxcbiAgICBvbnJlamVjdGVkPzogKChyZWFzb246IGFueSkgPT4gVFJlc3VsdDIgfCBQcm9taXNlTGlrZTxUUmVzdWx0Mj4pIHwgdW5kZWZpbmVkIHwgbnVsbCxcbiAgKTogUHJvbWlzZTxUUmVzdWx0MSB8IFRSZXN1bHQyPiB7XG4gICAgcmV0dXJuIHRoaXMucGFyc2UoKS50aGVuKG9uZnVsZmlsbGVkLCBvbnJlamVjdGVkKTtcbiAgfVxuXG4gIG92ZXJyaWRlIGNhdGNoPFRSZXN1bHQgPSBuZXZlcj4oXG4gICAgb25yZWplY3RlZD86ICgocmVhc29uOiBhbnkpID0+IFRSZXN1bHQgfCBQcm9taXNlTGlrZTxUUmVzdWx0PikgfCB1bmRlZmluZWQgfCBudWxsLFxuICApOiBQcm9taXNlPFQgfCBUUmVzdWx0PiB7XG4gICAgcmV0dXJuIHRoaXMucGFyc2UoKS5jYXRjaChvbnJlamVjdGVkKTtcbiAgfVxuXG4gIG92ZXJyaWRlIGZpbmFsbHkob25maW5hbGx5PzogKCgpID0+IHZvaWQpIHwgdW5kZWZpbmVkIHwgbnVsbCk6IFByb21pc2U8VD4ge1xuICAgIHJldHVybiB0aGlzLnBhcnNlKCkuZmluYWxseShvbmZpbmFsbHkpO1xuICB9XG59XG5cbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBBUElDbGllbnQge1xuICBiYXNlVVJMOiBzdHJpbmc7XG4gIG1heFJldHJpZXM6IG51bWJlcjtcbiAgdGltZW91dDogbnVtYmVyO1xuICBodHRwQWdlbnQ6IEFnZW50IHwgdW5kZWZpbmVkO1xuXG4gIHByaXZhdGUgZmV0Y2g6IEZldGNoO1xuICBwcm90ZWN0ZWQgaWRlbXBvdGVuY3lIZWFkZXI/OiBzdHJpbmc7XG5cbiAgY29uc3RydWN0b3Ioe1xuICAgIGJhc2VVUkwsXG4gICAgbWF4UmV0cmllcyA9IDIsXG4gICAgdGltZW91dCA9IDYwMDAwMCwgLy8gMTAgbWludXRlc1xuICAgIGh0dHBBZ2VudCxcbiAgICBmZXRjaDogb3ZlcnJpZGVuRmV0Y2gsXG4gIH06IHtcbiAgICBiYXNlVVJMOiBzdHJpbmc7XG4gICAgbWF4UmV0cmllcz86IG51bWJlciB8IHVuZGVmaW5lZDtcbiAgICB0aW1lb3V0OiBudW1iZXIgfCB1bmRlZmluZWQ7XG4gICAgaHR0cEFnZW50OiBBZ2VudCB8IHVuZGVmaW5lZDtcbiAgICBmZXRjaDogRmV0Y2ggfCB1bmRlZmluZWQ7XG4gIH0pIHtcbiAgICB0aGlzLmJhc2VVUkwgPSBiYXNlVVJMO1xuICAgIHRoaXMubWF4UmV0cmllcyA9IHZhbGlkYXRlUG9zaXRpdmVJbnRlZ2VyKCdtYXhSZXRyaWVzJywgbWF4UmV0cmllcyk7XG4gICAgdGhpcy50aW1lb3V0ID0gdmFsaWRhdGVQb3NpdGl2ZUludGVnZXIoJ3RpbWVvdXQnLCB0aW1lb3V0KTtcbiAgICB0aGlzLmh0dHBBZ2VudCA9IGh0dHBBZ2VudDtcblxuICAgIHRoaXMuZmV0Y2ggPSBvdmVycmlkZW5GZXRjaCA/PyBmZXRjaDtcbiAgfVxuXG4gIHByb3RlY3RlZCBhdXRoSGVhZGVycyhvcHRzOiBGaW5hbFJlcXVlc3RPcHRpb25zKTogSGVhZGVycyB7XG4gICAgcmV0dXJuIHt9O1xuICB9XG5cbiAgLyoqXG4gICAqIE92ZXJyaWRlIHRoaXMgdG8gYWRkIHlvdXIgb3duIGRlZmF1bHQgaGVhZGVycywgZm9yIGV4YW1wbGU6XG4gICAqXG4gICAqICB7XG4gICAqICAgIC4uLnN1cGVyLmRlZmF1bHRIZWFkZXJzKCksXG4gICAqICAgIEF1dGhvcml6YXRpb246ICdCZWFyZXIgMTIzJyxcbiAgICogIH1cbiAgICovXG4gIHByb3RlY3RlZCBkZWZhdWx0SGVhZGVycyhvcHRzOiBGaW5hbFJlcXVlc3RPcHRpb25zKTogSGVhZGVycyB7XG4gICAgcmV0dXJuIHtcbiAgICAgIEFjY2VwdDogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICdVc2VyLUFnZW50JzogdGhpcy5nZXRVc2VyQWdlbnQoKSxcbiAgICAgIC4uLmdldFBsYXRmb3JtSGVhZGVycygpLFxuICAgICAgLi4udGhpcy5hdXRoSGVhZGVycyhvcHRzKSxcbiAgICB9O1xuICB9XG5cbiAgcHJvdGVjdGVkIGFic3RyYWN0IGRlZmF1bHRRdWVyeSgpOiBEZWZhdWx0UXVlcnkgfCB1bmRlZmluZWQ7XG5cbiAgLyoqXG4gICAqIE92ZXJyaWRlIHRoaXMgdG8gYWRkIHlvdXIgb3duIGhlYWRlcnMgdmFsaWRhdGlvbjpcbiAgICovXG4gIHByb3RlY3RlZCB2YWxpZGF0ZUhlYWRlcnMoaGVhZGVyczogSGVhZGVycywgY3VzdG9tSGVhZGVyczogSGVhZGVycykge31cblxuICBwcm90ZWN0ZWQgZGVmYXVsdElkZW1wb3RlbmN5S2V5KCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGBzdGFpbmxlc3Mtbm9kZS1yZXRyeS0ke3V1aWQ0KCl9YDtcbiAgfVxuXG4gIGdldDxSZXEsIFJzcD4ocGF0aDogc3RyaW5nLCBvcHRzPzogUHJvbWlzZU9yVmFsdWU8UmVxdWVzdE9wdGlvbnM8UmVxPj4pOiBBUElQcm9taXNlPFJzcD4ge1xuICAgIHJldHVybiB0aGlzLm1ldGhvZFJlcXVlc3QoJ2dldCcsIHBhdGgsIG9wdHMpO1xuICB9XG5cbiAgcG9zdDxSZXEsIFJzcD4ocGF0aDogc3RyaW5nLCBvcHRzPzogUHJvbWlzZU9yVmFsdWU8UmVxdWVzdE9wdGlvbnM8UmVxPj4pOiBBUElQcm9taXNlPFJzcD4ge1xuICAgIHJldHVybiB0aGlzLm1ldGhvZFJlcXVlc3QoJ3Bvc3QnLCBwYXRoLCBvcHRzKTtcbiAgfVxuXG4gIHBhdGNoPFJlcSwgUnNwPihwYXRoOiBzdHJpbmcsIG9wdHM/OiBQcm9taXNlT3JWYWx1ZTxSZXF1ZXN0T3B0aW9uczxSZXE+Pik6IEFQSVByb21pc2U8UnNwPiB7XG4gICAgcmV0dXJuIHRoaXMubWV0aG9kUmVxdWVzdCgncGF0Y2gnLCBwYXRoLCBvcHRzKTtcbiAgfVxuXG4gIHB1dDxSZXEsIFJzcD4ocGF0aDogc3RyaW5nLCBvcHRzPzogUHJvbWlzZU9yVmFsdWU8UmVxdWVzdE9wdGlvbnM8UmVxPj4pOiBBUElQcm9taXNlPFJzcD4ge1xuICAgIHJldHVybiB0aGlzLm1ldGhvZFJlcXVlc3QoJ3B1dCcsIHBhdGgsIG9wdHMpO1xuICB9XG5cbiAgZGVsZXRlPFJlcSwgUnNwPihwYXRoOiBzdHJpbmcsIG9wdHM/OiBQcm9taXNlT3JWYWx1ZTxSZXF1ZXN0T3B0aW9uczxSZXE+Pik6IEFQSVByb21pc2U8UnNwPiB7XG4gICAgcmV0dXJuIHRoaXMubWV0aG9kUmVxdWVzdCgnZGVsZXRlJywgcGF0aCwgb3B0cyk7XG4gIH1cblxuICBwcml2YXRlIG1ldGhvZFJlcXVlc3Q8UmVxLCBSc3A+KFxuICAgIG1ldGhvZDogSFRUUE1ldGhvZCxcbiAgICBwYXRoOiBzdHJpbmcsXG4gICAgb3B0cz86IFByb21pc2VPclZhbHVlPFJlcXVlc3RPcHRpb25zPFJlcT4+LFxuICApOiBBUElQcm9taXNlPFJzcD4ge1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3QoXG4gICAgICBQcm9taXNlLnJlc29sdmUob3B0cykudGhlbihhc3luYyAob3B0cykgPT4ge1xuICAgICAgICBjb25zdCBib2R5ID1cbiAgICAgICAgICBvcHRzICYmIGlzQmxvYkxpa2Uob3B0cz8uYm9keSkgPyBuZXcgRGF0YVZpZXcoYXdhaXQgb3B0cy5ib2R5LmFycmF5QnVmZmVyKCkpXG4gICAgICAgICAgOiBvcHRzPy5ib2R5IGluc3RhbmNlb2YgRGF0YVZpZXcgPyBvcHRzLmJvZHlcbiAgICAgICAgICA6IG9wdHM/LmJvZHkgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlciA/IG5ldyBEYXRhVmlldyhvcHRzLmJvZHkpXG4gICAgICAgICAgOiBvcHRzICYmIEFycmF5QnVmZmVyLmlzVmlldyhvcHRzPy5ib2R5KSA/IG5ldyBEYXRhVmlldyhvcHRzLmJvZHkuYnVmZmVyKVxuICAgICAgICAgIDogb3B0cz8uYm9keTtcbiAgICAgICAgcmV0dXJuIHsgbWV0aG9kLCBwYXRoLCAuLi5vcHRzLCBib2R5IH07XG4gICAgICB9KSxcbiAgICApO1xuICB9XG5cbiAgZ2V0QVBJTGlzdDxJdGVtLCBQYWdlQ2xhc3MgZXh0ZW5kcyBBYnN0cmFjdFBhZ2U8SXRlbT4gPSBBYnN0cmFjdFBhZ2U8SXRlbT4+KFxuICAgIHBhdGg6IHN0cmluZyxcbiAgICBQYWdlOiBuZXcgKC4uLmFyZ3M6IGFueVtdKSA9PiBQYWdlQ2xhc3MsXG4gICAgb3B0cz86IFJlcXVlc3RPcHRpb25zPGFueT4sXG4gICk6IFBhZ2VQcm9taXNlPFBhZ2VDbGFzcywgSXRlbT4ge1xuICAgIHJldHVybiB0aGlzLnJlcXVlc3RBUElMaXN0KFBhZ2UsIHsgbWV0aG9kOiAnZ2V0JywgcGF0aCwgLi4ub3B0cyB9KTtcbiAgfVxuXG4gIHByaXZhdGUgY2FsY3VsYXRlQ29udGVudExlbmd0aChib2R5OiB1bmtub3duKTogc3RyaW5nIHwgbnVsbCB7XG4gICAgaWYgKHR5cGVvZiBib2R5ID09PSAnc3RyaW5nJykge1xuICAgICAgaWYgKHR5cGVvZiBCdWZmZXIgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIHJldHVybiBCdWZmZXIuYnl0ZUxlbmd0aChib2R5LCAndXRmOCcpLnRvU3RyaW5nKCk7XG4gICAgICB9XG5cbiAgICAgIGlmICh0eXBlb2YgVGV4dEVuY29kZXIgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgIGNvbnN0IGVuY29kZXIgPSBuZXcgVGV4dEVuY29kZXIoKTtcbiAgICAgICAgY29uc3QgZW5jb2RlZCA9IGVuY29kZXIuZW5jb2RlKGJvZHkpO1xuICAgICAgICByZXR1cm4gZW5jb2RlZC5sZW5ndGgudG9TdHJpbmcoKTtcbiAgICAgIH1cbiAgICB9IGVsc2UgaWYgKEFycmF5QnVmZmVyLmlzVmlldyhib2R5KSkge1xuICAgICAgcmV0dXJuIGJvZHkuYnl0ZUxlbmd0aC50b1N0cmluZygpO1xuICAgIH1cblxuICAgIHJldHVybiBudWxsO1xuICB9XG5cbiAgYnVpbGRSZXF1ZXN0PFJlcT4oXG4gICAgb3B0aW9uczogRmluYWxSZXF1ZXN0T3B0aW9uczxSZXE+LFxuICAgIHsgcmV0cnlDb3VudCA9IDAgfTogeyByZXRyeUNvdW50PzogbnVtYmVyIH0gPSB7fSxcbiAgKTogeyByZXE6IFJlcXVlc3RJbml0OyB1cmw6IHN0cmluZzsgdGltZW91dDogbnVtYmVyIH0ge1xuICAgIGNvbnN0IHsgbWV0aG9kLCBwYXRoLCBxdWVyeSwgaGVhZGVyczogaGVhZGVycyA9IHt9IH0gPSBvcHRpb25zO1xuXG4gICAgY29uc3QgYm9keSA9XG4gICAgICBBcnJheUJ1ZmZlci5pc1ZpZXcob3B0aW9ucy5ib2R5KSB8fCAob3B0aW9ucy5fX2JpbmFyeVJlcXVlc3QgJiYgdHlwZW9mIG9wdGlvbnMuYm9keSA9PT0gJ3N0cmluZycpID9cbiAgICAgICAgb3B0aW9ucy5ib2R5XG4gICAgICA6IGlzTXVsdGlwYXJ0Qm9keShvcHRpb25zLmJvZHkpID8gb3B0aW9ucy5ib2R5LmJvZHlcbiAgICAgIDogb3B0aW9ucy5ib2R5ID8gSlNPTi5zdHJpbmdpZnkob3B0aW9ucy5ib2R5LCBudWxsLCAyKVxuICAgICAgOiBudWxsO1xuICAgIGNvbnN0IGNvbnRlbnRMZW5ndGggPSB0aGlzLmNhbGN1bGF0ZUNvbnRlbnRMZW5ndGgoYm9keSk7XG5cbiAgICBjb25zdCB1cmwgPSB0aGlzLmJ1aWxkVVJMKHBhdGghLCBxdWVyeSk7XG4gICAgaWYgKCd0aW1lb3V0JyBpbiBvcHRpb25zKSB2YWxpZGF0ZVBvc2l0aXZlSW50ZWdlcigndGltZW91dCcsIG9wdGlvbnMudGltZW91dCk7XG4gICAgY29uc3QgdGltZW91dCA9IG9wdGlvbnMudGltZW91dCA/PyB0aGlzLnRpbWVvdXQ7XG4gICAgY29uc3QgaHR0cEFnZW50ID0gb3B0aW9ucy5odHRwQWdlbnQgPz8gdGhpcy5odHRwQWdlbnQgPz8gZ2V0RGVmYXVsdEFnZW50KHVybCk7XG4gICAgY29uc3QgbWluQWdlbnRUaW1lb3V0ID0gdGltZW91dCArIDEwMDA7XG4gICAgaWYgKFxuICAgICAgdHlwZW9mIChodHRwQWdlbnQgYXMgYW55KT8ub3B0aW9ucz8udGltZW91dCA9PT0gJ251bWJlcicgJiZcbiAgICAgIG1pbkFnZW50VGltZW91dCA+ICgoaHR0cEFnZW50IGFzIGFueSkub3B0aW9ucy50aW1lb3V0ID8/IDApXG4gICAgKSB7XG4gICAgICAvLyBBbGxvdyBhbnkgZ2l2ZW4gcmVxdWVzdCB0byBidW1wIG91ciBhZ2VudCBhY3RpdmUgc29ja2V0IHRpbWVvdXQuXG4gICAgICAvLyBUaGlzIG1heSBzZWVtIHN0cmFuZ2UsIGJ1dCBsZWFraW5nIGFjdGl2ZSBzb2NrZXRzIHNob3VsZCBiZSByYXJlIGFuZCBub3QgcGFydGljdWxhcmx5IHByb2JsZW1hdGljLFxuICAgICAgLy8gYW5kIHdpdGhvdXQgbXV0YXRpbmcgYWdlbnQgd2Ugd291bGQgbmVlZCB0byBjcmVhdGUgbW9yZSBvZiB0aGVtLlxuICAgICAgLy8gVGhpcyB0cmFkZW9mZiBvcHRpbWl6ZXMgZm9yIHBlcmZvcm1hbmNlLlxuICAgICAgKGh0dHBBZ2VudCBhcyBhbnkpLm9wdGlvbnMudGltZW91dCA9IG1pbkFnZW50VGltZW91dDtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5pZGVtcG90ZW5jeUhlYWRlciAmJiBtZXRob2QgIT09ICdnZXQnKSB7XG4gICAgICBpZiAoIW9wdGlvbnMuaWRlbXBvdGVuY3lLZXkpIG9wdGlvbnMuaWRlbXBvdGVuY3lLZXkgPSB0aGlzLmRlZmF1bHRJZGVtcG90ZW5jeUtleSgpO1xuICAgICAgaGVhZGVyc1t0aGlzLmlkZW1wb3RlbmN5SGVhZGVyXSA9IG9wdGlvbnMuaWRlbXBvdGVuY3lLZXk7XG4gICAgfVxuXG4gICAgY29uc3QgcmVxSGVhZGVycyA9IHRoaXMuYnVpbGRIZWFkZXJzKHsgb3B0aW9ucywgaGVhZGVycywgY29udGVudExlbmd0aCwgcmV0cnlDb3VudCB9KTtcblxuICAgIGNvbnN0IHJlcTogUmVxdWVzdEluaXQgPSB7XG4gICAgICBtZXRob2QsXG4gICAgICAuLi4oYm9keSAmJiB7IGJvZHk6IGJvZHkgYXMgYW55IH0pLFxuICAgICAgaGVhZGVyczogcmVxSGVhZGVycyxcbiAgICAgIC4uLihodHRwQWdlbnQgJiYgeyBhZ2VudDogaHR0cEFnZW50IH0pLFxuICAgICAgLy8gQHRzLWlnbm9yZSBub2RlLWZldGNoIHVzZXMgYSBjdXN0b20gQWJvcnRTaWduYWwgdHlwZSB0aGF0IGlzXG4gICAgICAvLyBub3QgY29tcGF0aWJsZSB3aXRoIHN0YW5kYXJkIHdlYiB0eXBlc1xuICAgICAgc2lnbmFsOiBvcHRpb25zLnNpZ25hbCA/PyBudWxsLFxuICAgIH07XG5cbiAgICByZXR1cm4geyByZXEsIHVybCwgdGltZW91dCB9O1xuICB9XG5cbiAgcHJpdmF0ZSBidWlsZEhlYWRlcnMoe1xuICAgIG9wdGlvbnMsXG4gICAgaGVhZGVycyxcbiAgICBjb250ZW50TGVuZ3RoLFxuICAgIHJldHJ5Q291bnQsXG4gIH06IHtcbiAgICBvcHRpb25zOiBGaW5hbFJlcXVlc3RPcHRpb25zO1xuICAgIGhlYWRlcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQ+O1xuICAgIGNvbnRlbnRMZW5ndGg6IHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQ7XG4gICAgcmV0cnlDb3VudDogbnVtYmVyO1xuICB9KTogUmVjb3JkPHN0cmluZywgc3RyaW5nPiB7XG4gICAgY29uc3QgcmVxSGVhZGVyczogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHt9O1xuICAgIGlmIChjb250ZW50TGVuZ3RoKSB7XG4gICAgICByZXFIZWFkZXJzWydjb250ZW50LWxlbmd0aCddID0gY29udGVudExlbmd0aDtcbiAgICB9XG5cbiAgICBjb25zdCBkZWZhdWx0SGVhZGVycyA9IHRoaXMuZGVmYXVsdEhlYWRlcnMob3B0aW9ucyk7XG4gICAgYXBwbHlIZWFkZXJzTXV0KHJlcUhlYWRlcnMsIGRlZmF1bHRIZWFkZXJzKTtcbiAgICBhcHBseUhlYWRlcnNNdXQocmVxSGVhZGVycywgaGVhZGVycyk7XG5cbiAgICAvLyBsZXQgYnVpbHRpbiBmZXRjaCBzZXQgdGhlIENvbnRlbnQtVHlwZSBmb3IgbXVsdGlwYXJ0IGJvZGllc1xuICAgIGlmIChpc011bHRpcGFydEJvZHkob3B0aW9ucy5ib2R5KSAmJiBzaGltc0tpbmQgIT09ICdub2RlJykge1xuICAgICAgZGVsZXRlIHJlcUhlYWRlcnNbJ2NvbnRlbnQtdHlwZSddO1xuICAgIH1cblxuICAgIC8vIERvbid0IHNldCB0aGUgcmV0cnkgY291bnQgaGVhZGVyIGlmIGl0IHdhcyBhbHJlYWR5IHNldCBvciByZW1vdmVkIGJ5IHRoZSBjYWxsZXIuIFdlIGNoZWNrIGBoZWFkZXJzYCxcbiAgICAvLyB3aGljaCBjYW4gY29udGFpbiBudWxscywgaW5zdGVhZCBvZiBgcmVxSGVhZGVyc2AgdG8gYWNjb3VudCBmb3IgdGhlIHJlbW92YWwgY2FzZS5cbiAgICBpZiAoZ2V0SGVhZGVyKGhlYWRlcnMsICd4LXN0YWlubGVzcy1yZXRyeS1jb3VudCcpID09PSB1bmRlZmluZWQpIHtcbiAgICAgIHJlcUhlYWRlcnNbJ3gtc3RhaW5sZXNzLXJldHJ5LWNvdW50J10gPSBTdHJpbmcocmV0cnlDb3VudCk7XG4gICAgfVxuXG4gICAgdGhpcy52YWxpZGF0ZUhlYWRlcnMocmVxSGVhZGVycywgaGVhZGVycyk7XG5cbiAgICByZXR1cm4gcmVxSGVhZGVycztcbiAgfVxuXG4gIC8qKlxuICAgKiBVc2VkIGFzIGEgY2FsbGJhY2sgZm9yIG11dGF0aW5nIHRoZSBnaXZlbiBgRmluYWxSZXF1ZXN0T3B0aW9uc2Agb2JqZWN0LlxuICAgKi9cbiAgcHJvdGVjdGVkIGFzeW5jIHByZXBhcmVPcHRpb25zKG9wdGlvbnM6IEZpbmFsUmVxdWVzdE9wdGlvbnMpOiBQcm9taXNlPHZvaWQ+IHt9XG5cbiAgLyoqXG4gICAqIFVzZWQgYXMgYSBjYWxsYmFjayBmb3IgbXV0YXRpbmcgdGhlIGdpdmVuIGBSZXF1ZXN0SW5pdGAgb2JqZWN0LlxuICAgKlxuICAgKiBUaGlzIGlzIHVzZWZ1bCBmb3IgY2FzZXMgd2hlcmUgeW91IHdhbnQgdG8gYWRkIGNlcnRhaW4gaGVhZGVycyBiYXNlZCBvZmYgb2ZcbiAgICogdGhlIHJlcXVlc3QgcHJvcGVydGllcywgZS5nLiBgbWV0aG9kYCBvciBgdXJsYC5cbiAgICovXG4gIHByb3RlY3RlZCBhc3luYyBwcmVwYXJlUmVxdWVzdChcbiAgICByZXF1ZXN0OiBSZXF1ZXN0SW5pdCxcbiAgICB7IHVybCwgb3B0aW9ucyB9OiB7IHVybDogc3RyaW5nOyBvcHRpb25zOiBGaW5hbFJlcXVlc3RPcHRpb25zIH0sXG4gICk6IFByb21pc2U8dm9pZD4ge31cblxuICBwcm90ZWN0ZWQgcGFyc2VIZWFkZXJzKGhlYWRlcnM6IEhlYWRlcnNJbml0IHwgbnVsbCB8IHVuZGVmaW5lZCk6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4ge1xuICAgIHJldHVybiAoXG4gICAgICAhaGVhZGVycyA/IHt9XG4gICAgICA6IFN5bWJvbC5pdGVyYXRvciBpbiBoZWFkZXJzID9cbiAgICAgICAgT2JqZWN0LmZyb21FbnRyaWVzKEFycmF5LmZyb20oaGVhZGVycyBhcyBJdGVyYWJsZTxzdHJpbmdbXT4pLm1hcCgoaGVhZGVyKSA9PiBbLi4uaGVhZGVyXSkpXG4gICAgICA6IHsgLi4uaGVhZGVycyB9XG4gICAgKTtcbiAgfVxuXG4gIHByb3RlY3RlZCBtYWtlU3RhdHVzRXJyb3IoXG4gICAgc3RhdHVzOiBudW1iZXIgfCB1bmRlZmluZWQsXG4gICAgZXJyb3I6IE9iamVjdCB8IHVuZGVmaW5lZCxcbiAgICBtZXNzYWdlOiBzdHJpbmcgfCB1bmRlZmluZWQsXG4gICAgaGVhZGVyczogSGVhZGVycyB8IHVuZGVmaW5lZCxcbiAgKSB7XG4gICAgcmV0dXJuIEFQSUVycm9yLmdlbmVyYXRlKHN0YXR1cywgZXJyb3IsIG1lc3NhZ2UsIGhlYWRlcnMpO1xuICB9XG5cbiAgcmVxdWVzdDxSZXEsIFJzcD4oXG4gICAgb3B0aW9uczogUHJvbWlzZU9yVmFsdWU8RmluYWxSZXF1ZXN0T3B0aW9uczxSZXE+PixcbiAgICByZW1haW5pbmdSZXRyaWVzOiBudW1iZXIgfCBudWxsID0gbnVsbCxcbiAgKTogQVBJUHJvbWlzZTxSc3A+IHtcbiAgICByZXR1cm4gbmV3IEFQSVByb21pc2UodGhpcy5tYWtlUmVxdWVzdChvcHRpb25zLCByZW1haW5pbmdSZXRyaWVzKSk7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIG1ha2VSZXF1ZXN0PFJlcT4oXG4gICAgb3B0aW9uc0lucHV0OiBQcm9taXNlT3JWYWx1ZTxGaW5hbFJlcXVlc3RPcHRpb25zPFJlcT4+LFxuICAgIHJldHJpZXNSZW1haW5pbmc6IG51bWJlciB8IG51bGwsXG4gICk6IFByb21pc2U8QVBJUmVzcG9uc2VQcm9wcz4ge1xuICAgIGNvbnN0IG9wdGlvbnMgPSBhd2FpdCBvcHRpb25zSW5wdXQ7XG4gICAgY29uc3QgbWF4UmV0cmllcyA9IG9wdGlvbnMubWF4UmV0cmllcyA/PyB0aGlzLm1heFJldHJpZXM7XG4gICAgaWYgKHJldHJpZXNSZW1haW5pbmcgPT0gbnVsbCkge1xuICAgICAgcmV0cmllc1JlbWFpbmluZyA9IG1heFJldHJpZXM7XG4gICAgfVxuXG4gICAgYXdhaXQgdGhpcy5wcmVwYXJlT3B0aW9ucyhvcHRpb25zKTtcblxuICAgIGNvbnN0IHsgcmVxLCB1cmwsIHRpbWVvdXQgfSA9IHRoaXMuYnVpbGRSZXF1ZXN0KG9wdGlvbnMsIHsgcmV0cnlDb3VudDogbWF4UmV0cmllcyAtIHJldHJpZXNSZW1haW5pbmcgfSk7XG5cbiAgICBhd2FpdCB0aGlzLnByZXBhcmVSZXF1ZXN0KHJlcSwgeyB1cmwsIG9wdGlvbnMgfSk7XG5cbiAgICBkZWJ1ZygncmVxdWVzdCcsIHVybCwgb3B0aW9ucywgcmVxLmhlYWRlcnMpO1xuXG4gICAgaWYgKG9wdGlvbnMuc2lnbmFsPy5hYm9ydGVkKSB7XG4gICAgICB0aHJvdyBuZXcgQVBJVXNlckFib3J0RXJyb3IoKTtcbiAgICB9XG5cbiAgICBjb25zdCBjb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5mZXRjaFdpdGhUaW1lb3V0KHVybCwgcmVxLCB0aW1lb3V0LCBjb250cm9sbGVyKS5jYXRjaChjYXN0VG9FcnJvcik7XG5cbiAgICBpZiAocmVzcG9uc2UgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgaWYgKG9wdGlvbnMuc2lnbmFsPy5hYm9ydGVkKSB7XG4gICAgICAgIHRocm93IG5ldyBBUElVc2VyQWJvcnRFcnJvcigpO1xuICAgICAgfVxuICAgICAgaWYgKHJldHJpZXNSZW1haW5pbmcpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucmV0cnlSZXF1ZXN0KG9wdGlvbnMsIHJldHJpZXNSZW1haW5pbmcpO1xuICAgICAgfVxuICAgICAgaWYgKHJlc3BvbnNlLm5hbWUgPT09ICdBYm9ydEVycm9yJykge1xuICAgICAgICB0aHJvdyBuZXcgQVBJQ29ubmVjdGlvblRpbWVvdXRFcnJvcigpO1xuICAgICAgfVxuICAgICAgdGhyb3cgbmV3IEFQSUNvbm5lY3Rpb25FcnJvcih7IGNhdXNlOiByZXNwb25zZSB9KTtcbiAgICB9XG5cbiAgICBjb25zdCByZXNwb25zZUhlYWRlcnMgPSBjcmVhdGVSZXNwb25zZUhlYWRlcnMocmVzcG9uc2UuaGVhZGVycyk7XG5cbiAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICBpZiAocmV0cmllc1JlbWFpbmluZyAmJiB0aGlzLnNob3VsZFJldHJ5KHJlc3BvbnNlKSkge1xuICAgICAgICBjb25zdCByZXRyeU1lc3NhZ2UgPSBgcmV0cnlpbmcsICR7cmV0cmllc1JlbWFpbmluZ30gYXR0ZW1wdHMgcmVtYWluaW5nYDtcbiAgICAgICAgZGVidWcoYHJlc3BvbnNlIChlcnJvcjsgJHtyZXRyeU1lc3NhZ2V9KWAsIHJlc3BvbnNlLnN0YXR1cywgdXJsLCByZXNwb25zZUhlYWRlcnMpO1xuICAgICAgICByZXR1cm4gdGhpcy5yZXRyeVJlcXVlc3Qob3B0aW9ucywgcmV0cmllc1JlbWFpbmluZywgcmVzcG9uc2VIZWFkZXJzKTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgZXJyVGV4dCA9IGF3YWl0IHJlc3BvbnNlLnRleHQoKS5jYXRjaCgoZSkgPT4gY2FzdFRvRXJyb3IoZSkubWVzc2FnZSk7XG4gICAgICBjb25zdCBlcnJKU09OID0gc2FmZUpTT04oZXJyVGV4dCk7XG4gICAgICBjb25zdCBlcnJNZXNzYWdlID0gZXJySlNPTiA/IHVuZGVmaW5lZCA6IGVyclRleHQ7XG4gICAgICBjb25zdCByZXRyeU1lc3NhZ2UgPSByZXRyaWVzUmVtYWluaW5nID8gYChlcnJvcjsgbm8gbW9yZSByZXRyaWVzIGxlZnQpYCA6IGAoZXJyb3I7IG5vdCByZXRyeWFibGUpYDtcblxuICAgICAgZGVidWcoYHJlc3BvbnNlIChlcnJvcjsgJHtyZXRyeU1lc3NhZ2V9KWAsIHJlc3BvbnNlLnN0YXR1cywgdXJsLCByZXNwb25zZUhlYWRlcnMsIGVyck1lc3NhZ2UpO1xuXG4gICAgICBjb25zdCBlcnIgPSB0aGlzLm1ha2VTdGF0dXNFcnJvcihyZXNwb25zZS5zdGF0dXMsIGVyckpTT04sIGVyck1lc3NhZ2UsIHJlc3BvbnNlSGVhZGVycyk7XG4gICAgICB0aHJvdyBlcnI7XG4gICAgfVxuXG4gICAgcmV0dXJuIHsgcmVzcG9uc2UsIG9wdGlvbnMsIGNvbnRyb2xsZXIgfTtcbiAgfVxuXG4gIHJlcXVlc3RBUElMaXN0PEl0ZW0gPSB1bmtub3duLCBQYWdlQ2xhc3MgZXh0ZW5kcyBBYnN0cmFjdFBhZ2U8SXRlbT4gPSBBYnN0cmFjdFBhZ2U8SXRlbT4+KFxuICAgIFBhZ2U6IG5ldyAoLi4uYXJnczogQ29uc3RydWN0b3JQYXJhbWV0ZXJzPHR5cGVvZiBBYnN0cmFjdFBhZ2U+KSA9PiBQYWdlQ2xhc3MsXG4gICAgb3B0aW9uczogRmluYWxSZXF1ZXN0T3B0aW9ucyxcbiAgKTogUGFnZVByb21pc2U8UGFnZUNsYXNzLCBJdGVtPiB7XG4gICAgY29uc3QgcmVxdWVzdCA9IHRoaXMubWFrZVJlcXVlc3Qob3B0aW9ucywgbnVsbCk7XG4gICAgcmV0dXJuIG5ldyBQYWdlUHJvbWlzZTxQYWdlQ2xhc3MsIEl0ZW0+KHRoaXMsIHJlcXVlc3QsIFBhZ2UpO1xuICB9XG5cbiAgYnVpbGRVUkw8UmVxPihwYXRoOiBzdHJpbmcsIHF1ZXJ5OiBSZXEgfCBudWxsIHwgdW5kZWZpbmVkKTogc3RyaW5nIHtcbiAgICBjb25zdCB1cmwgPVxuICAgICAgaXNBYnNvbHV0ZVVSTChwYXRoKSA/XG4gICAgICAgIG5ldyBVUkwocGF0aClcbiAgICAgIDogbmV3IFVSTCh0aGlzLmJhc2VVUkwgKyAodGhpcy5iYXNlVVJMLmVuZHNXaXRoKCcvJykgJiYgcGF0aC5zdGFydHNXaXRoKCcvJykgPyBwYXRoLnNsaWNlKDEpIDogcGF0aCkpO1xuXG4gICAgY29uc3QgZGVmYXVsdFF1ZXJ5ID0gdGhpcy5kZWZhdWx0UXVlcnkoKTtcbiAgICBpZiAoIWlzRW1wdHlPYmooZGVmYXVsdFF1ZXJ5KSkge1xuICAgICAgcXVlcnkgPSB7IC4uLmRlZmF1bHRRdWVyeSwgLi4ucXVlcnkgfSBhcyBSZXE7XG4gICAgfVxuXG4gICAgaWYgKHR5cGVvZiBxdWVyeSA9PT0gJ29iamVjdCcgJiYgcXVlcnkgJiYgIUFycmF5LmlzQXJyYXkocXVlcnkpKSB7XG4gICAgICB1cmwuc2VhcmNoID0gdGhpcy5zdHJpbmdpZnlRdWVyeShxdWVyeSBhcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik7XG4gICAgfVxuXG4gICAgcmV0dXJuIHVybC50b1N0cmluZygpO1xuICB9XG5cbiAgcHJvdGVjdGVkIHN0cmluZ2lmeVF1ZXJ5KHF1ZXJ5OiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPik6IHN0cmluZyB7XG4gICAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHF1ZXJ5KVxuICAgICAgLmZpbHRlcigoW18sIHZhbHVlXSkgPT4gdHlwZW9mIHZhbHVlICE9PSAndW5kZWZpbmVkJylcbiAgICAgIC5tYXAoKFtrZXksIHZhbHVlXSkgPT4ge1xuICAgICAgICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInIHx8IHR5cGVvZiB2YWx1ZSA9PT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgICAgcmV0dXJuIGAke2VuY29kZVVSSUNvbXBvbmVudChrZXkpfT0ke2VuY29kZVVSSUNvbXBvbmVudCh2YWx1ZSl9YDtcbiAgICAgICAgfVxuICAgICAgICBpZiAodmFsdWUgPT09IG51bGwpIHtcbiAgICAgICAgICByZXR1cm4gYCR7ZW5jb2RlVVJJQ29tcG9uZW50KGtleSl9PWA7XG4gICAgICAgIH1cbiAgICAgICAgdGhyb3cgbmV3IEFudGhyb3BpY0Vycm9yKFxuICAgICAgICAgIGBDYW5ub3Qgc3RyaW5naWZ5IHR5cGUgJHt0eXBlb2YgdmFsdWV9OyBFeHBlY3RlZCBzdHJpbmcsIG51bWJlciwgYm9vbGVhbiwgb3IgbnVsbC4gSWYgeW91IG5lZWQgdG8gcGFzcyBuZXN0ZWQgcXVlcnkgcGFyYW1ldGVycywgeW91IGNhbiBtYW51YWxseSBlbmNvZGUgdGhlbSwgZS5nLiB7IHF1ZXJ5OiB7ICdmb29ba2V5MV0nOiB2YWx1ZTEsICdmb29ba2V5Ml0nOiB2YWx1ZTIgfSB9LCBhbmQgcGxlYXNlIG9wZW4gYSBHaXRIdWIgaXNzdWUgcmVxdWVzdGluZyBiZXR0ZXIgc3VwcG9ydCBmb3IgeW91ciB1c2UgY2FzZS5gLFxuICAgICAgICApO1xuICAgICAgfSlcbiAgICAgIC5qb2luKCcmJyk7XG4gIH1cblxuICBhc3luYyBmZXRjaFdpdGhUaW1lb3V0KFxuICAgIHVybDogUmVxdWVzdEluZm8sXG4gICAgaW5pdDogUmVxdWVzdEluaXQgfCB1bmRlZmluZWQsXG4gICAgbXM6IG51bWJlcixcbiAgICBjb250cm9sbGVyOiBBYm9ydENvbnRyb2xsZXIsXG4gICk6IFByb21pc2U8UmVzcG9uc2U+IHtcbiAgICBjb25zdCB7IHNpZ25hbCwgLi4ub3B0aW9ucyB9ID0gaW5pdCB8fCB7fTtcbiAgICBpZiAoc2lnbmFsKSBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCAoKSA9PiBjb250cm9sbGVyLmFib3J0KCkpO1xuXG4gICAgY29uc3QgdGltZW91dCA9IHNldFRpbWVvdXQoKCkgPT4gY29udHJvbGxlci5hYm9ydCgpLCBtcyk7XG5cbiAgICByZXR1cm4gKFxuICAgICAgdGhpcy5nZXRSZXF1ZXN0Q2xpZW50KClcbiAgICAgICAgLy8gdXNlIHVuZGVmaW5lZCB0aGlzIGJpbmRpbmc7IGZldGNoIGVycm9ycyBpZiBib3VuZCB0byBzb21ldGhpbmcgZWxzZSBpbiBicm93c2VyL2Nsb3VkZmxhcmVcbiAgICAgICAgLmZldGNoLmNhbGwodW5kZWZpbmVkLCB1cmwsIHsgc2lnbmFsOiBjb250cm9sbGVyLnNpZ25hbCBhcyBhbnksIC4uLm9wdGlvbnMgfSlcbiAgICAgICAgLmZpbmFsbHkoKCkgPT4ge1xuICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0KTtcbiAgICAgICAgfSlcbiAgICApO1xuICB9XG5cbiAgcHJvdGVjdGVkIGdldFJlcXVlc3RDbGllbnQoKTogUmVxdWVzdENsaWVudCB7XG4gICAgcmV0dXJuIHsgZmV0Y2g6IHRoaXMuZmV0Y2ggfTtcbiAgfVxuXG4gIHByaXZhdGUgc2hvdWxkUmV0cnkocmVzcG9uc2U6IFJlc3BvbnNlKTogYm9vbGVhbiB7XG4gICAgLy8gTm90ZSB0aGlzIGlzIG5vdCBhIHN0YW5kYXJkIGhlYWRlci5cbiAgICBjb25zdCBzaG91bGRSZXRyeUhlYWRlciA9IHJlc3BvbnNlLmhlYWRlcnMuZ2V0KCd4LXNob3VsZC1yZXRyeScpO1xuXG4gICAgLy8gSWYgdGhlIHNlcnZlciBleHBsaWNpdGx5IHNheXMgd2hldGhlciBvciBub3QgdG8gcmV0cnksIG9iZXkuXG4gICAgaWYgKHNob3VsZFJldHJ5SGVhZGVyID09PSAndHJ1ZScpIHJldHVybiB0cnVlO1xuICAgIGlmIChzaG91bGRSZXRyeUhlYWRlciA9PT0gJ2ZhbHNlJykgcmV0dXJuIGZhbHNlO1xuXG4gICAgLy8gUmV0cnkgb24gcmVxdWVzdCB0aW1lb3V0cy5cbiAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSA0MDgpIHJldHVybiB0cnVlO1xuXG4gICAgLy8gUmV0cnkgb24gbG9jayB0aW1lb3V0cy5cbiAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSA0MDkpIHJldHVybiB0cnVlO1xuXG4gICAgLy8gUmV0cnkgb24gcmF0ZSBsaW1pdHMuXG4gICAgaWYgKHJlc3BvbnNlLnN0YXR1cyA9PT0gNDI5KSByZXR1cm4gdHJ1ZTtcblxuICAgIC8vIFJldHJ5IGludGVybmFsIGVycm9ycy5cbiAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID49IDUwMCkgcmV0dXJuIHRydWU7XG5cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIHJldHJ5UmVxdWVzdChcbiAgICBvcHRpb25zOiBGaW5hbFJlcXVlc3RPcHRpb25zLFxuICAgIHJldHJpZXNSZW1haW5pbmc6IG51bWJlcixcbiAgICByZXNwb25zZUhlYWRlcnM/OiBIZWFkZXJzIHwgdW5kZWZpbmVkLFxuICApOiBQcm9taXNlPEFQSVJlc3BvbnNlUHJvcHM+IHtcbiAgICBsZXQgdGltZW91dE1pbGxpczogbnVtYmVyIHwgdW5kZWZpbmVkO1xuXG4gICAgLy8gTm90ZSB0aGUgYHJldHJ5LWFmdGVyLW1zYCBoZWFkZXIgbWF5IG5vdCBiZSBzdGFuZGFyZCwgYnV0IGlzIGEgZ29vZCBpZGVhIGFuZCB3ZSdkIGxpa2UgcHJvYWN0aXZlIHN1cHBvcnQgZm9yIGl0LlxuICAgIGNvbnN0IHJldHJ5QWZ0ZXJNaWxsaXNIZWFkZXIgPSByZXNwb25zZUhlYWRlcnM/LlsncmV0cnktYWZ0ZXItbXMnXTtcbiAgICBpZiAocmV0cnlBZnRlck1pbGxpc0hlYWRlcikge1xuICAgICAgY29uc3QgdGltZW91dE1zID0gcGFyc2VGbG9hdChyZXRyeUFmdGVyTWlsbGlzSGVhZGVyKTtcbiAgICAgIGlmICghTnVtYmVyLmlzTmFOKHRpbWVvdXRNcykpIHtcbiAgICAgICAgdGltZW91dE1pbGxpcyA9IHRpbWVvdXRNcztcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBBYm91dCB0aGUgUmV0cnktQWZ0ZXIgaGVhZGVyOiBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9IVFRQL0hlYWRlcnMvUmV0cnktQWZ0ZXJcbiAgICBjb25zdCByZXRyeUFmdGVySGVhZGVyID0gcmVzcG9uc2VIZWFkZXJzPy5bJ3JldHJ5LWFmdGVyJ107XG4gICAgaWYgKHJldHJ5QWZ0ZXJIZWFkZXIgJiYgIXRpbWVvdXRNaWxsaXMpIHtcbiAgICAgIGNvbnN0IHRpbWVvdXRTZWNvbmRzID0gcGFyc2VGbG9hdChyZXRyeUFmdGVySGVhZGVyKTtcbiAgICAgIGlmICghTnVtYmVyLmlzTmFOKHRpbWVvdXRTZWNvbmRzKSkge1xuICAgICAgICB0aW1lb3V0TWlsbGlzID0gdGltZW91dFNlY29uZHMgKiAxMDAwO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgdGltZW91dE1pbGxpcyA9IERhdGUucGFyc2UocmV0cnlBZnRlckhlYWRlcikgLSBEYXRlLm5vdygpO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIElmIHRoZSBBUEkgYXNrcyB1cyB0byB3YWl0IGEgY2VydGFpbiBhbW91bnQgb2YgdGltZSAoYW5kIGl0J3MgYSByZWFzb25hYmxlIGFtb3VudCksXG4gICAgLy8ganVzdCBkbyB3aGF0IGl0IHNheXMsIGJ1dCBvdGhlcndpc2UgY2FsY3VsYXRlIGEgZGVmYXVsdFxuICAgIGlmICghKHRpbWVvdXRNaWxsaXMgJiYgMCA8PSB0aW1lb3V0TWlsbGlzICYmIHRpbWVvdXRNaWxsaXMgPCA2MCAqIDEwMDApKSB7XG4gICAgICBjb25zdCBtYXhSZXRyaWVzID0gb3B0aW9ucy5tYXhSZXRyaWVzID8/IHRoaXMubWF4UmV0cmllcztcbiAgICAgIHRpbWVvdXRNaWxsaXMgPSB0aGlzLmNhbGN1bGF0ZURlZmF1bHRSZXRyeVRpbWVvdXRNaWxsaXMocmV0cmllc1JlbWFpbmluZywgbWF4UmV0cmllcyk7XG4gICAgfVxuICAgIGF3YWl0IHNsZWVwKHRpbWVvdXRNaWxsaXMpO1xuXG4gICAgcmV0dXJuIHRoaXMubWFrZVJlcXVlc3Qob3B0aW9ucywgcmV0cmllc1JlbWFpbmluZyAtIDEpO1xuICB9XG5cbiAgcHJpdmF0ZSBjYWxjdWxhdGVEZWZhdWx0UmV0cnlUaW1lb3V0TWlsbGlzKHJldHJpZXNSZW1haW5pbmc6IG51bWJlciwgbWF4UmV0cmllczogbnVtYmVyKTogbnVtYmVyIHtcbiAgICBjb25zdCBpbml0aWFsUmV0cnlEZWxheSA9IDAuNTtcbiAgICBjb25zdCBtYXhSZXRyeURlbGF5ID0gOC4wO1xuXG4gICAgY29uc3QgbnVtUmV0cmllcyA9IG1heFJldHJpZXMgLSByZXRyaWVzUmVtYWluaW5nO1xuXG4gICAgLy8gQXBwbHkgZXhwb25lbnRpYWwgYmFja29mZiwgYnV0IG5vdCBtb3JlIHRoYW4gdGhlIG1heC5cbiAgICBjb25zdCBzbGVlcFNlY29uZHMgPSBNYXRoLm1pbihpbml0aWFsUmV0cnlEZWxheSAqIE1hdGgucG93KDIsIG51bVJldHJpZXMpLCBtYXhSZXRyeURlbGF5KTtcblxuICAgIC8vIEFwcGx5IHNvbWUgaml0dGVyLCB0YWtlIHVwIHRvIGF0IG1vc3QgMjUgcGVyY2VudCBvZiB0aGUgcmV0cnkgdGltZS5cbiAgICBjb25zdCBqaXR0ZXIgPSAxIC0gTWF0aC5yYW5kb20oKSAqIDAuMjU7XG5cbiAgICByZXR1cm4gc2xlZXBTZWNvbmRzICogaml0dGVyICogMTAwMDtcbiAgfVxuXG4gIHByaXZhdGUgZ2V0VXNlckFnZW50KCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGAke3RoaXMuY29uc3RydWN0b3IubmFtZX0vSlMgJHtWRVJTSU9OfWA7XG4gIH1cbn1cblxuZXhwb3J0IHR5cGUgUGFnZUluZm8gPSB7IHVybDogVVJMIH0gfCB7IHBhcmFtczogUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBudWxsIH07XG5cbmV4cG9ydCBhYnN0cmFjdCBjbGFzcyBBYnN0cmFjdFBhZ2U8SXRlbT4gaW1wbGVtZW50cyBBc3luY0l0ZXJhYmxlPEl0ZW0+IHtcbiAgI2NsaWVudDogQVBJQ2xpZW50O1xuICBwcm90ZWN0ZWQgb3B0aW9uczogRmluYWxSZXF1ZXN0T3B0aW9ucztcblxuICBwcm90ZWN0ZWQgcmVzcG9uc2U6IFJlc3BvbnNlO1xuICBwcm90ZWN0ZWQgYm9keTogdW5rbm93bjtcblxuICBjb25zdHJ1Y3RvcihjbGllbnQ6IEFQSUNsaWVudCwgcmVzcG9uc2U6IFJlc3BvbnNlLCBib2R5OiB1bmtub3duLCBvcHRpb25zOiBGaW5hbFJlcXVlc3RPcHRpb25zKSB7XG4gICAgdGhpcy4jY2xpZW50ID0gY2xpZW50O1xuICAgIHRoaXMub3B0aW9ucyA9IG9wdGlvbnM7XG4gICAgdGhpcy5yZXNwb25zZSA9IHJlc3BvbnNlO1xuICAgIHRoaXMuYm9keSA9IGJvZHk7XG4gIH1cblxuICAvKipcbiAgICogQGRlcHJlY2F0ZWQgVXNlIG5leHRQYWdlSW5mbyBpbnN0ZWFkXG4gICAqL1xuICBhYnN0cmFjdCBuZXh0UGFnZVBhcmFtcygpOiBQYXJ0aWFsPFJlY29yZDxzdHJpbmcsIHVua25vd24+PiB8IG51bGw7XG4gIGFic3RyYWN0IG5leHRQYWdlSW5mbygpOiBQYWdlSW5mbyB8IG51bGw7XG5cbiAgYWJzdHJhY3QgZ2V0UGFnaW5hdGVkSXRlbXMoKTogSXRlbVtdO1xuXG4gIGhhc05leHRQYWdlKCk6IGJvb2xlYW4ge1xuICAgIGNvbnN0IGl0ZW1zID0gdGhpcy5nZXRQYWdpbmF0ZWRJdGVtcygpO1xuICAgIGlmICghaXRlbXMubGVuZ3RoKSByZXR1cm4gZmFsc2U7XG4gICAgcmV0dXJuIHRoaXMubmV4dFBhZ2VJbmZvKCkgIT0gbnVsbDtcbiAgfVxuXG4gIGFzeW5jIGdldE5leHRQYWdlKCk6IFByb21pc2U8dGhpcz4ge1xuICAgIGNvbnN0IG5leHRJbmZvID0gdGhpcy5uZXh0UGFnZUluZm8oKTtcbiAgICBpZiAoIW5leHRJbmZvKSB7XG4gICAgICB0aHJvdyBuZXcgQW50aHJvcGljRXJyb3IoXG4gICAgICAgICdObyBuZXh0IHBhZ2UgZXhwZWN0ZWQ7IHBsZWFzZSBjaGVjayBgLmhhc05leHRQYWdlKClgIGJlZm9yZSBjYWxsaW5nIGAuZ2V0TmV4dFBhZ2UoKWAuJyxcbiAgICAgICk7XG4gICAgfVxuICAgIGNvbnN0IG5leHRPcHRpb25zID0geyAuLi50aGlzLm9wdGlvbnMgfTtcbiAgICBpZiAoJ3BhcmFtcycgaW4gbmV4dEluZm8gJiYgdHlwZW9mIG5leHRPcHRpb25zLnF1ZXJ5ID09PSAnb2JqZWN0Jykge1xuICAgICAgbmV4dE9wdGlvbnMucXVlcnkgPSB7IC4uLm5leHRPcHRpb25zLnF1ZXJ5LCAuLi5uZXh0SW5mby5wYXJhbXMgfTtcbiAgICB9IGVsc2UgaWYgKCd1cmwnIGluIG5leHRJbmZvKSB7XG4gICAgICBjb25zdCBwYXJhbXMgPSBbLi4uT2JqZWN0LmVudHJpZXMobmV4dE9wdGlvbnMucXVlcnkgfHwge30pLCAuLi5uZXh0SW5mby51cmwuc2VhcmNoUGFyYW1zLmVudHJpZXMoKV07XG4gICAgICBmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBwYXJhbXMpIHtcbiAgICAgICAgbmV4dEluZm8udXJsLnNlYXJjaFBhcmFtcy5zZXQoa2V5LCB2YWx1ZSBhcyBhbnkpO1xuICAgICAgfVxuICAgICAgbmV4dE9wdGlvbnMucXVlcnkgPSB1bmRlZmluZWQ7XG4gICAgICBuZXh0T3B0aW9ucy5wYXRoID0gbmV4dEluZm8udXJsLnRvU3RyaW5nKCk7XG4gICAgfVxuICAgIHJldHVybiBhd2FpdCB0aGlzLiNjbGllbnQucmVxdWVzdEFQSUxpc3QodGhpcy5jb25zdHJ1Y3RvciBhcyBhbnksIG5leHRPcHRpb25zKTtcbiAgfVxuXG4gIGFzeW5jICppdGVyUGFnZXMoKSB7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby10aGlzLWFsaWFzXG4gICAgbGV0IHBhZ2U6IEFic3RyYWN0UGFnZTxJdGVtPiA9IHRoaXM7XG4gICAgeWllbGQgcGFnZTtcbiAgICB3aGlsZSAocGFnZS5oYXNOZXh0UGFnZSgpKSB7XG4gICAgICBwYWdlID0gYXdhaXQgcGFnZS5nZXROZXh0UGFnZSgpO1xuICAgICAgeWllbGQgcGFnZTtcbiAgICB9XG4gIH1cblxuICBhc3luYyAqW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSgpIHtcbiAgICBmb3IgYXdhaXQgKGNvbnN0IHBhZ2Ugb2YgdGhpcy5pdGVyUGFnZXMoKSkge1xuICAgICAgZm9yIChjb25zdCBpdGVtIG9mIHBhZ2UuZ2V0UGFnaW5hdGVkSXRlbXMoKSkge1xuICAgICAgICB5aWVsZCBpdGVtO1xuICAgICAgfVxuICAgIH1cbiAgfVxufVxuXG4vKipcbiAqIFRoaXMgc3ViY2xhc3Mgb2YgUHJvbWlzZSB3aWxsIHJlc29sdmUgdG8gYW4gaW5zdGFudGlhdGVkIFBhZ2Ugb25jZSB0aGUgcmVxdWVzdCBjb21wbGV0ZXMuXG4gKlxuICogSXQgYWxzbyBpbXBsZW1lbnRzIEFzeW5jSXRlcmFibGUgdG8gYWxsb3cgYXV0by1wYWdpbmF0aW5nIGl0ZXJhdGlvbiBvbiBhbiB1bmF3YWl0ZWQgbGlzdCBjYWxsLCBlZzpcbiAqXG4gKiAgICBmb3IgYXdhaXQgKGNvbnN0IGl0ZW0gb2YgY2xpZW50Lml0ZW1zLmxpc3QoKSkge1xuICogICAgICBjb25zb2xlLmxvZyhpdGVtKVxuICogICAgfVxuICovXG5leHBvcnQgY2xhc3MgUGFnZVByb21pc2U8XG4gICAgUGFnZUNsYXNzIGV4dGVuZHMgQWJzdHJhY3RQYWdlPEl0ZW0+LFxuICAgIEl0ZW0gPSBSZXR1cm5UeXBlPFBhZ2VDbGFzc1snZ2V0UGFnaW5hdGVkSXRlbXMnXT5bbnVtYmVyXSxcbiAgPlxuICBleHRlbmRzIEFQSVByb21pc2U8UGFnZUNsYXNzPlxuICBpbXBsZW1lbnRzIEFzeW5jSXRlcmFibGU8SXRlbT5cbntcbiAgY29uc3RydWN0b3IoXG4gICAgY2xpZW50OiBBUElDbGllbnQsXG4gICAgcmVxdWVzdDogUHJvbWlzZTxBUElSZXNwb25zZVByb3BzPixcbiAgICBQYWdlOiBuZXcgKC4uLmFyZ3M6IENvbnN0cnVjdG9yUGFyYW1ldGVyczx0eXBlb2YgQWJzdHJhY3RQYWdlPikgPT4gUGFnZUNsYXNzLFxuICApIHtcbiAgICBzdXBlcihcbiAgICAgIHJlcXVlc3QsXG4gICAgICBhc3luYyAocHJvcHMpID0+IG5ldyBQYWdlKGNsaWVudCwgcHJvcHMucmVzcG9uc2UsIGF3YWl0IGRlZmF1bHRQYXJzZVJlc3BvbnNlKHByb3BzKSwgcHJvcHMub3B0aW9ucyksXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBbGxvdyBhdXRvLXBhZ2luYXRpbmcgaXRlcmF0aW9uIG9uIGFuIHVuYXdhaXRlZCBsaXN0IGNhbGwsIGVnOlxuICAgKlxuICAgKiAgICBmb3IgYXdhaXQgKGNvbnN0IGl0ZW0gb2YgY2xpZW50Lml0ZW1zLmxpc3QoKSkge1xuICAgKiAgICAgIGNvbnNvbGUubG9nKGl0ZW0pXG4gICAqICAgIH1cbiAgICovXG4gIGFzeW5jICpbU3ltYm9sLmFzeW5jSXRlcmF0b3JdKCkge1xuICAgIGNvbnN0IHBhZ2UgPSBhd2FpdCB0aGlzO1xuICAgIGZvciBhd2FpdCAoY29uc3QgaXRlbSBvZiBwYWdlKSB7XG4gICAgICB5aWVsZCBpdGVtO1xuICAgIH1cbiAgfVxufVxuXG5leHBvcnQgY29uc3QgY3JlYXRlUmVzcG9uc2VIZWFkZXJzID0gKFxuICBoZWFkZXJzOiBBd2FpdGVkPFJldHVyblR5cGU8RmV0Y2g+PlsnaGVhZGVycyddLFxuKTogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9PiB7XG4gIHJldHVybiBuZXcgUHJveHkoXG4gICAgT2JqZWN0LmZyb21FbnRyaWVzKFxuICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgaGVhZGVycy5lbnRyaWVzKCksXG4gICAgKSxcbiAgICB7XG4gICAgICBnZXQodGFyZ2V0LCBuYW1lKSB7XG4gICAgICAgIGNvbnN0IGtleSA9IG5hbWUudG9TdHJpbmcoKTtcbiAgICAgICAgcmV0dXJuIHRhcmdldFtrZXkudG9Mb3dlckNhc2UoKV0gfHwgdGFyZ2V0W2tleV07XG4gICAgICB9LFxuICAgIH0sXG4gICk7XG59O1xuXG50eXBlIEhUVFBNZXRob2QgPSAnZ2V0JyB8ICdwb3N0JyB8ICdwdXQnIHwgJ3BhdGNoJyB8ICdkZWxldGUnO1xuXG5leHBvcnQgdHlwZSBSZXF1ZXN0Q2xpZW50ID0geyBmZXRjaDogRmV0Y2ggfTtcbmV4cG9ydCB0eXBlIEhlYWRlcnMgPSBSZWNvcmQ8c3RyaW5nLCBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkPjtcbmV4cG9ydCB0eXBlIERlZmF1bHRRdWVyeSA9IFJlY29yZDxzdHJpbmcsIHN0cmluZyB8IHVuZGVmaW5lZD47XG5leHBvcnQgdHlwZSBLZXlzRW51bTxUPiA9IHsgW1AgaW4ga2V5b2YgUmVxdWlyZWQ8VD5dOiB0cnVlIH07XG5cbmV4cG9ydCB0eXBlIFJlcXVlc3RPcHRpb25zPFxuICBSZXEgPSB1bmtub3duIHwgUmVjb3JkPHN0cmluZywgdW5rbm93bj4gfCBSZWFkYWJsZSB8IEJsb2JMaWtlIHwgQXJyYXlCdWZmZXJWaWV3IHwgQXJyYXlCdWZmZXIsXG4+ID0ge1xuICBtZXRob2Q/OiBIVFRQTWV0aG9kO1xuICBwYXRoPzogc3RyaW5nO1xuICBxdWVyeT86IFJlcSB8IHVuZGVmaW5lZDtcbiAgYm9keT86IFJlcSB8IG51bGwgfCB1bmRlZmluZWQ7XG4gIGhlYWRlcnM/OiBIZWFkZXJzIHwgdW5kZWZpbmVkO1xuXG4gIG1heFJldHJpZXM/OiBudW1iZXI7XG4gIHN0cmVhbT86IGJvb2xlYW4gfCB1bmRlZmluZWQ7XG4gIHRpbWVvdXQ/OiBudW1iZXI7XG4gIGh0dHBBZ2VudD86IEFnZW50O1xuICBzaWduYWw/OiBBYm9ydFNpZ25hbCB8IHVuZGVmaW5lZCB8IG51bGw7XG4gIGlkZW1wb3RlbmN5S2V5Pzogc3RyaW5nO1xuXG4gIF9fYmluYXJ5UmVxdWVzdD86IGJvb2xlYW4gfCB1bmRlZmluZWQ7XG4gIF9fYmluYXJ5UmVzcG9uc2U/OiBib29sZWFuIHwgdW5kZWZpbmVkO1xuICBfX3N0cmVhbUNsYXNzPzogdHlwZW9mIFN0cmVhbTtcbn07XG5cbi8vIFRoaXMgaXMgcmVxdWlyZWQgc28gdGhhdCB3ZSBjYW4gZGV0ZXJtaW5lIGlmIGEgZ2l2ZW4gb2JqZWN0IG1hdGNoZXMgdGhlIFJlcXVlc3RPcHRpb25zXG4vLyB0eXBlIGF0IHJ1bnRpbWUuIFdoaWxlIHRoaXMgcmVxdWlyZXMgZHVwbGljYXRpb24sIGl0IGlzIGVuZm9yY2VkIGJ5IHRoZSBUeXBlU2NyaXB0XG4vLyBjb21waWxlciBzdWNoIHRoYXQgYW55IG1pc3NpbmcgLyBleHRyYW5lb3VzIGtleXMgd2lsbCBjYXVzZSBhbiBlcnJvci5cbmNvbnN0IHJlcXVlc3RPcHRpb25zS2V5czogS2V5c0VudW08UmVxdWVzdE9wdGlvbnM+ID0ge1xuICBtZXRob2Q6IHRydWUsXG4gIHBhdGg6IHRydWUsXG4gIHF1ZXJ5OiB0cnVlLFxuICBib2R5OiB0cnVlLFxuICBoZWFkZXJzOiB0cnVlLFxuXG4gIG1heFJldHJpZXM6IHRydWUsXG4gIHN0cmVhbTogdHJ1ZSxcbiAgdGltZW91dDogdHJ1ZSxcbiAgaHR0cEFnZW50OiB0cnVlLFxuICBzaWduYWw6IHRydWUsXG4gIGlkZW1wb3RlbmN5S2V5OiB0cnVlLFxuXG4gIF9fYmluYXJ5UmVxdWVzdDogdHJ1ZSxcbiAgX19iaW5hcnlSZXNwb25zZTogdHJ1ZSxcbiAgX19zdHJlYW1DbGFzczogdHJ1ZSxcbn07XG5cbmV4cG9ydCBjb25zdCBpc1JlcXVlc3RPcHRpb25zID0gKG9iajogdW5rbm93bik6IG9iaiBpcyBSZXF1ZXN0T3B0aW9ucyA9PiB7XG4gIHJldHVybiAoXG4gICAgdHlwZW9mIG9iaiA9PT0gJ29iamVjdCcgJiZcbiAgICBvYmogIT09IG51bGwgJiZcbiAgICAhaXNFbXB0eU9iaihvYmopICYmXG4gICAgT2JqZWN0LmtleXMob2JqKS5ldmVyeSgoaykgPT4gaGFzT3duKHJlcXVlc3RPcHRpb25zS2V5cywgaykpXG4gICk7XG59O1xuXG5leHBvcnQgdHlwZSBGaW5hbFJlcXVlc3RPcHRpb25zPFJlcSA9IHVua25vd24gfCBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IFJlYWRhYmxlIHwgRGF0YVZpZXc+ID1cbiAgUmVxdWVzdE9wdGlvbnM8UmVxPiAmIHtcbiAgICBtZXRob2Q6IEhUVFBNZXRob2Q7XG4gICAgcGF0aDogc3RyaW5nO1xuICB9O1xuXG5kZWNsYXJlIGNvbnN0IERlbm86IGFueTtcbmRlY2xhcmUgY29uc3QgRWRnZVJ1bnRpbWU6IGFueTtcbnR5cGUgQXJjaCA9ICd4MzInIHwgJ3g2NCcgfCAnYXJtJyB8ICdhcm02NCcgfCBgb3RoZXI6JHtzdHJpbmd9YCB8ICd1bmtub3duJztcbnR5cGUgUGxhdGZvcm1OYW1lID1cbiAgfCAnTWFjT1MnXG4gIHwgJ0xpbnV4J1xuICB8ICdXaW5kb3dzJ1xuICB8ICdGcmVlQlNEJ1xuICB8ICdPcGVuQlNEJ1xuICB8ICdpT1MnXG4gIHwgJ0FuZHJvaWQnXG4gIHwgYE90aGVyOiR7c3RyaW5nfWBcbiAgfCAnVW5rbm93bic7XG50eXBlIEJyb3dzZXIgPSAnaWUnIHwgJ2VkZ2UnIHwgJ2Nocm9tZScgfCAnZmlyZWZveCcgfCAnc2FmYXJpJztcbnR5cGUgUGxhdGZvcm1Qcm9wZXJ0aWVzID0ge1xuICAnWC1TdGFpbmxlc3MtTGFuZyc6ICdqcyc7XG4gICdYLVN0YWlubGVzcy1QYWNrYWdlLVZlcnNpb24nOiBzdHJpbmc7XG4gICdYLVN0YWlubGVzcy1PUyc6IFBsYXRmb3JtTmFtZTtcbiAgJ1gtU3RhaW5sZXNzLUFyY2gnOiBBcmNoO1xuICAnWC1TdGFpbmxlc3MtUnVudGltZSc6ICdub2RlJyB8ICdkZW5vJyB8ICdlZGdlJyB8IGBicm93c2VyOiR7QnJvd3Nlcn1gIHwgJ3Vua25vd24nO1xuICAnWC1TdGFpbmxlc3MtUnVudGltZS1WZXJzaW9uJzogc3RyaW5nO1xufTtcbmNvbnN0IGdldFBsYXRmb3JtUHJvcGVydGllcyA9ICgpOiBQbGF0Zm9ybVByb3BlcnRpZXMgPT4ge1xuICBpZiAodHlwZW9mIERlbm8gIT09ICd1bmRlZmluZWQnICYmIERlbm8uYnVpbGQgIT0gbnVsbCkge1xuICAgIHJldHVybiB7XG4gICAgICAnWC1TdGFpbmxlc3MtTGFuZyc6ICdqcycsXG4gICAgICAnWC1TdGFpbmxlc3MtUGFja2FnZS1WZXJzaW9uJzogVkVSU0lPTixcbiAgICAgICdYLVN0YWlubGVzcy1PUyc6IG5vcm1hbGl6ZVBsYXRmb3JtKERlbm8uYnVpbGQub3MpLFxuICAgICAgJ1gtU3RhaW5sZXNzLUFyY2gnOiBub3JtYWxpemVBcmNoKERlbm8uYnVpbGQuYXJjaCksXG4gICAgICAnWC1TdGFpbmxlc3MtUnVudGltZSc6ICdkZW5vJyxcbiAgICAgICdYLVN0YWlubGVzcy1SdW50aW1lLVZlcnNpb24nOlxuICAgICAgICB0eXBlb2YgRGVuby52ZXJzaW9uID09PSAnc3RyaW5nJyA/IERlbm8udmVyc2lvbiA6IERlbm8udmVyc2lvbj8uZGVubyA/PyAndW5rbm93bicsXG4gICAgfTtcbiAgfVxuICBpZiAodHlwZW9mIEVkZ2VSdW50aW1lICE9PSAndW5kZWZpbmVkJykge1xuICAgIHJldHVybiB7XG4gICAgICAnWC1TdGFpbmxlc3MtTGFuZyc6ICdqcycsXG4gICAgICAnWC1TdGFpbmxlc3MtUGFja2FnZS1WZXJzaW9uJzogVkVSU0lPTixcbiAgICAgICdYLVN0YWlubGVzcy1PUyc6ICdVbmtub3duJyxcbiAgICAgICdYLVN0YWlubGVzcy1BcmNoJzogYG90aGVyOiR7RWRnZVJ1bnRpbWV9YCxcbiAgICAgICdYLVN0YWlubGVzcy1SdW50aW1lJzogJ2VkZ2UnLFxuICAgICAgJ1gtU3RhaW5sZXNzLVJ1bnRpbWUtVmVyc2lvbic6IHByb2Nlc3MudmVyc2lvbixcbiAgICB9O1xuICB9XG4gIC8vIENoZWNrIGlmIE5vZGUuanNcbiAgaWYgKE9iamVjdC5wcm90b3R5cGUudG9TdHJpbmcuY2FsbCh0eXBlb2YgcHJvY2VzcyAhPT0gJ3VuZGVmaW5lZCcgPyBwcm9jZXNzIDogMCkgPT09ICdbb2JqZWN0IHByb2Nlc3NdJykge1xuICAgIHJldHVybiB7XG4gICAgICAnWC1TdGFpbmxlc3MtTGFuZyc6ICdqcycsXG4gICAgICAnWC1TdGFpbmxlc3MtUGFja2FnZS1WZXJzaW9uJzogVkVSU0lPTixcbiAgICAgICdYLVN0YWlubGVzcy1PUyc6IG5vcm1hbGl6ZVBsYXRmb3JtKHByb2Nlc3MucGxhdGZvcm0pLFxuICAgICAgJ1gtU3RhaW5sZXNzLUFyY2gnOiBub3JtYWxpemVBcmNoKHByb2Nlc3MuYXJjaCksXG4gICAgICAnWC1TdGFpbmxlc3MtUnVudGltZSc6ICdub2RlJyxcbiAgICAgICdYLVN0YWlubGVzcy1SdW50aW1lLVZlcnNpb24nOiBwcm9jZXNzLnZlcnNpb24sXG4gICAgfTtcbiAgfVxuXG4gIGNvbnN0IGJyb3dzZXJJbmZvID0gZ2V0QnJvd3NlckluZm8oKTtcbiAgaWYgKGJyb3dzZXJJbmZvKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICdYLVN0YWlubGVzcy1MYW5nJzogJ2pzJyxcbiAgICAgICdYLVN0YWlubGVzcy1QYWNrYWdlLVZlcnNpb24nOiBWRVJTSU9OLFxuICAgICAgJ1gtU3RhaW5sZXNzLU9TJzogJ1Vua25vd24nLFxuICAgICAgJ1gtU3RhaW5sZXNzLUFyY2gnOiAndW5rbm93bicsXG4gICAgICAnWC1TdGFpbmxlc3MtUnVudGltZSc6IGBicm93c2VyOiR7YnJvd3NlckluZm8uYnJvd3Nlcn1gLFxuICAgICAgJ1gtU3RhaW5sZXNzLVJ1bnRpbWUtVmVyc2lvbic6IGJyb3dzZXJJbmZvLnZlcnNpb24sXG4gICAgfTtcbiAgfVxuXG4gIC8vIFRPRE8gYWRkIHN1cHBvcnQgZm9yIENsb3VkZmxhcmUgd29ya2VycywgZXRjLlxuICByZXR1cm4ge1xuICAgICdYLVN0YWlubGVzcy1MYW5nJzogJ2pzJyxcbiAgICAnWC1TdGFpbmxlc3MtUGFja2FnZS1WZXJzaW9uJzogVkVSU0lPTixcbiAgICAnWC1TdGFpbmxlc3MtT1MnOiAnVW5rbm93bicsXG4gICAgJ1gtU3RhaW5sZXNzLUFyY2gnOiAndW5rbm93bicsXG4gICAgJ1gtU3RhaW5sZXNzLVJ1bnRpbWUnOiAndW5rbm93bicsXG4gICAgJ1gtU3RhaW5sZXNzLVJ1bnRpbWUtVmVyc2lvbic6ICd1bmtub3duJyxcbiAgfTtcbn07XG5cbnR5cGUgQnJvd3NlckluZm8gPSB7XG4gIGJyb3dzZXI6IEJyb3dzZXI7XG4gIHZlcnNpb246IHN0cmluZztcbn07XG5cbmRlY2xhcmUgY29uc3QgbmF2aWdhdG9yOiB7IHVzZXJBZ2VudDogc3RyaW5nIH0gfCB1bmRlZmluZWQ7XG5cbi8vIE5vdGU6IG1vZGlmaWVkIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL0pTLURldlRvb2xzL2hvc3QtZW52aXJvbm1lbnQvYmxvYi9iMWFiNzllY2RlMzdkYjVkNmUxNjNjMDUwZTU0ZmU3ZDI4N2Q3YzkyL3NyYy9pc29tb3JwaGljLmJyb3dzZXIudHNcbmZ1bmN0aW9uIGdldEJyb3dzZXJJbmZvKCk6IEJyb3dzZXJJbmZvIHwgbnVsbCB7XG4gIGlmICh0eXBlb2YgbmF2aWdhdG9yID09PSAndW5kZWZpbmVkJyB8fCAhbmF2aWdhdG9yKSB7XG4gICAgcmV0dXJuIG51bGw7XG4gIH1cblxuICAvLyBOT1RFOiBUaGUgb3JkZXIgbWF0dGVycyBoZXJlIVxuICBjb25zdCBicm93c2VyUGF0dGVybnMgPSBbXG4gICAgeyBrZXk6ICdlZGdlJyBhcyBjb25zdCwgcGF0dGVybjogL0VkZ2UoPzpcXFcrKFxcZCspXFwuKFxcZCspKD86XFwuKFxcZCspKT8pPy8gfSxcbiAgICB7IGtleTogJ2llJyBhcyBjb25zdCwgcGF0dGVybjogL01TSUUoPzpcXFcrKFxcZCspXFwuKFxcZCspKD86XFwuKFxcZCspKT8pPy8gfSxcbiAgICB7IGtleTogJ2llJyBhcyBjb25zdCwgcGF0dGVybjogL1RyaWRlbnQoPzouKnJ2XFw6KFxcZCspXFwuKFxcZCspKD86XFwuKFxcZCspKT8pPy8gfSxcbiAgICB7IGtleTogJ2Nocm9tZScgYXMgY29uc3QsIHBhdHRlcm46IC9DaHJvbWUoPzpcXFcrKFxcZCspXFwuKFxcZCspKD86XFwuKFxcZCspKT8pPy8gfSxcbiAgICB7IGtleTogJ2ZpcmVmb3gnIGFzIGNvbnN0LCBwYXR0ZXJuOiAvRmlyZWZveCg/OlxcVysoXFxkKylcXC4oXFxkKykoPzpcXC4oXFxkKykpPyk/LyB9LFxuICAgIHsga2V5OiAnc2FmYXJpJyBhcyBjb25zdCwgcGF0dGVybjogLyg/OlZlcnNpb25cXFcrKFxcZCspXFwuKFxcZCspKD86XFwuKFxcZCspKT8pPyg/OlxcVytNb2JpbGVcXFMqKT9cXFcrU2FmYXJpLyB9LFxuICBdO1xuXG4gIC8vIEZpbmQgdGhlIEZJUlNUIG1hdGNoaW5nIGJyb3dzZXJcbiAgZm9yIChjb25zdCB7IGtleSwgcGF0dGVybiB9IG9mIGJyb3dzZXJQYXR0ZXJucykge1xuICAgIGNvbnN0IG1hdGNoID0gcGF0dGVybi5leGVjKG5hdmlnYXRvci51c2VyQWdlbnQpO1xuICAgIGlmIChtYXRjaCkge1xuICAgICAgY29uc3QgbWFqb3IgPSBtYXRjaFsxXSB8fCAwO1xuICAgICAgY29uc3QgbWlub3IgPSBtYXRjaFsyXSB8fCAwO1xuICAgICAgY29uc3QgcGF0Y2ggPSBtYXRjaFszXSB8fCAwO1xuXG4gICAgICByZXR1cm4geyBicm93c2VyOiBrZXksIHZlcnNpb246IGAke21ham9yfS4ke21pbm9yfS4ke3BhdGNofWAgfTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gbnVsbDtcbn1cblxuY29uc3Qgbm9ybWFsaXplQXJjaCA9IChhcmNoOiBzdHJpbmcpOiBBcmNoID0+IHtcbiAgLy8gTm9kZSBkb2NzOlxuICAvLyAtIGh0dHBzOi8vbm9kZWpzLm9yZy9hcGkvcHJvY2Vzcy5odG1sI3Byb2Nlc3NhcmNoXG4gIC8vIERlbm8gZG9jczpcbiAgLy8gLSBodHRwczovL2RvYy5kZW5vLmxhbmQvZGVuby9zdGFibGUvfi9EZW5vLmJ1aWxkXG4gIGlmIChhcmNoID09PSAneDMyJykgcmV0dXJuICd4MzInO1xuICBpZiAoYXJjaCA9PT0gJ3g4Nl82NCcgfHwgYXJjaCA9PT0gJ3g2NCcpIHJldHVybiAneDY0JztcbiAgaWYgKGFyY2ggPT09ICdhcm0nKSByZXR1cm4gJ2FybSc7XG4gIGlmIChhcmNoID09PSAnYWFyY2g2NCcgfHwgYXJjaCA9PT0gJ2FybTY0JykgcmV0dXJuICdhcm02NCc7XG4gIGlmIChhcmNoKSByZXR1cm4gYG90aGVyOiR7YXJjaH1gO1xuICByZXR1cm4gJ3Vua25vd24nO1xufTtcblxuY29uc3Qgbm9ybWFsaXplUGxhdGZvcm0gPSAocGxhdGZvcm06IHN0cmluZyk6IFBsYXRmb3JtTmFtZSA9PiB7XG4gIC8vIE5vZGUgcGxhdGZvcm1zOlxuICAvLyAtIGh0dHBzOi8vbm9kZWpzLm9yZy9hcGkvcHJvY2Vzcy5odG1sI3Byb2Nlc3NwbGF0Zm9ybVxuICAvLyBEZW5vIHBsYXRmb3JtczpcbiAgLy8gLSBodHRwczovL2RvYy5kZW5vLmxhbmQvZGVuby9zdGFibGUvfi9EZW5vLmJ1aWxkXG4gIC8vIC0gaHR0cHM6Ly9naXRodWIuY29tL2Rlbm9sYW5kL2Rlbm8vaXNzdWVzLzE0Nzk5XG5cbiAgcGxhdGZvcm0gPSBwbGF0Zm9ybS50b0xvd2VyQ2FzZSgpO1xuXG4gIC8vIE5PVEU6IHRoaXMgaU9TIGNoZWNrIGlzIHVudGVzdGVkIGFuZCBtYXkgbm90IHdvcmtcbiAgLy8gTm9kZSBkb2VzIG5vdCB3b3JrIG5hdGl2ZWx5IG9uIElPUywgdGhlcmUgaXMgYSBmb3JrIGF0XG4gIC8vIGh0dHBzOi8vZ2l0aHViLmNvbS9ub2RlanMtbW9iaWxlL25vZGVqcy1tb2JpbGVcbiAgLy8gaG93ZXZlciBpdCBpcyB1bmtub3duIGF0IHRoZSB0aW1lIG9mIHdyaXRpbmcgaG93IHRvIGRldGVjdCBpZiBpdCBpcyBydW5uaW5nXG4gIGlmIChwbGF0Zm9ybS5pbmNsdWRlcygnaW9zJykpIHJldHVybiAnaU9TJztcbiAgaWYgKHBsYXRmb3JtID09PSAnYW5kcm9pZCcpIHJldHVybiAnQW5kcm9pZCc7XG4gIGlmIChwbGF0Zm9ybSA9PT0gJ2RhcndpbicpIHJldHVybiAnTWFjT1MnO1xuICBpZiAocGxhdGZvcm0gPT09ICd3aW4zMicpIHJldHVybiAnV2luZG93cyc7XG4gIGlmIChwbGF0Zm9ybSA9PT0gJ2ZyZWVic2QnKSByZXR1cm4gJ0ZyZWVCU0QnO1xuICBpZiAocGxhdGZvcm0gPT09ICdvcGVuYnNkJykgcmV0dXJuICdPcGVuQlNEJztcbiAgaWYgKHBsYXRmb3JtID09PSAnbGludXgnKSByZXR1cm4gJ0xpbnV4JztcbiAgaWYgKHBsYXRmb3JtKSByZXR1cm4gYE90aGVyOiR7cGxhdGZvcm19YDtcbiAgcmV0dXJuICdVbmtub3duJztcbn07XG5cbmxldCBfcGxhdGZvcm1IZWFkZXJzOiBQbGF0Zm9ybVByb3BlcnRpZXM7XG5jb25zdCBnZXRQbGF0Zm9ybUhlYWRlcnMgPSAoKSA9PiB7XG4gIHJldHVybiAoX3BsYXRmb3JtSGVhZGVycyA/Pz0gZ2V0UGxhdGZvcm1Qcm9wZXJ0aWVzKCkpO1xufTtcblxuZXhwb3J0IGNvbnN0IHNhZmVKU09OID0gKHRleHQ6IHN0cmluZykgPT4ge1xuICB0cnkge1xuICAgIHJldHVybiBKU09OLnBhcnNlKHRleHQpO1xuICB9IGNhdGNoIChlcnIpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG59O1xuXG4vLyBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL2EvMTk3MDk4NDZcbmNvbnN0IHN0YXJ0c1dpdGhTY2hlbWVSZWdleHAgPSBuZXcgUmVnRXhwKCdeKD86W2Etel0rOik/Ly8nLCAnaScpO1xuY29uc3QgaXNBYnNvbHV0ZVVSTCA9ICh1cmw6IHN0cmluZyk6IGJvb2xlYW4gPT4ge1xuICByZXR1cm4gc3RhcnRzV2l0aFNjaGVtZVJlZ2V4cC50ZXN0KHVybCk7XG59O1xuXG5leHBvcnQgY29uc3Qgc2xlZXAgPSAobXM6IG51bWJlcikgPT4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHNldFRpbWVvdXQocmVzb2x2ZSwgbXMpKTtcblxuY29uc3QgdmFsaWRhdGVQb3NpdGl2ZUludGVnZXIgPSAobmFtZTogc3RyaW5nLCBuOiB1bmtub3duKTogbnVtYmVyID0+IHtcbiAgaWYgKHR5cGVvZiBuICE9PSAnbnVtYmVyJyB8fCAhTnVtYmVyLmlzSW50ZWdlcihuKSkge1xuICAgIHRocm93IG5ldyBBbnRocm9waWNFcnJvcihgJHtuYW1lfSBtdXN0IGJlIGFuIGludGVnZXJgKTtcbiAgfVxuICBpZiAobiA8IDApIHtcbiAgICB0aHJvdyBuZXcgQW50aHJvcGljRXJyb3IoYCR7bmFtZX0gbXVzdCBiZSBhIHBvc2l0aXZlIGludGVnZXJgKTtcbiAgfVxuICByZXR1cm4gbjtcbn07XG5cbmV4cG9ydCBjb25zdCBjYXN0VG9FcnJvciA9IChlcnI6IGFueSk6IEVycm9yID0+IHtcbiAgaWYgKGVyciBpbnN0YW5jZW9mIEVycm9yKSByZXR1cm4gZXJyO1xuICBpZiAodHlwZW9mIGVyciA9PT0gJ29iamVjdCcgJiYgZXJyICE9PSBudWxsKSB7XG4gICAgdHJ5IHtcbiAgICAgIHJldHVybiBuZXcgRXJyb3IoSlNPTi5zdHJpbmdpZnkoZXJyKSk7XG4gICAgfSBjYXRjaCB7fVxuICB9XG4gIHJldHVybiBuZXcgRXJyb3IoU3RyaW5nKGVycikpO1xufTtcblxuZXhwb3J0IGNvbnN0IGVuc3VyZVByZXNlbnQgPSA8VD4odmFsdWU6IFQgfCBudWxsIHwgdW5kZWZpbmVkKTogVCA9PiB7XG4gIGlmICh2YWx1ZSA9PSBudWxsKSB0aHJvdyBuZXcgQW50aHJvcGljRXJyb3IoYEV4cGVjdGVkIGEgdmFsdWUgdG8gYmUgZ2l2ZW4gYnV0IHJlY2VpdmVkICR7dmFsdWV9IGluc3RlYWQuYCk7XG4gIHJldHVybiB2YWx1ZTtcbn07XG5cbi8qKlxuICogUmVhZCBhbiBlbnZpcm9ubWVudCB2YXJpYWJsZS5cbiAqXG4gKiBUcmltcyBiZWdpbm5pbmcgYW5kIHRyYWlsaW5nIHdoaXRlc3BhY2UuXG4gKlxuICogV2lsbCByZXR1cm4gdW5kZWZpbmVkIGlmIHRoZSBlbnZpcm9ubWVudCB2YXJpYWJsZSBkb2Vzbid0IGV4aXN0IG9yIGNhbm5vdCBiZSBhY2Nlc3NlZC5cbiAqL1xuZXhwb3J0IGNvbnN0IHJlYWRFbnYgPSAoZW52OiBzdHJpbmcpOiBzdHJpbmcgfCB1bmRlZmluZWQgPT4ge1xuICBpZiAodHlwZW9mIHByb2Nlc3MgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgcmV0dXJuIHByb2Nlc3MuZW52Py5bZW52XT8udHJpbSgpID8/IHVuZGVmaW5lZDtcbiAgfVxuICBpZiAodHlwZW9mIERlbm8gIT09ICd1bmRlZmluZWQnKSB7XG4gICAgcmV0dXJuIERlbm8uZW52Py5nZXQ/LihlbnYpPy50cmltKCk7XG4gIH1cbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn07XG5cbmV4cG9ydCBjb25zdCBjb2VyY2VJbnRlZ2VyID0gKHZhbHVlOiB1bmtub3duKTogbnVtYmVyID0+IHtcbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicpIHJldHVybiBNYXRoLnJvdW5kKHZhbHVlKTtcbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHJldHVybiBwYXJzZUludCh2YWx1ZSwgMTApO1xuXG4gIHRocm93IG5ldyBBbnRocm9waWNFcnJvcihgQ291bGQgbm90IGNvZXJjZSAke3ZhbHVlfSAodHlwZTogJHt0eXBlb2YgdmFsdWV9KSBpbnRvIGEgbnVtYmVyYCk7XG59O1xuXG5leHBvcnQgY29uc3QgY29lcmNlRmxvYXQgPSAodmFsdWU6IHVua25vd24pOiBudW1iZXIgPT4ge1xuICBpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykgcmV0dXJuIHZhbHVlO1xuICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykgcmV0dXJuIHBhcnNlRmxvYXQodmFsdWUpO1xuXG4gIHRocm93IG5ldyBBbnRocm9waWNFcnJvcihgQ291bGQgbm90IGNvZXJjZSAke3ZhbHVlfSAodHlwZTogJHt0eXBlb2YgdmFsdWV9KSBpbnRvIGEgbnVtYmVyYCk7XG59O1xuXG5leHBvcnQgY29uc3QgY29lcmNlQm9vbGVhbiA9ICh2YWx1ZTogdW5rbm93bik6IGJvb2xlYW4gPT4ge1xuICBpZiAodHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbicpIHJldHVybiB2YWx1ZTtcbiAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ3N0cmluZycpIHJldHVybiB2YWx1ZSA9PT0gJ3RydWUnO1xuICByZXR1cm4gQm9vbGVhbih2YWx1ZSk7XG59O1xuXG5leHBvcnQgY29uc3QgbWF5YmVDb2VyY2VJbnRlZ2VyID0gKHZhbHVlOiB1bmtub3duKTogbnVtYmVyIHwgdW5kZWZpbmVkID0+IHtcbiAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHJldHVybiBjb2VyY2VJbnRlZ2VyKHZhbHVlKTtcbn07XG5cbmV4cG9ydCBjb25zdCBtYXliZUNvZXJjZUZsb2F0ID0gKHZhbHVlOiB1bmtub3duKTogbnVtYmVyIHwgdW5kZWZpbmVkID0+IHtcbiAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHJldHVybiBjb2VyY2VGbG9hdCh2YWx1ZSk7XG59O1xuXG5leHBvcnQgY29uc3QgbWF5YmVDb2VyY2VCb29sZWFuID0gKHZhbHVlOiB1bmtub3duKTogYm9vbGVhbiB8IHVuZGVmaW5lZCA9PiB7XG4gIGlmICh2YWx1ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbiAgfVxuICByZXR1cm4gY29lcmNlQm9vbGVhbih2YWx1ZSk7XG59O1xuXG4vLyBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL2EvMzQ0OTEyODdcbmV4cG9ydCBmdW5jdGlvbiBpc0VtcHR5T2JqKG9iajogT2JqZWN0IHwgbnVsbCB8IHVuZGVmaW5lZCk6IGJvb2xlYW4ge1xuICBpZiAoIW9iaikgcmV0dXJuIHRydWU7XG4gIGZvciAoY29uc3QgX2sgaW4gb2JqKSByZXR1cm4gZmFsc2U7XG4gIHJldHVybiB0cnVlO1xufVxuXG4vLyBodHRwczovL2VzbGludC5vcmcvZG9jcy9sYXRlc3QvcnVsZXMvbm8tcHJvdG90eXBlLWJ1aWx0aW5zXG5leHBvcnQgZnVuY3Rpb24gaGFzT3duKG9iajogT2JqZWN0LCBrZXk6IHN0cmluZyk6IGJvb2xlYW4ge1xuICByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKG9iaiwga2V5KTtcbn1cblxuLyoqXG4gKiBDb3BpZXMgaGVhZGVycyBmcm9tIFwibmV3SGVhZGVyc1wiIG9udG8gXCJ0YXJnZXRIZWFkZXJzXCIsXG4gKiB1c2luZyBsb3dlci1jYXNlIGZvciBhbGwgcHJvcGVydGllcyxcbiAqIGlnbm9yaW5nIGFueSBrZXlzIHdpdGggdW5kZWZpbmVkIHZhbHVlcyxcbiAqIGFuZCBkZWxldGluZyBhbnkga2V5cyB3aXRoIG51bGwgdmFsdWVzLlxuICovXG5mdW5jdGlvbiBhcHBseUhlYWRlcnNNdXQodGFyZ2V0SGVhZGVyczogSGVhZGVycywgbmV3SGVhZGVyczogSGVhZGVycyk6IHZvaWQge1xuICBmb3IgKGNvbnN0IGsgaW4gbmV3SGVhZGVycykge1xuICAgIGlmICghaGFzT3duKG5ld0hlYWRlcnMsIGspKSBjb250aW51ZTtcbiAgICBjb25zdCBsb3dlcktleSA9IGsudG9Mb3dlckNhc2UoKTtcbiAgICBpZiAoIWxvd2VyS2V5KSBjb250aW51ZTtcblxuICAgIGNvbnN0IHZhbCA9IG5ld0hlYWRlcnNba107XG5cbiAgICBpZiAodmFsID09PSBudWxsKSB7XG4gICAgICBkZWxldGUgdGFyZ2V0SGVhZGVyc1tsb3dlcktleV07XG4gICAgfSBlbHNlIGlmICh2YWwgIT09IHVuZGVmaW5lZCkge1xuICAgICAgdGFyZ2V0SGVhZGVyc1tsb3dlcktleV0gPSB2YWw7XG4gICAgfVxuICB9XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkZWJ1ZyhhY3Rpb246IHN0cmluZywgLi4uYXJnczogYW55W10pIHtcbiAgaWYgKHR5cGVvZiBwcm9jZXNzICE9PSAndW5kZWZpbmVkJyAmJiBwcm9jZXNzPy5lbnY/LlsnREVCVUcnXSA9PT0gJ3RydWUnKSB7XG4gICAgY29uc29sZS5sb2coYEFudGhyb3BpYzpERUJVRzoke2FjdGlvbn1gLCAuLi5hcmdzKTtcbiAgfVxufVxuXG4vKipcbiAqIGh0dHBzOi8vc3RhY2tvdmVyZmxvdy5jb20vYS8yMTE3NTIzXG4gKi9cbmNvbnN0IHV1aWQ0ID0gKCkgPT4ge1xuICByZXR1cm4gJ3h4eHh4eHh4LXh4eHgtNHh4eC15eHh4LXh4eHh4eHh4eHh4eCcucmVwbGFjZSgvW3h5XS9nLCAoYykgPT4ge1xuICAgIGNvbnN0IHIgPSAoTWF0aC5yYW5kb20oKSAqIDE2KSB8IDA7XG4gICAgY29uc3QgdiA9IGMgPT09ICd4JyA/IHIgOiAociAmIDB4MykgfCAweDg7XG4gICAgcmV0dXJuIHYudG9TdHJpbmcoMTYpO1xuICB9KTtcbn07XG5cbmV4cG9ydCBjb25zdCBpc1J1bm5pbmdJbkJyb3dzZXIgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIHR5cGVvZiB3aW5kb3cgIT09ICd1bmRlZmluZWQnICYmXG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIHR5cGVvZiB3aW5kb3cuZG9jdW1lbnQgIT09ICd1bmRlZmluZWQnICYmXG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIHR5cGVvZiBuYXZpZ2F0b3IgIT09ICd1bmRlZmluZWQnXG4gICk7XG59O1xuXG5leHBvcnQgaW50ZXJmYWNlIEhlYWRlcnNQcm90b2NvbCB7XG4gIGdldDogKGhlYWRlcjogc3RyaW5nKSA9PiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkO1xufVxuZXhwb3J0IHR5cGUgSGVhZGVyc0xpa2UgPSBSZWNvcmQ8c3RyaW5nLCBzdHJpbmcgfCBzdHJpbmdbXSB8IHVuZGVmaW5lZD4gfCBIZWFkZXJzUHJvdG9jb2w7XG5cbmV4cG9ydCBjb25zdCBpc0hlYWRlcnNQcm90b2NvbCA9IChoZWFkZXJzOiBhbnkpOiBoZWFkZXJzIGlzIEhlYWRlcnNQcm90b2NvbCA9PiB7XG4gIHJldHVybiB0eXBlb2YgaGVhZGVycz8uZ2V0ID09PSAnZnVuY3Rpb24nO1xufTtcblxuZXhwb3J0IGNvbnN0IGdldFJlcXVpcmVkSGVhZGVyID0gKGhlYWRlcnM6IEhlYWRlcnNMaWtlIHwgSGVhZGVycywgaGVhZGVyOiBzdHJpbmcpOiBzdHJpbmcgPT4ge1xuICBjb25zdCBmb3VuZEhlYWRlciA9IGdldEhlYWRlcihoZWFkZXJzLCBoZWFkZXIpO1xuICBpZiAoZm91bmRIZWFkZXIgPT09IHVuZGVmaW5lZCkge1xuICAgIHRocm93IG5ldyBFcnJvcihgQ291bGQgbm90IGZpbmQgJHtoZWFkZXJ9IGhlYWRlcmApO1xuICB9XG4gIHJldHVybiBmb3VuZEhlYWRlcjtcbn07XG5cbmV4cG9ydCBjb25zdCBnZXRIZWFkZXIgPSAoaGVhZGVyczogSGVhZGVyc0xpa2UgfCBIZWFkZXJzLCBoZWFkZXI6IHN0cmluZyk6IHN0cmluZyB8IHVuZGVmaW5lZCA9PiB7XG4gIGNvbnN0IGxvd2VyQ2FzZWRIZWFkZXIgPSBoZWFkZXIudG9Mb3dlckNhc2UoKTtcbiAgaWYgKGlzSGVhZGVyc1Byb3RvY29sKGhlYWRlcnMpKSB7XG4gICAgLy8gdG8gZGVhbCB3aXRoIHRoZSBjYXNlIHdoZXJlIHRoZSBoZWFkZXIgbG9va3MgbGlrZSBTdGFpbmxlc3MtRXZlbnQtSWRcbiAgICBjb25zdCBpbnRlcmNhcHNIZWFkZXIgPVxuICAgICAgaGVhZGVyWzBdPy50b1VwcGVyQ2FzZSgpICtcbiAgICAgIGhlYWRlci5zdWJzdHJpbmcoMSkucmVwbGFjZSgvKFteXFx3XSkoXFx3KS9nLCAoX20sIGcxLCBnMikgPT4gZzEgKyBnMi50b1VwcGVyQ2FzZSgpKTtcbiAgICBmb3IgKGNvbnN0IGtleSBvZiBbaGVhZGVyLCBsb3dlckNhc2VkSGVhZGVyLCBoZWFkZXIudG9VcHBlckNhc2UoKSwgaW50ZXJjYXBzSGVhZGVyXSkge1xuICAgICAgY29uc3QgdmFsdWUgPSBoZWFkZXJzLmdldChrZXkpO1xuICAgICAgaWYgKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgIH1cbiAgICB9XG4gIH1cblxuICBmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBPYmplY3QuZW50cmllcyhoZWFkZXJzKSkge1xuICAgIGlmIChrZXkudG9Mb3dlckNhc2UoKSA9PT0gbG93ZXJDYXNlZEhlYWRlcikge1xuICAgICAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAgIGlmICh2YWx1ZS5sZW5ndGggPD0gMSkgcmV0dXJuIHZhbHVlWzBdO1xuICAgICAgICBjb25zb2xlLndhcm4oYFJlY2VpdmVkICR7dmFsdWUubGVuZ3RofSBlbnRyaWVzIGZvciB0aGUgJHtoZWFkZXJ9IGhlYWRlciwgdXNpbmcgdGhlIGZpcnN0IGVudHJ5LmApO1xuICAgICAgICByZXR1cm4gdmFsdWVbMF07XG4gICAgICB9XG4gICAgICByZXR1cm4gdmFsdWU7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIHVuZGVmaW5lZDtcbn07XG5cbi8qKlxuICogRW5jb2RlcyBhIHN0cmluZyB0byBCYXNlNjQgZm9ybWF0LlxuICovXG5leHBvcnQgY29uc3QgdG9CYXNlNjQgPSAoc3RyOiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkKTogc3RyaW5nID0+IHtcbiAgaWYgKCFzdHIpIHJldHVybiAnJztcbiAgaWYgKHR5cGVvZiBCdWZmZXIgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgcmV0dXJuIEJ1ZmZlci5mcm9tKHN0cikudG9TdHJpbmcoJ2Jhc2U2NCcpO1xuICB9XG5cbiAgaWYgKHR5cGVvZiBidG9hICE9PSAndW5kZWZpbmVkJykge1xuICAgIHJldHVybiBidG9hKHN0cik7XG4gIH1cblxuICB0aHJvdyBuZXcgQW50aHJvcGljRXJyb3IoJ0Nhbm5vdCBnZW5lcmF0ZSBiNjQgc3RyaW5nOyBFeHBlY3RlZCBgQnVmZmVyYCBvciBgYnRvYWAgdG8gYmUgZGVmaW5lZCcpO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIGlzT2JqKG9iajogdW5rbm93bik6IG9iaiBpcyBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB7XG4gIHJldHVybiBvYmogIT0gbnVsbCAmJiB0eXBlb2Ygb2JqID09PSAnb2JqZWN0JyAmJiAhQXJyYXkuaXNBcnJheShvYmopO1xufVxuIiwgIi8vIEZpbGUgZ2VuZXJhdGVkIGZyb20gb3VyIE9wZW5BUEkgc3BlYyBieSBTdGFpbmxlc3MuIFNlZSBDT05UUklCVVRJTkcubWQgZm9yIGRldGFpbHMuXG5cbmltcG9ydCAqIGFzIENvcmUgZnJvbSBcIi4vY29yZS5qc1wiO1xuXG5leHBvcnQgY2xhc3MgQVBJUmVzb3VyY2Uge1xuICBwcm90ZWN0ZWQgX2NsaWVudDogQ29yZS5BUElDbGllbnQ7XG5cbiAgY29uc3RydWN0b3IoY2xpZW50OiBDb3JlLkFQSUNsaWVudCkge1xuICAgIHRoaXMuX2NsaWVudCA9IGNsaWVudDtcbiAgfVxufVxuIiwgInR5cGUgVG9rZW4gPSB7XG4gIHR5cGU6IHN0cmluZztcbiAgdmFsdWU6IHN0cmluZztcbn07XG5cbmNvbnN0IHRva2VuaXplID0gKGlucHV0OiBzdHJpbmcpOiBUb2tlbltdID0+IHtcbiAgICBsZXQgY3VycmVudCA9IDA7XG4gICAgbGV0IHRva2VuczogVG9rZW5bXSA9IFtdO1xuXG4gICAgd2hpbGUgKGN1cnJlbnQgPCBpbnB1dC5sZW5ndGgpIHtcbiAgICAgIGxldCBjaGFyID0gaW5wdXRbY3VycmVudF07XG5cbiAgICAgIGlmIChjaGFyID09PSAnXFxcXCcpIHtcbiAgICAgICAgY3VycmVudCsrO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cblxuICAgICAgaWYgKGNoYXIgPT09ICd7Jykge1xuICAgICAgICB0b2tlbnMucHVzaCh7XG4gICAgICAgICAgdHlwZTogJ2JyYWNlJyxcbiAgICAgICAgICB2YWx1ZTogJ3snLFxuICAgICAgICB9KTtcblxuICAgICAgICBjdXJyZW50Kys7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICBpZiAoY2hhciA9PT0gJ30nKSB7XG4gICAgICAgIHRva2Vucy5wdXNoKHtcbiAgICAgICAgICB0eXBlOiAnYnJhY2UnLFxuICAgICAgICAgIHZhbHVlOiAnfScsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGN1cnJlbnQrKztcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG5cbiAgICAgIGlmIChjaGFyID09PSAnWycpIHtcbiAgICAgICAgdG9rZW5zLnB1c2goe1xuICAgICAgICAgIHR5cGU6ICdwYXJlbicsXG4gICAgICAgICAgdmFsdWU6ICdbJyxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY3VycmVudCsrO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cblxuICAgICAgaWYgKGNoYXIgPT09ICddJykge1xuICAgICAgICB0b2tlbnMucHVzaCh7XG4gICAgICAgICAgdHlwZTogJ3BhcmVuJyxcbiAgICAgICAgICB2YWx1ZTogJ10nLFxuICAgICAgICB9KTtcblxuICAgICAgICBjdXJyZW50Kys7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICBpZiAoY2hhciA9PT0gJzonKSB7XG4gICAgICAgIHRva2Vucy5wdXNoKHtcbiAgICAgICAgICB0eXBlOiAnc2VwYXJhdG9yJyxcbiAgICAgICAgICB2YWx1ZTogJzonLFxuICAgICAgICB9KTtcblxuICAgICAgICBjdXJyZW50Kys7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICBpZiAoY2hhciA9PT0gJywnKSB7XG4gICAgICAgIHRva2Vucy5wdXNoKHtcbiAgICAgICAgICB0eXBlOiAnZGVsaW1pdGVyJyxcbiAgICAgICAgICB2YWx1ZTogJywnLFxuICAgICAgICB9KTtcblxuICAgICAgICBjdXJyZW50Kys7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICBpZiAoY2hhciA9PT0gJ1wiJykge1xuICAgICAgICBsZXQgdmFsdWUgPSAnJztcbiAgICAgICAgbGV0IGRhbmdsaW5nUXVvdGUgPSBmYWxzZTtcblxuICAgICAgICBjaGFyID0gaW5wdXRbKytjdXJyZW50XTtcblxuICAgICAgICB3aGlsZSAoY2hhciAhPT0gJ1wiJykge1xuICAgICAgICAgIGlmIChjdXJyZW50ID09PSBpbnB1dC5sZW5ndGgpIHtcbiAgICAgICAgICAgIGRhbmdsaW5nUXVvdGUgPSB0cnVlO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKGNoYXIgPT09ICdcXFxcJykge1xuICAgICAgICAgICAgY3VycmVudCsrO1xuICAgICAgICAgICAgaWYgKGN1cnJlbnQgPT09IGlucHV0Lmxlbmd0aCkge1xuICAgICAgICAgICAgICBkYW5nbGluZ1F1b3RlID0gdHJ1ZTtcbiAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YWx1ZSArPSBjaGFyICsgaW5wdXRbY3VycmVudF07XG4gICAgICAgICAgICBjaGFyID0gaW5wdXRbKytjdXJyZW50XTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgdmFsdWUgKz0gY2hhcjtcbiAgICAgICAgICAgIGNoYXIgPSBpbnB1dFsrK2N1cnJlbnRdO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuXG4gICAgICAgIGNoYXIgPSBpbnB1dFsrK2N1cnJlbnRdO1xuXG4gICAgICAgIGlmICghZGFuZ2xpbmdRdW90ZSkge1xuICAgICAgICAgIHRva2Vucy5wdXNoKHtcbiAgICAgICAgICAgIHR5cGU6ICdzdHJpbmcnLFxuICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG5cbiAgICAgIGxldCBXSElURVNQQUNFID0gL1xccy87XG4gICAgICBpZiAoY2hhciAmJiBXSElURVNQQUNFLnRlc3QoY2hhcikpIHtcbiAgICAgICAgY3VycmVudCsrO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cblxuICAgICAgbGV0IE5VTUJFUlMgPSAvWzAtOV0vO1xuICAgICAgaWYgKChjaGFyICYmIE5VTUJFUlMudGVzdChjaGFyKSkgfHwgY2hhciA9PT0gJy0nIHx8IGNoYXIgPT09ICcuJykge1xuICAgICAgICBsZXQgdmFsdWUgPSAnJztcblxuICAgICAgICBpZiAoY2hhciA9PT0gJy0nKSB7XG4gICAgICAgICAgdmFsdWUgKz0gY2hhcjtcbiAgICAgICAgICBjaGFyID0gaW5wdXRbKytjdXJyZW50XTtcbiAgICAgICAgfVxuXG4gICAgICAgIHdoaWxlICgoY2hhciAmJiBOVU1CRVJTLnRlc3QoY2hhcikpIHx8IGNoYXIgPT09ICcuJykge1xuICAgICAgICAgIHZhbHVlICs9IGNoYXI7XG4gICAgICAgICAgY2hhciA9IGlucHV0WysrY3VycmVudF07XG4gICAgICAgIH1cblxuICAgICAgICB0b2tlbnMucHVzaCh7XG4gICAgICAgICAgdHlwZTogJ251bWJlcicsXG4gICAgICAgICAgdmFsdWUsXG4gICAgICAgIH0pO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cblxuICAgICAgbGV0IExFVFRFUlMgPSAvW2Etel0vaTtcbiAgICAgIGlmIChjaGFyICYmIExFVFRFUlMudGVzdChjaGFyKSkge1xuICAgICAgICBsZXQgdmFsdWUgPSAnJztcblxuICAgICAgICB3aGlsZSAoY2hhciAmJiBMRVRURVJTLnRlc3QoY2hhcikpIHtcbiAgICAgICAgICBpZiAoY3VycmVudCA9PT0gaW5wdXQubGVuZ3RoKSB7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG4gICAgICAgICAgdmFsdWUgKz0gY2hhcjtcbiAgICAgICAgICBjaGFyID0gaW5wdXRbKytjdXJyZW50XTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmICh2YWx1ZSA9PSAndHJ1ZScgfHwgdmFsdWUgPT0gJ2ZhbHNlJyB8fCB2YWx1ZSA9PT0gJ251bGwnKSB7XG4gICAgICAgICAgdG9rZW5zLnB1c2goe1xuICAgICAgICAgICAgdHlwZTogJ25hbWUnLFxuICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgfSk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgLy8gdW5rbm93biB0b2tlbiwgZS5nLiBgbnVsYCB3aGljaCBpc24ndCBxdWl0ZSBgbnVsbGBcbiAgICAgICAgICBjdXJyZW50Kys7XG4gICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG5cbiAgICAgIGN1cnJlbnQrKztcbiAgICB9XG5cbiAgICByZXR1cm4gdG9rZW5zO1xuICB9LFxuICBzdHJpcCA9ICh0b2tlbnM6IFRva2VuW10pOiBUb2tlbltdID0+IHtcbiAgICBpZiAodG9rZW5zLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuIHRva2VucztcbiAgICB9XG5cbiAgICBsZXQgbGFzdFRva2VuID0gdG9rZW5zW3Rva2Vucy5sZW5ndGggLSAxXSE7XG5cbiAgICBzd2l0Y2ggKGxhc3RUb2tlbi50eXBlKSB7XG4gICAgICBjYXNlICdzZXBhcmF0b3InOlxuICAgICAgICB0b2tlbnMgPSB0b2tlbnMuc2xpY2UoMCwgdG9rZW5zLmxlbmd0aCAtIDEpO1xuICAgICAgICByZXR1cm4gc3RyaXAodG9rZW5zKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICdudW1iZXInOlxuICAgICAgICBsZXQgbGFzdENoYXJhY3Rlck9mTGFzdFRva2VuID0gbGFzdFRva2VuLnZhbHVlW2xhc3RUb2tlbi52YWx1ZS5sZW5ndGggLSAxXTtcbiAgICAgICAgaWYgKGxhc3RDaGFyYWN0ZXJPZkxhc3RUb2tlbiA9PT0gJy4nIHx8IGxhc3RDaGFyYWN0ZXJPZkxhc3RUb2tlbiA9PT0gJy0nKSB7XG4gICAgICAgICAgdG9rZW5zID0gdG9rZW5zLnNsaWNlKDAsIHRva2Vucy5sZW5ndGggLSAxKTtcbiAgICAgICAgICByZXR1cm4gc3RyaXAodG9rZW5zKTtcbiAgICAgICAgfVxuICAgICAgY2FzZSAnc3RyaW5nJzpcbiAgICAgICAgbGV0IHRva2VuQmVmb3JlVGhlTGFzdFRva2VuID0gdG9rZW5zW3Rva2Vucy5sZW5ndGggLSAyXTtcbiAgICAgICAgaWYgKHRva2VuQmVmb3JlVGhlTGFzdFRva2VuPy50eXBlID09PSAnZGVsaW1pdGVyJykge1xuICAgICAgICAgIHRva2VucyA9IHRva2Vucy5zbGljZSgwLCB0b2tlbnMubGVuZ3RoIC0gMSk7XG4gICAgICAgICAgcmV0dXJuIHN0cmlwKHRva2Vucyk7XG4gICAgICAgIH0gZWxzZSBpZiAodG9rZW5CZWZvcmVUaGVMYXN0VG9rZW4/LnR5cGUgPT09ICdicmFjZScgJiYgdG9rZW5CZWZvcmVUaGVMYXN0VG9rZW4udmFsdWUgPT09ICd7Jykge1xuICAgICAgICAgIHRva2VucyA9IHRva2Vucy5zbGljZSgwLCB0b2tlbnMubGVuZ3RoIC0gMSk7XG4gICAgICAgICAgcmV0dXJuIHN0cmlwKHRva2Vucyk7XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICdkZWxpbWl0ZXInOlxuICAgICAgICB0b2tlbnMgPSB0b2tlbnMuc2xpY2UoMCwgdG9rZW5zLmxlbmd0aCAtIDEpO1xuICAgICAgICByZXR1cm4gc3RyaXAodG9rZW5zKTtcbiAgICAgICAgYnJlYWs7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRva2VucztcbiAgfSxcbiAgdW5zdHJpcCA9ICh0b2tlbnM6IFRva2VuW10pOiBUb2tlbltdID0+IHtcbiAgICBsZXQgdGFpbDogc3RyaW5nW10gPSBbXTtcblxuICAgIHRva2Vucy5tYXAoKHRva2VuKSA9PiB7XG4gICAgICBpZiAodG9rZW4udHlwZSA9PT0gJ2JyYWNlJykge1xuICAgICAgICBpZiAodG9rZW4udmFsdWUgPT09ICd7Jykge1xuICAgICAgICAgIHRhaWwucHVzaCgnfScpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHRhaWwuc3BsaWNlKHRhaWwubGFzdEluZGV4T2YoJ30nKSwgMSk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGlmICh0b2tlbi50eXBlID09PSAncGFyZW4nKSB7XG4gICAgICAgIGlmICh0b2tlbi52YWx1ZSA9PT0gJ1snKSB7XG4gICAgICAgICAgdGFpbC5wdXNoKCddJyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGFpbC5zcGxpY2UodGFpbC5sYXN0SW5kZXhPZignXScpLCAxKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pO1xuXG4gICAgaWYgKHRhaWwubGVuZ3RoID4gMCkge1xuICAgICAgdGFpbC5yZXZlcnNlKCkubWFwKChpdGVtKSA9PiB7XG4gICAgICAgIGlmIChpdGVtID09PSAnfScpIHtcbiAgICAgICAgICB0b2tlbnMucHVzaCh7XG4gICAgICAgICAgICB0eXBlOiAnYnJhY2UnLFxuICAgICAgICAgICAgdmFsdWU6ICd9JyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIGlmIChpdGVtID09PSAnXScpIHtcbiAgICAgICAgICB0b2tlbnMucHVzaCh7XG4gICAgICAgICAgICB0eXBlOiAncGFyZW4nLFxuICAgICAgICAgICAgdmFsdWU6ICddJyxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHRva2VucztcbiAgfSxcbiAgZ2VuZXJhdGUgPSAodG9rZW5zOiBUb2tlbltdKTogc3RyaW5nID0+IHtcbiAgICBsZXQgb3V0cHV0ID0gJyc7XG5cbiAgICB0b2tlbnMubWFwKCh0b2tlbikgPT4ge1xuICAgICAgc3dpdGNoICh0b2tlbi50eXBlKSB7XG4gICAgICAgIGNhc2UgJ3N0cmluZyc6XG4gICAgICAgICAgb3V0cHV0ICs9ICdcIicgKyB0b2tlbi52YWx1ZSArICdcIic7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgb3V0cHV0ICs9IHRva2VuLnZhbHVlO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgcmV0dXJuIG91dHB1dDtcbiAgfSxcbiAgcGFydGlhbFBhcnNlID0gKGlucHV0OiBzdHJpbmcpOiB1bmtub3duID0+IEpTT04ucGFyc2UoZ2VuZXJhdGUodW5zdHJpcChzdHJpcCh0b2tlbml6ZShpbnB1dCkpKSkpO1xuXG5leHBvcnQgeyBwYXJ0aWFsUGFyc2UgfTtcbiIsICJpbXBvcnQgKiBhcyBDb3JlIGZyb20gXCIuLi9jb3JlLmpzXCI7XG5pbXBvcnQgeyBBbnRocm9waWNFcnJvciwgQVBJVXNlckFib3J0RXJyb3IgfSBmcm9tIFwiLi4vZXJyb3IuanNcIjtcbmltcG9ydCB7XG4gIHR5cGUgQ29udGVudEJsb2NrLFxuICBNZXNzYWdlcyxcbiAgdHlwZSBNZXNzYWdlLFxuICB0eXBlIE1lc3NhZ2VTdHJlYW1FdmVudCxcbiAgdHlwZSBNZXNzYWdlUGFyYW0sXG4gIHR5cGUgTWVzc2FnZUNyZWF0ZVBhcmFtcyxcbiAgdHlwZSBNZXNzYWdlQ3JlYXRlUGFyYW1zQmFzZSxcbiAgdHlwZSBUZXh0QmxvY2ssXG59IGZyb20gXCIuLi9yZXNvdXJjZXMvbWVzc2FnZXMuanNcIjtcbmltcG9ydCB7IHR5cGUgUmVhZGFibGVTdHJlYW0gfSBmcm9tIFwiLi4vX3NoaW1zL2luZGV4LmpzXCI7XG5pbXBvcnQgeyBTdHJlYW0gfSBmcm9tIFwiLi4vc3RyZWFtaW5nLmpzXCI7XG5pbXBvcnQgeyBwYXJ0aWFsUGFyc2UgfSBmcm9tIFwiLi4vX3ZlbmRvci9wYXJ0aWFsLWpzb24tcGFyc2VyL3BhcnNlci5qc1wiO1xuXG5leHBvcnQgaW50ZXJmYWNlIE1lc3NhZ2VTdHJlYW1FdmVudHMge1xuICBjb25uZWN0OiAoKSA9PiB2b2lkO1xuICBzdHJlYW1FdmVudDogKGV2ZW50OiBNZXNzYWdlU3RyZWFtRXZlbnQsIHNuYXBzaG90OiBNZXNzYWdlKSA9PiB2b2lkO1xuICB0ZXh0OiAodGV4dERlbHRhOiBzdHJpbmcsIHRleHRTbmFwc2hvdDogc3RyaW5nKSA9PiB2b2lkO1xuICBpbnB1dEpzb246IChwYXJ0aWFsSnNvbjogc3RyaW5nLCBqc29uU25hcHNob3Q6IHVua25vd24pID0+IHZvaWQ7XG4gIG1lc3NhZ2U6IChtZXNzYWdlOiBNZXNzYWdlKSA9PiB2b2lkO1xuICBjb250ZW50QmxvY2s6IChjb250ZW50OiBDb250ZW50QmxvY2spID0+IHZvaWQ7XG4gIGZpbmFsTWVzc2FnZTogKG1lc3NhZ2U6IE1lc3NhZ2UpID0+IHZvaWQ7XG4gIGVycm9yOiAoZXJyb3I6IEFudGhyb3BpY0Vycm9yKSA9PiB2b2lkO1xuICBhYm9ydDogKGVycm9yOiBBUElVc2VyQWJvcnRFcnJvcikgPT4gdm9pZDtcbiAgZW5kOiAoKSA9PiB2b2lkO1xufVxuXG50eXBlIE1lc3NhZ2VTdHJlYW1FdmVudExpc3RlbmVyczxFdmVudCBleHRlbmRzIGtleW9mIE1lc3NhZ2VTdHJlYW1FdmVudHM+ID0ge1xuICBsaXN0ZW5lcjogTWVzc2FnZVN0cmVhbUV2ZW50c1tFdmVudF07XG4gIG9uY2U/OiBib29sZWFuO1xufVtdO1xuXG5jb25zdCBKU09OX0JVRl9QUk9QRVJUWSA9ICdfX2pzb25fYnVmJztcblxuZXhwb3J0IGNsYXNzIE1lc3NhZ2VTdHJlYW0gaW1wbGVtZW50cyBBc3luY0l0ZXJhYmxlPE1lc3NhZ2VTdHJlYW1FdmVudD4ge1xuICBtZXNzYWdlczogTWVzc2FnZVBhcmFtW10gPSBbXTtcbiAgcmVjZWl2ZWRNZXNzYWdlczogTWVzc2FnZVtdID0gW107XG4gICNjdXJyZW50TWVzc2FnZVNuYXBzaG90OiBNZXNzYWdlIHwgdW5kZWZpbmVkO1xuXG4gIGNvbnRyb2xsZXI6IEFib3J0Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcblxuICAjY29ubmVjdGVkUHJvbWlzZTogUHJvbWlzZTx2b2lkPjtcbiAgI3Jlc29sdmVDb25uZWN0ZWRQcm9taXNlOiAoKSA9PiB2b2lkID0gKCkgPT4ge307XG4gICNyZWplY3RDb25uZWN0ZWRQcm9taXNlOiAoZXJyb3I6IEFudGhyb3BpY0Vycm9yKSA9PiB2b2lkID0gKCkgPT4ge307XG5cbiAgI2VuZFByb21pc2U6IFByb21pc2U8dm9pZD47XG4gICNyZXNvbHZlRW5kUHJvbWlzZTogKCkgPT4gdm9pZCA9ICgpID0+IHt9O1xuICAjcmVqZWN0RW5kUHJvbWlzZTogKGVycm9yOiBBbnRocm9waWNFcnJvcikgPT4gdm9pZCA9ICgpID0+IHt9O1xuXG4gICNsaXN0ZW5lcnM6IHsgW0V2ZW50IGluIGtleW9mIE1lc3NhZ2VTdHJlYW1FdmVudHNdPzogTWVzc2FnZVN0cmVhbUV2ZW50TGlzdGVuZXJzPEV2ZW50PiB9ID0ge307XG5cbiAgI2VuZGVkID0gZmFsc2U7XG4gICNlcnJvcmVkID0gZmFsc2U7XG4gICNhYm9ydGVkID0gZmFsc2U7XG4gICNjYXRjaGluZ1Byb21pc2VDcmVhdGVkID0gZmFsc2U7XG5cbiAgY29uc3RydWN0b3IoKSB7XG4gICAgdGhpcy4jY29ubmVjdGVkUHJvbWlzZSA9IG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHRoaXMuI3Jlc29sdmVDb25uZWN0ZWRQcm9taXNlID0gcmVzb2x2ZTtcbiAgICAgIHRoaXMuI3JlamVjdENvbm5lY3RlZFByb21pc2UgPSByZWplY3Q7XG4gICAgfSk7XG5cbiAgICB0aGlzLiNlbmRQcm9taXNlID0gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgdGhpcy4jcmVzb2x2ZUVuZFByb21pc2UgPSByZXNvbHZlO1xuICAgICAgdGhpcy4jcmVqZWN0RW5kUHJvbWlzZSA9IHJlamVjdDtcbiAgICB9KTtcblxuICAgIC8vIERvbid0IGxldCB0aGVzZSBwcm9taXNlcyBjYXVzZSB1bmhhbmRsZWQgcmVqZWN0aW9uIGVycm9ycy5cbiAgICAvLyB3ZSB3aWxsIG1hbnVhbGx5IGNhdXNlIGFuIHVuaGFuZGxlZCByZWplY3Rpb24gZXJyb3IgbGF0ZXJcbiAgICAvLyBpZiB0aGUgdXNlciBoYXNuJ3QgcmVnaXN0ZXJlZCBhbnkgZXJyb3IgbGlzdGVuZXIgb3IgY2FsbGVkXG4gICAgLy8gYW55IHByb21pc2UtcmV0dXJuaW5nIG1ldGhvZC5cbiAgICB0aGlzLiNjb25uZWN0ZWRQcm9taXNlLmNhdGNoKCgpID0+IHt9KTtcbiAgICB0aGlzLiNlbmRQcm9taXNlLmNhdGNoKCgpID0+IHt9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBJbnRlbmRlZCBmb3IgdXNlIG9uIHRoZSBmcm9udGVuZCwgY29uc3VtaW5nIGEgc3RyZWFtIHByb2R1Y2VkIHdpdGhcbiAgICogYC50b1JlYWRhYmxlU3RyZWFtKClgIG9uIHRoZSBiYWNrZW5kLlxuICAgKlxuICAgKiBOb3RlIHRoYXQgbWVzc2FnZXMgc2VudCB0byB0aGUgbW9kZWwgZG8gbm90IGFwcGVhciBpbiBgLm9uKCdtZXNzYWdlJylgXG4gICAqIGluIHRoaXMgY29udGV4dC5cbiAgICovXG4gIHN0YXRpYyBmcm9tUmVhZGFibGVTdHJlYW0oc3RyZWFtOiBSZWFkYWJsZVN0cmVhbSk6IE1lc3NhZ2VTdHJlYW0ge1xuICAgIGNvbnN0IHJ1bm5lciA9IG5ldyBNZXNzYWdlU3RyZWFtKCk7XG4gICAgcnVubmVyLl9ydW4oKCkgPT4gcnVubmVyLl9mcm9tUmVhZGFibGVTdHJlYW0oc3RyZWFtKSk7XG4gICAgcmV0dXJuIHJ1bm5lcjtcbiAgfVxuXG4gIHN0YXRpYyBjcmVhdGVNZXNzYWdlKFxuICAgIG1lc3NhZ2VzOiBNZXNzYWdlcyxcbiAgICBwYXJhbXM6IE1lc3NhZ2VDcmVhdGVQYXJhbXNCYXNlLFxuICAgIG9wdGlvbnM/OiBDb3JlLlJlcXVlc3RPcHRpb25zLFxuICApOiBNZXNzYWdlU3RyZWFtIHtcbiAgICBjb25zdCBydW5uZXIgPSBuZXcgTWVzc2FnZVN0cmVhbSgpO1xuICAgIGZvciAoY29uc3QgbWVzc2FnZSBvZiBwYXJhbXMubWVzc2FnZXMpIHtcbiAgICAgIHJ1bm5lci5fYWRkTWVzc2FnZVBhcmFtKG1lc3NhZ2UpO1xuICAgIH1cbiAgICBydW5uZXIuX3J1bigoKSA9PlxuICAgICAgcnVubmVyLl9jcmVhdGVNZXNzYWdlKFxuICAgICAgICBtZXNzYWdlcyxcbiAgICAgICAgeyAuLi5wYXJhbXMsIHN0cmVhbTogdHJ1ZSB9LFxuICAgICAgICB7IC4uLm9wdGlvbnMsIGhlYWRlcnM6IHsgLi4ub3B0aW9ucz8uaGVhZGVycywgJ1gtU3RhaW5sZXNzLUhlbHBlci1NZXRob2QnOiAnc3RyZWFtJyB9IH0sXG4gICAgICApLFxuICAgICk7XG4gICAgcmV0dXJuIHJ1bm5lcjtcbiAgfVxuXG4gIHByb3RlY3RlZCBfcnVuKGV4ZWN1dG9yOiAoKSA9PiBQcm9taXNlPGFueT4pIHtcbiAgICBleGVjdXRvcigpLnRoZW4oKCkgPT4ge1xuICAgICAgdGhpcy5fZW1pdEZpbmFsKCk7XG4gICAgICB0aGlzLl9lbWl0KCdlbmQnKTtcbiAgICB9LCB0aGlzLiNoYW5kbGVFcnJvcik7XG4gIH1cblxuICBwcm90ZWN0ZWQgX2FkZE1lc3NhZ2VQYXJhbShtZXNzYWdlOiBNZXNzYWdlUGFyYW0pIHtcbiAgICB0aGlzLm1lc3NhZ2VzLnB1c2gobWVzc2FnZSk7XG4gIH1cblxuICBwcm90ZWN0ZWQgX2FkZE1lc3NhZ2UobWVzc2FnZTogTWVzc2FnZSwgZW1pdCA9IHRydWUpIHtcbiAgICB0aGlzLnJlY2VpdmVkTWVzc2FnZXMucHVzaChtZXNzYWdlKTtcbiAgICBpZiAoZW1pdCkge1xuICAgICAgdGhpcy5fZW1pdCgnbWVzc2FnZScsIG1lc3NhZ2UpO1xuICAgIH1cbiAgfVxuXG4gIHByb3RlY3RlZCBhc3luYyBfY3JlYXRlTWVzc2FnZShcbiAgICBtZXNzYWdlczogTWVzc2FnZXMsXG4gICAgcGFyYW1zOiBNZXNzYWdlQ3JlYXRlUGFyYW1zLFxuICAgIG9wdGlvbnM/OiBDb3JlLlJlcXVlc3RPcHRpb25zLFxuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBzaWduYWwgPSBvcHRpb25zPy5zaWduYWw7XG4gICAgaWYgKHNpZ25hbCkge1xuICAgICAgaWYgKHNpZ25hbC5hYm9ydGVkKSB0aGlzLmNvbnRyb2xsZXIuYWJvcnQoKTtcbiAgICAgIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKCdhYm9ydCcsICgpID0+IHRoaXMuY29udHJvbGxlci5hYm9ydCgpKTtcbiAgICB9XG4gICAgdGhpcy4jYmVnaW5SZXF1ZXN0KCk7XG4gICAgY29uc3Qgc3RyZWFtID0gYXdhaXQgbWVzc2FnZXMuY3JlYXRlKFxuICAgICAgeyAuLi5wYXJhbXMsIHN0cmVhbTogdHJ1ZSB9LFxuICAgICAgeyAuLi5vcHRpb25zLCBzaWduYWw6IHRoaXMuY29udHJvbGxlci5zaWduYWwgfSxcbiAgICApO1xuICAgIHRoaXMuX2Nvbm5lY3RlZCgpO1xuICAgIGZvciBhd2FpdCAoY29uc3QgZXZlbnQgb2Ygc3RyZWFtKSB7XG4gICAgICB0aGlzLiNhZGRTdHJlYW1FdmVudChldmVudCk7XG4gICAgfVxuICAgIGlmIChzdHJlYW0uY29udHJvbGxlci5zaWduYWw/LmFib3J0ZWQpIHtcbiAgICAgIHRocm93IG5ldyBBUElVc2VyQWJvcnRFcnJvcigpO1xuICAgIH1cbiAgICB0aGlzLiNlbmRSZXF1ZXN0KCk7XG4gIH1cblxuICBwcm90ZWN0ZWQgX2Nvbm5lY3RlZCgpIHtcbiAgICBpZiAodGhpcy5lbmRlZCkgcmV0dXJuO1xuICAgIHRoaXMuI3Jlc29sdmVDb25uZWN0ZWRQcm9taXNlKCk7XG4gICAgdGhpcy5fZW1pdCgnY29ubmVjdCcpO1xuICB9XG5cbiAgZ2V0IGVuZGVkKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLiNlbmRlZDtcbiAgfVxuXG4gIGdldCBlcnJvcmVkKCk6IGJvb2xlYW4ge1xuICAgIHJldHVybiB0aGlzLiNlcnJvcmVkO1xuICB9XG5cbiAgZ2V0IGFib3J0ZWQoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuI2Fib3J0ZWQ7XG4gIH1cblxuICBhYm9ydCgpIHtcbiAgICB0aGlzLmNvbnRyb2xsZXIuYWJvcnQoKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIHRoZSBsaXN0ZW5lciBmdW5jdGlvbiB0byB0aGUgZW5kIG9mIHRoZSBsaXN0ZW5lcnMgYXJyYXkgZm9yIHRoZSBldmVudC5cbiAgICogTm8gY2hlY2tzIGFyZSBtYWRlIHRvIHNlZSBpZiB0aGUgbGlzdGVuZXIgaGFzIGFscmVhZHkgYmVlbiBhZGRlZC4gTXVsdGlwbGUgY2FsbHMgcGFzc2luZ1xuICAgKiB0aGUgc2FtZSBjb21iaW5hdGlvbiBvZiBldmVudCBhbmQgbGlzdGVuZXIgd2lsbCByZXN1bHQgaW4gdGhlIGxpc3RlbmVyIGJlaW5nIGFkZGVkLCBhbmRcbiAgICogY2FsbGVkLCBtdWx0aXBsZSB0aW1lcy5cbiAgICogQHJldHVybnMgdGhpcyBNZXNzYWdlU3RyZWFtLCBzbyB0aGF0IGNhbGxzIGNhbiBiZSBjaGFpbmVkXG4gICAqL1xuICBvbjxFdmVudCBleHRlbmRzIGtleW9mIE1lc3NhZ2VTdHJlYW1FdmVudHM+KGV2ZW50OiBFdmVudCwgbGlzdGVuZXI6IE1lc3NhZ2VTdHJlYW1FdmVudHNbRXZlbnRdKTogdGhpcyB7XG4gICAgY29uc3QgbGlzdGVuZXJzOiBNZXNzYWdlU3RyZWFtRXZlbnRMaXN0ZW5lcnM8RXZlbnQ+ID1cbiAgICAgIHRoaXMuI2xpc3RlbmVyc1tldmVudF0gfHwgKHRoaXMuI2xpc3RlbmVyc1tldmVudF0gPSBbXSk7XG4gICAgbGlzdGVuZXJzLnB1c2goeyBsaXN0ZW5lciB9KTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIC8qKlxuICAgKiBSZW1vdmVzIHRoZSBzcGVjaWZpZWQgbGlzdGVuZXIgZnJvbSB0aGUgbGlzdGVuZXIgYXJyYXkgZm9yIHRoZSBldmVudC5cbiAgICogb2ZmKCkgd2lsbCByZW1vdmUsIGF0IG1vc3QsIG9uZSBpbnN0YW5jZSBvZiBhIGxpc3RlbmVyIGZyb20gdGhlIGxpc3RlbmVyIGFycmF5LiBJZiBhbnkgc2luZ2xlXG4gICAqIGxpc3RlbmVyIGhhcyBiZWVuIGFkZGVkIG11bHRpcGxlIHRpbWVzIHRvIHRoZSBsaXN0ZW5lciBhcnJheSBmb3IgdGhlIHNwZWNpZmllZCBldmVudCwgdGhlblxuICAgKiBvZmYoKSBtdXN0IGJlIGNhbGxlZCBtdWx0aXBsZSB0aW1lcyB0byByZW1vdmUgZWFjaCBpbnN0YW5jZS5cbiAgICogQHJldHVybnMgdGhpcyBNZXNzYWdlU3RyZWFtLCBzbyB0aGF0IGNhbGxzIGNhbiBiZSBjaGFpbmVkXG4gICAqL1xuICBvZmY8RXZlbnQgZXh0ZW5kcyBrZXlvZiBNZXNzYWdlU3RyZWFtRXZlbnRzPihldmVudDogRXZlbnQsIGxpc3RlbmVyOiBNZXNzYWdlU3RyZWFtRXZlbnRzW0V2ZW50XSk6IHRoaXMge1xuICAgIGNvbnN0IGxpc3RlbmVycyA9IHRoaXMuI2xpc3RlbmVyc1tldmVudF07XG4gICAgaWYgKCFsaXN0ZW5lcnMpIHJldHVybiB0aGlzO1xuICAgIGNvbnN0IGluZGV4ID0gbGlzdGVuZXJzLmZpbmRJbmRleCgobCkgPT4gbC5saXN0ZW5lciA9PT0gbGlzdGVuZXIpO1xuICAgIGlmIChpbmRleCA+PSAwKSBsaXN0ZW5lcnMuc3BsaWNlKGluZGV4LCAxKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIGEgb25lLXRpbWUgbGlzdGVuZXIgZnVuY3Rpb24gZm9yIHRoZSBldmVudC4gVGhlIG5leHQgdGltZSB0aGUgZXZlbnQgaXMgdHJpZ2dlcmVkLFxuICAgKiB0aGlzIGxpc3RlbmVyIGlzIHJlbW92ZWQgYW5kIHRoZW4gaW52b2tlZC5cbiAgICogQHJldHVybnMgdGhpcyBNZXNzYWdlU3RyZWFtLCBzbyB0aGF0IGNhbGxzIGNhbiBiZSBjaGFpbmVkXG4gICAqL1xuICBvbmNlPEV2ZW50IGV4dGVuZHMga2V5b2YgTWVzc2FnZVN0cmVhbUV2ZW50cz4oZXZlbnQ6IEV2ZW50LCBsaXN0ZW5lcjogTWVzc2FnZVN0cmVhbUV2ZW50c1tFdmVudF0pOiB0aGlzIHtcbiAgICBjb25zdCBsaXN0ZW5lcnM6IE1lc3NhZ2VTdHJlYW1FdmVudExpc3RlbmVyczxFdmVudD4gPVxuICAgICAgdGhpcy4jbGlzdGVuZXJzW2V2ZW50XSB8fCAodGhpcy4jbGlzdGVuZXJzW2V2ZW50XSA9IFtdKTtcbiAgICBsaXN0ZW5lcnMucHVzaCh7IGxpc3RlbmVyLCBvbmNlOiB0cnVlIH0pO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoaXMgaXMgc2ltaWxhciB0byBgLm9uY2UoKWAsIGJ1dCByZXR1cm5zIGEgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHRoZSBuZXh0IHRpbWVcbiAgICogdGhlIGV2ZW50IGlzIHRyaWdnZXJlZCwgaW5zdGVhZCBvZiBjYWxsaW5nIGEgbGlzdGVuZXIgY2FsbGJhY2suXG4gICAqIEByZXR1cm5zIGEgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHRoZSBuZXh0IHRpbWUgZ2l2ZW4gZXZlbnQgaXMgdHJpZ2dlcmVkLFxuICAgKiBvciByZWplY3RzIGlmIGFuIGVycm9yIGlzIGVtaXR0ZWQuICAoSWYgeW91IHJlcXVlc3QgdGhlICdlcnJvcicgZXZlbnQsXG4gICAqIHJldHVybnMgYSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgZXJyb3IpLlxuICAgKlxuICAgKiBFeGFtcGxlOlxuICAgKlxuICAgKiAgIGNvbnN0IG1lc3NhZ2UgPSBhd2FpdCBzdHJlYW0uZW1pdHRlZCgnbWVzc2FnZScpIC8vIHJlamVjdHMgaWYgdGhlIHN0cmVhbSBlcnJvcnNcbiAgICovXG4gIGVtaXR0ZWQ8RXZlbnQgZXh0ZW5kcyBrZXlvZiBNZXNzYWdlU3RyZWFtRXZlbnRzPihcbiAgICBldmVudDogRXZlbnQsXG4gICk6IFByb21pc2U8XG4gICAgUGFyYW1ldGVyczxNZXNzYWdlU3RyZWFtRXZlbnRzW0V2ZW50XT4gZXh0ZW5kcyBbaW5mZXIgUGFyYW1dID8gUGFyYW1cbiAgICA6IFBhcmFtZXRlcnM8TWVzc2FnZVN0cmVhbUV2ZW50c1tFdmVudF0+IGV4dGVuZHMgW10gPyB2b2lkXG4gICAgOiBQYXJhbWV0ZXJzPE1lc3NhZ2VTdHJlYW1FdmVudHNbRXZlbnRdPlxuICA+IHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgdGhpcy4jY2F0Y2hpbmdQcm9taXNlQ3JlYXRlZCA9IHRydWU7XG4gICAgICBpZiAoZXZlbnQgIT09ICdlcnJvcicpIHRoaXMub25jZSgnZXJyb3InLCByZWplY3QpO1xuICAgICAgdGhpcy5vbmNlKGV2ZW50LCByZXNvbHZlIGFzIGFueSk7XG4gICAgfSk7XG4gIH1cblxuICBhc3luYyBkb25lKCk6IFByb21pc2U8dm9pZD4ge1xuICAgIHRoaXMuI2NhdGNoaW5nUHJvbWlzZUNyZWF0ZWQgPSB0cnVlO1xuICAgIGF3YWl0IHRoaXMuI2VuZFByb21pc2U7XG4gIH1cblxuICBnZXQgY3VycmVudE1lc3NhZ2UoKTogTWVzc2FnZSB8IHVuZGVmaW5lZCB7XG4gICAgcmV0dXJuIHRoaXMuI2N1cnJlbnRNZXNzYWdlU25hcHNob3Q7XG4gIH1cblxuICAjZ2V0RmluYWxNZXNzYWdlKCk6IE1lc3NhZ2Uge1xuICAgIGlmICh0aGlzLnJlY2VpdmVkTWVzc2FnZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICB0aHJvdyBuZXcgQW50aHJvcGljRXJyb3IoJ3N0cmVhbSBlbmRlZCB3aXRob3V0IHByb2R1Y2luZyBhIE1lc3NhZ2Ugd2l0aCByb2xlPWFzc2lzdGFudCcpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5yZWNlaXZlZE1lc3NhZ2VzLmF0KC0xKSE7XG4gIH1cblxuICAvKipcbiAgICogQHJldHVybnMgYSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgdGhlIGZpbmFsIGFzc2lzdGFudCBNZXNzYWdlIHJlc3BvbnNlLFxuICAgKiBvciByZWplY3RzIGlmIGFuIGVycm9yIG9jY3VycmVkIG9yIHRoZSBzdHJlYW0gZW5kZWQgcHJlbWF0dXJlbHkgd2l0aG91dCBwcm9kdWNpbmcgYSBNZXNzYWdlLlxuICAgKi9cbiAgYXN5bmMgZmluYWxNZXNzYWdlKCk6IFByb21pc2U8TWVzc2FnZT4ge1xuICAgIGF3YWl0IHRoaXMuZG9uZSgpO1xuICAgIHJldHVybiB0aGlzLiNnZXRGaW5hbE1lc3NhZ2UoKTtcbiAgfVxuXG4gICNnZXRGaW5hbFRleHQoKTogc3RyaW5nIHtcbiAgICBpZiAodGhpcy5yZWNlaXZlZE1lc3NhZ2VzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgdGhyb3cgbmV3IEFudGhyb3BpY0Vycm9yKCdzdHJlYW0gZW5kZWQgd2l0aG91dCBwcm9kdWNpbmcgYSBNZXNzYWdlIHdpdGggcm9sZT1hc3Npc3RhbnQnKTtcbiAgICB9XG4gICAgY29uc3QgdGV4dEJsb2NrcyA9IHRoaXMucmVjZWl2ZWRNZXNzYWdlc1xuICAgICAgLmF0KC0xKSFcbiAgICAgIC5jb250ZW50LmZpbHRlcigoYmxvY2spOiBibG9jayBpcyBUZXh0QmxvY2sgPT4gYmxvY2sudHlwZSA9PT0gJ3RleHQnKVxuICAgICAgLm1hcCgoYmxvY2spID0+IGJsb2NrLnRleHQpO1xuICAgIGlmICh0ZXh0QmxvY2tzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgdGhyb3cgbmV3IEFudGhyb3BpY0Vycm9yKCdzdHJlYW0gZW5kZWQgd2l0aG91dCBwcm9kdWNpbmcgYSBjb250ZW50IGJsb2NrIHdpdGggdHlwZT10ZXh0Jyk7XG4gICAgfVxuICAgIHJldHVybiB0ZXh0QmxvY2tzLmpvaW4oJyAnKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAcmV0dXJucyBhIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSB0aGUgZmluYWwgYXNzaXN0YW50IE1lc3NhZ2UncyB0ZXh0IHJlc3BvbnNlLCBjb25jYXRlbmF0ZWRcbiAgICogdG9nZXRoZXIgaWYgdGhlcmUgYXJlIG1vcmUgdGhhbiBvbmUgdGV4dCBibG9ja3MuXG4gICAqIFJlamVjdHMgaWYgYW4gZXJyb3Igb2NjdXJyZWQgb3IgdGhlIHN0cmVhbSBlbmRlZCBwcmVtYXR1cmVseSB3aXRob3V0IHByb2R1Y2luZyBhIE1lc3NhZ2UuXG4gICAqL1xuICBhc3luYyBmaW5hbFRleHQoKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBhd2FpdCB0aGlzLmRvbmUoKTtcbiAgICByZXR1cm4gdGhpcy4jZ2V0RmluYWxUZXh0KCk7XG4gIH1cblxuICAjaGFuZGxlRXJyb3IgPSAoZXJyb3I6IHVua25vd24pID0+IHtcbiAgICB0aGlzLiNlcnJvcmVkID0gdHJ1ZTtcbiAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvciAmJiBlcnJvci5uYW1lID09PSAnQWJvcnRFcnJvcicpIHtcbiAgICAgIGVycm9yID0gbmV3IEFQSVVzZXJBYm9ydEVycm9yKCk7XG4gICAgfVxuICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEFQSVVzZXJBYm9ydEVycm9yKSB7XG4gICAgICB0aGlzLiNhYm9ydGVkID0gdHJ1ZTtcbiAgICAgIHJldHVybiB0aGlzLl9lbWl0KCdhYm9ydCcsIGVycm9yKTtcbiAgICB9XG4gICAgaWYgKGVycm9yIGluc3RhbmNlb2YgQW50aHJvcGljRXJyb3IpIHtcbiAgICAgIHJldHVybiB0aGlzLl9lbWl0KCdlcnJvcicsIGVycm9yKTtcbiAgICB9XG4gICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgIGNvbnN0IGFudGhyb3BpY0Vycm9yOiBBbnRocm9waWNFcnJvciA9IG5ldyBBbnRocm9waWNFcnJvcihlcnJvci5tZXNzYWdlKTtcbiAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgIGFudGhyb3BpY0Vycm9yLmNhdXNlID0gZXJyb3I7XG4gICAgICByZXR1cm4gdGhpcy5fZW1pdCgnZXJyb3InLCBhbnRocm9waWNFcnJvcik7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLl9lbWl0KCdlcnJvcicsIG5ldyBBbnRocm9waWNFcnJvcihTdHJpbmcoZXJyb3IpKSk7XG4gIH07XG5cbiAgcHJvdGVjdGVkIF9lbWl0PEV2ZW50IGV4dGVuZHMga2V5b2YgTWVzc2FnZVN0cmVhbUV2ZW50cz4oXG4gICAgZXZlbnQ6IEV2ZW50LFxuICAgIC4uLmFyZ3M6IFBhcmFtZXRlcnM8TWVzc2FnZVN0cmVhbUV2ZW50c1tFdmVudF0+XG4gICkge1xuICAgIC8vIG1ha2Ugc3VyZSB3ZSBkb24ndCBlbWl0IGFueSBNZXNzYWdlU3RyZWFtRXZlbnRzIGFmdGVyIGVuZFxuICAgIGlmICh0aGlzLiNlbmRlZCkgcmV0dXJuO1xuXG4gICAgaWYgKGV2ZW50ID09PSAnZW5kJykge1xuICAgICAgdGhpcy4jZW5kZWQgPSB0cnVlO1xuICAgICAgdGhpcy4jcmVzb2x2ZUVuZFByb21pc2UoKTtcbiAgICB9XG5cbiAgICBjb25zdCBsaXN0ZW5lcnM6IE1lc3NhZ2VTdHJlYW1FdmVudExpc3RlbmVyczxFdmVudD4gfCB1bmRlZmluZWQgPSB0aGlzLiNsaXN0ZW5lcnNbZXZlbnRdO1xuICAgIGlmIChsaXN0ZW5lcnMpIHtcbiAgICAgIHRoaXMuI2xpc3RlbmVyc1tldmVudF0gPSBsaXN0ZW5lcnMuZmlsdGVyKChsKSA9PiAhbC5vbmNlKSBhcyBhbnk7XG4gICAgICBsaXN0ZW5lcnMuZm9yRWFjaCgoeyBsaXN0ZW5lciB9OiBhbnkpID0+IGxpc3RlbmVyKC4uLmFyZ3MpKTtcbiAgICB9XG5cbiAgICBpZiAoZXZlbnQgPT09ICdhYm9ydCcpIHtcbiAgICAgIGNvbnN0IGVycm9yID0gYXJnc1swXSBhcyBBUElVc2VyQWJvcnRFcnJvcjtcbiAgICAgIGlmICghdGhpcy4jY2F0Y2hpbmdQcm9taXNlQ3JlYXRlZCAmJiAhbGlzdGVuZXJzPy5sZW5ndGgpIHtcbiAgICAgICAgUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICAgICAgfVxuICAgICAgdGhpcy4jcmVqZWN0Q29ubmVjdGVkUHJvbWlzZShlcnJvcik7XG4gICAgICB0aGlzLiNyZWplY3RFbmRQcm9taXNlKGVycm9yKTtcbiAgICAgIHRoaXMuX2VtaXQoJ2VuZCcpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChldmVudCA9PT0gJ2Vycm9yJykge1xuICAgICAgLy8gTk9URTogX2VtaXQoJ2Vycm9yJywgZXJyb3IpIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBmcm9tICNoYW5kbGVFcnJvcigpLlxuXG4gICAgICBjb25zdCBlcnJvciA9IGFyZ3NbMF0gYXMgQW50aHJvcGljRXJyb3I7XG4gICAgICBpZiAoIXRoaXMuI2NhdGNoaW5nUHJvbWlzZUNyZWF0ZWQgJiYgIWxpc3RlbmVycz8ubGVuZ3RoKSB7XG4gICAgICAgIC8vIFRyaWdnZXIgYW4gdW5oYW5kbGVkIHJlamVjdGlvbiBpZiB0aGUgdXNlciBoYXNuJ3QgcmVnaXN0ZXJlZCBhbnkgZXJyb3IgaGFuZGxlcnMuXG4gICAgICAgIC8vIElmIHlvdSBhcmUgc2VlaW5nIHN0YWNrIHRyYWNlcyBoZXJlLCBtYWtlIHN1cmUgdG8gaGFuZGxlIGVycm9ycyB2aWEgZWl0aGVyOlxuICAgICAgICAvLyAtIHJ1bm5lci5vbignZXJyb3InLCAoKSA9PiAuLi4pXG4gICAgICAgIC8vIC0gYXdhaXQgcnVubmVyLmRvbmUoKVxuICAgICAgICAvLyAtIGF3YWl0IHJ1bm5lci5maW5hbC4uLigpXG4gICAgICAgIC8vIC0gZXRjLlxuICAgICAgICBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gICAgICB9XG4gICAgICB0aGlzLiNyZWplY3RDb25uZWN0ZWRQcm9taXNlKGVycm9yKTtcbiAgICAgIHRoaXMuI3JlamVjdEVuZFByb21pc2UoZXJyb3IpO1xuICAgICAgdGhpcy5fZW1pdCgnZW5kJyk7XG4gICAgfVxuICB9XG5cbiAgcHJvdGVjdGVkIF9lbWl0RmluYWwoKSB7XG4gICAgY29uc3QgZmluYWxNZXNzYWdlID0gdGhpcy5yZWNlaXZlZE1lc3NhZ2VzLmF0KC0xKTtcbiAgICBpZiAoZmluYWxNZXNzYWdlKSB7XG4gICAgICB0aGlzLl9lbWl0KCdmaW5hbE1lc3NhZ2UnLCB0aGlzLiNnZXRGaW5hbE1lc3NhZ2UoKSk7XG4gICAgfVxuICB9XG5cbiAgI2JlZ2luUmVxdWVzdCgpIHtcbiAgICBpZiAodGhpcy5lbmRlZCkgcmV0dXJuO1xuICAgIHRoaXMuI2N1cnJlbnRNZXNzYWdlU25hcHNob3QgPSB1bmRlZmluZWQ7XG4gIH1cbiAgI2FkZFN0cmVhbUV2ZW50KGV2ZW50OiBNZXNzYWdlU3RyZWFtRXZlbnQpIHtcbiAgICBpZiAodGhpcy5lbmRlZCkgcmV0dXJuO1xuICAgIGNvbnN0IG1lc3NhZ2VTbmFwc2hvdCA9IHRoaXMuI2FjY3VtdWxhdGVNZXNzYWdlKGV2ZW50KTtcbiAgICB0aGlzLl9lbWl0KCdzdHJlYW1FdmVudCcsIGV2ZW50LCBtZXNzYWdlU25hcHNob3QpO1xuXG4gICAgc3dpdGNoIChldmVudC50eXBlKSB7XG4gICAgICBjYXNlICdjb250ZW50X2Jsb2NrX2RlbHRhJzoge1xuICAgICAgICBjb25zdCBjb250ZW50ID0gbWVzc2FnZVNuYXBzaG90LmNvbnRlbnQuYXQoLTEpITtcbiAgICAgICAgaWYgKGV2ZW50LmRlbHRhLnR5cGUgPT09ICd0ZXh0X2RlbHRhJyAmJiBjb250ZW50LnR5cGUgPT09ICd0ZXh0Jykge1xuICAgICAgICAgIHRoaXMuX2VtaXQoJ3RleHQnLCBldmVudC5kZWx0YS50ZXh0LCBjb250ZW50LnRleHQgfHwgJycpO1xuICAgICAgICB9IGVsc2UgaWYgKGV2ZW50LmRlbHRhLnR5cGUgPT09ICdpbnB1dF9qc29uX2RlbHRhJyAmJiBjb250ZW50LnR5cGUgPT09ICd0b29sX3VzZScpIHtcbiAgICAgICAgICBpZiAoY29udGVudC5pbnB1dCkge1xuICAgICAgICAgICAgdGhpcy5fZW1pdCgnaW5wdXRKc29uJywgZXZlbnQuZGVsdGEucGFydGlhbF9qc29uLCBjb250ZW50LmlucHV0KTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlICdtZXNzYWdlX3N0b3AnOiB7XG4gICAgICAgIHRoaXMuX2FkZE1lc3NhZ2VQYXJhbShtZXNzYWdlU25hcHNob3QpO1xuICAgICAgICB0aGlzLl9hZGRNZXNzYWdlKG1lc3NhZ2VTbmFwc2hvdCwgdHJ1ZSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FzZSAnY29udGVudF9ibG9ja19zdG9wJzoge1xuICAgICAgICB0aGlzLl9lbWl0KCdjb250ZW50QmxvY2snLCBtZXNzYWdlU25hcHNob3QuY29udGVudC5hdCgtMSkhKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlICdtZXNzYWdlX3N0YXJ0Jzoge1xuICAgICAgICB0aGlzLiNjdXJyZW50TWVzc2FnZVNuYXBzaG90ID0gbWVzc2FnZVNuYXBzaG90O1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhc2UgJ2NvbnRlbnRfYmxvY2tfc3RhcnQnOlxuICAgICAgY2FzZSAnbWVzc2FnZV9kZWx0YSc6XG4gICAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuICAjZW5kUmVxdWVzdCgpOiBNZXNzYWdlIHtcbiAgICBpZiAodGhpcy5lbmRlZCkge1xuICAgICAgdGhyb3cgbmV3IEFudGhyb3BpY0Vycm9yKGBzdHJlYW0gaGFzIGVuZGVkLCB0aGlzIHNob3VsZG4ndCBoYXBwZW5gKTtcbiAgICB9XG4gICAgY29uc3Qgc25hcHNob3QgPSB0aGlzLiNjdXJyZW50TWVzc2FnZVNuYXBzaG90O1xuICAgIGlmICghc25hcHNob3QpIHtcbiAgICAgIHRocm93IG5ldyBBbnRocm9waWNFcnJvcihgcmVxdWVzdCBlbmRlZCB3aXRob3V0IHNlbmRpbmcgYW55IGNodW5rc2ApO1xuICAgIH1cbiAgICB0aGlzLiNjdXJyZW50TWVzc2FnZVNuYXBzaG90ID0gdW5kZWZpbmVkO1xuICAgIHJldHVybiBzbmFwc2hvdDtcbiAgfVxuXG4gIHByb3RlY3RlZCBhc3luYyBfZnJvbVJlYWRhYmxlU3RyZWFtKFxuICAgIHJlYWRhYmxlU3RyZWFtOiBSZWFkYWJsZVN0cmVhbSxcbiAgICBvcHRpb25zPzogQ29yZS5SZXF1ZXN0T3B0aW9ucyxcbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3Qgc2lnbmFsID0gb3B0aW9ucz8uc2lnbmFsO1xuICAgIGlmIChzaWduYWwpIHtcbiAgICAgIGlmIChzaWduYWwuYWJvcnRlZCkgdGhpcy5jb250cm9sbGVyLmFib3J0KCk7XG4gICAgICBzaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCAoKSA9PiB0aGlzLmNvbnRyb2xsZXIuYWJvcnQoKSk7XG4gICAgfVxuICAgIHRoaXMuI2JlZ2luUmVxdWVzdCgpO1xuICAgIHRoaXMuX2Nvbm5lY3RlZCgpO1xuICAgIGNvbnN0IHN0cmVhbSA9IFN0cmVhbS5mcm9tUmVhZGFibGVTdHJlYW08TWVzc2FnZVN0cmVhbUV2ZW50PihyZWFkYWJsZVN0cmVhbSwgdGhpcy5jb250cm9sbGVyKTtcbiAgICBmb3IgYXdhaXQgKGNvbnN0IGV2ZW50IG9mIHN0cmVhbSkge1xuICAgICAgdGhpcy4jYWRkU3RyZWFtRXZlbnQoZXZlbnQpO1xuICAgIH1cbiAgICBpZiAoc3RyZWFtLmNvbnRyb2xsZXIuc2lnbmFsPy5hYm9ydGVkKSB7XG4gICAgICB0aHJvdyBuZXcgQVBJVXNlckFib3J0RXJyb3IoKTtcbiAgICB9XG4gICAgdGhpcy4jZW5kUmVxdWVzdCgpO1xuICB9XG5cbiAgLyoqXG4gICAqIE11dGF0ZXMgdGhpcy4jY3VycmVudE1lc3NhZ2Ugd2l0aCB0aGUgY3VycmVudCBldmVudC4gSGFuZGxpbmcgdGhlIGFjY3VtdWxhdGlvbiBvZiBtdWx0aXBsZSBtZXNzYWdlc1xuICAgKiB3aWxsIGJlIG5lZWRlZCB0byBiZSBoYW5kbGVkIGJ5IHRoZSBjYWxsZXIsIHRoaXMgbWV0aG9kIHdpbGwgdGhyb3cgaWYgeW91IHRyeSB0byBhY2N1bXVsYXRlIGZvciBtdWx0aXBsZVxuICAgKiBtZXNzYWdlcy5cbiAgICovXG4gICNhY2N1bXVsYXRlTWVzc2FnZShldmVudDogTWVzc2FnZVN0cmVhbUV2ZW50KTogTWVzc2FnZSB7XG4gICAgbGV0IHNuYXBzaG90ID0gdGhpcy4jY3VycmVudE1lc3NhZ2VTbmFwc2hvdDtcblxuICAgIGlmIChldmVudC50eXBlID09PSAnbWVzc2FnZV9zdGFydCcpIHtcbiAgICAgIGlmIChzbmFwc2hvdCkge1xuICAgICAgICB0aHJvdyBuZXcgQW50aHJvcGljRXJyb3IoYFVuZXhwZWN0ZWQgZXZlbnQgb3JkZXIsIGdvdCAke2V2ZW50LnR5cGV9IGJlZm9yZSByZWNlaXZpbmcgXCJtZXNzYWdlX3N0b3BcImApO1xuICAgICAgfVxuICAgICAgcmV0dXJuIGV2ZW50Lm1lc3NhZ2U7XG4gICAgfVxuXG4gICAgaWYgKCFzbmFwc2hvdCkge1xuICAgICAgdGhyb3cgbmV3IEFudGhyb3BpY0Vycm9yKGBVbmV4cGVjdGVkIGV2ZW50IG9yZGVyLCBnb3QgJHtldmVudC50eXBlfSBiZWZvcmUgXCJtZXNzYWdlX3N0YXJ0XCJgKTtcbiAgICB9XG5cbiAgICBzd2l0Y2ggKGV2ZW50LnR5cGUpIHtcbiAgICAgIGNhc2UgJ21lc3NhZ2Vfc3RvcCc6XG4gICAgICAgIHJldHVybiBzbmFwc2hvdDtcbiAgICAgIGNhc2UgJ21lc3NhZ2VfZGVsdGEnOlxuICAgICAgICBzbmFwc2hvdC5zdG9wX3JlYXNvbiA9IGV2ZW50LmRlbHRhLnN0b3BfcmVhc29uO1xuICAgICAgICBzbmFwc2hvdC5zdG9wX3NlcXVlbmNlID0gZXZlbnQuZGVsdGEuc3RvcF9zZXF1ZW5jZTtcbiAgICAgICAgc25hcHNob3QudXNhZ2Uub3V0cHV0X3Rva2VucyA9IGV2ZW50LnVzYWdlLm91dHB1dF90b2tlbnM7XG4gICAgICAgIHJldHVybiBzbmFwc2hvdDtcbiAgICAgIGNhc2UgJ2NvbnRlbnRfYmxvY2tfc3RhcnQnOlxuICAgICAgICBzbmFwc2hvdC5jb250ZW50LnB1c2goZXZlbnQuY29udGVudF9ibG9jayk7XG4gICAgICAgIHJldHVybiBzbmFwc2hvdDtcbiAgICAgIGNhc2UgJ2NvbnRlbnRfYmxvY2tfZGVsdGEnOiB7XG4gICAgICAgIGNvbnN0IHNuYXBzaG90Q29udGVudCA9IHNuYXBzaG90LmNvbnRlbnQuYXQoZXZlbnQuaW5kZXgpO1xuICAgICAgICBpZiAoc25hcHNob3RDb250ZW50Py50eXBlID09PSAndGV4dCcgJiYgZXZlbnQuZGVsdGEudHlwZSA9PT0gJ3RleHRfZGVsdGEnKSB7XG4gICAgICAgICAgc25hcHNob3RDb250ZW50LnRleHQgKz0gZXZlbnQuZGVsdGEudGV4dDtcbiAgICAgICAgfSBlbHNlIGlmIChzbmFwc2hvdENvbnRlbnQ/LnR5cGUgPT09ICd0b29sX3VzZScgJiYgZXZlbnQuZGVsdGEudHlwZSA9PT0gJ2lucHV0X2pzb25fZGVsdGEnKSB7XG4gICAgICAgICAgLy8gd2UgbmVlZCB0byBrZWVwIHRyYWNrIG9mIHRoZSByYXcgSlNPTiBzdHJpbmcgYXMgd2VsbCBzbyB0aGF0IHdlIGNhblxuICAgICAgICAgIC8vIHJlLXBhcnNlIGl0IGZvciBlYWNoIGRlbHRhLCBmb3Igbm93IHdlIGp1c3Qgc3RvcmUgaXQgYXMgYW4gdW50eXBlZFxuICAgICAgICAgIC8vIG5vbi1lbnVtZXJhYmxlIHByb3BlcnR5IG9uIHRoZSBzbmFwc2hvdFxuICAgICAgICAgIGxldCBqc29uQnVmID0gKHNuYXBzaG90Q29udGVudCBhcyBhbnkpW0pTT05fQlVGX1BST1BFUlRZXSB8fCAnJztcbiAgICAgICAgICBqc29uQnVmICs9IGV2ZW50LmRlbHRhLnBhcnRpYWxfanNvbjtcblxuICAgICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShzbmFwc2hvdENvbnRlbnQsIEpTT05fQlVGX1BST1BFUlRZLCB7XG4gICAgICAgICAgICB2YWx1ZToganNvbkJ1ZixcbiAgICAgICAgICAgIGVudW1lcmFibGU6IGZhbHNlLFxuICAgICAgICAgICAgd3JpdGFibGU6IHRydWUsXG4gICAgICAgICAgfSk7XG5cbiAgICAgICAgICBpZiAoanNvbkJ1Zikge1xuICAgICAgICAgICAgc25hcHNob3RDb250ZW50LmlucHV0ID0gcGFydGlhbFBhcnNlKGpzb25CdWYpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc25hcHNob3Q7XG4gICAgICB9XG4gICAgICBjYXNlICdjb250ZW50X2Jsb2NrX3N0b3AnOlxuICAgICAgICByZXR1cm4gc25hcHNob3Q7XG4gICAgfVxuICB9XG5cbiAgW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSgpOiBBc3luY0l0ZXJhdG9yPE1lc3NhZ2VTdHJlYW1FdmVudD4ge1xuICAgIGNvbnN0IHB1c2hRdWV1ZTogTWVzc2FnZVN0cmVhbUV2ZW50W10gPSBbXTtcbiAgICBjb25zdCByZWFkUXVldWU6IHtcbiAgICAgIHJlc29sdmU6IChjaHVuazogTWVzc2FnZVN0cmVhbUV2ZW50IHwgdW5kZWZpbmVkKSA9PiB2b2lkO1xuICAgICAgcmVqZWN0OiAoZXJyb3I6IHVua25vd24pID0+IHZvaWQ7XG4gICAgfVtdID0gW107XG4gICAgbGV0IGRvbmUgPSBmYWxzZTtcblxuICAgIHRoaXMub24oJ3N0cmVhbUV2ZW50JywgKGV2ZW50KSA9PiB7XG4gICAgICBjb25zdCByZWFkZXIgPSByZWFkUXVldWUuc2hpZnQoKTtcbiAgICAgIGlmIChyZWFkZXIpIHtcbiAgICAgICAgcmVhZGVyLnJlc29sdmUoZXZlbnQpO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgcHVzaFF1ZXVlLnB1c2goZXZlbnQpO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgdGhpcy5vbignZW5kJywgKCkgPT4ge1xuICAgICAgZG9uZSA9IHRydWU7XG4gICAgICBmb3IgKGNvbnN0IHJlYWRlciBvZiByZWFkUXVldWUpIHtcbiAgICAgICAgcmVhZGVyLnJlc29sdmUodW5kZWZpbmVkKTtcbiAgICAgIH1cbiAgICAgIHJlYWRRdWV1ZS5sZW5ndGggPSAwO1xuICAgIH0pO1xuXG4gICAgdGhpcy5vbignYWJvcnQnLCAoZXJyKSA9PiB7XG4gICAgICBkb25lID0gdHJ1ZTtcbiAgICAgIGZvciAoY29uc3QgcmVhZGVyIG9mIHJlYWRRdWV1ZSkge1xuICAgICAgICByZWFkZXIucmVqZWN0KGVycik7XG4gICAgICB9XG4gICAgICByZWFkUXVldWUubGVuZ3RoID0gMDtcbiAgICB9KTtcblxuICAgIHRoaXMub24oJ2Vycm9yJywgKGVycikgPT4ge1xuICAgICAgZG9uZSA9IHRydWU7XG4gICAgICBmb3IgKGNvbnN0IHJlYWRlciBvZiByZWFkUXVldWUpIHtcbiAgICAgICAgcmVhZGVyLnJlamVjdChlcnIpO1xuICAgICAgfVxuICAgICAgcmVhZFF1ZXVlLmxlbmd0aCA9IDA7XG4gICAgfSk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgbmV4dDogYXN5bmMgKCk6IFByb21pc2U8SXRlcmF0b3JSZXN1bHQ8TWVzc2FnZVN0cmVhbUV2ZW50Pj4gPT4ge1xuICAgICAgICBpZiAoIXB1c2hRdWV1ZS5sZW5ndGgpIHtcbiAgICAgICAgICBpZiAoZG9uZSkge1xuICAgICAgICAgICAgcmV0dXJuIHsgdmFsdWU6IHVuZGVmaW5lZCwgZG9uZTogdHJ1ZSB9O1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2U8TWVzc2FnZVN0cmVhbUV2ZW50IHwgdW5kZWZpbmVkPigocmVzb2x2ZSwgcmVqZWN0KSA9PlxuICAgICAgICAgICAgcmVhZFF1ZXVlLnB1c2goeyByZXNvbHZlLCByZWplY3QgfSksXG4gICAgICAgICAgKS50aGVuKChjaHVuaykgPT4gKGNodW5rID8geyB2YWx1ZTogY2h1bmssIGRvbmU6IGZhbHNlIH0gOiB7IHZhbHVlOiB1bmRlZmluZWQsIGRvbmU6IHRydWUgfSkpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGNodW5rID0gcHVzaFF1ZXVlLnNoaWZ0KCkhO1xuICAgICAgICByZXR1cm4geyB2YWx1ZTogY2h1bmssIGRvbmU6IGZhbHNlIH07XG4gICAgICB9LFxuICAgICAgcmV0dXJuOiBhc3luYyAoKSA9PiB7XG4gICAgICAgIHRoaXMuYWJvcnQoKTtcbiAgICAgICAgcmV0dXJuIHsgdmFsdWU6IHVuZGVmaW5lZCwgZG9uZTogdHJ1ZSB9O1xuICAgICAgfSxcbiAgICB9O1xuICB9XG5cbiAgdG9SZWFkYWJsZVN0cmVhbSgpOiBSZWFkYWJsZVN0cmVhbSB7XG4gICAgY29uc3Qgc3RyZWFtID0gbmV3IFN0cmVhbSh0aGlzW1N5bWJvbC5hc3luY0l0ZXJhdG9yXS5iaW5kKHRoaXMpLCB0aGlzLmNvbnRyb2xsZXIpO1xuICAgIHJldHVybiBzdHJlYW0udG9SZWFkYWJsZVN0cmVhbSgpO1xuICB9XG59XG4iLCAiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cblxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vcmVzb3VyY2UuanNcIjtcbmltcG9ydCB7IEFQSVByb21pc2UgfSBmcm9tIFwiLi4vY29yZS5qc1wiO1xuaW1wb3J0ICogYXMgQ29yZSBmcm9tIFwiLi4vY29yZS5qc1wiO1xuaW1wb3J0ICogYXMgTWVzc2FnZXNBUEkgZnJvbSBcIi4vbWVzc2FnZXMuanNcIjtcbmltcG9ydCB7IFN0cmVhbSB9IGZyb20gXCIuLi9zdHJlYW1pbmcuanNcIjtcbmltcG9ydCB7IE1lc3NhZ2VTdHJlYW0gfSBmcm9tIFwiLi4vbGliL01lc3NhZ2VTdHJlYW0uanNcIjtcblxuZXhwb3J0IHsgTWVzc2FnZVN0cmVhbSB9IGZyb20gXCIuLi9saWIvTWVzc2FnZVN0cmVhbS5qc1wiO1xuXG5leHBvcnQgY2xhc3MgTWVzc2FnZXMgZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gIC8qKlxuICAgKiBDcmVhdGUgYSBNZXNzYWdlLlxuICAgKlxuICAgKiBTZW5kIGEgc3RydWN0dXJlZCBsaXN0IG9mIGlucHV0IG1lc3NhZ2VzIHdpdGggdGV4dCBhbmQvb3IgaW1hZ2UgY29udGVudCwgYW5kIHRoZVxuICAgKiBtb2RlbCB3aWxsIGdlbmVyYXRlIHRoZSBuZXh0IG1lc3NhZ2UgaW4gdGhlIGNvbnZlcnNhdGlvbi5cbiAgICpcbiAgICogVGhlIE1lc3NhZ2VzIEFQSSBjYW4gYmUgdXNlZCBmb3IgZWl0aGVyIHNpbmdsZSBxdWVyaWVzIG9yIHN0YXRlbGVzcyBtdWx0aS10dXJuXG4gICAqIGNvbnZlcnNhdGlvbnMuXG4gICAqL1xuICBjcmVhdGUoYm9keTogTWVzc2FnZUNyZWF0ZVBhcmFtc05vblN0cmVhbWluZywgb3B0aW9ucz86IENvcmUuUmVxdWVzdE9wdGlvbnMpOiBBUElQcm9taXNlPE1lc3NhZ2U+O1xuICBjcmVhdGUoXG4gICAgYm9keTogTWVzc2FnZUNyZWF0ZVBhcmFtc1N0cmVhbWluZyxcbiAgICBvcHRpb25zPzogQ29yZS5SZXF1ZXN0T3B0aW9ucyxcbiAgKTogQVBJUHJvbWlzZTxTdHJlYW08UmF3TWVzc2FnZVN0cmVhbUV2ZW50Pj47XG4gIGNyZWF0ZShcbiAgICBib2R5OiBNZXNzYWdlQ3JlYXRlUGFyYW1zQmFzZSxcbiAgICBvcHRpb25zPzogQ29yZS5SZXF1ZXN0T3B0aW9ucyxcbiAgKTogQVBJUHJvbWlzZTxTdHJlYW08UmF3TWVzc2FnZVN0cmVhbUV2ZW50PiB8IE1lc3NhZ2U+O1xuICBjcmVhdGUoXG4gICAgYm9keTogTWVzc2FnZUNyZWF0ZVBhcmFtcyxcbiAgICBvcHRpb25zPzogQ29yZS5SZXF1ZXN0T3B0aW9ucyxcbiAgKTogQVBJUHJvbWlzZTxNZXNzYWdlPiB8IEFQSVByb21pc2U8U3RyZWFtPFJhd01lc3NhZ2VTdHJlYW1FdmVudD4+IHtcbiAgICBpZiAoYm9keS5tb2RlbCBpbiBERVBSRUNBVEVEX01PREVMUykge1xuICAgICAgY29uc29sZS53YXJuKFxuICAgICAgICBgVGhlIG1vZGVsICcke2JvZHkubW9kZWx9JyBpcyBkZXByZWNhdGVkIGFuZCB3aWxsIHJlYWNoIGVuZC1vZi1saWZlIG9uICR7XG4gICAgICAgICAgREVQUkVDQVRFRF9NT0RFTFNbYm9keS5tb2RlbF1cbiAgICAgICAgfVxcblBsZWFzZSBtaWdyYXRlIHRvIGEgbmV3ZXIgbW9kZWwuIFZpc2l0IGh0dHBzOi8vZG9jcy5hbnRocm9waWMuY29tL2VuL2RvY3MvcmVzb3VyY2VzL21vZGVsLWRlcHJlY2F0aW9ucyBmb3IgbW9yZSBpbmZvcm1hdGlvbi5gLFxuICAgICAgKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX2NsaWVudC5wb3N0KCcvdjEvbWVzc2FnZXMnLCB7XG4gICAgICBib2R5LFxuICAgICAgdGltZW91dDogKHRoaXMuX2NsaWVudCBhcyBhbnkpLl9vcHRpb25zLnRpbWVvdXQgPz8gNjAwMDAwLFxuICAgICAgLi4ub3B0aW9ucyxcbiAgICAgIHN0cmVhbTogYm9keS5zdHJlYW0gPz8gZmFsc2UsXG4gICAgfSkgYXMgQVBJUHJvbWlzZTxNZXNzYWdlPiB8IEFQSVByb21pc2U8U3RyZWFtPFJhd01lc3NhZ2VTdHJlYW1FdmVudD4+O1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIE1lc3NhZ2Ugc3RyZWFtXG4gICAqL1xuICBzdHJlYW0oYm9keTogTWVzc2FnZVN0cmVhbVBhcmFtcywgb3B0aW9ucz86IENvcmUuUmVxdWVzdE9wdGlvbnMpOiBNZXNzYWdlU3RyZWFtIHtcbiAgICByZXR1cm4gTWVzc2FnZVN0cmVhbS5jcmVhdGVNZXNzYWdlKHRoaXMsIGJvZHksIG9wdGlvbnMpO1xuICB9XG59XG5cbmV4cG9ydCB0eXBlIENvbnRlbnRCbG9jayA9IFRleHRCbG9jayB8IFRvb2xVc2VCbG9jaztcblxuZXhwb3J0IHR5cGUgQ29udGVudEJsb2NrRGVsdGFFdmVudCA9IFJhd0NvbnRlbnRCbG9ja0RlbHRhRXZlbnQ7XG5cbmV4cG9ydCB0eXBlIENvbnRlbnRCbG9ja1N0YXJ0RXZlbnQgPSBSYXdDb250ZW50QmxvY2tTdGFydEV2ZW50O1xuXG5leHBvcnQgdHlwZSBDb250ZW50QmxvY2tTdG9wRXZlbnQgPSBSYXdDb250ZW50QmxvY2tTdG9wRXZlbnQ7XG5cbmV4cG9ydCBpbnRlcmZhY2UgSW1hZ2VCbG9ja1BhcmFtIHtcbiAgc291cmNlOiBJbWFnZUJsb2NrUGFyYW0uU291cmNlO1xuXG4gIHR5cGU6ICdpbWFnZSc7XG59XG5cbmV4cG9ydCBuYW1lc3BhY2UgSW1hZ2VCbG9ja1BhcmFtIHtcbiAgZXhwb3J0IGludGVyZmFjZSBTb3VyY2Uge1xuICAgIGRhdGE6IHN0cmluZztcblxuICAgIG1lZGlhX3R5cGU6ICdpbWFnZS9qcGVnJyB8ICdpbWFnZS9wbmcnIHwgJ2ltYWdlL2dpZicgfCAnaW1hZ2Uvd2VicCc7XG5cbiAgICB0eXBlOiAnYmFzZTY0JztcbiAgfVxufVxuXG5leHBvcnQgdHlwZSBJbnB1dEpzb25EZWx0YSA9IElucHV0SlNPTkRlbHRhO1xuXG5leHBvcnQgaW50ZXJmYWNlIElucHV0SlNPTkRlbHRhIHtcbiAgcGFydGlhbF9qc29uOiBzdHJpbmc7XG5cbiAgdHlwZTogJ2lucHV0X2pzb25fZGVsdGEnO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIE1lc3NhZ2Uge1xuICAvKipcbiAgICogVW5pcXVlIG9iamVjdCBpZGVudGlmaWVyLlxuICAgKlxuICAgKiBUaGUgZm9ybWF0IGFuZCBsZW5ndGggb2YgSURzIG1heSBjaGFuZ2Ugb3ZlciB0aW1lLlxuICAgKi9cbiAgaWQ6IHN0cmluZztcblxuICAvKipcbiAgICogQ29udGVudCBnZW5lcmF0ZWQgYnkgdGhlIG1vZGVsLlxuICAgKlxuICAgKiBUaGlzIGlzIGFuIGFycmF5IG9mIGNvbnRlbnQgYmxvY2tzLCBlYWNoIG9mIHdoaWNoIGhhcyBhIGB0eXBlYCB0aGF0IGRldGVybWluZXNcbiAgICogaXRzIHNoYXBlLlxuICAgKlxuICAgKiBFeGFtcGxlOlxuICAgKlxuICAgKiBgYGBqc29uXG4gICAqIFt7IFwidHlwZVwiOiBcInRleHRcIiwgXCJ0ZXh0XCI6IFwiSGksIEknbSBDbGF1ZGUuXCIgfV1cbiAgICogYGBgXG4gICAqXG4gICAqIElmIHRoZSByZXF1ZXN0IGlucHV0IGBtZXNzYWdlc2AgZW5kZWQgd2l0aCBhbiBgYXNzaXN0YW50YCB0dXJuLCB0aGVuIHRoZVxuICAgKiByZXNwb25zZSBgY29udGVudGAgd2lsbCBjb250aW51ZSBkaXJlY3RseSBmcm9tIHRoYXQgbGFzdCB0dXJuLiBZb3UgY2FuIHVzZSB0aGlzXG4gICAqIHRvIGNvbnN0cmFpbiB0aGUgbW9kZWwncyBvdXRwdXQuXG4gICAqXG4gICAqIEZvciBleGFtcGxlLCBpZiB0aGUgaW5wdXQgYG1lc3NhZ2VzYCB3ZXJlOlxuICAgKlxuICAgKiBgYGBqc29uXG4gICAqIFtcbiAgICogICB7XG4gICAqICAgICBcInJvbGVcIjogXCJ1c2VyXCIsXG4gICAqICAgICBcImNvbnRlbnRcIjogXCJXaGF0J3MgdGhlIEdyZWVrIG5hbWUgZm9yIFN1bj8gKEEpIFNvbCAoQikgSGVsaW9zIChDKSBTdW5cIlxuICAgKiAgIH0sXG4gICAqICAgeyBcInJvbGVcIjogXCJhc3Npc3RhbnRcIiwgXCJjb250ZW50XCI6IFwiVGhlIGJlc3QgYW5zd2VyIGlzIChcIiB9XG4gICAqIF1cbiAgICogYGBgXG4gICAqXG4gICAqIFRoZW4gdGhlIHJlc3BvbnNlIGBjb250ZW50YCBtaWdodCBiZTpcbiAgICpcbiAgICogYGBganNvblxuICAgKiBbeyBcInR5cGVcIjogXCJ0ZXh0XCIsIFwidGV4dFwiOiBcIkIpXCIgfV1cbiAgICogYGBgXG4gICAqL1xuICBjb250ZW50OiBBcnJheTxDb250ZW50QmxvY2s+O1xuXG4gIC8qKlxuICAgKiBUaGUgbW9kZWwgdGhhdCB3aWxsIGNvbXBsZXRlIHlvdXIgcHJvbXB0LlxcblxcblNlZVxuICAgKiBbbW9kZWxzXShodHRwczovL2RvY3MuYW50aHJvcGljLmNvbS9lbi9kb2NzL21vZGVscy1vdmVydmlldykgZm9yIGFkZGl0aW9uYWxcbiAgICogZGV0YWlscyBhbmQgb3B0aW9ucy5cbiAgICovXG4gIG1vZGVsOiBNb2RlbDtcblxuICAvKipcbiAgICogQ29udmVyc2F0aW9uYWwgcm9sZSBvZiB0aGUgZ2VuZXJhdGVkIG1lc3NhZ2UuXG4gICAqXG4gICAqIFRoaXMgd2lsbCBhbHdheXMgYmUgYFwiYXNzaXN0YW50XCJgLlxuICAgKi9cbiAgcm9sZTogJ2Fzc2lzdGFudCc7XG5cbiAgLyoqXG4gICAqIFRoZSByZWFzb24gdGhhdCB3ZSBzdG9wcGVkLlxuICAgKlxuICAgKiBUaGlzIG1heSBiZSBvbmUgdGhlIGZvbGxvd2luZyB2YWx1ZXM6XG4gICAqXG4gICAqIC0gYFwiZW5kX3R1cm5cImA6IHRoZSBtb2RlbCByZWFjaGVkIGEgbmF0dXJhbCBzdG9wcGluZyBwb2ludFxuICAgKiAtIGBcIm1heF90b2tlbnNcImA6IHdlIGV4Y2VlZGVkIHRoZSByZXF1ZXN0ZWQgYG1heF90b2tlbnNgIG9yIHRoZSBtb2RlbCdzIG1heGltdW1cbiAgICogLSBgXCJzdG9wX3NlcXVlbmNlXCJgOiBvbmUgb2YgeW91ciBwcm92aWRlZCBjdXN0b20gYHN0b3Bfc2VxdWVuY2VzYCB3YXMgZ2VuZXJhdGVkXG4gICAqIC0gYFwidG9vbF91c2VcImA6IHRoZSBtb2RlbCBpbnZva2VkIG9uZSBvciBtb3JlIHRvb2xzXG4gICAqXG4gICAqIEluIG5vbi1zdHJlYW1pbmcgbW9kZSB0aGlzIHZhbHVlIGlzIGFsd2F5cyBub24tbnVsbC4gSW4gc3RyZWFtaW5nIG1vZGUsIGl0IGlzXG4gICAqIG51bGwgaW4gdGhlIGBtZXNzYWdlX3N0YXJ0YCBldmVudCBhbmQgbm9uLW51bGwgb3RoZXJ3aXNlLlxuICAgKi9cbiAgc3RvcF9yZWFzb246ICdlbmRfdHVybicgfCAnbWF4X3Rva2VucycgfCAnc3RvcF9zZXF1ZW5jZScgfCAndG9vbF91c2UnIHwgbnVsbDtcblxuICAvKipcbiAgICogV2hpY2ggY3VzdG9tIHN0b3Agc2VxdWVuY2Ugd2FzIGdlbmVyYXRlZCwgaWYgYW55LlxuICAgKlxuICAgKiBUaGlzIHZhbHVlIHdpbGwgYmUgYSBub24tbnVsbCBzdHJpbmcgaWYgb25lIG9mIHlvdXIgY3VzdG9tIHN0b3Agc2VxdWVuY2VzIHdhc1xuICAgKiBnZW5lcmF0ZWQuXG4gICAqL1xuICBzdG9wX3NlcXVlbmNlOiBzdHJpbmcgfCBudWxsO1xuXG4gIC8qKlxuICAgKiBPYmplY3QgdHlwZS5cbiAgICpcbiAgICogRm9yIE1lc3NhZ2VzLCB0aGlzIGlzIGFsd2F5cyBgXCJtZXNzYWdlXCJgLlxuICAgKi9cbiAgdHlwZTogJ21lc3NhZ2UnO1xuXG4gIC8qKlxuICAgKiBCaWxsaW5nIGFuZCByYXRlLWxpbWl0IHVzYWdlLlxuICAgKlxuICAgKiBBbnRocm9waWMncyBBUEkgYmlsbHMgYW5kIHJhdGUtbGltaXRzIGJ5IHRva2VuIGNvdW50cywgYXMgdG9rZW5zIHJlcHJlc2VudCB0aGVcbiAgICogdW5kZXJseWluZyBjb3N0IHRvIG91ciBzeXN0ZW1zLlxuICAgKlxuICAgKiBVbmRlciB0aGUgaG9vZCwgdGhlIEFQSSB0cmFuc2Zvcm1zIHJlcXVlc3RzIGludG8gYSBmb3JtYXQgc3VpdGFibGUgZm9yIHRoZVxuICAgKiBtb2RlbC4gVGhlIG1vZGVsJ3Mgb3V0cHV0IHRoZW4gZ29lcyB0aHJvdWdoIGEgcGFyc2luZyBzdGFnZSBiZWZvcmUgYmVjb21pbmcgYW5cbiAgICogQVBJIHJlc3BvbnNlLiBBcyBhIHJlc3VsdCwgdGhlIHRva2VuIGNvdW50cyBpbiBgdXNhZ2VgIHdpbGwgbm90IG1hdGNoIG9uZS10by1vbmVcbiAgICogd2l0aCB0aGUgZXhhY3QgdmlzaWJsZSBjb250ZW50IG9mIGFuIEFQSSByZXF1ZXN0IG9yIHJlc3BvbnNlLlxuICAgKlxuICAgKiBGb3IgZXhhbXBsZSwgYG91dHB1dF90b2tlbnNgIHdpbGwgYmUgbm9uLXplcm8sIGV2ZW4gZm9yIGFuIGVtcHR5IHN0cmluZyByZXNwb25zZVxuICAgKiBmcm9tIENsYXVkZS5cbiAgICovXG4gIHVzYWdlOiBVc2FnZTtcbn1cblxuZXhwb3J0IHR5cGUgTWVzc2FnZURlbHRhRXZlbnQgPSBSYXdNZXNzYWdlRGVsdGFFdmVudDtcblxuZXhwb3J0IGludGVyZmFjZSBNZXNzYWdlRGVsdGFVc2FnZSB7XG4gIC8qKlxuICAgKiBUaGUgY3VtdWxhdGl2ZSBudW1iZXIgb2Ygb3V0cHV0IHRva2VucyB3aGljaCB3ZXJlIHVzZWQuXG4gICAqL1xuICBvdXRwdXRfdG9rZW5zOiBudW1iZXI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWVzc2FnZVBhcmFtIHtcbiAgY29udGVudDogc3RyaW5nIHwgQXJyYXk8VGV4dEJsb2NrUGFyYW0gfCBJbWFnZUJsb2NrUGFyYW0gfCBUb29sVXNlQmxvY2tQYXJhbSB8IFRvb2xSZXN1bHRCbG9ja1BhcmFtPjtcblxuICByb2xlOiAndXNlcicgfCAnYXNzaXN0YW50Jztcbn1cblxuZXhwb3J0IHR5cGUgTWVzc2FnZVN0YXJ0RXZlbnQgPSBSYXdNZXNzYWdlU3RhcnRFdmVudDtcblxuZXhwb3J0IHR5cGUgTWVzc2FnZVN0b3BFdmVudCA9IFJhd01lc3NhZ2VTdG9wRXZlbnQ7XG5cbmV4cG9ydCB0eXBlIE1lc3NhZ2VTdHJlYW1FdmVudCA9IFJhd01lc3NhZ2VTdHJlYW1FdmVudDtcblxuLyoqXG4gKiBUaGUgbW9kZWwgdGhhdCB3aWxsIGNvbXBsZXRlIHlvdXIgcHJvbXB0LlxcblxcblNlZVxuICogW21vZGVsc10oaHR0cHM6Ly9kb2NzLmFudGhyb3BpYy5jb20vZW4vZG9jcy9tb2RlbHMtb3ZlcnZpZXcpIGZvciBhZGRpdGlvbmFsXG4gKiBkZXRhaWxzIGFuZCBvcHRpb25zLlxuICovXG5leHBvcnQgdHlwZSBNb2RlbCA9XG4gIHwgKHN0cmluZyAmIHt9KVxuICB8ICdjbGF1ZGUtMy01LXNvbm5ldC0yMDI0MDYyMCdcbiAgfCAnY2xhdWRlLTMtb3B1cy0yMDI0MDIyOSdcbiAgfCAnY2xhdWRlLTMtc29ubmV0LTIwMjQwMjI5J1xuICB8ICdjbGF1ZGUtMy1oYWlrdS0yMDI0MDMwNydcbiAgfCAnY2xhdWRlLTIuMSdcbiAgfCAnY2xhdWRlLTIuMCdcbiAgfCAnY2xhdWRlLWluc3RhbnQtMS4yJztcblxudHlwZSBEZXByZWNhdGVkTW9kZWxzVHlwZSA9IHtcbiAgW0sgaW4gTW9kZWxdPzogc3RyaW5nO1xufTtcblxuY29uc3QgREVQUkVDQVRFRF9NT0RFTFM6IERlcHJlY2F0ZWRNb2RlbHNUeXBlID0ge1xuICAnY2xhdWRlLTEuMyc6ICdOb3ZlbWJlciA2dGgsIDIwMjQnLFxuICAnY2xhdWRlLTEuMy0xMDBrJzogJ05vdmVtYmVyIDZ0aCwgMjAyNCcsXG4gICdjbGF1ZGUtaW5zdGFudC0xLjEnOiAnTm92ZW1iZXIgNnRoLCAyMDI0JyxcbiAgJ2NsYXVkZS1pbnN0YW50LTEuMS0xMDBrJzogJ05vdmVtYmVyIDZ0aCwgMjAyNCcsXG4gICdjbGF1ZGUtaW5zdGFudC0xLjInOiAnTm92ZW1iZXIgNnRoLCAyMDI0Jyxcbn07XG5cbmV4cG9ydCBpbnRlcmZhY2UgUmF3Q29udGVudEJsb2NrRGVsdGFFdmVudCB7XG4gIGRlbHRhOiBUZXh0RGVsdGEgfCBJbnB1dEpTT05EZWx0YTtcblxuICBpbmRleDogbnVtYmVyO1xuXG4gIHR5cGU6ICdjb250ZW50X2Jsb2NrX2RlbHRhJztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBSYXdDb250ZW50QmxvY2tTdGFydEV2ZW50IHtcbiAgY29udGVudF9ibG9jazogVGV4dEJsb2NrIHwgVG9vbFVzZUJsb2NrO1xuXG4gIGluZGV4OiBudW1iZXI7XG5cbiAgdHlwZTogJ2NvbnRlbnRfYmxvY2tfc3RhcnQnO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFJhd0NvbnRlbnRCbG9ja1N0b3BFdmVudCB7XG4gIGluZGV4OiBudW1iZXI7XG5cbiAgdHlwZTogJ2NvbnRlbnRfYmxvY2tfc3RvcCc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUmF3TWVzc2FnZURlbHRhRXZlbnQge1xuICBkZWx0YTogUmF3TWVzc2FnZURlbHRhRXZlbnQuRGVsdGE7XG5cbiAgdHlwZTogJ21lc3NhZ2VfZGVsdGEnO1xuXG4gIC8qKlxuICAgKiBCaWxsaW5nIGFuZCByYXRlLWxpbWl0IHVzYWdlLlxuICAgKlxuICAgKiBBbnRocm9waWMncyBBUEkgYmlsbHMgYW5kIHJhdGUtbGltaXRzIGJ5IHRva2VuIGNvdW50cywgYXMgdG9rZW5zIHJlcHJlc2VudCB0aGVcbiAgICogdW5kZXJseWluZyBjb3N0IHRvIG91ciBzeXN0ZW1zLlxuICAgKlxuICAgKiBVbmRlciB0aGUgaG9vZCwgdGhlIEFQSSB0cmFuc2Zvcm1zIHJlcXVlc3RzIGludG8gYSBmb3JtYXQgc3VpdGFibGUgZm9yIHRoZVxuICAgKiBtb2RlbC4gVGhlIG1vZGVsJ3Mgb3V0cHV0IHRoZW4gZ29lcyB0aHJvdWdoIGEgcGFyc2luZyBzdGFnZSBiZWZvcmUgYmVjb21pbmcgYW5cbiAgICogQVBJIHJlc3BvbnNlLiBBcyBhIHJlc3VsdCwgdGhlIHRva2VuIGNvdW50cyBpbiBgdXNhZ2VgIHdpbGwgbm90IG1hdGNoIG9uZS10by1vbmVcbiAgICogd2l0aCB0aGUgZXhhY3QgdmlzaWJsZSBjb250ZW50IG9mIGFuIEFQSSByZXF1ZXN0IG9yIHJlc3BvbnNlLlxuICAgKlxuICAgKiBGb3IgZXhhbXBsZSwgYG91dHB1dF90b2tlbnNgIHdpbGwgYmUgbm9uLXplcm8sIGV2ZW4gZm9yIGFuIGVtcHR5IHN0cmluZyByZXNwb25zZVxuICAgKiBmcm9tIENsYXVkZS5cbiAgICovXG4gIHVzYWdlOiBNZXNzYWdlRGVsdGFVc2FnZTtcbn1cblxuZXhwb3J0IG5hbWVzcGFjZSBSYXdNZXNzYWdlRGVsdGFFdmVudCB7XG4gIGV4cG9ydCBpbnRlcmZhY2UgRGVsdGEge1xuICAgIHN0b3BfcmVhc29uOiAnZW5kX3R1cm4nIHwgJ21heF90b2tlbnMnIHwgJ3N0b3Bfc2VxdWVuY2UnIHwgJ3Rvb2xfdXNlJyB8IG51bGw7XG5cbiAgICBzdG9wX3NlcXVlbmNlOiBzdHJpbmcgfCBudWxsO1xuICB9XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUmF3TWVzc2FnZVN0YXJ0RXZlbnQge1xuICBtZXNzYWdlOiBNZXNzYWdlO1xuXG4gIHR5cGU6ICdtZXNzYWdlX3N0YXJ0Jztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBSYXdNZXNzYWdlU3RvcEV2ZW50IHtcbiAgdHlwZTogJ21lc3NhZ2Vfc3RvcCc7XG59XG5cbmV4cG9ydCB0eXBlIFJhd01lc3NhZ2VTdHJlYW1FdmVudCA9XG4gIHwgUmF3TWVzc2FnZVN0YXJ0RXZlbnRcbiAgfCBSYXdNZXNzYWdlRGVsdGFFdmVudFxuICB8IFJhd01lc3NhZ2VTdG9wRXZlbnRcbiAgfCBSYXdDb250ZW50QmxvY2tTdGFydEV2ZW50XG4gIHwgUmF3Q29udGVudEJsb2NrRGVsdGFFdmVudFxuICB8IFJhd0NvbnRlbnRCbG9ja1N0b3BFdmVudDtcblxuZXhwb3J0IGludGVyZmFjZSBUZXh0QmxvY2sge1xuICB0ZXh0OiBzdHJpbmc7XG5cbiAgdHlwZTogJ3RleHQnO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFRleHRCbG9ja1BhcmFtIHtcbiAgdGV4dDogc3RyaW5nO1xuXG4gIHR5cGU6ICd0ZXh0Jztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBUZXh0RGVsdGEge1xuICB0ZXh0OiBzdHJpbmc7XG5cbiAgdHlwZTogJ3RleHRfZGVsdGEnO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFRvb2wge1xuICAvKipcbiAgICogW0pTT04gc2NoZW1hXShodHRwczovL2pzb24tc2NoZW1hLm9yZy8pIGZvciB0aGlzIHRvb2wncyBpbnB1dC5cbiAgICpcbiAgICogVGhpcyBkZWZpbmVzIHRoZSBzaGFwZSBvZiB0aGUgYGlucHV0YCB0aGF0IHlvdXIgdG9vbCBhY2NlcHRzIGFuZCB0aGF0IHRoZSBtb2RlbFxuICAgKiB3aWxsIHByb2R1Y2UuXG4gICAqL1xuICBpbnB1dF9zY2hlbWE6IFRvb2wuSW5wdXRTY2hlbWE7XG5cbiAgbmFtZTogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBEZXNjcmlwdGlvbiBvZiB3aGF0IHRoaXMgdG9vbCBkb2VzLlxuICAgKlxuICAgKiBUb29sIGRlc2NyaXB0aW9ucyBzaG91bGQgYmUgYXMgZGV0YWlsZWQgYXMgcG9zc2libGUuIFRoZSBtb3JlIGluZm9ybWF0aW9uIHRoYXRcbiAgICogdGhlIG1vZGVsIGhhcyBhYm91dCB3aGF0IHRoZSB0b29sIGlzIGFuZCBob3cgdG8gdXNlIGl0LCB0aGUgYmV0dGVyIGl0IHdpbGxcbiAgICogcGVyZm9ybS4gWW91IGNhbiB1c2UgbmF0dXJhbCBsYW5ndWFnZSBkZXNjcmlwdGlvbnMgdG8gcmVpbmZvcmNlIGltcG9ydGFudFxuICAgKiBhc3BlY3RzIG9mIHRoZSB0b29sIGlucHV0IEpTT04gc2NoZW1hLlxuICAgKi9cbiAgZGVzY3JpcHRpb24/OiBzdHJpbmc7XG59XG5cbmV4cG9ydCBuYW1lc3BhY2UgVG9vbCB7XG4gIC8qKlxuICAgKiBbSlNPTiBzY2hlbWFdKGh0dHBzOi8vanNvbi1zY2hlbWEub3JnLykgZm9yIHRoaXMgdG9vbCdzIGlucHV0LlxuICAgKlxuICAgKiBUaGlzIGRlZmluZXMgdGhlIHNoYXBlIG9mIHRoZSBgaW5wdXRgIHRoYXQgeW91ciB0b29sIGFjY2VwdHMgYW5kIHRoYXQgdGhlIG1vZGVsXG4gICAqIHdpbGwgcHJvZHVjZS5cbiAgICovXG4gIGV4cG9ydCBpbnRlcmZhY2UgSW5wdXRTY2hlbWEge1xuICAgIHR5cGU6ICdvYmplY3QnO1xuXG4gICAgcHJvcGVydGllcz86IHVua25vd24gfCBudWxsO1xuICAgIFtrOiBzdHJpbmddOiB1bmtub3duO1xuICB9XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgVG9vbFJlc3VsdEJsb2NrUGFyYW0ge1xuICB0b29sX3VzZV9pZDogc3RyaW5nO1xuXG4gIHR5cGU6ICd0b29sX3Jlc3VsdCc7XG5cbiAgY29udGVudD86IHN0cmluZyB8IEFycmF5PFRleHRCbG9ja1BhcmFtIHwgSW1hZ2VCbG9ja1BhcmFtPjtcblxuICBpc19lcnJvcj86IGJvb2xlYW47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgVG9vbFVzZUJsb2NrIHtcbiAgaWQ6IHN0cmluZztcblxuICBpbnB1dDogdW5rbm93bjtcblxuICBuYW1lOiBzdHJpbmc7XG5cbiAgdHlwZTogJ3Rvb2xfdXNlJztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBUb29sVXNlQmxvY2tQYXJhbSB7XG4gIGlkOiBzdHJpbmc7XG5cbiAgaW5wdXQ6IHVua25vd247XG5cbiAgbmFtZTogc3RyaW5nO1xuXG4gIHR5cGU6ICd0b29sX3VzZSc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgVXNhZ2Uge1xuICAvKipcbiAgICogVGhlIG51bWJlciBvZiBpbnB1dCB0b2tlbnMgd2hpY2ggd2VyZSB1c2VkLlxuICAgKi9cbiAgaW5wdXRfdG9rZW5zOiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIFRoZSBudW1iZXIgb2Ygb3V0cHV0IHRva2VucyB3aGljaCB3ZXJlIHVzZWQuXG4gICAqL1xuICBvdXRwdXRfdG9rZW5zOiBudW1iZXI7XG59XG5cbmV4cG9ydCB0eXBlIE1lc3NhZ2VDcmVhdGVQYXJhbXMgPSBNZXNzYWdlQ3JlYXRlUGFyYW1zTm9uU3RyZWFtaW5nIHwgTWVzc2FnZUNyZWF0ZVBhcmFtc1N0cmVhbWluZztcblxuZXhwb3J0IGludGVyZmFjZSBNZXNzYWdlQ3JlYXRlUGFyYW1zQmFzZSB7XG4gIC8qKlxuICAgKiBUaGUgbWF4aW11bSBudW1iZXIgb2YgdG9rZW5zIHRvIGdlbmVyYXRlIGJlZm9yZSBzdG9wcGluZy5cbiAgICpcbiAgICogTm90ZSB0aGF0IG91ciBtb2RlbHMgbWF5IHN0b3AgX2JlZm9yZV8gcmVhY2hpbmcgdGhpcyBtYXhpbXVtLiBUaGlzIHBhcmFtZXRlclxuICAgKiBvbmx5IHNwZWNpZmllcyB0aGUgYWJzb2x1dGUgbWF4aW11bSBudW1iZXIgb2YgdG9rZW5zIHRvIGdlbmVyYXRlLlxuICAgKlxuICAgKiBEaWZmZXJlbnQgbW9kZWxzIGhhdmUgZGlmZmVyZW50IG1heGltdW0gdmFsdWVzIGZvciB0aGlzIHBhcmFtZXRlci4gU2VlXG4gICAqIFttb2RlbHNdKGh0dHBzOi8vZG9jcy5hbnRocm9waWMuY29tL2VuL2RvY3MvbW9kZWxzLW92ZXJ2aWV3KSBmb3IgZGV0YWlscy5cbiAgICovXG4gIG1heF90b2tlbnM6IG51bWJlcjtcblxuICAvKipcbiAgICogSW5wdXQgbWVzc2FnZXMuXG4gICAqXG4gICAqIE91ciBtb2RlbHMgYXJlIHRyYWluZWQgdG8gb3BlcmF0ZSBvbiBhbHRlcm5hdGluZyBgdXNlcmAgYW5kIGBhc3Npc3RhbnRgXG4gICAqIGNvbnZlcnNhdGlvbmFsIHR1cm5zLiBXaGVuIGNyZWF0aW5nIGEgbmV3IGBNZXNzYWdlYCwgeW91IHNwZWNpZnkgdGhlIHByaW9yXG4gICAqIGNvbnZlcnNhdGlvbmFsIHR1cm5zIHdpdGggdGhlIGBtZXNzYWdlc2AgcGFyYW1ldGVyLCBhbmQgdGhlIG1vZGVsIHRoZW4gZ2VuZXJhdGVzXG4gICAqIHRoZSBuZXh0IGBNZXNzYWdlYCBpbiB0aGUgY29udmVyc2F0aW9uLlxuICAgKlxuICAgKiBFYWNoIGlucHV0IG1lc3NhZ2UgbXVzdCBiZSBhbiBvYmplY3Qgd2l0aCBhIGByb2xlYCBhbmQgYGNvbnRlbnRgLiBZb3UgY2FuXG4gICAqIHNwZWNpZnkgYSBzaW5nbGUgYHVzZXJgLXJvbGUgbWVzc2FnZSwgb3IgeW91IGNhbiBpbmNsdWRlIG11bHRpcGxlIGB1c2VyYCBhbmRcbiAgICogYGFzc2lzdGFudGAgbWVzc2FnZXMuIFRoZSBmaXJzdCBtZXNzYWdlIG11c3QgYWx3YXlzIHVzZSB0aGUgYHVzZXJgIHJvbGUuXG4gICAqXG4gICAqIElmIHRoZSBmaW5hbCBtZXNzYWdlIHVzZXMgdGhlIGBhc3Npc3RhbnRgIHJvbGUsIHRoZSByZXNwb25zZSBjb250ZW50IHdpbGxcbiAgICogY29udGludWUgaW1tZWRpYXRlbHkgZnJvbSB0aGUgY29udGVudCBpbiB0aGF0IG1lc3NhZ2UuIFRoaXMgY2FuIGJlIHVzZWQgdG9cbiAgICogY29uc3RyYWluIHBhcnQgb2YgdGhlIG1vZGVsJ3MgcmVzcG9uc2UuXG4gICAqXG4gICAqIEV4YW1wbGUgd2l0aCBhIHNpbmdsZSBgdXNlcmAgbWVzc2FnZTpcbiAgICpcbiAgICogYGBganNvblxuICAgKiBbeyBcInJvbGVcIjogXCJ1c2VyXCIsIFwiY29udGVudFwiOiBcIkhlbGxvLCBDbGF1ZGVcIiB9XVxuICAgKiBgYGBcbiAgICpcbiAgICogRXhhbXBsZSB3aXRoIG11bHRpcGxlIGNvbnZlcnNhdGlvbmFsIHR1cm5zOlxuICAgKlxuICAgKiBgYGBqc29uXG4gICAqIFtcbiAgICogICB7IFwicm9sZVwiOiBcInVzZXJcIiwgXCJjb250ZW50XCI6IFwiSGVsbG8gdGhlcmUuXCIgfSxcbiAgICogICB7IFwicm9sZVwiOiBcImFzc2lzdGFudFwiLCBcImNvbnRlbnRcIjogXCJIaSwgSSdtIENsYXVkZS4gSG93IGNhbiBJIGhlbHAgeW91P1wiIH0sXG4gICAqICAgeyBcInJvbGVcIjogXCJ1c2VyXCIsIFwiY29udGVudFwiOiBcIkNhbiB5b3UgZXhwbGFpbiBMTE1zIGluIHBsYWluIEVuZ2xpc2g/XCIgfVxuICAgKiBdXG4gICAqIGBgYFxuICAgKlxuICAgKiBFeGFtcGxlIHdpdGggYSBwYXJ0aWFsbHktZmlsbGVkIHJlc3BvbnNlIGZyb20gQ2xhdWRlOlxuICAgKlxuICAgKiBgYGBqc29uXG4gICAqIFtcbiAgICogICB7XG4gICAqICAgICBcInJvbGVcIjogXCJ1c2VyXCIsXG4gICAqICAgICBcImNvbnRlbnRcIjogXCJXaGF0J3MgdGhlIEdyZWVrIG5hbWUgZm9yIFN1bj8gKEEpIFNvbCAoQikgSGVsaW9zIChDKSBTdW5cIlxuICAgKiAgIH0sXG4gICAqICAgeyBcInJvbGVcIjogXCJhc3Npc3RhbnRcIiwgXCJjb250ZW50XCI6IFwiVGhlIGJlc3QgYW5zd2VyIGlzIChcIiB9XG4gICAqIF1cbiAgICogYGBgXG4gICAqXG4gICAqIEVhY2ggaW5wdXQgbWVzc2FnZSBgY29udGVudGAgbWF5IGJlIGVpdGhlciBhIHNpbmdsZSBgc3RyaW5nYCBvciBhbiBhcnJheSBvZlxuICAgKiBjb250ZW50IGJsb2Nrcywgd2hlcmUgZWFjaCBibG9jayBoYXMgYSBzcGVjaWZpYyBgdHlwZWAuIFVzaW5nIGEgYHN0cmluZ2AgZm9yXG4gICAqIGBjb250ZW50YCBpcyBzaG9ydGhhbmQgZm9yIGFuIGFycmF5IG9mIG9uZSBjb250ZW50IGJsb2NrIG9mIHR5cGUgYFwidGV4dFwiYC4gVGhlXG4gICAqIGZvbGxvd2luZyBpbnB1dCBtZXNzYWdlcyBhcmUgZXF1aXZhbGVudDpcbiAgICpcbiAgICogYGBganNvblxuICAgKiB7IFwicm9sZVwiOiBcInVzZXJcIiwgXCJjb250ZW50XCI6IFwiSGVsbG8sIENsYXVkZVwiIH1cbiAgICogYGBgXG4gICAqXG4gICAqIGBgYGpzb25cbiAgICogeyBcInJvbGVcIjogXCJ1c2VyXCIsIFwiY29udGVudFwiOiBbeyBcInR5cGVcIjogXCJ0ZXh0XCIsIFwidGV4dFwiOiBcIkhlbGxvLCBDbGF1ZGVcIiB9XSB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBTdGFydGluZyB3aXRoIENsYXVkZSAzIG1vZGVscywgeW91IGNhbiBhbHNvIHNlbmQgaW1hZ2UgY29udGVudCBibG9ja3M6XG4gICAqXG4gICAqIGBgYGpzb25cbiAgICoge1xuICAgKiAgIFwicm9sZVwiOiBcInVzZXJcIixcbiAgICogICBcImNvbnRlbnRcIjogW1xuICAgKiAgICAge1xuICAgKiAgICAgICBcInR5cGVcIjogXCJpbWFnZVwiLFxuICAgKiAgICAgICBcInNvdXJjZVwiOiB7XG4gICAqICAgICAgICAgXCJ0eXBlXCI6IFwiYmFzZTY0XCIsXG4gICAqICAgICAgICAgXCJtZWRpYV90eXBlXCI6IFwiaW1hZ2UvanBlZ1wiLFxuICAgKiAgICAgICAgIFwiZGF0YVwiOiBcIi85ai80QUFRU2taSlJnLi4uXCJcbiAgICogICAgICAgfVxuICAgKiAgICAgfSxcbiAgICogICAgIHsgXCJ0eXBlXCI6IFwidGV4dFwiLCBcInRleHRcIjogXCJXaGF0IGlzIGluIHRoaXMgaW1hZ2U/XCIgfVxuICAgKiAgIF1cbiAgICogfVxuICAgKiBgYGBcbiAgICpcbiAgICogV2UgY3VycmVudGx5IHN1cHBvcnQgdGhlIGBiYXNlNjRgIHNvdXJjZSB0eXBlIGZvciBpbWFnZXMsIGFuZCB0aGUgYGltYWdlL2pwZWdgLFxuICAgKiBgaW1hZ2UvcG5nYCwgYGltYWdlL2dpZmAsIGFuZCBgaW1hZ2Uvd2VicGAgbWVkaWEgdHlwZXMuXG4gICAqXG4gICAqIFNlZSBbZXhhbXBsZXNdKGh0dHBzOi8vZG9jcy5hbnRocm9waWMuY29tL2VuL2FwaS9tZXNzYWdlcy1leGFtcGxlcyN2aXNpb24pIGZvclxuICAgKiBtb3JlIGlucHV0IGV4YW1wbGVzLlxuICAgKlxuICAgKiBOb3RlIHRoYXQgaWYgeW91IHdhbnQgdG8gaW5jbHVkZSBhXG4gICAqIFtzeXN0ZW0gcHJvbXB0XShodHRwczovL2RvY3MuYW50aHJvcGljLmNvbS9lbi9kb2NzL3N5c3RlbS1wcm9tcHRzKSwgeW91IGNhbiB1c2VcbiAgICogdGhlIHRvcC1sZXZlbCBgc3lzdGVtYCBwYXJhbWV0ZXIgXHUyMDE0IHRoZXJlIGlzIG5vIGBcInN5c3RlbVwiYCByb2xlIGZvciBpbnB1dFxuICAgKiBtZXNzYWdlcyBpbiB0aGUgTWVzc2FnZXMgQVBJLlxuICAgKi9cbiAgbWVzc2FnZXM6IEFycmF5PE1lc3NhZ2VQYXJhbT47XG5cbiAgLyoqXG4gICAqIFRoZSBtb2RlbCB0aGF0IHdpbGwgY29tcGxldGUgeW91ciBwcm9tcHQuXFxuXFxuU2VlXG4gICAqIFttb2RlbHNdKGh0dHBzOi8vZG9jcy5hbnRocm9waWMuY29tL2VuL2RvY3MvbW9kZWxzLW92ZXJ2aWV3KSBmb3IgYWRkaXRpb25hbFxuICAgKiBkZXRhaWxzIGFuZCBvcHRpb25zLlxuICAgKi9cbiAgbW9kZWw6IE1vZGVsO1xuXG4gIC8qKlxuICAgKiBBbiBvYmplY3QgZGVzY3JpYmluZyBtZXRhZGF0YSBhYm91dCB0aGUgcmVxdWVzdC5cbiAgICovXG4gIG1ldGFkYXRhPzogTWVzc2FnZUNyZWF0ZVBhcmFtcy5NZXRhZGF0YTtcblxuICAvKipcbiAgICogQ3VzdG9tIHRleHQgc2VxdWVuY2VzIHRoYXQgd2lsbCBjYXVzZSB0aGUgbW9kZWwgdG8gc3RvcCBnZW5lcmF0aW5nLlxuICAgKlxuICAgKiBPdXIgbW9kZWxzIHdpbGwgbm9ybWFsbHkgc3RvcCB3aGVuIHRoZXkgaGF2ZSBuYXR1cmFsbHkgY29tcGxldGVkIHRoZWlyIHR1cm4sXG4gICAqIHdoaWNoIHdpbGwgcmVzdWx0IGluIGEgcmVzcG9uc2UgYHN0b3BfcmVhc29uYCBvZiBgXCJlbmRfdHVyblwiYC5cbiAgICpcbiAgICogSWYgeW91IHdhbnQgdGhlIG1vZGVsIHRvIHN0b3AgZ2VuZXJhdGluZyB3aGVuIGl0IGVuY291bnRlcnMgY3VzdG9tIHN0cmluZ3Mgb2ZcbiAgICogdGV4dCwgeW91IGNhbiB1c2UgdGhlIGBzdG9wX3NlcXVlbmNlc2AgcGFyYW1ldGVyLiBJZiB0aGUgbW9kZWwgZW5jb3VudGVycyBvbmUgb2ZcbiAgICogdGhlIGN1c3RvbSBzZXF1ZW5jZXMsIHRoZSByZXNwb25zZSBgc3RvcF9yZWFzb25gIHZhbHVlIHdpbGwgYmUgYFwic3RvcF9zZXF1ZW5jZVwiYFxuICAgKiBhbmQgdGhlIHJlc3BvbnNlIGBzdG9wX3NlcXVlbmNlYCB2YWx1ZSB3aWxsIGNvbnRhaW4gdGhlIG1hdGNoZWQgc3RvcCBzZXF1ZW5jZS5cbiAgICovXG4gIHN0b3Bfc2VxdWVuY2VzPzogQXJyYXk8c3RyaW5nPjtcblxuICAvKipcbiAgICogV2hldGhlciB0byBpbmNyZW1lbnRhbGx5IHN0cmVhbSB0aGUgcmVzcG9uc2UgdXNpbmcgc2VydmVyLXNlbnQgZXZlbnRzLlxuICAgKlxuICAgKiBTZWUgW3N0cmVhbWluZ10oaHR0cHM6Ly9kb2NzLmFudGhyb3BpYy5jb20vZW4vYXBpL21lc3NhZ2VzLXN0cmVhbWluZykgZm9yXG4gICAqIGRldGFpbHMuXG4gICAqL1xuICBzdHJlYW0/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBTeXN0ZW0gcHJvbXB0LlxuICAgKlxuICAgKiBBIHN5c3RlbSBwcm9tcHQgaXMgYSB3YXkgb2YgcHJvdmlkaW5nIGNvbnRleHQgYW5kIGluc3RydWN0aW9ucyB0byBDbGF1ZGUsIHN1Y2hcbiAgICogYXMgc3BlY2lmeWluZyBhIHBhcnRpY3VsYXIgZ29hbCBvciByb2xlLiBTZWUgb3VyXG4gICAqIFtndWlkZSB0byBzeXN0ZW0gcHJvbXB0c10oaHR0cHM6Ly9kb2NzLmFudGhyb3BpYy5jb20vZW4vZG9jcy9zeXN0ZW0tcHJvbXB0cykuXG4gICAqL1xuICBzeXN0ZW0/OiBzdHJpbmcgfCBBcnJheTxUZXh0QmxvY2tQYXJhbT47XG5cbiAgLyoqXG4gICAqIEFtb3VudCBvZiByYW5kb21uZXNzIGluamVjdGVkIGludG8gdGhlIHJlc3BvbnNlLlxuICAgKlxuICAgKiBEZWZhdWx0cyB0byBgMS4wYC4gUmFuZ2VzIGZyb20gYDAuMGAgdG8gYDEuMGAuIFVzZSBgdGVtcGVyYXR1cmVgIGNsb3NlciB0byBgMC4wYFxuICAgKiBmb3IgYW5hbHl0aWNhbCAvIG11bHRpcGxlIGNob2ljZSwgYW5kIGNsb3NlciB0byBgMS4wYCBmb3IgY3JlYXRpdmUgYW5kXG4gICAqIGdlbmVyYXRpdmUgdGFza3MuXG4gICAqXG4gICAqIE5vdGUgdGhhdCBldmVuIHdpdGggYHRlbXBlcmF0dXJlYCBvZiBgMC4wYCwgdGhlIHJlc3VsdHMgd2lsbCBub3QgYmUgZnVsbHlcbiAgICogZGV0ZXJtaW5pc3RpYy5cbiAgICovXG4gIHRlbXBlcmF0dXJlPzogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBIb3cgdGhlIG1vZGVsIHNob3VsZCB1c2UgdGhlIHByb3ZpZGVkIHRvb2xzLiBUaGUgbW9kZWwgY2FuIHVzZSBhIHNwZWNpZmljIHRvb2wsXG4gICAqIGFueSBhdmFpbGFibGUgdG9vbCwgb3IgZGVjaWRlIGJ5IGl0c2VsZi5cbiAgICovXG4gIHRvb2xfY2hvaWNlPzpcbiAgICB8IE1lc3NhZ2VDcmVhdGVQYXJhbXMuVG9vbENob2ljZUF1dG9cbiAgICB8IE1lc3NhZ2VDcmVhdGVQYXJhbXMuVG9vbENob2ljZUFueVxuICAgIHwgTWVzc2FnZUNyZWF0ZVBhcmFtcy5Ub29sQ2hvaWNlVG9vbDtcblxuICAvKipcbiAgICogRGVmaW5pdGlvbnMgb2YgdG9vbHMgdGhhdCB0aGUgbW9kZWwgbWF5IHVzZS5cbiAgICpcbiAgICogSWYgeW91IGluY2x1ZGUgYHRvb2xzYCBpbiB5b3VyIEFQSSByZXF1ZXN0LCB0aGUgbW9kZWwgbWF5IHJldHVybiBgdG9vbF91c2VgXG4gICAqIGNvbnRlbnQgYmxvY2tzIHRoYXQgcmVwcmVzZW50IHRoZSBtb2RlbCdzIHVzZSBvZiB0aG9zZSB0b29scy4gWW91IGNhbiB0aGVuIHJ1blxuICAgKiB0aG9zZSB0b29scyB1c2luZyB0aGUgdG9vbCBpbnB1dCBnZW5lcmF0ZWQgYnkgdGhlIG1vZGVsIGFuZCB0aGVuIG9wdGlvbmFsbHlcbiAgICogcmV0dXJuIHJlc3VsdHMgYmFjayB0byB0aGUgbW9kZWwgdXNpbmcgYHRvb2xfcmVzdWx0YCBjb250ZW50IGJsb2Nrcy5cbiAgICpcbiAgICogRWFjaCB0b29sIGRlZmluaXRpb24gaW5jbHVkZXM6XG4gICAqXG4gICAqIC0gYG5hbWVgOiBOYW1lIG9mIHRoZSB0b29sLlxuICAgKiAtIGBkZXNjcmlwdGlvbmA6IE9wdGlvbmFsLCBidXQgc3Ryb25nbHktcmVjb21tZW5kZWQgZGVzY3JpcHRpb24gb2YgdGhlIHRvb2wuXG4gICAqIC0gYGlucHV0X3NjaGVtYWA6IFtKU09OIHNjaGVtYV0oaHR0cHM6Ly9qc29uLXNjaGVtYS5vcmcvKSBmb3IgdGhlIHRvb2wgYGlucHV0YFxuICAgKiAgIHNoYXBlIHRoYXQgdGhlIG1vZGVsIHdpbGwgcHJvZHVjZSBpbiBgdG9vbF91c2VgIG91dHB1dCBjb250ZW50IGJsb2Nrcy5cbiAgICpcbiAgICogRm9yIGV4YW1wbGUsIGlmIHlvdSBkZWZpbmVkIGB0b29sc2AgYXM6XG4gICAqXG4gICAqIGBgYGpzb25cbiAgICogW1xuICAgKiAgIHtcbiAgICogICAgIFwibmFtZVwiOiBcImdldF9zdG9ja19wcmljZVwiLFxuICAgKiAgICAgXCJkZXNjcmlwdGlvblwiOiBcIkdldCB0aGUgY3VycmVudCBzdG9jayBwcmljZSBmb3IgYSBnaXZlbiB0aWNrZXIgc3ltYm9sLlwiLFxuICAgKiAgICAgXCJpbnB1dF9zY2hlbWFcIjoge1xuICAgKiAgICAgICBcInR5cGVcIjogXCJvYmplY3RcIixcbiAgICogICAgICAgXCJwcm9wZXJ0aWVzXCI6IHtcbiAgICogICAgICAgICBcInRpY2tlclwiOiB7XG4gICAqICAgICAgICAgICBcInR5cGVcIjogXCJzdHJpbmdcIixcbiAgICogICAgICAgICAgIFwiZGVzY3JpcHRpb25cIjogXCJUaGUgc3RvY2sgdGlja2VyIHN5bWJvbCwgZS5nLiBBQVBMIGZvciBBcHBsZSBJbmMuXCJcbiAgICogICAgICAgICB9XG4gICAqICAgICAgIH0sXG4gICAqICAgICAgIFwicmVxdWlyZWRcIjogW1widGlja2VyXCJdXG4gICAqICAgICB9XG4gICAqICAgfVxuICAgKiBdXG4gICAqIGBgYFxuICAgKlxuICAgKiBBbmQgdGhlbiBhc2tlZCB0aGUgbW9kZWwgXCJXaGF0J3MgdGhlIFMmUCA1MDAgYXQgdG9kYXk/XCIsIHRoZSBtb2RlbCBtaWdodCBwcm9kdWNlXG4gICAqIGB0b29sX3VzZWAgY29udGVudCBibG9ja3MgaW4gdGhlIHJlc3BvbnNlIGxpa2UgdGhpczpcbiAgICpcbiAgICogYGBganNvblxuICAgKiBbXG4gICAqICAge1xuICAgKiAgICAgXCJ0eXBlXCI6IFwidG9vbF91c2VcIixcbiAgICogICAgIFwiaWRcIjogXCJ0b29sdV8wMUQ3RkxyZmg0R1lxN3lUMVVMRmV5TVZcIixcbiAgICogICAgIFwibmFtZVwiOiBcImdldF9zdG9ja19wcmljZVwiLFxuICAgKiAgICAgXCJpbnB1dFwiOiB7IFwidGlja2VyXCI6IFwiXkdTUENcIiB9XG4gICAqICAgfVxuICAgKiBdXG4gICAqIGBgYFxuICAgKlxuICAgKiBZb3UgbWlnaHQgdGhlbiBydW4geW91ciBgZ2V0X3N0b2NrX3ByaWNlYCB0b29sIHdpdGggYHtcInRpY2tlclwiOiBcIl5HU1BDXCJ9YCBhcyBhblxuICAgKiBpbnB1dCwgYW5kIHJldHVybiB0aGUgZm9sbG93aW5nIGJhY2sgdG8gdGhlIG1vZGVsIGluIGEgc3Vic2VxdWVudCBgdXNlcmBcbiAgICogbWVzc2FnZTpcbiAgICpcbiAgICogYGBganNvblxuICAgKiBbXG4gICAqICAge1xuICAgKiAgICAgXCJ0eXBlXCI6IFwidG9vbF9yZXN1bHRcIixcbiAgICogICAgIFwidG9vbF91c2VfaWRcIjogXCJ0b29sdV8wMUQ3RkxyZmg0R1lxN3lUMVVMRmV5TVZcIixcbiAgICogICAgIFwiY29udGVudFwiOiBcIjI1OS43NSBVU0RcIlxuICAgKiAgIH1cbiAgICogXVxuICAgKiBgYGBcbiAgICpcbiAgICogVG9vbHMgY2FuIGJlIHVzZWQgZm9yIHdvcmtmbG93cyB0aGF0IGluY2x1ZGUgcnVubmluZyBjbGllbnQtc2lkZSB0b29scyBhbmRcbiAgICogZnVuY3Rpb25zLCBvciBtb3JlIGdlbmVyYWxseSB3aGVuZXZlciB5b3Ugd2FudCB0aGUgbW9kZWwgdG8gcHJvZHVjZSBhIHBhcnRpY3VsYXJcbiAgICogSlNPTiBzdHJ1Y3R1cmUgb2Ygb3V0cHV0LlxuICAgKlxuICAgKiBTZWUgb3VyIFtndWlkZV0oaHR0cHM6Ly9kb2NzLmFudGhyb3BpYy5jb20vZW4vZG9jcy90b29sLXVzZSkgZm9yIG1vcmUgZGV0YWlscy5cbiAgICovXG4gIHRvb2xzPzogQXJyYXk8VG9vbD47XG5cbiAgLyoqXG4gICAqIE9ubHkgc2FtcGxlIGZyb20gdGhlIHRvcCBLIG9wdGlvbnMgZm9yIGVhY2ggc3Vic2VxdWVudCB0b2tlbi5cbiAgICpcbiAgICogVXNlZCB0byByZW1vdmUgXCJsb25nIHRhaWxcIiBsb3cgcHJvYmFiaWxpdHkgcmVzcG9uc2VzLlxuICAgKiBbTGVhcm4gbW9yZSB0ZWNobmljYWwgZGV0YWlscyBoZXJlXShodHRwczovL3Rvd2FyZHNkYXRhc2NpZW5jZS5jb20vaG93LXRvLXNhbXBsZS1mcm9tLWxhbmd1YWdlLW1vZGVscy02ODJiY2ViOTcyNzcpLlxuICAgKlxuICAgKiBSZWNvbW1lbmRlZCBmb3IgYWR2YW5jZWQgdXNlIGNhc2VzIG9ubHkuIFlvdSB1c3VhbGx5IG9ubHkgbmVlZCB0byB1c2VcbiAgICogYHRlbXBlcmF0dXJlYC5cbiAgICovXG4gIHRvcF9rPzogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBVc2UgbnVjbGV1cyBzYW1wbGluZy5cbiAgICpcbiAgICogSW4gbnVjbGV1cyBzYW1wbGluZywgd2UgY29tcHV0ZSB0aGUgY3VtdWxhdGl2ZSBkaXN0cmlidXRpb24gb3ZlciBhbGwgdGhlIG9wdGlvbnNcbiAgICogZm9yIGVhY2ggc3Vic2VxdWVudCB0b2tlbiBpbiBkZWNyZWFzaW5nIHByb2JhYmlsaXR5IG9yZGVyIGFuZCBjdXQgaXQgb2ZmIG9uY2UgaXRcbiAgICogcmVhY2hlcyBhIHBhcnRpY3VsYXIgcHJvYmFiaWxpdHkgc3BlY2lmaWVkIGJ5IGB0b3BfcGAuIFlvdSBzaG91bGQgZWl0aGVyIGFsdGVyXG4gICAqIGB0ZW1wZXJhdHVyZWAgb3IgYHRvcF9wYCwgYnV0IG5vdCBib3RoLlxuICAgKlxuICAgKiBSZWNvbW1lbmRlZCBmb3IgYWR2YW5jZWQgdXNlIGNhc2VzIG9ubHkuIFlvdSB1c3VhbGx5IG9ubHkgbmVlZCB0byB1c2VcbiAgICogYHRlbXBlcmF0dXJlYC5cbiAgICovXG4gIHRvcF9wPzogbnVtYmVyO1xufVxuXG5leHBvcnQgbmFtZXNwYWNlIE1lc3NhZ2VDcmVhdGVQYXJhbXMge1xuICAvKipcbiAgICogQW4gb2JqZWN0IGRlc2NyaWJpbmcgbWV0YWRhdGEgYWJvdXQgdGhlIHJlcXVlc3QuXG4gICAqL1xuICBleHBvcnQgaW50ZXJmYWNlIE1ldGFkYXRhIHtcbiAgICAvKipcbiAgICAgKiBBbiBleHRlcm5hbCBpZGVudGlmaWVyIGZvciB0aGUgdXNlciB3aG8gaXMgYXNzb2NpYXRlZCB3aXRoIHRoZSByZXF1ZXN0LlxuICAgICAqXG4gICAgICogVGhpcyBzaG91bGQgYmUgYSB1dWlkLCBoYXNoIHZhbHVlLCBvciBvdGhlciBvcGFxdWUgaWRlbnRpZmllci4gQW50aHJvcGljIG1heSB1c2VcbiAgICAgKiB0aGlzIGlkIHRvIGhlbHAgZGV0ZWN0IGFidXNlLiBEbyBub3QgaW5jbHVkZSBhbnkgaWRlbnRpZnlpbmcgaW5mb3JtYXRpb24gc3VjaCBhc1xuICAgICAqIG5hbWUsIGVtYWlsIGFkZHJlc3MsIG9yIHBob25lIG51bWJlci5cbiAgICAgKi9cbiAgICB1c2VyX2lkPzogc3RyaW5nIHwgbnVsbDtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGUgbW9kZWwgd2lsbCBhdXRvbWF0aWNhbGx5IGRlY2lkZSB3aGV0aGVyIHRvIHVzZSB0b29scy5cbiAgICovXG4gIGV4cG9ydCBpbnRlcmZhY2UgVG9vbENob2ljZUF1dG8ge1xuICAgIHR5cGU6ICdhdXRvJztcblxuICAgIC8qKlxuICAgICAqIFdoZXRoZXIgdG8gZGlzYWJsZSBwYXJhbGxlbCB0b29sIHVzZS5cbiAgICAgKlxuICAgICAqIERlZmF1bHRzIHRvIGBmYWxzZWAuIElmIHNldCB0byBgdHJ1ZWAsIHRoZSBtb2RlbCB3aWxsIG91dHB1dCBhdCBtb3N0IG9uZSB0b29sXG4gICAgICogdXNlLlxuICAgICAqL1xuICAgIGRpc2FibGVfcGFyYWxsZWxfdG9vbF91c2U/OiBib29sZWFuO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoZSBtb2RlbCB3aWxsIHVzZSBhbnkgYXZhaWxhYmxlIHRvb2xzLlxuICAgKi9cbiAgZXhwb3J0IGludGVyZmFjZSBUb29sQ2hvaWNlQW55IHtcbiAgICB0eXBlOiAnYW55JztcblxuICAgIC8qKlxuICAgICAqIFdoZXRoZXIgdG8gZGlzYWJsZSBwYXJhbGxlbCB0b29sIHVzZS5cbiAgICAgKlxuICAgICAqIERlZmF1bHRzIHRvIGBmYWxzZWAuIElmIHNldCB0byBgdHJ1ZWAsIHRoZSBtb2RlbCB3aWxsIG91dHB1dCBleGFjdGx5IG9uZSB0b29sXG4gICAgICogdXNlLlxuICAgICAqL1xuICAgIGRpc2FibGVfcGFyYWxsZWxfdG9vbF91c2U/OiBib29sZWFuO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoZSBtb2RlbCB3aWxsIHVzZSB0aGUgc3BlY2lmaWVkIHRvb2wgd2l0aCBgdG9vbF9jaG9pY2UubmFtZWAuXG4gICAqL1xuICBleHBvcnQgaW50ZXJmYWNlIFRvb2xDaG9pY2VUb29sIHtcbiAgICAvKipcbiAgICAgKiBUaGUgbmFtZSBvZiB0aGUgdG9vbCB0byB1c2UuXG4gICAgICovXG4gICAgbmFtZTogc3RyaW5nO1xuXG4gICAgdHlwZTogJ3Rvb2wnO1xuXG4gICAgLyoqXG4gICAgICogV2hldGhlciB0byBkaXNhYmxlIHBhcmFsbGVsIHRvb2wgdXNlLlxuICAgICAqXG4gICAgICogRGVmYXVsdHMgdG8gYGZhbHNlYC4gSWYgc2V0IHRvIGB0cnVlYCwgdGhlIG1vZGVsIHdpbGwgb3V0cHV0IGV4YWN0bHkgb25lIHRvb2xcbiAgICAgKiB1c2UuXG4gICAgICovXG4gICAgZGlzYWJsZV9wYXJhbGxlbF90b29sX3VzZT86IGJvb2xlYW47XG4gIH1cblxuICBleHBvcnQgdHlwZSBNZXNzYWdlQ3JlYXRlUGFyYW1zTm9uU3RyZWFtaW5nID0gTWVzc2FnZXNBUEkuTWVzc2FnZUNyZWF0ZVBhcmFtc05vblN0cmVhbWluZztcbiAgZXhwb3J0IHR5cGUgTWVzc2FnZUNyZWF0ZVBhcmFtc1N0cmVhbWluZyA9IE1lc3NhZ2VzQVBJLk1lc3NhZ2VDcmVhdGVQYXJhbXNTdHJlYW1pbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWVzc2FnZUNyZWF0ZVBhcmFtc05vblN0cmVhbWluZyBleHRlbmRzIE1lc3NhZ2VDcmVhdGVQYXJhbXNCYXNlIHtcbiAgLyoqXG4gICAqIFdoZXRoZXIgdG8gaW5jcmVtZW50YWxseSBzdHJlYW0gdGhlIHJlc3BvbnNlIHVzaW5nIHNlcnZlci1zZW50IGV2ZW50cy5cbiAgICpcbiAgICogU2VlIFtzdHJlYW1pbmddKGh0dHBzOi8vZG9jcy5hbnRocm9waWMuY29tL2VuL2FwaS9tZXNzYWdlcy1zdHJlYW1pbmcpIGZvclxuICAgKiBkZXRhaWxzLlxuICAgKi9cbiAgc3RyZWFtPzogZmFsc2U7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWVzc2FnZUNyZWF0ZVBhcmFtc1N0cmVhbWluZyBleHRlbmRzIE1lc3NhZ2VDcmVhdGVQYXJhbXNCYXNlIHtcbiAgLyoqXG4gICAqIFdoZXRoZXIgdG8gaW5jcmVtZW50YWxseSBzdHJlYW0gdGhlIHJlc3BvbnNlIHVzaW5nIHNlcnZlci1zZW50IGV2ZW50cy5cbiAgICpcbiAgICogU2VlIFtzdHJlYW1pbmddKGh0dHBzOi8vZG9jcy5hbnRocm9waWMuY29tL2VuL2FwaS9tZXNzYWdlcy1zdHJlYW1pbmcpIGZvclxuICAgKiBkZXRhaWxzLlxuICAgKi9cbiAgc3RyZWFtOiB0cnVlO1xufVxuXG5leHBvcnQgdHlwZSBNZXNzYWdlU3RyZWFtUGFyYW1zID0gTWVzc2FnZUNyZWF0ZVBhcmFtc0Jhc2U7XG5cbmV4cG9ydCBuYW1lc3BhY2UgTWVzc2FnZXMge1xuICBleHBvcnQgaW1wb3J0IENvbnRlbnRCbG9jayA9IE1lc3NhZ2VzQVBJLkNvbnRlbnRCbG9jaztcbiAgZXhwb3J0IGltcG9ydCBDb250ZW50QmxvY2tEZWx0YUV2ZW50ID0gTWVzc2FnZXNBUEkuQ29udGVudEJsb2NrRGVsdGFFdmVudDtcbiAgZXhwb3J0IGltcG9ydCBDb250ZW50QmxvY2tTdGFydEV2ZW50ID0gTWVzc2FnZXNBUEkuQ29udGVudEJsb2NrU3RhcnRFdmVudDtcbiAgZXhwb3J0IGltcG9ydCBDb250ZW50QmxvY2tTdG9wRXZlbnQgPSBNZXNzYWdlc0FQSS5Db250ZW50QmxvY2tTdG9wRXZlbnQ7XG4gIGV4cG9ydCBpbXBvcnQgSW1hZ2VCbG9ja1BhcmFtID0gTWVzc2FnZXNBUEkuSW1hZ2VCbG9ja1BhcmFtO1xuICBleHBvcnQgaW1wb3J0IElucHV0Skpzb25EZWx0YSA9IE1lc3NhZ2VzQVBJLklucHV0SnNvbkRlbHRhO1xuICBleHBvcnQgaW1wb3J0IElucHV0SlNPTkRlbHRhID0gTWVzc2FnZXNBUEkuSW5wdXRKU09ORGVsdGE7XG4gIGV4cG9ydCBpbXBvcnQgTWVzc2FnZSA9IE1lc3NhZ2VzQVBJLk1lc3NhZ2U7XG4gIGV4cG9ydCBpbXBvcnQgTWVzc2FnZURlbHRhRXZlbnQgPSBNZXNzYWdlc0FQSS5NZXNzYWdlRGVsdGFFdmVudDtcbiAgZXhwb3J0IGltcG9ydCBNZXNzYWdlRGVsdGFVc2FnZSA9IE1lc3NhZ2VzQVBJLk1lc3NhZ2VEZWx0YVVzYWdlO1xuICBleHBvcnQgaW1wb3J0IE1lc3NhZ2VQYXJhbSA9IE1lc3NhZ2VzQVBJLk1lc3NhZ2VQYXJhbTtcbiAgZXhwb3J0IGltcG9ydCBNZXNzYWdlU3RhcnRFdmVudCA9IE1lc3NhZ2VzQVBJLk1lc3NhZ2VTdGFydEV2ZW50O1xuICBleHBvcnQgaW1wb3J0IE1lc3NhZ2VTdG9wRXZlbnQgPSBNZXNzYWdlc0FQSS5NZXNzYWdlU3RvcEV2ZW50O1xuICBleHBvcnQgaW1wb3J0IE1lc3NhZ2VTdHJlYW1FdmVudCA9IE1lc3NhZ2VzQVBJLk1lc3NhZ2VTdHJlYW1FdmVudDtcbiAgZXhwb3J0IGltcG9ydCBNb2RlbCA9IE1lc3NhZ2VzQVBJLk1vZGVsO1xuICBleHBvcnQgaW1wb3J0IFJhd0NvbnRlbnRCbG9ja0RlbHRhRXZlbnQgPSBNZXNzYWdlc0FQSS5SYXdDb250ZW50QmxvY2tEZWx0YUV2ZW50O1xuICBleHBvcnQgaW1wb3J0IFJhd0NvbnRlbnRCbG9ja1N0YXJ0RXZlbnQgPSBNZXNzYWdlc0FQSS5SYXdDb250ZW50QmxvY2tTdGFydEV2ZW50O1xuICBleHBvcnQgaW1wb3J0IFJhd0NvbnRlbnRCbG9ja1N0b3BFdmVudCA9IE1lc3NhZ2VzQVBJLlJhd0NvbnRlbnRCbG9ja1N0b3BFdmVudDtcbiAgZXhwb3J0IGltcG9ydCBSYXdNZXNzYWdlRGVsdGFFdmVudCA9IE1lc3NhZ2VzQVBJLlJhd01lc3NhZ2VEZWx0YUV2ZW50O1xuICBleHBvcnQgaW1wb3J0IFJhd01lc3NhZ2VTdGFydEV2ZW50ID0gTWVzc2FnZXNBUEkuUmF3TWVzc2FnZVN0YXJ0RXZlbnQ7XG4gIGV4cG9ydCBpbXBvcnQgUmF3TWVzc2FnZVN0b3BFdmVudCA9IE1lc3NhZ2VzQVBJLlJhd01lc3NhZ2VTdG9wRXZlbnQ7XG4gIGV4cG9ydCBpbXBvcnQgUmF3TWVzc2FnZVN0cmVhbUV2ZW50ID0gTWVzc2FnZXNBUEkuUmF3TWVzc2FnZVN0cmVhbUV2ZW50O1xuICBleHBvcnQgaW1wb3J0IFRleHRCbG9jayA9IE1lc3NhZ2VzQVBJLlRleHRCbG9jaztcbiAgZXhwb3J0IGltcG9ydCBUZXh0QmxvY2tQYXJhbSA9IE1lc3NhZ2VzQVBJLlRleHRCbG9ja1BhcmFtO1xuICBleHBvcnQgaW1wb3J0IFRleHREZWx0YSA9IE1lc3NhZ2VzQVBJLlRleHREZWx0YTtcbiAgZXhwb3J0IGltcG9ydCBUb29sID0gTWVzc2FnZXNBUEkuVG9vbDtcbiAgZXhwb3J0IGltcG9ydCBUb29sUmVzdWx0QmxvY2tQYXJhbSA9IE1lc3NhZ2VzQVBJLlRvb2xSZXN1bHRCbG9ja1BhcmFtO1xuICBleHBvcnQgaW1wb3J0IFRvb2xVc2VCbG9jayA9IE1lc3NhZ2VzQVBJLlRvb2xVc2VCbG9jaztcbiAgZXhwb3J0IGltcG9ydCBUb29sVXNlQmxvY2tQYXJhbSA9IE1lc3NhZ2VzQVBJLlRvb2xVc2VCbG9ja1BhcmFtO1xuICBleHBvcnQgaW1wb3J0IFVzYWdlID0gTWVzc2FnZXNBUEkuVXNhZ2U7XG4gIGV4cG9ydCBpbXBvcnQgTWVzc2FnZUNyZWF0ZVBhcmFtcyA9IE1lc3NhZ2VzQVBJLk1lc3NhZ2VDcmVhdGVQYXJhbXM7XG4gIGV4cG9ydCBpbXBvcnQgTWVzc2FnZUNyZWF0ZVBhcmFtc05vblN0cmVhbWluZyA9IE1lc3NhZ2VzQVBJLk1lc3NhZ2VDcmVhdGVQYXJhbXNOb25TdHJlYW1pbmc7XG4gIGV4cG9ydCBpbXBvcnQgTWVzc2FnZUNyZWF0ZVBhcmFtc1N0cmVhbWluZyA9IE1lc3NhZ2VzQVBJLk1lc3NhZ2VDcmVhdGVQYXJhbXNTdHJlYW1pbmc7XG4gIGV4cG9ydCBpbXBvcnQgTWVzc2FnZVN0cmVhbVBhcmFtcyA9IE1lc3NhZ2VzQVBJLk1lc3NhZ2VTdHJlYW1QYXJhbXM7XG59XG4iLCAiZXhwb3J0IGRlZmF1bHQgY3J5cHRvO1xuZXhwb3J0IGNvbnN0IGlzQ3J5cHRvS2V5ID0gKGtleSkgPT4ga2V5IGluc3RhbmNlb2YgQ3J5cHRvS2V5O1xuIiwgImltcG9ydCBkaWdlc3QgZnJvbSAnLi4vcnVudGltZS9kaWdlc3QuanMnO1xuZXhwb3J0IGNvbnN0IGVuY29kZXIgPSBuZXcgVGV4dEVuY29kZXIoKTtcbmV4cG9ydCBjb25zdCBkZWNvZGVyID0gbmV3IFRleHREZWNvZGVyKCk7XG5jb25zdCBNQVhfSU5UMzIgPSAyICoqIDMyO1xuZXhwb3J0IGZ1bmN0aW9uIGNvbmNhdCguLi5idWZmZXJzKSB7XG4gICAgY29uc3Qgc2l6ZSA9IGJ1ZmZlcnMucmVkdWNlKChhY2MsIHsgbGVuZ3RoIH0pID0+IGFjYyArIGxlbmd0aCwgMCk7XG4gICAgY29uc3QgYnVmID0gbmV3IFVpbnQ4QXJyYXkoc2l6ZSk7XG4gICAgbGV0IGkgPSAwO1xuICAgIGZvciAoY29uc3QgYnVmZmVyIG9mIGJ1ZmZlcnMpIHtcbiAgICAgICAgYnVmLnNldChidWZmZXIsIGkpO1xuICAgICAgICBpICs9IGJ1ZmZlci5sZW5ndGg7XG4gICAgfVxuICAgIHJldHVybiBidWY7XG59XG5leHBvcnQgZnVuY3Rpb24gcDJzKGFsZywgcDJzSW5wdXQpIHtcbiAgICByZXR1cm4gY29uY2F0KGVuY29kZXIuZW5jb2RlKGFsZyksIG5ldyBVaW50OEFycmF5KFswXSksIHAyc0lucHV0KTtcbn1cbmZ1bmN0aW9uIHdyaXRlVUludDMyQkUoYnVmLCB2YWx1ZSwgb2Zmc2V0KSB7XG4gICAgaWYgKHZhbHVlIDwgMCB8fCB2YWx1ZSA+PSBNQVhfSU5UMzIpIHtcbiAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoYHZhbHVlIG11c3QgYmUgPj0gMCBhbmQgPD0gJHtNQVhfSU5UMzIgLSAxfS4gUmVjZWl2ZWQgJHt2YWx1ZX1gKTtcbiAgICB9XG4gICAgYnVmLnNldChbdmFsdWUgPj4+IDI0LCB2YWx1ZSA+Pj4gMTYsIHZhbHVlID4+PiA4LCB2YWx1ZSAmIDB4ZmZdLCBvZmZzZXQpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHVpbnQ2NGJlKHZhbHVlKSB7XG4gICAgY29uc3QgaGlnaCA9IE1hdGguZmxvb3IodmFsdWUgLyBNQVhfSU5UMzIpO1xuICAgIGNvbnN0IGxvdyA9IHZhbHVlICUgTUFYX0lOVDMyO1xuICAgIGNvbnN0IGJ1ZiA9IG5ldyBVaW50OEFycmF5KDgpO1xuICAgIHdyaXRlVUludDMyQkUoYnVmLCBoaWdoLCAwKTtcbiAgICB3cml0ZVVJbnQzMkJFKGJ1ZiwgbG93LCA0KTtcbiAgICByZXR1cm4gYnVmO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHVpbnQzMmJlKHZhbHVlKSB7XG4gICAgY29uc3QgYnVmID0gbmV3IFVpbnQ4QXJyYXkoNCk7XG4gICAgd3JpdGVVSW50MzJCRShidWYsIHZhbHVlKTtcbiAgICByZXR1cm4gYnVmO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGxlbmd0aEFuZElucHV0KGlucHV0KSB7XG4gICAgcmV0dXJuIGNvbmNhdCh1aW50MzJiZShpbnB1dC5sZW5ndGgpLCBpbnB1dCk7XG59XG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gY29uY2F0S2RmKHNlY3JldCwgYml0cywgdmFsdWUpIHtcbiAgICBjb25zdCBpdGVyYXRpb25zID0gTWF0aC5jZWlsKChiaXRzID4+IDMpIC8gMzIpO1xuICAgIGNvbnN0IHJlcyA9IG5ldyBVaW50OEFycmF5KGl0ZXJhdGlvbnMgKiAzMik7XG4gICAgZm9yIChsZXQgaXRlciA9IDA7IGl0ZXIgPCBpdGVyYXRpb25zOyBpdGVyKyspIHtcbiAgICAgICAgY29uc3QgYnVmID0gbmV3IFVpbnQ4QXJyYXkoNCArIHNlY3JldC5sZW5ndGggKyB2YWx1ZS5sZW5ndGgpO1xuICAgICAgICBidWYuc2V0KHVpbnQzMmJlKGl0ZXIgKyAxKSk7XG4gICAgICAgIGJ1Zi5zZXQoc2VjcmV0LCA0KTtcbiAgICAgICAgYnVmLnNldCh2YWx1ZSwgNCArIHNlY3JldC5sZW5ndGgpO1xuICAgICAgICByZXMuc2V0KGF3YWl0IGRpZ2VzdCgnc2hhMjU2JywgYnVmKSwgaXRlciAqIDMyKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlcy5zbGljZSgwLCBiaXRzID4+IDMpO1xufVxuIiwgImltcG9ydCB7IGVuY29kZXIsIGRlY29kZXIgfSBmcm9tICcuLi9saWIvYnVmZmVyX3V0aWxzLmpzJztcbmV4cG9ydCBjb25zdCBlbmNvZGVCYXNlNjQgPSAoaW5wdXQpID0+IHtcbiAgICBsZXQgdW5lbmNvZGVkID0gaW5wdXQ7XG4gICAgaWYgKHR5cGVvZiB1bmVuY29kZWQgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIHVuZW5jb2RlZCA9IGVuY29kZXIuZW5jb2RlKHVuZW5jb2RlZCk7XG4gICAgfVxuICAgIGNvbnN0IENIVU5LX1NJWkUgPSAweDgwMDA7XG4gICAgY29uc3QgYXJyID0gW107XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB1bmVuY29kZWQubGVuZ3RoOyBpICs9IENIVU5LX1NJWkUpIHtcbiAgICAgICAgYXJyLnB1c2goU3RyaW5nLmZyb21DaGFyQ29kZS5hcHBseShudWxsLCB1bmVuY29kZWQuc3ViYXJyYXkoaSwgaSArIENIVU5LX1NJWkUpKSk7XG4gICAgfVxuICAgIHJldHVybiBidG9hKGFyci5qb2luKCcnKSk7XG59O1xuZXhwb3J0IGNvbnN0IGVuY29kZSA9IChpbnB1dCkgPT4ge1xuICAgIHJldHVybiBlbmNvZGVCYXNlNjQoaW5wdXQpLnJlcGxhY2UoLz0vZywgJycpLnJlcGxhY2UoL1xcKy9nLCAnLScpLnJlcGxhY2UoL1xcLy9nLCAnXycpO1xufTtcbmV4cG9ydCBjb25zdCBkZWNvZGVCYXNlNjQgPSAoZW5jb2RlZCkgPT4ge1xuICAgIGNvbnN0IGJpbmFyeSA9IGF0b2IoZW5jb2RlZCk7XG4gICAgY29uc3QgYnl0ZXMgPSBuZXcgVWludDhBcnJheShiaW5hcnkubGVuZ3RoKTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGJpbmFyeS5sZW5ndGg7IGkrKykge1xuICAgICAgICBieXRlc1tpXSA9IGJpbmFyeS5jaGFyQ29kZUF0KGkpO1xuICAgIH1cbiAgICByZXR1cm4gYnl0ZXM7XG59O1xuZXhwb3J0IGNvbnN0IGRlY29kZSA9IChpbnB1dCkgPT4ge1xuICAgIGxldCBlbmNvZGVkID0gaW5wdXQ7XG4gICAgaWYgKGVuY29kZWQgaW5zdGFuY2VvZiBVaW50OEFycmF5KSB7XG4gICAgICAgIGVuY29kZWQgPSBkZWNvZGVyLmRlY29kZShlbmNvZGVkKTtcbiAgICB9XG4gICAgZW5jb2RlZCA9IGVuY29kZWQucmVwbGFjZSgvLS9nLCAnKycpLnJlcGxhY2UoL18vZywgJy8nKS5yZXBsYWNlKC9cXHMvZywgJycpO1xuICAgIHRyeSB7XG4gICAgICAgIHJldHVybiBkZWNvZGVCYXNlNjQoZW5jb2RlZCk7XG4gICAgfVxuICAgIGNhdGNoIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignVGhlIGlucHV0IHRvIGJlIGRlY29kZWQgaXMgbm90IGNvcnJlY3RseSBlbmNvZGVkLicpO1xuICAgIH1cbn07XG4iLCAiZXhwb3J0IGNsYXNzIEpPU0VFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgICBzdGF0aWMgZ2V0IGNvZGUoKSB7XG4gICAgICAgIHJldHVybiAnRVJSX0pPU0VfR0VORVJJQyc7XG4gICAgfVxuICAgIGNvbnN0cnVjdG9yKG1lc3NhZ2UpIHtcbiAgICAgICAgc3VwZXIobWVzc2FnZSk7XG4gICAgICAgIHRoaXMuY29kZSA9ICdFUlJfSk9TRV9HRU5FUklDJztcbiAgICAgICAgdGhpcy5uYW1lID0gdGhpcy5jb25zdHJ1Y3Rvci5uYW1lO1xuICAgICAgICBFcnJvci5jYXB0dXJlU3RhY2tUcmFjZT8uKHRoaXMsIHRoaXMuY29uc3RydWN0b3IpO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBKV1RDbGFpbVZhbGlkYXRpb25GYWlsZWQgZXh0ZW5kcyBKT1NFRXJyb3Ige1xuICAgIHN0YXRpYyBnZXQgY29kZSgpIHtcbiAgICAgICAgcmV0dXJuICdFUlJfSldUX0NMQUlNX1ZBTElEQVRJT05fRkFJTEVEJztcbiAgICB9XG4gICAgY29uc3RydWN0b3IobWVzc2FnZSwgcGF5bG9hZCwgY2xhaW0gPSAndW5zcGVjaWZpZWQnLCByZWFzb24gPSAndW5zcGVjaWZpZWQnKSB7XG4gICAgICAgIHN1cGVyKG1lc3NhZ2UpO1xuICAgICAgICB0aGlzLmNvZGUgPSAnRVJSX0pXVF9DTEFJTV9WQUxJREFUSU9OX0ZBSUxFRCc7XG4gICAgICAgIHRoaXMuY2xhaW0gPSBjbGFpbTtcbiAgICAgICAgdGhpcy5yZWFzb24gPSByZWFzb247XG4gICAgICAgIHRoaXMucGF5bG9hZCA9IHBheWxvYWQ7XG4gICAgfVxufVxuZXhwb3J0IGNsYXNzIEpXVEV4cGlyZWQgZXh0ZW5kcyBKT1NFRXJyb3Ige1xuICAgIHN0YXRpYyBnZXQgY29kZSgpIHtcbiAgICAgICAgcmV0dXJuICdFUlJfSldUX0VYUElSRUQnO1xuICAgIH1cbiAgICBjb25zdHJ1Y3RvcihtZXNzYWdlLCBwYXlsb2FkLCBjbGFpbSA9ICd1bnNwZWNpZmllZCcsIHJlYXNvbiA9ICd1bnNwZWNpZmllZCcpIHtcbiAgICAgICAgc3VwZXIobWVzc2FnZSk7XG4gICAgICAgIHRoaXMuY29kZSA9ICdFUlJfSldUX0VYUElSRUQnO1xuICAgICAgICB0aGlzLmNsYWltID0gY2xhaW07XG4gICAgICAgIHRoaXMucmVhc29uID0gcmVhc29uO1xuICAgICAgICB0aGlzLnBheWxvYWQgPSBwYXlsb2FkO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBKT1NFQWxnTm90QWxsb3dlZCBleHRlbmRzIEpPU0VFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMuY29kZSA9ICdFUlJfSk9TRV9BTEdfTk9UX0FMTE9XRUQnO1xuICAgIH1cbiAgICBzdGF0aWMgZ2V0IGNvZGUoKSB7XG4gICAgICAgIHJldHVybiAnRVJSX0pPU0VfQUxHX05PVF9BTExPV0VEJztcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgSk9TRU5vdFN1cHBvcnRlZCBleHRlbmRzIEpPU0VFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMuY29kZSA9ICdFUlJfSk9TRV9OT1RfU1VQUE9SVEVEJztcbiAgICB9XG4gICAgc3RhdGljIGdldCBjb2RlKCkge1xuICAgICAgICByZXR1cm4gJ0VSUl9KT1NFX05PVF9TVVBQT1JURUQnO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBKV0VEZWNyeXB0aW9uRmFpbGVkIGV4dGVuZHMgSk9TRUVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5jb2RlID0gJ0VSUl9KV0VfREVDUllQVElPTl9GQUlMRUQnO1xuICAgICAgICB0aGlzLm1lc3NhZ2UgPSAnZGVjcnlwdGlvbiBvcGVyYXRpb24gZmFpbGVkJztcbiAgICB9XG4gICAgc3RhdGljIGdldCBjb2RlKCkge1xuICAgICAgICByZXR1cm4gJ0VSUl9KV0VfREVDUllQVElPTl9GQUlMRUQnO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBKV0VJbnZhbGlkIGV4dGVuZHMgSk9TRUVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5jb2RlID0gJ0VSUl9KV0VfSU5WQUxJRCc7XG4gICAgfVxuICAgIHN0YXRpYyBnZXQgY29kZSgpIHtcbiAgICAgICAgcmV0dXJuICdFUlJfSldFX0lOVkFMSUQnO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBKV1NJbnZhbGlkIGV4dGVuZHMgSk9TRUVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5jb2RlID0gJ0VSUl9KV1NfSU5WQUxJRCc7XG4gICAgfVxuICAgIHN0YXRpYyBnZXQgY29kZSgpIHtcbiAgICAgICAgcmV0dXJuICdFUlJfSldTX0lOVkFMSUQnO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBKV1RJbnZhbGlkIGV4dGVuZHMgSk9TRUVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5jb2RlID0gJ0VSUl9KV1RfSU5WQUxJRCc7XG4gICAgfVxuICAgIHN0YXRpYyBnZXQgY29kZSgpIHtcbiAgICAgICAgcmV0dXJuICdFUlJfSldUX0lOVkFMSUQnO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBKV0tJbnZhbGlkIGV4dGVuZHMgSk9TRUVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5jb2RlID0gJ0VSUl9KV0tfSU5WQUxJRCc7XG4gICAgfVxuICAgIHN0YXRpYyBnZXQgY29kZSgpIHtcbiAgICAgICAgcmV0dXJuICdFUlJfSldLX0lOVkFMSUQnO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBKV0tTSW52YWxpZCBleHRlbmRzIEpPU0VFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMuY29kZSA9ICdFUlJfSldLU19JTlZBTElEJztcbiAgICB9XG4gICAgc3RhdGljIGdldCBjb2RlKCkge1xuICAgICAgICByZXR1cm4gJ0VSUl9KV0tTX0lOVkFMSUQnO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBKV0tTTm9NYXRjaGluZ0tleSBleHRlbmRzIEpPU0VFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMuY29kZSA9ICdFUlJfSldLU19OT19NQVRDSElOR19LRVknO1xuICAgICAgICB0aGlzLm1lc3NhZ2UgPSAnbm8gYXBwbGljYWJsZSBrZXkgZm91bmQgaW4gdGhlIEpTT04gV2ViIEtleSBTZXQnO1xuICAgIH1cbiAgICBzdGF0aWMgZ2V0IGNvZGUoKSB7XG4gICAgICAgIHJldHVybiAnRVJSX0pXS1NfTk9fTUFUQ0hJTkdfS0VZJztcbiAgICB9XG59XG5leHBvcnQgY2xhc3MgSldLU011bHRpcGxlTWF0Y2hpbmdLZXlzIGV4dGVuZHMgSk9TRUVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoLi4uYXJndW1lbnRzKTtcbiAgICAgICAgdGhpcy5jb2RlID0gJ0VSUl9KV0tTX01VTFRJUExFX01BVENISU5HX0tFWVMnO1xuICAgICAgICB0aGlzLm1lc3NhZ2UgPSAnbXVsdGlwbGUgbWF0Y2hpbmcga2V5cyBmb3VuZCBpbiB0aGUgSlNPTiBXZWIgS2V5IFNldCc7XG4gICAgfVxuICAgIHN0YXRpYyBnZXQgY29kZSgpIHtcbiAgICAgICAgcmV0dXJuICdFUlJfSldLU19NVUxUSVBMRV9NQVRDSElOR19LRVlTJztcbiAgICB9XG59XG5TeW1ib2wuYXN5bmNJdGVyYXRvcjtcbmV4cG9ydCBjbGFzcyBKV0tTVGltZW91dCBleHRlbmRzIEpPU0VFcnJvciB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgIHRoaXMuY29kZSA9ICdFUlJfSldLU19USU1FT1VUJztcbiAgICAgICAgdGhpcy5tZXNzYWdlID0gJ3JlcXVlc3QgdGltZWQgb3V0JztcbiAgICB9XG4gICAgc3RhdGljIGdldCBjb2RlKCkge1xuICAgICAgICByZXR1cm4gJ0VSUl9KV0tTX1RJTUVPVVQnO1xuICAgIH1cbn1cbmV4cG9ydCBjbGFzcyBKV1NTaWduYXR1cmVWZXJpZmljYXRpb25GYWlsZWQgZXh0ZW5kcyBKT1NFRXJyb3Ige1xuICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICBzdXBlciguLi5hcmd1bWVudHMpO1xuICAgICAgICB0aGlzLmNvZGUgPSAnRVJSX0pXU19TSUdOQVRVUkVfVkVSSUZJQ0FUSU9OX0ZBSUxFRCc7XG4gICAgICAgIHRoaXMubWVzc2FnZSA9ICdzaWduYXR1cmUgdmVyaWZpY2F0aW9uIGZhaWxlZCc7XG4gICAgfVxuICAgIHN0YXRpYyBnZXQgY29kZSgpIHtcbiAgICAgICAgcmV0dXJuICdFUlJfSldTX1NJR05BVFVSRV9WRVJJRklDQVRJT05fRkFJTEVEJztcbiAgICB9XG59XG4iLCAiZnVuY3Rpb24gdW51c2FibGUobmFtZSwgcHJvcCA9ICdhbGdvcml0aG0ubmFtZScpIHtcbiAgICByZXR1cm4gbmV3IFR5cGVFcnJvcihgQ3J5cHRvS2V5IGRvZXMgbm90IHN1cHBvcnQgdGhpcyBvcGVyYXRpb24sIGl0cyAke3Byb3B9IG11c3QgYmUgJHtuYW1lfWApO1xufVxuZnVuY3Rpb24gaXNBbGdvcml0aG0oYWxnb3JpdGhtLCBuYW1lKSB7XG4gICAgcmV0dXJuIGFsZ29yaXRobS5uYW1lID09PSBuYW1lO1xufVxuZnVuY3Rpb24gZ2V0SGFzaExlbmd0aChoYXNoKSB7XG4gICAgcmV0dXJuIHBhcnNlSW50KGhhc2gubmFtZS5zbGljZSg0KSwgMTApO1xufVxuZnVuY3Rpb24gZ2V0TmFtZWRDdXJ2ZShhbGcpIHtcbiAgICBzd2l0Y2ggKGFsZykge1xuICAgICAgICBjYXNlICdFUzI1Nic6XG4gICAgICAgICAgICByZXR1cm4gJ1AtMjU2JztcbiAgICAgICAgY2FzZSAnRVMzODQnOlxuICAgICAgICAgICAgcmV0dXJuICdQLTM4NCc7XG4gICAgICAgIGNhc2UgJ0VTNTEyJzpcbiAgICAgICAgICAgIHJldHVybiAnUC01MjEnO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCd1bnJlYWNoYWJsZScpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGNoZWNrVXNhZ2Uoa2V5LCB1c2FnZXMpIHtcbiAgICBpZiAodXNhZ2VzLmxlbmd0aCAmJiAhdXNhZ2VzLnNvbWUoKGV4cGVjdGVkKSA9PiBrZXkudXNhZ2VzLmluY2x1ZGVzKGV4cGVjdGVkKSkpIHtcbiAgICAgICAgbGV0IG1zZyA9ICdDcnlwdG9LZXkgZG9lcyBub3Qgc3VwcG9ydCB0aGlzIG9wZXJhdGlvbiwgaXRzIHVzYWdlcyBtdXN0IGluY2x1ZGUgJztcbiAgICAgICAgaWYgKHVzYWdlcy5sZW5ndGggPiAyKSB7XG4gICAgICAgICAgICBjb25zdCBsYXN0ID0gdXNhZ2VzLnBvcCgpO1xuICAgICAgICAgICAgbXNnICs9IGBvbmUgb2YgJHt1c2FnZXMuam9pbignLCAnKX0sIG9yICR7bGFzdH0uYDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh1c2FnZXMubGVuZ3RoID09PSAyKSB7XG4gICAgICAgICAgICBtc2cgKz0gYG9uZSBvZiAke3VzYWdlc1swXX0gb3IgJHt1c2FnZXNbMV19LmA7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBtc2cgKz0gYCR7dXNhZ2VzWzBdfS5gO1xuICAgICAgICB9XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IobXNnKTtcbiAgICB9XG59XG5leHBvcnQgZnVuY3Rpb24gY2hlY2tTaWdDcnlwdG9LZXkoa2V5LCBhbGcsIC4uLnVzYWdlcykge1xuICAgIHN3aXRjaCAoYWxnKSB7XG4gICAgICAgIGNhc2UgJ0hTMjU2JzpcbiAgICAgICAgY2FzZSAnSFMzODQnOlxuICAgICAgICBjYXNlICdIUzUxMic6IHtcbiAgICAgICAgICAgIGlmICghaXNBbGdvcml0aG0oa2V5LmFsZ29yaXRobSwgJ0hNQUMnKSlcbiAgICAgICAgICAgICAgICB0aHJvdyB1bnVzYWJsZSgnSE1BQycpO1xuICAgICAgICAgICAgY29uc3QgZXhwZWN0ZWQgPSBwYXJzZUludChhbGcuc2xpY2UoMiksIDEwKTtcbiAgICAgICAgICAgIGNvbnN0IGFjdHVhbCA9IGdldEhhc2hMZW5ndGgoa2V5LmFsZ29yaXRobS5oYXNoKTtcbiAgICAgICAgICAgIGlmIChhY3R1YWwgIT09IGV4cGVjdGVkKVxuICAgICAgICAgICAgICAgIHRocm93IHVudXNhYmxlKGBTSEEtJHtleHBlY3RlZH1gLCAnYWxnb3JpdGhtLmhhc2gnKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGNhc2UgJ1JTMjU2JzpcbiAgICAgICAgY2FzZSAnUlMzODQnOlxuICAgICAgICBjYXNlICdSUzUxMic6IHtcbiAgICAgICAgICAgIGlmICghaXNBbGdvcml0aG0oa2V5LmFsZ29yaXRobSwgJ1JTQVNTQS1QS0NTMS12MV81JykpXG4gICAgICAgICAgICAgICAgdGhyb3cgdW51c2FibGUoJ1JTQVNTQS1QS0NTMS12MV81Jyk7XG4gICAgICAgICAgICBjb25zdCBleHBlY3RlZCA9IHBhcnNlSW50KGFsZy5zbGljZSgyKSwgMTApO1xuICAgICAgICAgICAgY29uc3QgYWN0dWFsID0gZ2V0SGFzaExlbmd0aChrZXkuYWxnb3JpdGhtLmhhc2gpO1xuICAgICAgICAgICAgaWYgKGFjdHVhbCAhPT0gZXhwZWN0ZWQpXG4gICAgICAgICAgICAgICAgdGhyb3cgdW51c2FibGUoYFNIQS0ke2V4cGVjdGVkfWAsICdhbGdvcml0aG0uaGFzaCcpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgY2FzZSAnUFMyNTYnOlxuICAgICAgICBjYXNlICdQUzM4NCc6XG4gICAgICAgIGNhc2UgJ1BTNTEyJzoge1xuICAgICAgICAgICAgaWYgKCFpc0FsZ29yaXRobShrZXkuYWxnb3JpdGhtLCAnUlNBLVBTUycpKVxuICAgICAgICAgICAgICAgIHRocm93IHVudXNhYmxlKCdSU0EtUFNTJyk7XG4gICAgICAgICAgICBjb25zdCBleHBlY3RlZCA9IHBhcnNlSW50KGFsZy5zbGljZSgyKSwgMTApO1xuICAgICAgICAgICAgY29uc3QgYWN0dWFsID0gZ2V0SGFzaExlbmd0aChrZXkuYWxnb3JpdGhtLmhhc2gpO1xuICAgICAgICAgICAgaWYgKGFjdHVhbCAhPT0gZXhwZWN0ZWQpXG4gICAgICAgICAgICAgICAgdGhyb3cgdW51c2FibGUoYFNIQS0ke2V4cGVjdGVkfWAsICdhbGdvcml0aG0uaGFzaCcpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgY2FzZSAnRWREU0EnOiB7XG4gICAgICAgICAgICBpZiAoa2V5LmFsZ29yaXRobS5uYW1lICE9PSAnRWQyNTUxOScgJiYga2V5LmFsZ29yaXRobS5uYW1lICE9PSAnRWQ0NDgnKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgdW51c2FibGUoJ0VkMjU1MTkgb3IgRWQ0NDgnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGNhc2UgJ0VTMjU2JzpcbiAgICAgICAgY2FzZSAnRVMzODQnOlxuICAgICAgICBjYXNlICdFUzUxMic6IHtcbiAgICAgICAgICAgIGlmICghaXNBbGdvcml0aG0oa2V5LmFsZ29yaXRobSwgJ0VDRFNBJykpXG4gICAgICAgICAgICAgICAgdGhyb3cgdW51c2FibGUoJ0VDRFNBJyk7XG4gICAgICAgICAgICBjb25zdCBleHBlY3RlZCA9IGdldE5hbWVkQ3VydmUoYWxnKTtcbiAgICAgICAgICAgIGNvbnN0IGFjdHVhbCA9IGtleS5hbGdvcml0aG0ubmFtZWRDdXJ2ZTtcbiAgICAgICAgICAgIGlmIChhY3R1YWwgIT09IGV4cGVjdGVkKVxuICAgICAgICAgICAgICAgIHRocm93IHVudXNhYmxlKGV4cGVjdGVkLCAnYWxnb3JpdGhtLm5hbWVkQ3VydmUnKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdDcnlwdG9LZXkgZG9lcyBub3Qgc3VwcG9ydCB0aGlzIG9wZXJhdGlvbicpO1xuICAgIH1cbiAgICBjaGVja1VzYWdlKGtleSwgdXNhZ2VzKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBjaGVja0VuY0NyeXB0b0tleShrZXksIGFsZywgLi4udXNhZ2VzKSB7XG4gICAgc3dpdGNoIChhbGcpIHtcbiAgICAgICAgY2FzZSAnQTEyOEdDTSc6XG4gICAgICAgIGNhc2UgJ0ExOTJHQ00nOlxuICAgICAgICBjYXNlICdBMjU2R0NNJzoge1xuICAgICAgICAgICAgaWYgKCFpc0FsZ29yaXRobShrZXkuYWxnb3JpdGhtLCAnQUVTLUdDTScpKVxuICAgICAgICAgICAgICAgIHRocm93IHVudXNhYmxlKCdBRVMtR0NNJyk7XG4gICAgICAgICAgICBjb25zdCBleHBlY3RlZCA9IHBhcnNlSW50KGFsZy5zbGljZSgxLCA0KSwgMTApO1xuICAgICAgICAgICAgY29uc3QgYWN0dWFsID0ga2V5LmFsZ29yaXRobS5sZW5ndGg7XG4gICAgICAgICAgICBpZiAoYWN0dWFsICE9PSBleHBlY3RlZClcbiAgICAgICAgICAgICAgICB0aHJvdyB1bnVzYWJsZShleHBlY3RlZCwgJ2FsZ29yaXRobS5sZW5ndGgnKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGNhc2UgJ0ExMjhLVyc6XG4gICAgICAgIGNhc2UgJ0ExOTJLVyc6XG4gICAgICAgIGNhc2UgJ0EyNTZLVyc6IHtcbiAgICAgICAgICAgIGlmICghaXNBbGdvcml0aG0oa2V5LmFsZ29yaXRobSwgJ0FFUy1LVycpKVxuICAgICAgICAgICAgICAgIHRocm93IHVudXNhYmxlKCdBRVMtS1cnKTtcbiAgICAgICAgICAgIGNvbnN0IGV4cGVjdGVkID0gcGFyc2VJbnQoYWxnLnNsaWNlKDEsIDQpLCAxMCk7XG4gICAgICAgICAgICBjb25zdCBhY3R1YWwgPSBrZXkuYWxnb3JpdGhtLmxlbmd0aDtcbiAgICAgICAgICAgIGlmIChhY3R1YWwgIT09IGV4cGVjdGVkKVxuICAgICAgICAgICAgICAgIHRocm93IHVudXNhYmxlKGV4cGVjdGVkLCAnYWxnb3JpdGhtLmxlbmd0aCcpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgY2FzZSAnRUNESCc6IHtcbiAgICAgICAgICAgIHN3aXRjaCAoa2V5LmFsZ29yaXRobS5uYW1lKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAnRUNESCc6XG4gICAgICAgICAgICAgICAgY2FzZSAnWDI1NTE5JzpcbiAgICAgICAgICAgICAgICBjYXNlICdYNDQ4JzpcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgdW51c2FibGUoJ0VDREgsIFgyNTUxOSwgb3IgWDQ0OCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgY2FzZSAnUEJFUzItSFMyNTYrQTEyOEtXJzpcbiAgICAgICAgY2FzZSAnUEJFUzItSFMzODQrQTE5MktXJzpcbiAgICAgICAgY2FzZSAnUEJFUzItSFM1MTIrQTI1NktXJzpcbiAgICAgICAgICAgIGlmICghaXNBbGdvcml0aG0oa2V5LmFsZ29yaXRobSwgJ1BCS0RGMicpKVxuICAgICAgICAgICAgICAgIHRocm93IHVudXNhYmxlKCdQQktERjInKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdSU0EtT0FFUCc6XG4gICAgICAgIGNhc2UgJ1JTQS1PQUVQLTI1Nic6XG4gICAgICAgIGNhc2UgJ1JTQS1PQUVQLTM4NCc6XG4gICAgICAgIGNhc2UgJ1JTQS1PQUVQLTUxMic6IHtcbiAgICAgICAgICAgIGlmICghaXNBbGdvcml0aG0oa2V5LmFsZ29yaXRobSwgJ1JTQS1PQUVQJykpXG4gICAgICAgICAgICAgICAgdGhyb3cgdW51c2FibGUoJ1JTQS1PQUVQJyk7XG4gICAgICAgICAgICBjb25zdCBleHBlY3RlZCA9IHBhcnNlSW50KGFsZy5zbGljZSg5KSwgMTApIHx8IDE7XG4gICAgICAgICAgICBjb25zdCBhY3R1YWwgPSBnZXRIYXNoTGVuZ3RoKGtleS5hbGdvcml0aG0uaGFzaCk7XG4gICAgICAgICAgICBpZiAoYWN0dWFsICE9PSBleHBlY3RlZClcbiAgICAgICAgICAgICAgICB0aHJvdyB1bnVzYWJsZShgU0hBLSR7ZXhwZWN0ZWR9YCwgJ2FsZ29yaXRobS5oYXNoJyk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignQ3J5cHRvS2V5IGRvZXMgbm90IHN1cHBvcnQgdGhpcyBvcGVyYXRpb24nKTtcbiAgICB9XG4gICAgY2hlY2tVc2FnZShrZXksIHVzYWdlcyk7XG59XG4iLCAiZnVuY3Rpb24gbWVzc2FnZShtc2csIGFjdHVhbCwgLi4udHlwZXMpIHtcbiAgICB0eXBlcyA9IHR5cGVzLmZpbHRlcihCb29sZWFuKTtcbiAgICBpZiAodHlwZXMubGVuZ3RoID4gMikge1xuICAgICAgICBjb25zdCBsYXN0ID0gdHlwZXMucG9wKCk7XG4gICAgICAgIG1zZyArPSBgb25lIG9mIHR5cGUgJHt0eXBlcy5qb2luKCcsICcpfSwgb3IgJHtsYXN0fS5gO1xuICAgIH1cbiAgICBlbHNlIGlmICh0eXBlcy5sZW5ndGggPT09IDIpIHtcbiAgICAgICAgbXNnICs9IGBvbmUgb2YgdHlwZSAke3R5cGVzWzBdfSBvciAke3R5cGVzWzFdfS5gO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgbXNnICs9IGBvZiB0eXBlICR7dHlwZXNbMF19LmA7XG4gICAgfVxuICAgIGlmIChhY3R1YWwgPT0gbnVsbCkge1xuICAgICAgICBtc2cgKz0gYCBSZWNlaXZlZCAke2FjdHVhbH1gO1xuICAgIH1cbiAgICBlbHNlIGlmICh0eXBlb2YgYWN0dWFsID09PSAnZnVuY3Rpb24nICYmIGFjdHVhbC5uYW1lKSB7XG4gICAgICAgIG1zZyArPSBgIFJlY2VpdmVkIGZ1bmN0aW9uICR7YWN0dWFsLm5hbWV9YDtcbiAgICB9XG4gICAgZWxzZSBpZiAodHlwZW9mIGFjdHVhbCA9PT0gJ29iamVjdCcgJiYgYWN0dWFsICE9IG51bGwpIHtcbiAgICAgICAgaWYgKGFjdHVhbC5jb25zdHJ1Y3Rvcj8ubmFtZSkge1xuICAgICAgICAgICAgbXNnICs9IGAgUmVjZWl2ZWQgYW4gaW5zdGFuY2Ugb2YgJHthY3R1YWwuY29uc3RydWN0b3IubmFtZX1gO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBtc2c7XG59XG5leHBvcnQgZGVmYXVsdCAoYWN0dWFsLCAuLi50eXBlcykgPT4ge1xuICAgIHJldHVybiBtZXNzYWdlKCdLZXkgbXVzdCBiZSAnLCBhY3R1YWwsIC4uLnR5cGVzKTtcbn07XG5leHBvcnQgZnVuY3Rpb24gd2l0aEFsZyhhbGcsIGFjdHVhbCwgLi4udHlwZXMpIHtcbiAgICByZXR1cm4gbWVzc2FnZShgS2V5IGZvciB0aGUgJHthbGd9IGFsZ29yaXRobSBtdXN0IGJlIGAsIGFjdHVhbCwgLi4udHlwZXMpO1xufVxuIiwgImltcG9ydCB7IGlzQ3J5cHRvS2V5IH0gZnJvbSAnLi93ZWJjcnlwdG8uanMnO1xuZXhwb3J0IGRlZmF1bHQgKGtleSkgPT4ge1xuICAgIGlmIChpc0NyeXB0b0tleShrZXkpKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4ga2V5Py5bU3ltYm9sLnRvU3RyaW5nVGFnXSA9PT0gJ0tleU9iamVjdCc7XG59O1xuZXhwb3J0IGNvbnN0IHR5cGVzID0gWydDcnlwdG9LZXknXTtcbiIsICJjb25zdCBpc0Rpc2pvaW50ID0gKC4uLmhlYWRlcnMpID0+IHtcbiAgICBjb25zdCBzb3VyY2VzID0gaGVhZGVycy5maWx0ZXIoQm9vbGVhbik7XG4gICAgaWYgKHNvdXJjZXMubGVuZ3RoID09PSAwIHx8IHNvdXJjZXMubGVuZ3RoID09PSAxKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBsZXQgYWNjO1xuICAgIGZvciAoY29uc3QgaGVhZGVyIG9mIHNvdXJjZXMpIHtcbiAgICAgICAgY29uc3QgcGFyYW1ldGVycyA9IE9iamVjdC5rZXlzKGhlYWRlcik7XG4gICAgICAgIGlmICghYWNjIHx8IGFjYy5zaXplID09PSAwKSB7XG4gICAgICAgICAgICBhY2MgPSBuZXcgU2V0KHBhcmFtZXRlcnMpO1xuICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChjb25zdCBwYXJhbWV0ZXIgb2YgcGFyYW1ldGVycykge1xuICAgICAgICAgICAgaWYgKGFjYy5oYXMocGFyYW1ldGVyKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGFjYy5hZGQocGFyYW1ldGVyKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbn07XG5leHBvcnQgZGVmYXVsdCBpc0Rpc2pvaW50O1xuIiwgImZ1bmN0aW9uIGlzT2JqZWN0TGlrZSh2YWx1ZSkge1xuICAgIHJldHVybiB0eXBlb2YgdmFsdWUgPT09ICdvYmplY3QnICYmIHZhbHVlICE9PSBudWxsO1xufVxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gaXNPYmplY3QoaW5wdXQpIHtcbiAgICBpZiAoIWlzT2JqZWN0TGlrZShpbnB1dCkgfHwgT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKGlucHV0KSAhPT0gJ1tvYmplY3QgT2JqZWN0XScpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpZiAoT2JqZWN0LmdldFByb3RvdHlwZU9mKGlucHV0KSA9PT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgbGV0IHByb3RvID0gaW5wdXQ7XG4gICAgd2hpbGUgKE9iamVjdC5nZXRQcm90b3R5cGVPZihwcm90bykgIT09IG51bGwpIHtcbiAgICAgICAgcHJvdG8gPSBPYmplY3QuZ2V0UHJvdG90eXBlT2YocHJvdG8pO1xuICAgIH1cbiAgICByZXR1cm4gT2JqZWN0LmdldFByb3RvdHlwZU9mKGlucHV0KSA9PT0gcHJvdG87XG59XG4iLCAiZXhwb3J0IGRlZmF1bHQgKGFsZywga2V5KSA9PiB7XG4gICAgaWYgKGFsZy5zdGFydHNXaXRoKCdSUycpIHx8IGFsZy5zdGFydHNXaXRoKCdQUycpKSB7XG4gICAgICAgIGNvbnN0IHsgbW9kdWx1c0xlbmd0aCB9ID0ga2V5LmFsZ29yaXRobTtcbiAgICAgICAgaWYgKHR5cGVvZiBtb2R1bHVzTGVuZ3RoICE9PSAnbnVtYmVyJyB8fCBtb2R1bHVzTGVuZ3RoIDwgMjA0OCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgJHthbGd9IHJlcXVpcmVzIGtleSBtb2R1bHVzTGVuZ3RoIHRvIGJlIDIwNDggYml0cyBvciBsYXJnZXJgKTtcbiAgICAgICAgfVxuICAgIH1cbn07XG4iLCAiaW1wb3J0IGlzT2JqZWN0IGZyb20gJy4vaXNfb2JqZWN0LmpzJztcbmV4cG9ydCBmdW5jdGlvbiBpc0pXSyhrZXkpIHtcbiAgICByZXR1cm4gaXNPYmplY3Qoa2V5KSAmJiB0eXBlb2Yga2V5Lmt0eSA9PT0gJ3N0cmluZyc7XG59XG5leHBvcnQgZnVuY3Rpb24gaXNQcml2YXRlSldLKGtleSkge1xuICAgIHJldHVybiBrZXkua3R5ICE9PSAnb2N0JyAmJiB0eXBlb2Yga2V5LmQgPT09ICdzdHJpbmcnO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGlzUHVibGljSldLKGtleSkge1xuICAgIHJldHVybiBrZXkua3R5ICE9PSAnb2N0JyAmJiB0eXBlb2Yga2V5LmQgPT09ICd1bmRlZmluZWQnO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGlzU2VjcmV0SldLKGtleSkge1xuICAgIHJldHVybiBpc0pXSyhrZXkpICYmIGtleS5rdHkgPT09ICdvY3QnICYmIHR5cGVvZiBrZXkuayA9PT0gJ3N0cmluZyc7XG59XG4iLCAiaW1wb3J0IGNyeXB0byBmcm9tICcuL3dlYmNyeXB0by5qcyc7XG5pbXBvcnQgeyBKT1NFTm90U3VwcG9ydGVkIH0gZnJvbSAnLi4vdXRpbC9lcnJvcnMuanMnO1xuZnVuY3Rpb24gc3VidGxlTWFwcGluZyhqd2spIHtcbiAgICBsZXQgYWxnb3JpdGhtO1xuICAgIGxldCBrZXlVc2FnZXM7XG4gICAgc3dpdGNoIChqd2sua3R5KSB7XG4gICAgICAgIGNhc2UgJ1JTQSc6IHtcbiAgICAgICAgICAgIHN3aXRjaCAoandrLmFsZykge1xuICAgICAgICAgICAgICAgIGNhc2UgJ1BTMjU2JzpcbiAgICAgICAgICAgICAgICBjYXNlICdQUzM4NCc6XG4gICAgICAgICAgICAgICAgY2FzZSAnUFM1MTInOlxuICAgICAgICAgICAgICAgICAgICBhbGdvcml0aG0gPSB7IG5hbWU6ICdSU0EtUFNTJywgaGFzaDogYFNIQS0ke2p3ay5hbGcuc2xpY2UoLTMpfWAgfTtcbiAgICAgICAgICAgICAgICAgICAga2V5VXNhZ2VzID0gandrLmQgPyBbJ3NpZ24nXSA6IFsndmVyaWZ5J107XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgJ1JTMjU2JzpcbiAgICAgICAgICAgICAgICBjYXNlICdSUzM4NCc6XG4gICAgICAgICAgICAgICAgY2FzZSAnUlM1MTInOlxuICAgICAgICAgICAgICAgICAgICBhbGdvcml0aG0gPSB7IG5hbWU6ICdSU0FTU0EtUEtDUzEtdjFfNScsIGhhc2g6IGBTSEEtJHtqd2suYWxnLnNsaWNlKC0zKX1gIH07XG4gICAgICAgICAgICAgICAgICAgIGtleVVzYWdlcyA9IGp3ay5kID8gWydzaWduJ10gOiBbJ3ZlcmlmeSddO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlICdSU0EtT0FFUCc6XG4gICAgICAgICAgICAgICAgY2FzZSAnUlNBLU9BRVAtMjU2JzpcbiAgICAgICAgICAgICAgICBjYXNlICdSU0EtT0FFUC0zODQnOlxuICAgICAgICAgICAgICAgIGNhc2UgJ1JTQS1PQUVQLTUxMic6XG4gICAgICAgICAgICAgICAgICAgIGFsZ29yaXRobSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdSU0EtT0FFUCcsXG4gICAgICAgICAgICAgICAgICAgICAgICBoYXNoOiBgU0hBLSR7cGFyc2VJbnQoandrLmFsZy5zbGljZSgtMyksIDEwKSB8fCAxfWAsXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgICAgIGtleVVzYWdlcyA9IGp3ay5kID8gWydkZWNyeXB0JywgJ3Vud3JhcEtleSddIDogWydlbmNyeXB0JywgJ3dyYXBLZXknXTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEpPU0VOb3RTdXBwb3J0ZWQoJ0ludmFsaWQgb3IgdW5zdXBwb3J0ZWQgSldLIFwiYWxnXCIgKEFsZ29yaXRobSkgUGFyYW1ldGVyIHZhbHVlJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBjYXNlICdFQyc6IHtcbiAgICAgICAgICAgIHN3aXRjaCAoandrLmFsZykge1xuICAgICAgICAgICAgICAgIGNhc2UgJ0VTMjU2JzpcbiAgICAgICAgICAgICAgICAgICAgYWxnb3JpdGhtID0geyBuYW1lOiAnRUNEU0EnLCBuYW1lZEN1cnZlOiAnUC0yNTYnIH07XG4gICAgICAgICAgICAgICAgICAgIGtleVVzYWdlcyA9IGp3ay5kID8gWydzaWduJ10gOiBbJ3ZlcmlmeSddO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBjYXNlICdFUzM4NCc6XG4gICAgICAgICAgICAgICAgICAgIGFsZ29yaXRobSA9IHsgbmFtZTogJ0VDRFNBJywgbmFtZWRDdXJ2ZTogJ1AtMzg0JyB9O1xuICAgICAgICAgICAgICAgICAgICBrZXlVc2FnZXMgPSBqd2suZCA/IFsnc2lnbiddIDogWyd2ZXJpZnknXTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSAnRVM1MTInOlxuICAgICAgICAgICAgICAgICAgICBhbGdvcml0aG0gPSB7IG5hbWU6ICdFQ0RTQScsIG5hbWVkQ3VydmU6ICdQLTUyMScgfTtcbiAgICAgICAgICAgICAgICAgICAga2V5VXNhZ2VzID0gandrLmQgPyBbJ3NpZ24nXSA6IFsndmVyaWZ5J107XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgJ0VDREgtRVMnOlxuICAgICAgICAgICAgICAgIGNhc2UgJ0VDREgtRVMrQTEyOEtXJzpcbiAgICAgICAgICAgICAgICBjYXNlICdFQ0RILUVTK0ExOTJLVyc6XG4gICAgICAgICAgICAgICAgY2FzZSAnRUNESC1FUytBMjU2S1cnOlxuICAgICAgICAgICAgICAgICAgICBhbGdvcml0aG0gPSB7IG5hbWU6ICdFQ0RIJywgbmFtZWRDdXJ2ZTogandrLmNydiB9O1xuICAgICAgICAgICAgICAgICAgICBrZXlVc2FnZXMgPSBqd2suZCA/IFsnZGVyaXZlQml0cyddIDogW107XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBKT1NFTm90U3VwcG9ydGVkKCdJbnZhbGlkIG9yIHVuc3VwcG9ydGVkIEpXSyBcImFsZ1wiIChBbGdvcml0aG0pIFBhcmFtZXRlciB2YWx1ZScpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIH1cbiAgICAgICAgY2FzZSAnT0tQJzoge1xuICAgICAgICAgICAgc3dpdGNoIChqd2suYWxnKSB7XG4gICAgICAgICAgICAgICAgY2FzZSAnRWREU0EnOlxuICAgICAgICAgICAgICAgICAgICBhbGdvcml0aG0gPSB7IG5hbWU6IGp3ay5jcnYgfTtcbiAgICAgICAgICAgICAgICAgICAga2V5VXNhZ2VzID0gandrLmQgPyBbJ3NpZ24nXSA6IFsndmVyaWZ5J107XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgJ0VDREgtRVMnOlxuICAgICAgICAgICAgICAgIGNhc2UgJ0VDREgtRVMrQTEyOEtXJzpcbiAgICAgICAgICAgICAgICBjYXNlICdFQ0RILUVTK0ExOTJLVyc6XG4gICAgICAgICAgICAgICAgY2FzZSAnRUNESC1FUytBMjU2S1cnOlxuICAgICAgICAgICAgICAgICAgICBhbGdvcml0aG0gPSB7IG5hbWU6IGp3ay5jcnYgfTtcbiAgICAgICAgICAgICAgICAgICAga2V5VXNhZ2VzID0gandrLmQgPyBbJ2Rlcml2ZUJpdHMnXSA6IFtdO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgSk9TRU5vdFN1cHBvcnRlZCgnSW52YWxpZCBvciB1bnN1cHBvcnRlZCBKV0sgXCJhbGdcIiAoQWxnb3JpdGhtKSBQYXJhbWV0ZXIgdmFsdWUnKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB9XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICB0aHJvdyBuZXcgSk9TRU5vdFN1cHBvcnRlZCgnSW52YWxpZCBvciB1bnN1cHBvcnRlZCBKV0sgXCJrdHlcIiAoS2V5IFR5cGUpIFBhcmFtZXRlciB2YWx1ZScpO1xuICAgIH1cbiAgICByZXR1cm4geyBhbGdvcml0aG0sIGtleVVzYWdlcyB9O1xufVxuY29uc3QgcGFyc2UgPSBhc3luYyAoandrKSA9PiB7XG4gICAgaWYgKCFqd2suYWxnKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1wiYWxnXCIgYXJndW1lbnQgaXMgcmVxdWlyZWQgd2hlbiBcImp3ay5hbGdcIiBpcyBub3QgcHJlc2VudCcpO1xuICAgIH1cbiAgICBjb25zdCB7IGFsZ29yaXRobSwga2V5VXNhZ2VzIH0gPSBzdWJ0bGVNYXBwaW5nKGp3ayk7XG4gICAgY29uc3QgcmVzdCA9IFtcbiAgICAgICAgYWxnb3JpdGhtLFxuICAgICAgICBqd2suZXh0ID8/IGZhbHNlLFxuICAgICAgICBqd2sua2V5X29wcyA/PyBrZXlVc2FnZXMsXG4gICAgXTtcbiAgICBjb25zdCBrZXlEYXRhID0geyAuLi5qd2sgfTtcbiAgICBkZWxldGUga2V5RGF0YS5hbGc7XG4gICAgZGVsZXRlIGtleURhdGEudXNlO1xuICAgIHJldHVybiBjcnlwdG8uc3VidGxlLmltcG9ydEtleSgnandrJywga2V5RGF0YSwgLi4ucmVzdCk7XG59O1xuZXhwb3J0IGRlZmF1bHQgcGFyc2U7XG4iLCAiaW1wb3J0IHsgaXNKV0sgfSBmcm9tICcuLi9saWIvaXNfandrLmpzJztcbmltcG9ydCB7IGRlY29kZSB9IGZyb20gJy4vYmFzZTY0dXJsLmpzJztcbmltcG9ydCBpbXBvcnRKV0sgZnJvbSAnLi9qd2tfdG9fa2V5LmpzJztcbmNvbnN0IGV4cG9ydEtleVZhbHVlID0gKGspID0+IGRlY29kZShrKTtcbmxldCBwcml2Q2FjaGU7XG5sZXQgcHViQ2FjaGU7XG5jb25zdCBpc0tleU9iamVjdCA9IChrZXkpID0+IHtcbiAgICByZXR1cm4ga2V5Py5bU3ltYm9sLnRvU3RyaW5nVGFnXSA9PT0gJ0tleU9iamVjdCc7XG59O1xuY29uc3QgaW1wb3J0QW5kQ2FjaGUgPSBhc3luYyAoY2FjaGUsIGtleSwgandrLCBhbGcsIGZyZWV6ZSA9IGZhbHNlKSA9PiB7XG4gICAgbGV0IGNhY2hlZCA9IGNhY2hlLmdldChrZXkpO1xuICAgIGlmIChjYWNoZWQ/LlthbGddKSB7XG4gICAgICAgIHJldHVybiBjYWNoZWRbYWxnXTtcbiAgICB9XG4gICAgY29uc3QgY3J5cHRvS2V5ID0gYXdhaXQgaW1wb3J0SldLKHsgLi4uandrLCBhbGcgfSk7XG4gICAgaWYgKGZyZWV6ZSlcbiAgICAgICAgT2JqZWN0LmZyZWV6ZShrZXkpO1xuICAgIGlmICghY2FjaGVkKSB7XG4gICAgICAgIGNhY2hlLnNldChrZXksIHsgW2FsZ106IGNyeXB0b0tleSB9KTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGNhY2hlZFthbGddID0gY3J5cHRvS2V5O1xuICAgIH1cbiAgICByZXR1cm4gY3J5cHRvS2V5O1xufTtcbmNvbnN0IG5vcm1hbGl6ZVB1YmxpY0tleSA9IChrZXksIGFsZykgPT4ge1xuICAgIGlmIChpc0tleU9iamVjdChrZXkpKSB7XG4gICAgICAgIGxldCBqd2sgPSBrZXkuZXhwb3J0KHsgZm9ybWF0OiAnandrJyB9KTtcbiAgICAgICAgZGVsZXRlIGp3ay5kO1xuICAgICAgICBkZWxldGUgandrLmRwO1xuICAgICAgICBkZWxldGUgandrLmRxO1xuICAgICAgICBkZWxldGUgandrLnA7XG4gICAgICAgIGRlbGV0ZSBqd2sucTtcbiAgICAgICAgZGVsZXRlIGp3ay5xaTtcbiAgICAgICAgaWYgKGp3ay5rKSB7XG4gICAgICAgICAgICByZXR1cm4gZXhwb3J0S2V5VmFsdWUoandrLmspO1xuICAgICAgICB9XG4gICAgICAgIHB1YkNhY2hlIHx8IChwdWJDYWNoZSA9IG5ldyBXZWFrTWFwKCkpO1xuICAgICAgICByZXR1cm4gaW1wb3J0QW5kQ2FjaGUocHViQ2FjaGUsIGtleSwgandrLCBhbGcpO1xuICAgIH1cbiAgICBpZiAoaXNKV0soa2V5KSkge1xuICAgICAgICBpZiAoa2V5LmspXG4gICAgICAgICAgICByZXR1cm4gZGVjb2RlKGtleS5rKTtcbiAgICAgICAgcHViQ2FjaGUgfHwgKHB1YkNhY2hlID0gbmV3IFdlYWtNYXAoKSk7XG4gICAgICAgIGNvbnN0IGNyeXB0b0tleSA9IGltcG9ydEFuZENhY2hlKHB1YkNhY2hlLCBrZXksIGtleSwgYWxnLCB0cnVlKTtcbiAgICAgICAgcmV0dXJuIGNyeXB0b0tleTtcbiAgICB9XG4gICAgcmV0dXJuIGtleTtcbn07XG5jb25zdCBub3JtYWxpemVQcml2YXRlS2V5ID0gKGtleSwgYWxnKSA9PiB7XG4gICAgaWYgKGlzS2V5T2JqZWN0KGtleSkpIHtcbiAgICAgICAgbGV0IGp3ayA9IGtleS5leHBvcnQoeyBmb3JtYXQ6ICdqd2snIH0pO1xuICAgICAgICBpZiAoandrLmspIHtcbiAgICAgICAgICAgIHJldHVybiBleHBvcnRLZXlWYWx1ZShqd2suayk7XG4gICAgICAgIH1cbiAgICAgICAgcHJpdkNhY2hlIHx8IChwcml2Q2FjaGUgPSBuZXcgV2Vha01hcCgpKTtcbiAgICAgICAgcmV0dXJuIGltcG9ydEFuZENhY2hlKHByaXZDYWNoZSwga2V5LCBqd2ssIGFsZyk7XG4gICAgfVxuICAgIGlmIChpc0pXSyhrZXkpKSB7XG4gICAgICAgIGlmIChrZXkuaylcbiAgICAgICAgICAgIHJldHVybiBkZWNvZGUoa2V5LmspO1xuICAgICAgICBwcml2Q2FjaGUgfHwgKHByaXZDYWNoZSA9IG5ldyBXZWFrTWFwKCkpO1xuICAgICAgICBjb25zdCBjcnlwdG9LZXkgPSBpbXBvcnRBbmRDYWNoZShwcml2Q2FjaGUsIGtleSwga2V5LCBhbGcsIHRydWUpO1xuICAgICAgICByZXR1cm4gY3J5cHRvS2V5O1xuICAgIH1cbiAgICByZXR1cm4ga2V5O1xufTtcbmV4cG9ydCBkZWZhdWx0IHsgbm9ybWFsaXplUHVibGljS2V5LCBub3JtYWxpemVQcml2YXRlS2V5IH07XG4iLCAiaW1wb3J0IGNyeXB0bywgeyBpc0NyeXB0b0tleSB9IGZyb20gJy4vd2ViY3J5cHRvLmpzJztcbmltcG9ydCBpbnZhbGlkS2V5SW5wdXQgZnJvbSAnLi4vbGliL2ludmFsaWRfa2V5X2lucHV0LmpzJztcbmltcG9ydCB7IGVuY29kZUJhc2U2NCwgZGVjb2RlQmFzZTY0IH0gZnJvbSAnLi9iYXNlNjR1cmwuanMnO1xuaW1wb3J0IGZvcm1hdFBFTSBmcm9tICcuLi9saWIvZm9ybWF0X3BlbS5qcyc7XG5pbXBvcnQgeyBKT1NFTm90U3VwcG9ydGVkIH0gZnJvbSAnLi4vdXRpbC9lcnJvcnMuanMnO1xuaW1wb3J0IHsgdHlwZXMgfSBmcm9tICcuL2lzX2tleV9saWtlLmpzJztcbmNvbnN0IGdlbmVyaWNFeHBvcnQgPSBhc3luYyAoa2V5VHlwZSwga2V5Rm9ybWF0LCBrZXkpID0+IHtcbiAgICBpZiAoIWlzQ3J5cHRvS2V5KGtleSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihpbnZhbGlkS2V5SW5wdXQoa2V5LCAuLi50eXBlcykpO1xuICAgIH1cbiAgICBpZiAoIWtleS5leHRyYWN0YWJsZSkge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdDcnlwdG9LZXkgaXMgbm90IGV4dHJhY3RhYmxlJyk7XG4gICAgfVxuICAgIGlmIChrZXkudHlwZSAhPT0ga2V5VHlwZSkge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBrZXkgaXMgbm90IGEgJHtrZXlUeXBlfSBrZXlgKTtcbiAgICB9XG4gICAgcmV0dXJuIGZvcm1hdFBFTShlbmNvZGVCYXNlNjQobmV3IFVpbnQ4QXJyYXkoYXdhaXQgY3J5cHRvLnN1YnRsZS5leHBvcnRLZXkoa2V5Rm9ybWF0LCBrZXkpKSksIGAke2tleVR5cGUudG9VcHBlckNhc2UoKX0gS0VZYCk7XG59O1xuZXhwb3J0IGNvbnN0IHRvU1BLSSA9IChrZXkpID0+IHtcbiAgICByZXR1cm4gZ2VuZXJpY0V4cG9ydCgncHVibGljJywgJ3Nwa2knLCBrZXkpO1xufTtcbmV4cG9ydCBjb25zdCB0b1BLQ1M4ID0gKGtleSkgPT4ge1xuICAgIHJldHVybiBnZW5lcmljRXhwb3J0KCdwcml2YXRlJywgJ3BrY3M4Jywga2V5KTtcbn07XG5jb25zdCBmaW5kT2lkID0gKGtleURhdGEsIG9pZCwgZnJvbSA9IDApID0+IHtcbiAgICBpZiAoZnJvbSA9PT0gMCkge1xuICAgICAgICBvaWQudW5zaGlmdChvaWQubGVuZ3RoKTtcbiAgICAgICAgb2lkLnVuc2hpZnQoMHgwNik7XG4gICAgfVxuICAgIGNvbnN0IGkgPSBrZXlEYXRhLmluZGV4T2Yob2lkWzBdLCBmcm9tKTtcbiAgICBpZiAoaSA9PT0gLTEpXG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICBjb25zdCBzdWIgPSBrZXlEYXRhLnN1YmFycmF5KGksIGkgKyBvaWQubGVuZ3RoKTtcbiAgICBpZiAoc3ViLmxlbmd0aCAhPT0gb2lkLmxlbmd0aClcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIHJldHVybiBzdWIuZXZlcnkoKHZhbHVlLCBpbmRleCkgPT4gdmFsdWUgPT09IG9pZFtpbmRleF0pIHx8IGZpbmRPaWQoa2V5RGF0YSwgb2lkLCBpICsgMSk7XG59O1xuY29uc3QgZ2V0TmFtZWRDdXJ2ZSA9IChrZXlEYXRhKSA9PiB7XG4gICAgc3dpdGNoICh0cnVlKSB7XG4gICAgICAgIGNhc2UgZmluZE9pZChrZXlEYXRhLCBbMHgyYSwgMHg4NiwgMHg0OCwgMHhjZSwgMHgzZCwgMHgwMywgMHgwMSwgMHgwN10pOlxuICAgICAgICAgICAgcmV0dXJuICdQLTI1Nic7XG4gICAgICAgIGNhc2UgZmluZE9pZChrZXlEYXRhLCBbMHgyYiwgMHg4MSwgMHgwNCwgMHgwMCwgMHgyMl0pOlxuICAgICAgICAgICAgcmV0dXJuICdQLTM4NCc7XG4gICAgICAgIGNhc2UgZmluZE9pZChrZXlEYXRhLCBbMHgyYiwgMHg4MSwgMHgwNCwgMHgwMCwgMHgyM10pOlxuICAgICAgICAgICAgcmV0dXJuICdQLTUyMSc7XG4gICAgICAgIGNhc2UgZmluZE9pZChrZXlEYXRhLCBbMHgyYiwgMHg2NSwgMHg2ZV0pOlxuICAgICAgICAgICAgcmV0dXJuICdYMjU1MTknO1xuICAgICAgICBjYXNlIGZpbmRPaWQoa2V5RGF0YSwgWzB4MmIsIDB4NjUsIDB4NmZdKTpcbiAgICAgICAgICAgIHJldHVybiAnWDQ0OCc7XG4gICAgICAgIGNhc2UgZmluZE9pZChrZXlEYXRhLCBbMHgyYiwgMHg2NSwgMHg3MF0pOlxuICAgICAgICAgICAgcmV0dXJuICdFZDI1NTE5JztcbiAgICAgICAgY2FzZSBmaW5kT2lkKGtleURhdGEsIFsweDJiLCAweDY1LCAweDcxXSk6XG4gICAgICAgICAgICByZXR1cm4gJ0VkNDQ4JztcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIHRocm93IG5ldyBKT1NFTm90U3VwcG9ydGVkKCdJbnZhbGlkIG9yIHVuc3VwcG9ydGVkIEVDIEtleSBDdXJ2ZSBvciBPS1AgS2V5IFN1YiBUeXBlJyk7XG4gICAgfVxufTtcbmNvbnN0IGdlbmVyaWNJbXBvcnQgPSBhc3luYyAocmVwbGFjZSwga2V5Rm9ybWF0LCBwZW0sIGFsZywgb3B0aW9ucykgPT4ge1xuICAgIGxldCBhbGdvcml0aG07XG4gICAgbGV0IGtleVVzYWdlcztcbiAgICBjb25zdCBrZXlEYXRhID0gbmV3IFVpbnQ4QXJyYXkoYXRvYihwZW0ucmVwbGFjZShyZXBsYWNlLCAnJykpXG4gICAgICAgIC5zcGxpdCgnJylcbiAgICAgICAgLm1hcCgoYykgPT4gYy5jaGFyQ29kZUF0KDApKSk7XG4gICAgY29uc3QgaXNQdWJsaWMgPSBrZXlGb3JtYXQgPT09ICdzcGtpJztcbiAgICBzd2l0Y2ggKGFsZykge1xuICAgICAgICBjYXNlICdQUzI1Nic6XG4gICAgICAgIGNhc2UgJ1BTMzg0JzpcbiAgICAgICAgY2FzZSAnUFM1MTInOlxuICAgICAgICAgICAgYWxnb3JpdGhtID0geyBuYW1lOiAnUlNBLVBTUycsIGhhc2g6IGBTSEEtJHthbGcuc2xpY2UoLTMpfWAgfTtcbiAgICAgICAgICAgIGtleVVzYWdlcyA9IGlzUHVibGljID8gWyd2ZXJpZnknXSA6IFsnc2lnbiddO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ1JTMjU2JzpcbiAgICAgICAgY2FzZSAnUlMzODQnOlxuICAgICAgICBjYXNlICdSUzUxMic6XG4gICAgICAgICAgICBhbGdvcml0aG0gPSB7IG5hbWU6ICdSU0FTU0EtUEtDUzEtdjFfNScsIGhhc2g6IGBTSEEtJHthbGcuc2xpY2UoLTMpfWAgfTtcbiAgICAgICAgICAgIGtleVVzYWdlcyA9IGlzUHVibGljID8gWyd2ZXJpZnknXSA6IFsnc2lnbiddO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ1JTQS1PQUVQJzpcbiAgICAgICAgY2FzZSAnUlNBLU9BRVAtMjU2JzpcbiAgICAgICAgY2FzZSAnUlNBLU9BRVAtMzg0JzpcbiAgICAgICAgY2FzZSAnUlNBLU9BRVAtNTEyJzpcbiAgICAgICAgICAgIGFsZ29yaXRobSA9IHtcbiAgICAgICAgICAgICAgICBuYW1lOiAnUlNBLU9BRVAnLFxuICAgICAgICAgICAgICAgIGhhc2g6IGBTSEEtJHtwYXJzZUludChhbGcuc2xpY2UoLTMpLCAxMCkgfHwgMX1gLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGtleVVzYWdlcyA9IGlzUHVibGljID8gWydlbmNyeXB0JywgJ3dyYXBLZXknXSA6IFsnZGVjcnlwdCcsICd1bndyYXBLZXknXTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdFUzI1Nic6XG4gICAgICAgICAgICBhbGdvcml0aG0gPSB7IG5hbWU6ICdFQ0RTQScsIG5hbWVkQ3VydmU6ICdQLTI1NicgfTtcbiAgICAgICAgICAgIGtleVVzYWdlcyA9IGlzUHVibGljID8gWyd2ZXJpZnknXSA6IFsnc2lnbiddO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ0VTMzg0JzpcbiAgICAgICAgICAgIGFsZ29yaXRobSA9IHsgbmFtZTogJ0VDRFNBJywgbmFtZWRDdXJ2ZTogJ1AtMzg0JyB9O1xuICAgICAgICAgICAga2V5VXNhZ2VzID0gaXNQdWJsaWMgPyBbJ3ZlcmlmeSddIDogWydzaWduJ107XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnRVM1MTInOlxuICAgICAgICAgICAgYWxnb3JpdGhtID0geyBuYW1lOiAnRUNEU0EnLCBuYW1lZEN1cnZlOiAnUC01MjEnIH07XG4gICAgICAgICAgICBrZXlVc2FnZXMgPSBpc1B1YmxpYyA/IFsndmVyaWZ5J10gOiBbJ3NpZ24nXTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdFQ0RILUVTJzpcbiAgICAgICAgY2FzZSAnRUNESC1FUytBMTI4S1cnOlxuICAgICAgICBjYXNlICdFQ0RILUVTK0ExOTJLVyc6XG4gICAgICAgIGNhc2UgJ0VDREgtRVMrQTI1NktXJzoge1xuICAgICAgICAgICAgY29uc3QgbmFtZWRDdXJ2ZSA9IGdldE5hbWVkQ3VydmUoa2V5RGF0YSk7XG4gICAgICAgICAgICBhbGdvcml0aG0gPSBuYW1lZEN1cnZlLnN0YXJ0c1dpdGgoJ1AtJykgPyB7IG5hbWU6ICdFQ0RIJywgbmFtZWRDdXJ2ZSB9IDogeyBuYW1lOiBuYW1lZEN1cnZlIH07XG4gICAgICAgICAgICBrZXlVc2FnZXMgPSBpc1B1YmxpYyA/IFtdIDogWydkZXJpdmVCaXRzJ107XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICBjYXNlICdFZERTQSc6XG4gICAgICAgICAgICBhbGdvcml0aG0gPSB7IG5hbWU6IGdldE5hbWVkQ3VydmUoa2V5RGF0YSkgfTtcbiAgICAgICAgICAgIGtleVVzYWdlcyA9IGlzUHVibGljID8gWyd2ZXJpZnknXSA6IFsnc2lnbiddO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICB0aHJvdyBuZXcgSk9TRU5vdFN1cHBvcnRlZCgnSW52YWxpZCBvciB1bnN1cHBvcnRlZCBcImFsZ1wiIChBbGdvcml0aG0pIHZhbHVlJyk7XG4gICAgfVxuICAgIHJldHVybiBjcnlwdG8uc3VidGxlLmltcG9ydEtleShrZXlGb3JtYXQsIGtleURhdGEsIGFsZ29yaXRobSwgb3B0aW9ucz8uZXh0cmFjdGFibGUgPz8gZmFsc2UsIGtleVVzYWdlcyk7XG59O1xuZXhwb3J0IGNvbnN0IGZyb21QS0NTOCA9IChwZW0sIGFsZywgb3B0aW9ucykgPT4ge1xuICAgIHJldHVybiBnZW5lcmljSW1wb3J0KC8oPzotLS0tLSg/OkJFR0lOfEVORCkgUFJJVkFURSBLRVktLS0tLXxcXHMpL2csICdwa2NzOCcsIHBlbSwgYWxnLCBvcHRpb25zKTtcbn07XG5leHBvcnQgY29uc3QgZnJvbVNQS0kgPSAocGVtLCBhbGcsIG9wdGlvbnMpID0+IHtcbiAgICByZXR1cm4gZ2VuZXJpY0ltcG9ydCgvKD86LS0tLS0oPzpCRUdJTnxFTkQpIFBVQkxJQyBLRVktLS0tLXxcXHMpL2csICdzcGtpJywgcGVtLCBhbGcsIG9wdGlvbnMpO1xufTtcbmZ1bmN0aW9uIGdldEVsZW1lbnQoc2VxKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgbGV0IG5leHQgPSAwO1xuICAgIHdoaWxlIChuZXh0IDwgc2VxLmxlbmd0aCkge1xuICAgICAgICBjb25zdCBuZXh0UGFydCA9IHBhcnNlRWxlbWVudChzZXEuc3ViYXJyYXkobmV4dCkpO1xuICAgICAgICByZXN1bHQucHVzaChuZXh0UGFydCk7XG4gICAgICAgIG5leHQgKz0gbmV4dFBhcnQuYnl0ZUxlbmd0aDtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIHBhcnNlRWxlbWVudChieXRlcykge1xuICAgIGxldCBwb3NpdGlvbiA9IDA7XG4gICAgbGV0IHRhZyA9IGJ5dGVzWzBdICYgMHgxZjtcbiAgICBwb3NpdGlvbisrO1xuICAgIGlmICh0YWcgPT09IDB4MWYpIHtcbiAgICAgICAgdGFnID0gMDtcbiAgICAgICAgd2hpbGUgKGJ5dGVzW3Bvc2l0aW9uXSA+PSAweDgwKSB7XG4gICAgICAgICAgICB0YWcgPSB0YWcgKiAxMjggKyBieXRlc1twb3NpdGlvbl0gLSAweDgwO1xuICAgICAgICAgICAgcG9zaXRpb24rKztcbiAgICAgICAgfVxuICAgICAgICB0YWcgPSB0YWcgKiAxMjggKyBieXRlc1twb3NpdGlvbl0gLSAweDgwO1xuICAgICAgICBwb3NpdGlvbisrO1xuICAgIH1cbiAgICBsZXQgbGVuZ3RoID0gMDtcbiAgICBpZiAoYnl0ZXNbcG9zaXRpb25dIDwgMHg4MCkge1xuICAgICAgICBsZW5ndGggPSBieXRlc1twb3NpdGlvbl07XG4gICAgICAgIHBvc2l0aW9uKys7XG4gICAgfVxuICAgIGVsc2UgaWYgKGxlbmd0aCA9PT0gMHg4MCkge1xuICAgICAgICBsZW5ndGggPSAwO1xuICAgICAgICB3aGlsZSAoYnl0ZXNbcG9zaXRpb24gKyBsZW5ndGhdICE9PSAwIHx8IGJ5dGVzW3Bvc2l0aW9uICsgbGVuZ3RoICsgMV0gIT09IDApIHtcbiAgICAgICAgICAgIGlmIChsZW5ndGggPiBieXRlcy5ieXRlTGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignaW52YWxpZCBpbmRlZmluaXRlIGZvcm0gbGVuZ3RoJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsZW5ndGgrKztcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBieXRlTGVuZ3RoID0gcG9zaXRpb24gKyBsZW5ndGggKyAyO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgYnl0ZUxlbmd0aCxcbiAgICAgICAgICAgIGNvbnRlbnRzOiBieXRlcy5zdWJhcnJheShwb3NpdGlvbiwgcG9zaXRpb24gKyBsZW5ndGgpLFxuICAgICAgICAgICAgcmF3OiBieXRlcy5zdWJhcnJheSgwLCBieXRlTGVuZ3RoKSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGNvbnN0IG51bWJlck9mRGlnaXRzID0gYnl0ZXNbcG9zaXRpb25dICYgMHg3ZjtcbiAgICAgICAgcG9zaXRpb24rKztcbiAgICAgICAgbGVuZ3RoID0gMDtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBudW1iZXJPZkRpZ2l0czsgaSsrKSB7XG4gICAgICAgICAgICBsZW5ndGggPSBsZW5ndGggKiAyNTYgKyBieXRlc1twb3NpdGlvbl07XG4gICAgICAgICAgICBwb3NpdGlvbisrO1xuICAgICAgICB9XG4gICAgfVxuICAgIGNvbnN0IGJ5dGVMZW5ndGggPSBwb3NpdGlvbiArIGxlbmd0aDtcbiAgICByZXR1cm4ge1xuICAgICAgICBieXRlTGVuZ3RoLFxuICAgICAgICBjb250ZW50czogYnl0ZXMuc3ViYXJyYXkocG9zaXRpb24sIGJ5dGVMZW5ndGgpLFxuICAgICAgICByYXc6IGJ5dGVzLnN1YmFycmF5KDAsIGJ5dGVMZW5ndGgpLFxuICAgIH07XG59XG5mdW5jdGlvbiBzcGtpRnJvbVg1MDkoYnVmKSB7XG4gICAgY29uc3QgdGJzQ2VydGlmaWNhdGUgPSBnZXRFbGVtZW50KGdldEVsZW1lbnQocGFyc2VFbGVtZW50KGJ1ZikuY29udGVudHMpWzBdLmNvbnRlbnRzKTtcbiAgICByZXR1cm4gZW5jb2RlQmFzZTY0KHRic0NlcnRpZmljYXRlW3Ric0NlcnRpZmljYXRlWzBdLnJhd1swXSA9PT0gMHhhMCA/IDYgOiA1XS5yYXcpO1xufVxuZnVuY3Rpb24gZ2V0U1BLSSh4NTA5KSB7XG4gICAgY29uc3QgcGVtID0geDUwOS5yZXBsYWNlKC8oPzotLS0tLSg/OkJFR0lOfEVORCkgQ0VSVElGSUNBVEUtLS0tLXxcXHMpL2csICcnKTtcbiAgICBjb25zdCByYXcgPSBkZWNvZGVCYXNlNjQocGVtKTtcbiAgICByZXR1cm4gZm9ybWF0UEVNKHNwa2lGcm9tWDUwOShyYXcpLCAnUFVCTElDIEtFWScpO1xufVxuZXhwb3J0IGNvbnN0IGZyb21YNTA5ID0gKHBlbSwgYWxnLCBvcHRpb25zKSA9PiB7XG4gICAgbGV0IHNwa2k7XG4gICAgdHJ5IHtcbiAgICAgICAgc3BraSA9IGdldFNQS0kocGVtKTtcbiAgICB9XG4gICAgY2F0Y2ggKGNhdXNlKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ0ZhaWxlZCB0byBwYXJzZSB0aGUgWC41MDkgY2VydGlmaWNhdGUnLCB7IGNhdXNlIH0pO1xuICAgIH1cbiAgICByZXR1cm4gZnJvbVNQS0koc3BraSwgYWxnLCBvcHRpb25zKTtcbn07XG4iLCAiaW1wb3J0IHsgZGVjb2RlIGFzIGRlY29kZUJhc2U2NFVSTCB9IGZyb20gJy4uL3J1bnRpbWUvYmFzZTY0dXJsLmpzJztcbmltcG9ydCB7IGZyb21TUEtJLCBmcm9tUEtDUzgsIGZyb21YNTA5IH0gZnJvbSAnLi4vcnVudGltZS9hc24xLmpzJztcbmltcG9ydCBhc0tleU9iamVjdCBmcm9tICcuLi9ydW50aW1lL2p3a190b19rZXkuanMnO1xuaW1wb3J0IHsgSk9TRU5vdFN1cHBvcnRlZCB9IGZyb20gJy4uL3V0aWwvZXJyb3JzLmpzJztcbmltcG9ydCBpc09iamVjdCBmcm9tICcuLi9saWIvaXNfb2JqZWN0LmpzJztcbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBpbXBvcnRTUEtJKHNwa2ksIGFsZywgb3B0aW9ucykge1xuICAgIGlmICh0eXBlb2Ygc3BraSAhPT0gJ3N0cmluZycgfHwgc3BraS5pbmRleE9mKCctLS0tLUJFR0lOIFBVQkxJQyBLRVktLS0tLScpICE9PSAwKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1wic3BraVwiIG11c3QgYmUgU1BLSSBmb3JtYXR0ZWQgc3RyaW5nJyk7XG4gICAgfVxuICAgIHJldHVybiBmcm9tU1BLSShzcGtpLCBhbGcsIG9wdGlvbnMpO1xufVxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGltcG9ydFg1MDkoeDUwOSwgYWxnLCBvcHRpb25zKSB7XG4gICAgaWYgKHR5cGVvZiB4NTA5ICE9PSAnc3RyaW5nJyB8fCB4NTA5LmluZGV4T2YoJy0tLS0tQkVHSU4gQ0VSVElGSUNBVEUtLS0tLScpICE9PSAwKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1wieDUwOVwiIG11c3QgYmUgWC41MDkgZm9ybWF0dGVkIHN0cmluZycpO1xuICAgIH1cbiAgICByZXR1cm4gZnJvbVg1MDkoeDUwOSwgYWxnLCBvcHRpb25zKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBpbXBvcnRQS0NTOChwa2NzOCwgYWxnLCBvcHRpb25zKSB7XG4gICAgaWYgKHR5cGVvZiBwa2NzOCAhPT0gJ3N0cmluZycgfHwgcGtjczguaW5kZXhPZignLS0tLS1CRUdJTiBQUklWQVRFIEtFWS0tLS0tJykgIT09IDApIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignXCJwa2NzOFwiIG11c3QgYmUgUEtDUyM4IGZvcm1hdHRlZCBzdHJpbmcnKTtcbiAgICB9XG4gICAgcmV0dXJuIGZyb21QS0NTOChwa2NzOCwgYWxnLCBvcHRpb25zKTtcbn1cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBpbXBvcnRKV0soandrLCBhbGcpIHtcbiAgICBpZiAoIWlzT2JqZWN0KGp3aykpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignSldLIG11c3QgYmUgYW4gb2JqZWN0Jyk7XG4gICAgfVxuICAgIGFsZyB8fCAoYWxnID0gandrLmFsZyk7XG4gICAgc3dpdGNoIChqd2sua3R5KSB7XG4gICAgICAgIGNhc2UgJ29jdCc6XG4gICAgICAgICAgICBpZiAodHlwZW9mIGp3ay5rICE9PSAnc3RyaW5nJyB8fCAhandrLmspIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdtaXNzaW5nIFwia1wiIChLZXkgVmFsdWUpIFBhcmFtZXRlciB2YWx1ZScpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGRlY29kZUJhc2U2NFVSTChqd2suayk7XG4gICAgICAgIGNhc2UgJ1JTQSc6XG4gICAgICAgICAgICBpZiAoandrLm90aCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEpPU0VOb3RTdXBwb3J0ZWQoJ1JTQSBKV0sgXCJvdGhcIiAoT3RoZXIgUHJpbWVzIEluZm8pIFBhcmFtZXRlciB2YWx1ZSBpcyBub3Qgc3VwcG9ydGVkJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgIGNhc2UgJ0VDJzpcbiAgICAgICAgY2FzZSAnT0tQJzpcbiAgICAgICAgICAgIHJldHVybiBhc0tleU9iamVjdCh7IC4uLmp3aywgYWxnIH0pO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgdGhyb3cgbmV3IEpPU0VOb3RTdXBwb3J0ZWQoJ1Vuc3VwcG9ydGVkIFwia3R5XCIgKEtleSBUeXBlKSBQYXJhbWV0ZXIgdmFsdWUnKTtcbiAgICB9XG59XG4iLCAiaW1wb3J0IHsgd2l0aEFsZyBhcyBpbnZhbGlkS2V5SW5wdXQgfSBmcm9tICcuL2ludmFsaWRfa2V5X2lucHV0LmpzJztcbmltcG9ydCBpc0tleUxpa2UsIHsgdHlwZXMgfSBmcm9tICcuLi9ydW50aW1lL2lzX2tleV9saWtlLmpzJztcbmltcG9ydCAqIGFzIGp3ayBmcm9tICcuL2lzX2p3ay5qcyc7XG5jb25zdCB0YWcgPSAoa2V5KSA9PiBrZXk/LltTeW1ib2wudG9TdHJpbmdUYWddO1xuY29uc3QgandrTWF0Y2hlc09wID0gKGFsZywga2V5LCB1c2FnZSkgPT4ge1xuICAgIGlmIChrZXkudXNlICE9PSB1bmRlZmluZWQgJiYga2V5LnVzZSAhPT0gJ3NpZycpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignSW52YWxpZCBrZXkgZm9yIHRoaXMgb3BlcmF0aW9uLCB3aGVuIHByZXNlbnQgaXRzIHVzZSBtdXN0IGJlIHNpZycpO1xuICAgIH1cbiAgICBpZiAoa2V5LmtleV9vcHMgIT09IHVuZGVmaW5lZCAmJiBrZXkua2V5X29wcy5pbmNsdWRlcz8uKHVzYWdlKSAhPT0gdHJ1ZSkge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGBJbnZhbGlkIGtleSBmb3IgdGhpcyBvcGVyYXRpb24sIHdoZW4gcHJlc2VudCBpdHMga2V5X29wcyBtdXN0IGluY2x1ZGUgJHt1c2FnZX1gKTtcbiAgICB9XG4gICAgaWYgKGtleS5hbGcgIT09IHVuZGVmaW5lZCAmJiBrZXkuYWxnICE9PSBhbGcpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgSW52YWxpZCBrZXkgZm9yIHRoaXMgb3BlcmF0aW9uLCB3aGVuIHByZXNlbnQgaXRzIGFsZyBtdXN0IGJlICR7YWxnfWApO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbn07XG5jb25zdCBzeW1tZXRyaWNUeXBlQ2hlY2sgPSAoYWxnLCBrZXksIHVzYWdlLCBhbGxvd0p3aykgPT4ge1xuICAgIGlmIChrZXkgaW5zdGFuY2VvZiBVaW50OEFycmF5KVxuICAgICAgICByZXR1cm47XG4gICAgaWYgKGFsbG93SndrICYmIGp3ay5pc0pXSyhrZXkpKSB7XG4gICAgICAgIGlmIChqd2suaXNTZWNyZXRKV0soa2V5KSAmJiBqd2tNYXRjaGVzT3AoYWxnLCBrZXksIHVzYWdlKSlcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgSlNPTiBXZWIgS2V5IGZvciBzeW1tZXRyaWMgYWxnb3JpdGhtcyBtdXN0IGhhdmUgSldLIFwia3R5XCIgKEtleSBUeXBlKSBlcXVhbCB0byBcIm9jdFwiIGFuZCB0aGUgSldLIFwia1wiIChLZXkgVmFsdWUpIHByZXNlbnRgKTtcbiAgICB9XG4gICAgaWYgKCFpc0tleUxpa2Uoa2V5KSkge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGludmFsaWRLZXlJbnB1dChhbGcsIGtleSwgLi4udHlwZXMsICdVaW50OEFycmF5JywgYWxsb3dKd2sgPyAnSlNPTiBXZWIgS2V5JyA6IG51bGwpKTtcbiAgICB9XG4gICAgaWYgKGtleS50eXBlICE9PSAnc2VjcmV0Jykge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGAke3RhZyhrZXkpfSBpbnN0YW5jZXMgZm9yIHN5bW1ldHJpYyBhbGdvcml0aG1zIG11c3QgYmUgb2YgdHlwZSBcInNlY3JldFwiYCk7XG4gICAgfVxufTtcbmNvbnN0IGFzeW1tZXRyaWNUeXBlQ2hlY2sgPSAoYWxnLCBrZXksIHVzYWdlLCBhbGxvd0p3aykgPT4ge1xuICAgIGlmIChhbGxvd0p3ayAmJiBqd2suaXNKV0soa2V5KSkge1xuICAgICAgICBzd2l0Y2ggKHVzYWdlKSB7XG4gICAgICAgICAgICBjYXNlICdzaWduJzpcbiAgICAgICAgICAgICAgICBpZiAoandrLmlzUHJpdmF0ZUpXSyhrZXkpICYmIGp3a01hdGNoZXNPcChhbGcsIGtleSwgdXNhZ2UpKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgSlNPTiBXZWIgS2V5IGZvciB0aGlzIG9wZXJhdGlvbiBiZSBhIHByaXZhdGUgSldLYCk7XG4gICAgICAgICAgICBjYXNlICd2ZXJpZnknOlxuICAgICAgICAgICAgICAgIGlmIChqd2suaXNQdWJsaWNKV0soa2V5KSAmJiBqd2tNYXRjaGVzT3AoYWxnLCBrZXksIHVzYWdlKSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoYEpTT04gV2ViIEtleSBmb3IgdGhpcyBvcGVyYXRpb24gYmUgYSBwdWJsaWMgSldLYCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKCFpc0tleUxpa2Uoa2V5KSkge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGludmFsaWRLZXlJbnB1dChhbGcsIGtleSwgLi4udHlwZXMsIGFsbG93SndrID8gJ0pTT04gV2ViIEtleScgOiBudWxsKSk7XG4gICAgfVxuICAgIGlmIChrZXkudHlwZSA9PT0gJ3NlY3JldCcpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihgJHt0YWcoa2V5KX0gaW5zdGFuY2VzIGZvciBhc3ltbWV0cmljIGFsZ29yaXRobXMgbXVzdCBub3QgYmUgb2YgdHlwZSBcInNlY3JldFwiYCk7XG4gICAgfVxuICAgIGlmICh1c2FnZSA9PT0gJ3NpZ24nICYmIGtleS50eXBlID09PSAncHVibGljJykge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGAke3RhZyhrZXkpfSBpbnN0YW5jZXMgZm9yIGFzeW1tZXRyaWMgYWxnb3JpdGhtIHNpZ25pbmcgbXVzdCBiZSBvZiB0eXBlIFwicHJpdmF0ZVwiYCk7XG4gICAgfVxuICAgIGlmICh1c2FnZSA9PT0gJ2RlY3J5cHQnICYmIGtleS50eXBlID09PSAncHVibGljJykge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGAke3RhZyhrZXkpfSBpbnN0YW5jZXMgZm9yIGFzeW1tZXRyaWMgYWxnb3JpdGhtIGRlY3J5cHRpb24gbXVzdCBiZSBvZiB0eXBlIFwicHJpdmF0ZVwiYCk7XG4gICAgfVxuICAgIGlmIChrZXkuYWxnb3JpdGhtICYmIHVzYWdlID09PSAndmVyaWZ5JyAmJiBrZXkudHlwZSA9PT0gJ3ByaXZhdGUnKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoYCR7dGFnKGtleSl9IGluc3RhbmNlcyBmb3IgYXN5bW1ldHJpYyBhbGdvcml0aG0gdmVyaWZ5aW5nIG11c3QgYmUgb2YgdHlwZSBcInB1YmxpY1wiYCk7XG4gICAgfVxuICAgIGlmIChrZXkuYWxnb3JpdGhtICYmIHVzYWdlID09PSAnZW5jcnlwdCcgJiYga2V5LnR5cGUgPT09ICdwcml2YXRlJykge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGAke3RhZyhrZXkpfSBpbnN0YW5jZXMgZm9yIGFzeW1tZXRyaWMgYWxnb3JpdGhtIGVuY3J5cHRpb24gbXVzdCBiZSBvZiB0eXBlIFwicHVibGljXCJgKTtcbiAgICB9XG59O1xuZnVuY3Rpb24gY2hlY2tLZXlUeXBlKGFsbG93SndrLCBhbGcsIGtleSwgdXNhZ2UpIHtcbiAgICBjb25zdCBzeW1tZXRyaWMgPSBhbGcuc3RhcnRzV2l0aCgnSFMnKSB8fFxuICAgICAgICBhbGcgPT09ICdkaXInIHx8XG4gICAgICAgIGFsZy5zdGFydHNXaXRoKCdQQkVTMicpIHx8XG4gICAgICAgIC9eQVxcZHszfSg/OkdDTSk/S1ckLy50ZXN0KGFsZyk7XG4gICAgaWYgKHN5bW1ldHJpYykge1xuICAgICAgICBzeW1tZXRyaWNUeXBlQ2hlY2soYWxnLCBrZXksIHVzYWdlLCBhbGxvd0p3ayk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBhc3ltbWV0cmljVHlwZUNoZWNrKGFsZywga2V5LCB1c2FnZSwgYWxsb3dKd2spO1xuICAgIH1cbn1cbmV4cG9ydCBkZWZhdWx0IGNoZWNrS2V5VHlwZS5iaW5kKHVuZGVmaW5lZCwgZmFsc2UpO1xuZXhwb3J0IGNvbnN0IGNoZWNrS2V5VHlwZVdpdGhKd2sgPSBjaGVja0tleVR5cGUuYmluZCh1bmRlZmluZWQsIHRydWUpO1xuIiwgImltcG9ydCB7IEpPU0VOb3RTdXBwb3J0ZWQgfSBmcm9tICcuLi91dGlsL2Vycm9ycy5qcyc7XG5mdW5jdGlvbiB2YWxpZGF0ZUNyaXQoRXJyLCByZWNvZ25pemVkRGVmYXVsdCwgcmVjb2duaXplZE9wdGlvbiwgcHJvdGVjdGVkSGVhZGVyLCBqb3NlSGVhZGVyKSB7XG4gICAgaWYgKGpvc2VIZWFkZXIuY3JpdCAhPT0gdW5kZWZpbmVkICYmIHByb3RlY3RlZEhlYWRlcj8uY3JpdCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnIoJ1wiY3JpdFwiIChDcml0aWNhbCkgSGVhZGVyIFBhcmFtZXRlciBNVVNUIGJlIGludGVncml0eSBwcm90ZWN0ZWQnKTtcbiAgICB9XG4gICAgaWYgKCFwcm90ZWN0ZWRIZWFkZXIgfHwgcHJvdGVjdGVkSGVhZGVyLmNyaXQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICByZXR1cm4gbmV3IFNldCgpO1xuICAgIH1cbiAgICBpZiAoIUFycmF5LmlzQXJyYXkocHJvdGVjdGVkSGVhZGVyLmNyaXQpIHx8XG4gICAgICAgIHByb3RlY3RlZEhlYWRlci5jcml0Lmxlbmd0aCA9PT0gMCB8fFxuICAgICAgICBwcm90ZWN0ZWRIZWFkZXIuY3JpdC5zb21lKChpbnB1dCkgPT4gdHlwZW9mIGlucHV0ICE9PSAnc3RyaW5nJyB8fCBpbnB1dC5sZW5ndGggPT09IDApKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnIoJ1wiY3JpdFwiIChDcml0aWNhbCkgSGVhZGVyIFBhcmFtZXRlciBNVVNUIGJlIGFuIGFycmF5IG9mIG5vbi1lbXB0eSBzdHJpbmdzIHdoZW4gcHJlc2VudCcpO1xuICAgIH1cbiAgICBsZXQgcmVjb2duaXplZDtcbiAgICBpZiAocmVjb2duaXplZE9wdGlvbiAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHJlY29nbml6ZWQgPSBuZXcgTWFwKFsuLi5PYmplY3QuZW50cmllcyhyZWNvZ25pemVkT3B0aW9uKSwgLi4ucmVjb2duaXplZERlZmF1bHQuZW50cmllcygpXSk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICByZWNvZ25pemVkID0gcmVjb2duaXplZERlZmF1bHQ7XG4gICAgfVxuICAgIGZvciAoY29uc3QgcGFyYW1ldGVyIG9mIHByb3RlY3RlZEhlYWRlci5jcml0KSB7XG4gICAgICAgIGlmICghcmVjb2duaXplZC5oYXMocGFyYW1ldGVyKSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEpPU0VOb3RTdXBwb3J0ZWQoYEV4dGVuc2lvbiBIZWFkZXIgUGFyYW1ldGVyIFwiJHtwYXJhbWV0ZXJ9XCIgaXMgbm90IHJlY29nbml6ZWRgKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoam9zZUhlYWRlcltwYXJhbWV0ZXJdID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnIoYEV4dGVuc2lvbiBIZWFkZXIgUGFyYW1ldGVyIFwiJHtwYXJhbWV0ZXJ9XCIgaXMgbWlzc2luZ2ApO1xuICAgICAgICB9XG4gICAgICAgIGlmIChyZWNvZ25pemVkLmdldChwYXJhbWV0ZXIpICYmIHByb3RlY3RlZEhlYWRlcltwYXJhbWV0ZXJdID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnIoYEV4dGVuc2lvbiBIZWFkZXIgUGFyYW1ldGVyIFwiJHtwYXJhbWV0ZXJ9XCIgTVVTVCBiZSBpbnRlZ3JpdHkgcHJvdGVjdGVkYCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIG5ldyBTZXQocHJvdGVjdGVkSGVhZGVyLmNyaXQpO1xufVxuZXhwb3J0IGRlZmF1bHQgdmFsaWRhdGVDcml0O1xuIiwgImltcG9ydCB7IEpPU0VOb3RTdXBwb3J0ZWQgfSBmcm9tICcuLi91dGlsL2Vycm9ycy5qcyc7XG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBzdWJ0bGVEc2EoYWxnLCBhbGdvcml0aG0pIHtcbiAgICBjb25zdCBoYXNoID0gYFNIQS0ke2FsZy5zbGljZSgtMyl9YDtcbiAgICBzd2l0Y2ggKGFsZykge1xuICAgICAgICBjYXNlICdIUzI1Nic6XG4gICAgICAgIGNhc2UgJ0hTMzg0JzpcbiAgICAgICAgY2FzZSAnSFM1MTInOlxuICAgICAgICAgICAgcmV0dXJuIHsgaGFzaCwgbmFtZTogJ0hNQUMnIH07XG4gICAgICAgIGNhc2UgJ1BTMjU2JzpcbiAgICAgICAgY2FzZSAnUFMzODQnOlxuICAgICAgICBjYXNlICdQUzUxMic6XG4gICAgICAgICAgICByZXR1cm4geyBoYXNoLCBuYW1lOiAnUlNBLVBTUycsIHNhbHRMZW5ndGg6IGFsZy5zbGljZSgtMykgPj4gMyB9O1xuICAgICAgICBjYXNlICdSUzI1Nic6XG4gICAgICAgIGNhc2UgJ1JTMzg0JzpcbiAgICAgICAgY2FzZSAnUlM1MTInOlxuICAgICAgICAgICAgcmV0dXJuIHsgaGFzaCwgbmFtZTogJ1JTQVNTQS1QS0NTMS12MV81JyB9O1xuICAgICAgICBjYXNlICdFUzI1Nic6XG4gICAgICAgIGNhc2UgJ0VTMzg0JzpcbiAgICAgICAgY2FzZSAnRVM1MTInOlxuICAgICAgICAgICAgcmV0dXJuIHsgaGFzaCwgbmFtZTogJ0VDRFNBJywgbmFtZWRDdXJ2ZTogYWxnb3JpdGhtLm5hbWVkQ3VydmUgfTtcbiAgICAgICAgY2FzZSAnRWREU0EnOlxuICAgICAgICAgICAgcmV0dXJuIHsgbmFtZTogYWxnb3JpdGhtLm5hbWUgfTtcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIHRocm93IG5ldyBKT1NFTm90U3VwcG9ydGVkKGBhbGcgJHthbGd9IGlzIG5vdCBzdXBwb3J0ZWQgZWl0aGVyIGJ5IEpPU0Ugb3IgeW91ciBqYXZhc2NyaXB0IHJ1bnRpbWVgKTtcbiAgICB9XG59XG4iLCAiaW1wb3J0IGNyeXB0bywgeyBpc0NyeXB0b0tleSB9IGZyb20gJy4vd2ViY3J5cHRvLmpzJztcbmltcG9ydCB7IGNoZWNrU2lnQ3J5cHRvS2V5IH0gZnJvbSAnLi4vbGliL2NyeXB0b19rZXkuanMnO1xuaW1wb3J0IGludmFsaWRLZXlJbnB1dCBmcm9tICcuLi9saWIvaW52YWxpZF9rZXlfaW5wdXQuanMnO1xuaW1wb3J0IHsgdHlwZXMgfSBmcm9tICcuL2lzX2tleV9saWtlLmpzJztcbmltcG9ydCBub3JtYWxpemUgZnJvbSAnLi9ub3JtYWxpemVfa2V5LmpzJztcbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIGdldENyeXB0b0tleShhbGcsIGtleSwgdXNhZ2UpIHtcbiAgICBpZiAodXNhZ2UgPT09ICdzaWduJykge1xuICAgICAgICBrZXkgPSBhd2FpdCBub3JtYWxpemUubm9ybWFsaXplUHJpdmF0ZUtleShrZXksIGFsZyk7XG4gICAgfVxuICAgIGlmICh1c2FnZSA9PT0gJ3ZlcmlmeScpIHtcbiAgICAgICAga2V5ID0gYXdhaXQgbm9ybWFsaXplLm5vcm1hbGl6ZVB1YmxpY0tleShrZXksIGFsZyk7XG4gICAgfVxuICAgIGlmIChpc0NyeXB0b0tleShrZXkpKSB7XG4gICAgICAgIGNoZWNrU2lnQ3J5cHRvS2V5KGtleSwgYWxnLCB1c2FnZSk7XG4gICAgICAgIHJldHVybiBrZXk7XG4gICAgfVxuICAgIGlmIChrZXkgaW5zdGFuY2VvZiBVaW50OEFycmF5KSB7XG4gICAgICAgIGlmICghYWxnLnN0YXJ0c1dpdGgoJ0hTJykpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoaW52YWxpZEtleUlucHV0KGtleSwgLi4udHlwZXMpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY3J5cHRvLnN1YnRsZS5pbXBvcnRLZXkoJ3JhdycsIGtleSwgeyBoYXNoOiBgU0hBLSR7YWxnLnNsaWNlKC0zKX1gLCBuYW1lOiAnSE1BQycgfSwgZmFsc2UsIFt1c2FnZV0pO1xuICAgIH1cbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKGludmFsaWRLZXlJbnB1dChrZXksIC4uLnR5cGVzLCAnVWludDhBcnJheScsICdKU09OIFdlYiBLZXknKSk7XG59XG4iLCAiZXhwb3J0IGRlZmF1bHQgKGRhdGUpID0+IE1hdGguZmxvb3IoZGF0ZS5nZXRUaW1lKCkgLyAxMDAwKTtcbiIsICJjb25zdCBtaW51dGUgPSA2MDtcbmNvbnN0IGhvdXIgPSBtaW51dGUgKiA2MDtcbmNvbnN0IGRheSA9IGhvdXIgKiAyNDtcbmNvbnN0IHdlZWsgPSBkYXkgKiA3O1xuY29uc3QgeWVhciA9IGRheSAqIDM2NS4yNTtcbmNvbnN0IFJFR0VYID0gL14oXFwrfFxcLSk/ID8oXFxkK3xcXGQrXFwuXFxkKykgPyhzZWNvbmRzP3xzZWNzP3xzfG1pbnV0ZXM/fG1pbnM/fG18aG91cnM/fGhycz98aHxkYXlzP3xkfHdlZWtzP3x3fHllYXJzP3x5cnM/fHkpKD86IChhZ298ZnJvbSBub3cpKT8kL2k7XG5leHBvcnQgZGVmYXVsdCAoc3RyKSA9PiB7XG4gICAgY29uc3QgbWF0Y2hlZCA9IFJFR0VYLmV4ZWMoc3RyKTtcbiAgICBpZiAoIW1hdGNoZWQgfHwgKG1hdGNoZWRbNF0gJiYgbWF0Y2hlZFsxXSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcignSW52YWxpZCB0aW1lIHBlcmlvZCBmb3JtYXQnKTtcbiAgICB9XG4gICAgY29uc3QgdmFsdWUgPSBwYXJzZUZsb2F0KG1hdGNoZWRbMl0pO1xuICAgIGNvbnN0IHVuaXQgPSBtYXRjaGVkWzNdLnRvTG93ZXJDYXNlKCk7XG4gICAgbGV0IG51bWVyaWNEYXRlO1xuICAgIHN3aXRjaCAodW5pdCkge1xuICAgICAgICBjYXNlICdzZWMnOlxuICAgICAgICBjYXNlICdzZWNzJzpcbiAgICAgICAgY2FzZSAnc2Vjb25kJzpcbiAgICAgICAgY2FzZSAnc2Vjb25kcyc6XG4gICAgICAgIGNhc2UgJ3MnOlxuICAgICAgICAgICAgbnVtZXJpY0RhdGUgPSBNYXRoLnJvdW5kKHZhbHVlKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdtaW51dGUnOlxuICAgICAgICBjYXNlICdtaW51dGVzJzpcbiAgICAgICAgY2FzZSAnbWluJzpcbiAgICAgICAgY2FzZSAnbWlucyc6XG4gICAgICAgIGNhc2UgJ20nOlxuICAgICAgICAgICAgbnVtZXJpY0RhdGUgPSBNYXRoLnJvdW5kKHZhbHVlICogbWludXRlKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdob3VyJzpcbiAgICAgICAgY2FzZSAnaG91cnMnOlxuICAgICAgICBjYXNlICdocic6XG4gICAgICAgIGNhc2UgJ2hycyc6XG4gICAgICAgIGNhc2UgJ2gnOlxuICAgICAgICAgICAgbnVtZXJpY0RhdGUgPSBNYXRoLnJvdW5kKHZhbHVlICogaG91cik7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnZGF5JzpcbiAgICAgICAgY2FzZSAnZGF5cyc6XG4gICAgICAgIGNhc2UgJ2QnOlxuICAgICAgICAgICAgbnVtZXJpY0RhdGUgPSBNYXRoLnJvdW5kKHZhbHVlICogZGF5KTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICd3ZWVrJzpcbiAgICAgICAgY2FzZSAnd2Vla3MnOlxuICAgICAgICBjYXNlICd3JzpcbiAgICAgICAgICAgIG51bWVyaWNEYXRlID0gTWF0aC5yb3VuZCh2YWx1ZSAqIHdlZWspO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICBudW1lcmljRGF0ZSA9IE1hdGgucm91bmQodmFsdWUgKiB5ZWFyKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBpZiAobWF0Y2hlZFsxXSA9PT0gJy0nIHx8IG1hdGNoZWRbNF0gPT09ICdhZ28nKSB7XG4gICAgICAgIHJldHVybiAtbnVtZXJpY0RhdGU7XG4gICAgfVxuICAgIHJldHVybiBudW1lcmljRGF0ZTtcbn07XG4iLCAiaW1wb3J0IHN1YnRsZUFsZ29yaXRobSBmcm9tICcuL3N1YnRsZV9kc2EuanMnO1xuaW1wb3J0IGNyeXB0byBmcm9tICcuL3dlYmNyeXB0by5qcyc7XG5pbXBvcnQgY2hlY2tLZXlMZW5ndGggZnJvbSAnLi9jaGVja19rZXlfbGVuZ3RoLmpzJztcbmltcG9ydCBnZXRTaWduS2V5IGZyb20gJy4vZ2V0X3NpZ25fdmVyaWZ5X2tleS5qcyc7XG5jb25zdCBzaWduID0gYXN5bmMgKGFsZywga2V5LCBkYXRhKSA9PiB7XG4gICAgY29uc3QgY3J5cHRvS2V5ID0gYXdhaXQgZ2V0U2lnbktleShhbGcsIGtleSwgJ3NpZ24nKTtcbiAgICBjaGVja0tleUxlbmd0aChhbGcsIGNyeXB0b0tleSk7XG4gICAgY29uc3Qgc2lnbmF0dXJlID0gYXdhaXQgY3J5cHRvLnN1YnRsZS5zaWduKHN1YnRsZUFsZ29yaXRobShhbGcsIGNyeXB0b0tleS5hbGdvcml0aG0pLCBjcnlwdG9LZXksIGRhdGEpO1xuICAgIHJldHVybiBuZXcgVWludDhBcnJheShzaWduYXR1cmUpO1xufTtcbmV4cG9ydCBkZWZhdWx0IHNpZ247XG4iLCAiaW1wb3J0IHsgZW5jb2RlIGFzIGJhc2U2NHVybCB9IGZyb20gJy4uLy4uL3J1bnRpbWUvYmFzZTY0dXJsLmpzJztcbmltcG9ydCBzaWduIGZyb20gJy4uLy4uL3J1bnRpbWUvc2lnbi5qcyc7XG5pbXBvcnQgaXNEaXNqb2ludCBmcm9tICcuLi8uLi9saWIvaXNfZGlzam9pbnQuanMnO1xuaW1wb3J0IHsgSldTSW52YWxpZCB9IGZyb20gJy4uLy4uL3V0aWwvZXJyb3JzLmpzJztcbmltcG9ydCB7IGVuY29kZXIsIGRlY29kZXIsIGNvbmNhdCB9IGZyb20gJy4uLy4uL2xpYi9idWZmZXJfdXRpbHMuanMnO1xuaW1wb3J0IHsgY2hlY2tLZXlUeXBlV2l0aEp3ayB9IGZyb20gJy4uLy4uL2xpYi9jaGVja19rZXlfdHlwZS5qcyc7XG5pbXBvcnQgdmFsaWRhdGVDcml0IGZyb20gJy4uLy4uL2xpYi92YWxpZGF0ZV9jcml0LmpzJztcbmV4cG9ydCBjbGFzcyBGbGF0dGVuZWRTaWduIHtcbiAgICBjb25zdHJ1Y3RvcihwYXlsb2FkKSB7XG4gICAgICAgIGlmICghKHBheWxvYWQgaW5zdGFuY2VvZiBVaW50OEFycmF5KSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcigncGF5bG9hZCBtdXN0IGJlIGFuIGluc3RhbmNlIG9mIFVpbnQ4QXJyYXknKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLl9wYXlsb2FkID0gcGF5bG9hZDtcbiAgICB9XG4gICAgc2V0UHJvdGVjdGVkSGVhZGVyKHByb3RlY3RlZEhlYWRlcikge1xuICAgICAgICBpZiAodGhpcy5fcHJvdGVjdGVkSGVhZGVyKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdzZXRQcm90ZWN0ZWRIZWFkZXIgY2FuIG9ubHkgYmUgY2FsbGVkIG9uY2UnKTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLl9wcm90ZWN0ZWRIZWFkZXIgPSBwcm90ZWN0ZWRIZWFkZXI7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBzZXRVbnByb3RlY3RlZEhlYWRlcih1bnByb3RlY3RlZEhlYWRlcikge1xuICAgICAgICBpZiAodGhpcy5fdW5wcm90ZWN0ZWRIZWFkZXIpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ3NldFVucHJvdGVjdGVkSGVhZGVyIGNhbiBvbmx5IGJlIGNhbGxlZCBvbmNlJyk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5fdW5wcm90ZWN0ZWRIZWFkZXIgPSB1bnByb3RlY3RlZEhlYWRlcjtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGFzeW5jIHNpZ24oa2V5LCBvcHRpb25zKSB7XG4gICAgICAgIGlmICghdGhpcy5fcHJvdGVjdGVkSGVhZGVyICYmICF0aGlzLl91bnByb3RlY3RlZEhlYWRlcikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEpXU0ludmFsaWQoJ2VpdGhlciBzZXRQcm90ZWN0ZWRIZWFkZXIgb3Igc2V0VW5wcm90ZWN0ZWRIZWFkZXIgbXVzdCBiZSBjYWxsZWQgYmVmb3JlICNzaWduKCknKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoIWlzRGlzam9pbnQodGhpcy5fcHJvdGVjdGVkSGVhZGVyLCB0aGlzLl91bnByb3RlY3RlZEhlYWRlcikpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBKV1NJbnZhbGlkKCdKV1MgUHJvdGVjdGVkIGFuZCBKV1MgVW5wcm90ZWN0ZWQgSGVhZGVyIFBhcmFtZXRlciBuYW1lcyBtdXN0IGJlIGRpc2pvaW50Jyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgam9zZUhlYWRlciA9IHtcbiAgICAgICAgICAgIC4uLnRoaXMuX3Byb3RlY3RlZEhlYWRlcixcbiAgICAgICAgICAgIC4uLnRoaXMuX3VucHJvdGVjdGVkSGVhZGVyLFxuICAgICAgICB9O1xuICAgICAgICBjb25zdCBleHRlbnNpb25zID0gdmFsaWRhdGVDcml0KEpXU0ludmFsaWQsIG5ldyBNYXAoW1snYjY0JywgdHJ1ZV1dKSwgb3B0aW9ucz8uY3JpdCwgdGhpcy5fcHJvdGVjdGVkSGVhZGVyLCBqb3NlSGVhZGVyKTtcbiAgICAgICAgbGV0IGI2NCA9IHRydWU7XG4gICAgICAgIGlmIChleHRlbnNpb25zLmhhcygnYjY0JykpIHtcbiAgICAgICAgICAgIGI2NCA9IHRoaXMuX3Byb3RlY3RlZEhlYWRlci5iNjQ7XG4gICAgICAgICAgICBpZiAodHlwZW9mIGI2NCAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IEpXU0ludmFsaWQoJ1RoZSBcImI2NFwiIChiYXNlNjR1cmwtZW5jb2RlIHBheWxvYWQpIEhlYWRlciBQYXJhbWV0ZXIgbXVzdCBiZSBhIGJvb2xlYW4nKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjb25zdCB7IGFsZyB9ID0gam9zZUhlYWRlcjtcbiAgICAgICAgaWYgKHR5cGVvZiBhbGcgIT09ICdzdHJpbmcnIHx8ICFhbGcpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBKV1NJbnZhbGlkKCdKV1MgXCJhbGdcIiAoQWxnb3JpdGhtKSBIZWFkZXIgUGFyYW1ldGVyIG1pc3Npbmcgb3IgaW52YWxpZCcpO1xuICAgICAgICB9XG4gICAgICAgIGNoZWNrS2V5VHlwZVdpdGhKd2soYWxnLCBrZXksICdzaWduJyk7XG4gICAgICAgIGxldCBwYXlsb2FkID0gdGhpcy5fcGF5bG9hZDtcbiAgICAgICAgaWYgKGI2NCkge1xuICAgICAgICAgICAgcGF5bG9hZCA9IGVuY29kZXIuZW5jb2RlKGJhc2U2NHVybChwYXlsb2FkKSk7XG4gICAgICAgIH1cbiAgICAgICAgbGV0IHByb3RlY3RlZEhlYWRlcjtcbiAgICAgICAgaWYgKHRoaXMuX3Byb3RlY3RlZEhlYWRlcikge1xuICAgICAgICAgICAgcHJvdGVjdGVkSGVhZGVyID0gZW5jb2Rlci5lbmNvZGUoYmFzZTY0dXJsKEpTT04uc3RyaW5naWZ5KHRoaXMuX3Byb3RlY3RlZEhlYWRlcikpKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHByb3RlY3RlZEhlYWRlciA9IGVuY29kZXIuZW5jb2RlKCcnKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBkYXRhID0gY29uY2F0KHByb3RlY3RlZEhlYWRlciwgZW5jb2Rlci5lbmNvZGUoJy4nKSwgcGF5bG9hZCk7XG4gICAgICAgIGNvbnN0IHNpZ25hdHVyZSA9IGF3YWl0IHNpZ24oYWxnLCBrZXksIGRhdGEpO1xuICAgICAgICBjb25zdCBqd3MgPSB7XG4gICAgICAgICAgICBzaWduYXR1cmU6IGJhc2U2NHVybChzaWduYXR1cmUpLFxuICAgICAgICAgICAgcGF5bG9hZDogJycsXG4gICAgICAgIH07XG4gICAgICAgIGlmIChiNjQpIHtcbiAgICAgICAgICAgIGp3cy5wYXlsb2FkID0gZGVjb2Rlci5kZWNvZGUocGF5bG9hZCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuX3VucHJvdGVjdGVkSGVhZGVyKSB7XG4gICAgICAgICAgICBqd3MuaGVhZGVyID0gdGhpcy5fdW5wcm90ZWN0ZWRIZWFkZXI7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHRoaXMuX3Byb3RlY3RlZEhlYWRlcikge1xuICAgICAgICAgICAgandzLnByb3RlY3RlZCA9IGRlY29kZXIuZGVjb2RlKHByb3RlY3RlZEhlYWRlcik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGp3cztcbiAgICB9XG59XG4iLCAiaW1wb3J0IHsgRmxhdHRlbmVkU2lnbiB9IGZyb20gJy4uL2ZsYXR0ZW5lZC9zaWduLmpzJztcbmV4cG9ydCBjbGFzcyBDb21wYWN0U2lnbiB7XG4gICAgY29uc3RydWN0b3IocGF5bG9hZCkge1xuICAgICAgICB0aGlzLl9mbGF0dGVuZWQgPSBuZXcgRmxhdHRlbmVkU2lnbihwYXlsb2FkKTtcbiAgICB9XG4gICAgc2V0UHJvdGVjdGVkSGVhZGVyKHByb3RlY3RlZEhlYWRlcikge1xuICAgICAgICB0aGlzLl9mbGF0dGVuZWQuc2V0UHJvdGVjdGVkSGVhZGVyKHByb3RlY3RlZEhlYWRlcik7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBhc3luYyBzaWduKGtleSwgb3B0aW9ucykge1xuICAgICAgICBjb25zdCBqd3MgPSBhd2FpdCB0aGlzLl9mbGF0dGVuZWQuc2lnbihrZXksIG9wdGlvbnMpO1xuICAgICAgICBpZiAoandzLnBheWxvYWQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcigndXNlIHRoZSBmbGF0dGVuZWQgbW9kdWxlIGZvciBjcmVhdGluZyBKV1Mgd2l0aCBiNjQ6IGZhbHNlJyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGAke2p3cy5wcm90ZWN0ZWR9LiR7andzLnBheWxvYWR9LiR7andzLnNpZ25hdHVyZX1gO1xuICAgIH1cbn1cbiIsICJpbXBvcnQgZXBvY2ggZnJvbSAnLi4vbGliL2Vwb2NoLmpzJztcbmltcG9ydCBpc09iamVjdCBmcm9tICcuLi9saWIvaXNfb2JqZWN0LmpzJztcbmltcG9ydCBzZWNzIGZyb20gJy4uL2xpYi9zZWNzLmpzJztcbmZ1bmN0aW9uIHZhbGlkYXRlSW5wdXQobGFiZWwsIGlucHV0KSB7XG4gICAgaWYgKCFOdW1iZXIuaXNGaW5pdGUoaW5wdXQpKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoYEludmFsaWQgJHtsYWJlbH0gaW5wdXRgKTtcbiAgICB9XG4gICAgcmV0dXJuIGlucHV0O1xufVxuZXhwb3J0IGNsYXNzIFByb2R1Y2VKV1Qge1xuICAgIGNvbnN0cnVjdG9yKHBheWxvYWQgPSB7fSkge1xuICAgICAgICBpZiAoIWlzT2JqZWN0KHBheWxvYWQpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdKV1QgQ2xhaW1zIFNldCBNVVNUIGJlIGFuIG9iamVjdCcpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuX3BheWxvYWQgPSBwYXlsb2FkO1xuICAgIH1cbiAgICBzZXRJc3N1ZXIoaXNzdWVyKSB7XG4gICAgICAgIHRoaXMuX3BheWxvYWQgPSB7IC4uLnRoaXMuX3BheWxvYWQsIGlzczogaXNzdWVyIH07XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBzZXRTdWJqZWN0KHN1YmplY3QpIHtcbiAgICAgICAgdGhpcy5fcGF5bG9hZCA9IHsgLi4udGhpcy5fcGF5bG9hZCwgc3ViOiBzdWJqZWN0IH07XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBzZXRBdWRpZW5jZShhdWRpZW5jZSkge1xuICAgICAgICB0aGlzLl9wYXlsb2FkID0geyAuLi50aGlzLl9wYXlsb2FkLCBhdWQ6IGF1ZGllbmNlIH07XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBzZXRKdGkoand0SWQpIHtcbiAgICAgICAgdGhpcy5fcGF5bG9hZCA9IHsgLi4udGhpcy5fcGF5bG9hZCwganRpOiBqd3RJZCB9O1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgc2V0Tm90QmVmb3JlKGlucHV0KSB7XG4gICAgICAgIGlmICh0eXBlb2YgaW5wdXQgPT09ICdudW1iZXInKSB7XG4gICAgICAgICAgICB0aGlzLl9wYXlsb2FkID0geyAuLi50aGlzLl9wYXlsb2FkLCBuYmY6IHZhbGlkYXRlSW5wdXQoJ3NldE5vdEJlZm9yZScsIGlucHV0KSB9O1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGlucHV0IGluc3RhbmNlb2YgRGF0ZSkge1xuICAgICAgICAgICAgdGhpcy5fcGF5bG9hZCA9IHsgLi4udGhpcy5fcGF5bG9hZCwgbmJmOiB2YWxpZGF0ZUlucHV0KCdzZXROb3RCZWZvcmUnLCBlcG9jaChpbnB1dCkpIH07XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLl9wYXlsb2FkID0geyAuLi50aGlzLl9wYXlsb2FkLCBuYmY6IGVwb2NoKG5ldyBEYXRlKCkpICsgc2VjcyhpbnB1dCkgfTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgc2V0RXhwaXJhdGlvblRpbWUoaW5wdXQpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBpbnB1dCA9PT0gJ251bWJlcicpIHtcbiAgICAgICAgICAgIHRoaXMuX3BheWxvYWQgPSB7IC4uLnRoaXMuX3BheWxvYWQsIGV4cDogdmFsaWRhdGVJbnB1dCgnc2V0RXhwaXJhdGlvblRpbWUnLCBpbnB1dCkgfTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChpbnB1dCBpbnN0YW5jZW9mIERhdGUpIHtcbiAgICAgICAgICAgIHRoaXMuX3BheWxvYWQgPSB7IC4uLnRoaXMuX3BheWxvYWQsIGV4cDogdmFsaWRhdGVJbnB1dCgnc2V0RXhwaXJhdGlvblRpbWUnLCBlcG9jaChpbnB1dCkpIH07XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLl9wYXlsb2FkID0geyAuLi50aGlzLl9wYXlsb2FkLCBleHA6IGVwb2NoKG5ldyBEYXRlKCkpICsgc2VjcyhpbnB1dCkgfTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgc2V0SXNzdWVkQXQoaW5wdXQpIHtcbiAgICAgICAgaWYgKHR5cGVvZiBpbnB1dCA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgIHRoaXMuX3BheWxvYWQgPSB7IC4uLnRoaXMuX3BheWxvYWQsIGlhdDogZXBvY2gobmV3IERhdGUoKSkgfTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChpbnB1dCBpbnN0YW5jZW9mIERhdGUpIHtcbiAgICAgICAgICAgIHRoaXMuX3BheWxvYWQgPSB7IC4uLnRoaXMuX3BheWxvYWQsIGlhdDogdmFsaWRhdGVJbnB1dCgnc2V0SXNzdWVkQXQnLCBlcG9jaChpbnB1dCkpIH07XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAodHlwZW9mIGlucHV0ID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgdGhpcy5fcGF5bG9hZCA9IHtcbiAgICAgICAgICAgICAgICAuLi50aGlzLl9wYXlsb2FkLFxuICAgICAgICAgICAgICAgIGlhdDogdmFsaWRhdGVJbnB1dCgnc2V0SXNzdWVkQXQnLCBlcG9jaChuZXcgRGF0ZSgpKSArIHNlY3MoaW5wdXQpKSxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aGlzLl9wYXlsb2FkID0geyAuLi50aGlzLl9wYXlsb2FkLCBpYXQ6IHZhbGlkYXRlSW5wdXQoJ3NldElzc3VlZEF0JywgaW5wdXQpIH07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxufVxuIiwgImltcG9ydCB7IENvbXBhY3RTaWduIH0gZnJvbSAnLi4vandzL2NvbXBhY3Qvc2lnbi5qcyc7XG5pbXBvcnQgeyBKV1RJbnZhbGlkIH0gZnJvbSAnLi4vdXRpbC9lcnJvcnMuanMnO1xuaW1wb3J0IHsgZW5jb2RlciB9IGZyb20gJy4uL2xpYi9idWZmZXJfdXRpbHMuanMnO1xuaW1wb3J0IHsgUHJvZHVjZUpXVCB9IGZyb20gJy4vcHJvZHVjZS5qcyc7XG5leHBvcnQgY2xhc3MgU2lnbkpXVCBleHRlbmRzIFByb2R1Y2VKV1Qge1xuICAgIHNldFByb3RlY3RlZEhlYWRlcihwcm90ZWN0ZWRIZWFkZXIpIHtcbiAgICAgICAgdGhpcy5fcHJvdGVjdGVkSGVhZGVyID0gcHJvdGVjdGVkSGVhZGVyO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgYXN5bmMgc2lnbihrZXksIG9wdGlvbnMpIHtcbiAgICAgICAgY29uc3Qgc2lnID0gbmV3IENvbXBhY3RTaWduKGVuY29kZXIuZW5jb2RlKEpTT04uc3RyaW5naWZ5KHRoaXMuX3BheWxvYWQpKSk7XG4gICAgICAgIHNpZy5zZXRQcm90ZWN0ZWRIZWFkZXIodGhpcy5fcHJvdGVjdGVkSGVhZGVyKTtcbiAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkodGhpcy5fcHJvdGVjdGVkSGVhZGVyPy5jcml0KSAmJlxuICAgICAgICAgICAgdGhpcy5fcHJvdGVjdGVkSGVhZGVyLmNyaXQuaW5jbHVkZXMoJ2I2NCcpICYmXG4gICAgICAgICAgICB0aGlzLl9wcm90ZWN0ZWRIZWFkZXIuYjY0ID09PSBmYWxzZSkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEpXVEludmFsaWQoJ0pXVHMgTVVTVCBOT1QgdXNlIHVuZW5jb2RlZCBwYXlsb2FkJyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHNpZy5zaWduKGtleSwgb3B0aW9ucyk7XG4gICAgfVxufVxuIiwgImltcG9ydCB7IFNpZ25KV1QsIGltcG9ydFBLQ1M4IH0gZnJvbSAnam9zZSdcblxudHlwZSBUb2tlbiA9IHtcbiAgYWNjZXNzX3Rva2VuOiBzdHJpbmdcbiAgZXhwaXJlc19pbjogbnVtYmVyXG4gIHRva2VuX3R5cGU6IHN0cmluZ1xufVxuXG50eXBlIFRva2VuV2l0aEV4cGlyYXRpb24gPSBUb2tlbiAmIHtcbiAgZXhwaXJlc19hdDogbnVtYmVyXG59XG5cbmxldCB0b2tlbjogVG9rZW5XaXRoRXhwaXJhdGlvbiB8IG51bGwgPSBudWxsXG5cbmFzeW5jIGZ1bmN0aW9uIGNyZWF0ZVRva2VuKG9wdGlvbnM6IHtcbiAgY2xpZW50RW1haWw6IHN0cmluZ1xuICBwcml2YXRlS2V5OiBzdHJpbmdcbn0pIHtcbiAgY29uc3QgcmF3UHJpdmF0ZUtleSA9IG9wdGlvbnMucHJpdmF0ZUtleS5yZXBsYWNlKC9cXFxcbi9nLCAnXFxuJylcbiAgY29uc3QgcHJpdmF0ZUtleSA9IGF3YWl0IGltcG9ydFBLQ1M4KHJhd1ByaXZhdGVLZXksICdSUzI1NicpXG5cbiAgY29uc3QgcGF5bG9hZCA9IHtcbiAgICBpc3M6IG9wdGlvbnMuY2xpZW50RW1haWwsXG4gICAgc2NvcGU6ICdodHRwczovL3d3dy5nb29nbGVhcGlzLmNvbS9hdXRoL2Nsb3VkLXBsYXRmb3JtJyxcbiAgICBhdWQ6ICdodHRwczovL3d3dy5nb29nbGVhcGlzLmNvbS9vYXV0aDIvdjQvdG9rZW4nLFxuICAgIGV4cDogTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCkgKyA2MCAqIDYwLFxuICAgIGlhdDogTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMTAwMCksXG4gIH1cbiAgY29uc3QgdG9rZW4gPSBhd2FpdCBuZXcgU2lnbkpXVChwYXlsb2FkKVxuICAgIC5zZXRQcm90ZWN0ZWRIZWFkZXIoeyBhbGc6ICdSUzI1NicgfSlcbiAgICAuc2V0SXNzdWVkQXQoKVxuICAgIC5zZXRJc3N1ZXIob3B0aW9ucy5jbGllbnRFbWFpbClcbiAgICAuc2V0QXVkaWVuY2UoJ2h0dHBzOi8vd3d3Lmdvb2dsZWFwaXMuY29tL29hdXRoMi92NC90b2tlbicpXG4gICAgLnNldEV4cGlyYXRpb25UaW1lKCcxaCcpXG4gICAgLnNpZ24ocHJpdmF0ZUtleSlcblxuICAvLyBGb3JtIGRhdGEgZm9yIHRoZSB0b2tlbiByZXF1ZXN0XG4gIGNvbnN0IGZvcm0gPSB7XG4gICAgZ3JhbnRfdHlwZTogJ3VybjppZXRmOnBhcmFtczpvYXV0aDpncmFudC10eXBlOmp3dC1iZWFyZXInLFxuICAgIGFzc2VydGlvbjogdG9rZW4sXG4gIH1cblxuICAvLyBNYWtlIHRoZSB0b2tlbiByZXF1ZXN0XG4gIGNvbnN0IHRva2VuUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChcbiAgICAnaHR0cHM6Ly93d3cuZ29vZ2xlYXBpcy5jb20vb2F1dGgyL3Y0L3Rva2VuJyxcbiAgICB7XG4gICAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGZvcm0pLFxuICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgfSxcbiAgKVxuXG4gIGNvbnN0IGpzb24gPSAoYXdhaXQgdG9rZW5SZXNwb25zZS5qc29uKCkpIGFzIFRva2VuXG5cbiAgcmV0dXJuIHtcbiAgICAuLi5qc29uLFxuICAgIGV4cGlyZXNfYXQ6IE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDEwMDApICsganNvbi5leHBpcmVzX2luLFxuICB9XG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhdXRoZW50aWNhdGUob3B0aW9uczoge1xuICBjbGllbnRFbWFpbDogc3RyaW5nXG4gIHByaXZhdGVLZXk6IHN0cmluZ1xufSk6IFByb21pc2U8VG9rZW4+IHtcbiAgaWYgKCFvcHRpb25zLmNsaWVudEVtYWlsIHx8ICFvcHRpb25zLnByaXZhdGVLZXkpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoJ2NsaWVudEVtYWlsIGFuZCBwcml2YXRlS2V5IGFyZSByZXF1aXJlZCcpXG4gIH1cbiAgaWYgKHRva2VuID09PSBudWxsKSB7XG4gICAgdG9rZW4gPSBhd2FpdCBjcmVhdGVUb2tlbihvcHRpb25zKVxuICB9IGVsc2UgaWYgKHRva2VuLmV4cGlyZXNfYXQgPCBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxMDAwKSkge1xuICAgIHRva2VuID0gYXdhaXQgY3JlYXRlVG9rZW4ob3B0aW9ucylcbiAgfVxuICByZXR1cm4gdG9rZW5cbn1cbiIsICJpbXBvcnQgKiBhcyBDb3JlIGZyb20gJ0BhbnRocm9waWMtYWkvc2RrL2NvcmUnXG5pbXBvcnQgKiBhcyBSZXNvdXJjZXMgZnJvbSAnQGFudGhyb3BpYy1haS9zZGsvcmVzb3VyY2VzL2luZGV4J1xuaW1wb3J0IHR5cGUgKiBhcyBBUEkgZnJvbSAnQGFudGhyb3BpYy1haS9zZGsvaW5kZXgnXG5pbXBvcnQgeyB0eXBlIFJlcXVlc3RJbml0IH0gZnJvbSAnQGFudGhyb3BpYy1haS9zZGsvX3NoaW1zL2luZGV4J1xuaW1wb3J0IHsgYXV0aGVudGljYXRlIH0gZnJvbSAnLi9hdXRoZW50aWNhdGUnXG5cbmNvbnN0IERFRkFVTFRfVkVSU0lPTiA9ICd2ZXJ0ZXgtMjAyMy0xMC0xNidcblxuZXhwb3J0IHR5cGUgQ2xpZW50T3B0aW9ucyA9IE9taXQ8QVBJLkNsaWVudE9wdGlvbnMsICdhcGlLZXknIHwgJ2F1dGhUb2tlbic+ICYge1xuICByZWdpb24/OiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkXG4gIHByb2plY3RJZD86IHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWRcbiAgYWNjZXNzVG9rZW4/OiBzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkXG4gIGNsaWVudEVtYWlsPzogc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZFxuICBwcml2YXRlS2V5Pzogc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZFxufVxuXG5leHBvcnQgY2xhc3MgQW50aHJvcGljVmVydGV4V2ViIGV4dGVuZHMgQ29yZS5BUElDbGllbnQge1xuICByZWdpb246IHN0cmluZ1xuICBwcm9qZWN0SWQ6IHN0cmluZyB8IG51bGxcbiAgYWNjZXNzVG9rZW46IHN0cmluZyB8IG51bGxcblxuICBwcml2YXRlIF9vcHRpb25zOiBDbGllbnRPcHRpb25zXG5cbiAgY29uc3RydWN0b3Ioe1xuICAgIGJhc2VVUkwgPSBDb3JlLnJlYWRFbnYoJ0FOVEhST1BJQ19WRVJURVhfQkFTRV9VUkwnKSxcbiAgICByZWdpb24gPSBDb3JlLnJlYWRFbnYoJ0NMT1VEX01MX1JFR0lPTicpID8/IG51bGwsXG4gICAgcHJvamVjdElkID0gQ29yZS5yZWFkRW52KCdBTlRIUk9QSUNfVkVSVEVYX1BST0pFQ1RfSUQnKSA/PyBudWxsLFxuICAgIGFjY2Vzc1Rva2VuID0gQ29yZS5yZWFkRW52KCdBTlRIUk9QSUNfVkVSVEVYX0FDQ0VTU19UT0tFTicpID8/IG51bGwsXG4gICAgY2xpZW50RW1haWwgPSBDb3JlLnJlYWRFbnYoJ0FOVEhST1BJQ19WRVJURVhfQ0xJRU5UX0VNQUlMJykgPz8gbnVsbCxcbiAgICBwcml2YXRlS2V5ID0gQ29yZS5yZWFkRW52KCdBTlRIUk9QSUNfVkVSVEVYX1BSSVZBVEVfS0VZJykgPz8gbnVsbCxcbiAgICAuLi5vcHRzXG4gIH06IENsaWVudE9wdGlvbnMgPSB7fSkge1xuICAgIGlmICghcmVnaW9uKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdObyByZWdpb24gd2FzIGdpdmVuLiBUaGUgY2xpZW50IHNob3VsZCBiZSBpbnN0YW50aWF0ZWQgd2l0aCB0aGUgYHJlZ2lvbmAgb3B0aW9uIG9yIHRoZSBgQ0xPVURfTUxfUkVHSU9OYCBlbnZpcm9ubWVudCB2YXJpYWJsZSBzaG91bGQgYmUgc2V0LicsXG4gICAgICApXG4gICAgfVxuXG4gICAgY29uc3Qgb3B0aW9uczogQ2xpZW50T3B0aW9ucyA9IHtcbiAgICAgIC4uLm9wdHMsXG4gICAgICBiYXNlVVJMOiBiYXNlVVJMIHx8IGBodHRwczovLyR7cmVnaW9ufS1haXBsYXRmb3JtLmdvb2dsZWFwaXMuY29tL3YxYCxcbiAgICAgIGNsaWVudEVtYWlsLFxuICAgICAgcHJpdmF0ZUtleSxcbiAgICB9XG5cbiAgICBzdXBlcih7XG4gICAgICBiYXNlVVJMOiBvcHRpb25zLmJhc2VVUkwhLFxuICAgICAgdGltZW91dDogb3B0aW9ucy50aW1lb3V0ID8/IDYwMDAwMCAvKiAxMCBtaW51dGVzICovLFxuICAgICAgaHR0cEFnZW50OiBvcHRpb25zLmh0dHBBZ2VudCxcbiAgICAgIG1heFJldHJpZXM6IG9wdGlvbnMubWF4UmV0cmllcyxcbiAgICAgIGZldGNoOiBvcHRpb25zLmZldGNoLFxuICAgIH0pXG4gICAgdGhpcy5fb3B0aW9ucyA9IG9wdGlvbnNcblxuICAgIHRoaXMucmVnaW9uID0gcmVnaW9uXG4gICAgdGhpcy5wcm9qZWN0SWQgPSBwcm9qZWN0SWRcbiAgICB0aGlzLmFjY2Vzc1Rva2VuID0gYWNjZXNzVG9rZW5cbiAgfVxuXG4gIG1lc3NhZ2VzOiBSZXNvdXJjZXMuTWVzc2FnZXMgPSBuZXcgUmVzb3VyY2VzLk1lc3NhZ2VzKHRoaXMpXG5cbiAgcHJvdGVjdGVkIG92ZXJyaWRlIGRlZmF1bHRRdWVyeSgpOiBDb3JlLkRlZmF1bHRRdWVyeSB8IHVuZGVmaW5lZCB7XG4gICAgcmV0dXJuIHRoaXMuX29wdGlvbnMuZGVmYXVsdFF1ZXJ5XG4gIH1cblxuICBwcm90ZWN0ZWQgb3ZlcnJpZGUgZGVmYXVsdEhlYWRlcnMoXG4gICAgb3B0czogQ29yZS5GaW5hbFJlcXVlc3RPcHRpb25zLFxuICApOiBDb3JlLkhlYWRlcnMge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5zdXBlci5kZWZhdWx0SGVhZGVycyhvcHRzKSxcbiAgICAgIC4uLnRoaXMuX29wdGlvbnMuZGVmYXVsdEhlYWRlcnMsXG4gICAgfVxuICB9XG5cbiAgcHJvdGVjdGVkIG92ZXJyaWRlIGFzeW5jIHByZXBhcmVPcHRpb25zKFxuICAgIG9wdGlvbnM6IENvcmUuRmluYWxSZXF1ZXN0T3B0aW9ucyxcbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgaWYgKCF0aGlzLmFjY2Vzc1Rva2VuKSB7XG4gICAgICBpZiAoIXRoaXMuX29wdGlvbnMuY2xpZW50RW1haWwgfHwgIXRoaXMuX29wdGlvbnMucHJpdmF0ZUtleSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgJ05vIGNsaWVudEVtYWlsIG9yIHByaXZhdGVLZXkgd2FzIHByb3ZpZGVkLiBTZXQgaXQgaW4gdGhlIGNvbnN0cnVjdG9yIG9yIHVzZSB0aGUgQU5USFJPUElDX1ZFUlRFWF9DTElFTlRfRU1BSUwgYW5kIEFOVEhST1BJQ19WRVJURVhfUFJJVkFURV9LRVkgZW52aXJvbm1lbnQgdmFyaWFibGVzLicsXG4gICAgICAgIClcbiAgICAgIH1cbiAgICAgIHRoaXMuYWNjZXNzVG9rZW4gPSAoXG4gICAgICAgIGF3YWl0IGF1dGhlbnRpY2F0ZSh7XG4gICAgICAgICAgY2xpZW50RW1haWw6IHRoaXMuX29wdGlvbnMuY2xpZW50RW1haWwsXG4gICAgICAgICAgcHJpdmF0ZUtleTogdGhpcy5fb3B0aW9ucy5wcml2YXRlS2V5LFxuICAgICAgICB9KVxuICAgICAgKS5hY2Nlc3NfdG9rZW5cbiAgICB9XG5cbiAgICBvcHRpb25zLmhlYWRlcnMgPSB7XG4gICAgICAuLi5vcHRpb25zLmhlYWRlcnMsXG4gICAgICBBdXRob3JpemF0aW9uOiBgQmVhcmVyICR7dGhpcy5hY2Nlc3NUb2tlbn1gLFxuICAgICAgJ3gtZ29vZy11c2VyLXByb2plY3QnOiB0aGlzLnByb2plY3RJZCxcbiAgICB9XG4gIH1cblxuICBvdmVycmlkZSBidWlsZFJlcXVlc3Qob3B0aW9uczogQ29yZS5GaW5hbFJlcXVlc3RPcHRpb25zPHVua25vd24+KToge1xuICAgIHJlcTogUmVxdWVzdEluaXRcbiAgICB1cmw6IHN0cmluZ1xuICAgIHRpbWVvdXQ6IG51bWJlclxuICB9IHtcbiAgICBpZiAoQ29yZS5pc09iaihvcHRpb25zLmJvZHkpKSB7XG4gICAgICBpZiAoIW9wdGlvbnMuYm9keVsnYW50aHJvcGljX3ZlcnNpb24nXSkge1xuICAgICAgICBvcHRpb25zLmJvZHlbJ2FudGhyb3BpY192ZXJzaW9uJ10gPSBERUZBVUxUX1ZFUlNJT05cbiAgICAgIH1cbiAgICB9XG5cbiAgICBpZiAob3B0aW9ucy5wYXRoID09PSAnL3YxL21lc3NhZ2VzJyAmJiBvcHRpb25zLm1ldGhvZCA9PT0gJ3Bvc3QnKSB7XG4gICAgICBpZiAoIXRoaXMucHJvamVjdElkKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAnTm8gcHJvamVjdElkIHdhcyBnaXZlbiBhbmQgaXQgY291bGQgbm90IGJlIHJlc29sdmVkIGZyb20gY3JlZGVudGlhbHMuIFRoZSBjbGllbnQgc2hvdWxkIGJlIGluc3RhbnRpYXRlZCB3aXRoIHRoZSBgcHJvamVjdElkYCBvcHRpb24gb3IgdGhlIGBBTlRIUk9QSUNfVkVSVEVYX1BST0pFQ1RfSURgIGVudmlyb25tZW50IHZhcmlhYmxlIHNob3VsZCBiZSBzZXQuJyxcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICBpZiAoIUNvcmUuaXNPYmoob3B0aW9ucy5ib2R5KSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgJ0V4cGVjdGVkIHJlcXVlc3QgYm9keSB0byBiZSBhbiBvYmplY3QgZm9yIHBvc3QgL3YxL21lc3NhZ2VzJyxcbiAgICAgICAgKVxuICAgICAgfVxuXG4gICAgICBjb25zdCBtb2RlbCA9IG9wdGlvbnMuYm9keVsnbW9kZWwnXVxuICAgICAgb3B0aW9ucy5ib2R5Wydtb2RlbCddID0gdW5kZWZpbmVkXG5cbiAgICAgIGNvbnN0IHN0cmVhbSA9IG9wdGlvbnMuYm9keVsnc3RyZWFtJ10gPz8gZmFsc2VcblxuICAgICAgY29uc3Qgc3BlY2lmaWVyID0gc3RyZWFtID8gJ3N0cmVhbVJhd1ByZWRpY3QnIDogJ3Jhd1ByZWRpY3QnXG5cbiAgICAgIG9wdGlvbnMucGF0aCA9IGAvcHJvamVjdHMvJHt0aGlzLnByb2plY3RJZH0vbG9jYXRpb25zLyR7dGhpcy5yZWdpb259L3B1Ymxpc2hlcnMvYW50aHJvcGljL21vZGVscy8ke21vZGVsfToke3NwZWNpZmllcn1gXG4gICAgfVxuXG4gICAgcmV0dXJuIHN1cGVyLmJ1aWxkUmVxdWVzdChvcHRpb25zKVxuICB9XG59XG4iXSwKICAibWFwcGluZ3MiOiAiO0FBQUEsWUFBWSxjQUFjOzs7QUNBMUIsU0FBUyxvQkFBb0IsUUFBNkI7QUFDeEQsTUFBSSxTQUFTO0FBQ2IsUUFBTSxRQUFRLElBQUksV0FBVyxNQUFNO0FBQ25DLFdBQVMsSUFBSSxHQUFHLElBQUksTUFBTSxZQUFZLEtBQUs7QUFDekMsY0FBVSxPQUFPLGFBQWEsTUFBTSxDQUFDLENBQUM7QUFBQSxFQUN4QztBQUNBLFNBQU8sS0FBSyxNQUFNO0FBQ3BCO0FBRUEsZUFBc0IsaUJBQWlCLFVBR3BDO0FBRUQsTUFBSSxTQUFTLFdBQVcsT0FBTyxHQUFHO0FBQ2hDLFVBQU0sQ0FBQyxRQUFRLElBQUksSUFBSSxTQUFTLE1BQU0sR0FBRztBQUN6QyxVQUFNLGFBQWEsT0FBTyxNQUFNLEdBQUcsRUFBRSxDQUFDLEVBQUUsTUFBTSxHQUFHLEVBQUUsQ0FBQztBQUNwRCxXQUFPLEVBQUUsWUFBWSxLQUFLO0FBQUEsRUFDNUI7QUFFQSxRQUFNLFdBQVcsTUFBTSxNQUFNLFFBQVE7QUFDckMsUUFBTSxjQUFjLE1BQU0sU0FBUyxZQUFZO0FBRS9DLFFBQU0sU0FBUyxvQkFBb0IsV0FBVztBQUM5QyxTQUFPO0FBQUEsSUFDTCxZQUFZLFNBQVMsUUFBUSxJQUFJLGNBQWMsS0FBSztBQUFBLElBQ3BELE1BQU07QUFBQSxFQUNSO0FBQ0Y7OztBQzVCTyxJQUFNLFVBQVU7OztBQzBCaEIsSUFBSSxPQUFPO0FBQ1gsSUFBSSxPQUFrQztBQUN0QyxJQUFJQSxTQUFvQztBQUN4QyxJQUFJQyxXQUF3QztBQUM1QyxJQUFJQyxZQUEwQztBQUM5QyxJQUFJQyxXQUF3QztBQUM1QyxJQUFJQyxZQUEwQztBQUM5QyxJQUFJQyxRQUFrQztBQUN0QyxJQUFJQyxRQUFrQztBQUN0QyxJQUFJQyxrQkFBc0Q7QUFDMUQsSUFBSSw2QkFBOEU7QUFDbEYsSUFBSSxrQkFBd0Q7QUFDNUQsSUFBSSxlQUFrRDtBQUN0RCxJQUFJLGlCQUFzRDtBQUUzRCxTQUFVLFNBQVMsT0FBYyxVQUE2QixFQUFFLE1BQU0sTUFBSyxHQUFFO0FBQ2pGLE1BQUksTUFBTTtBQUNSLFVBQU0sSUFBSSxNQUNSLDhDQUE4QyxNQUFNLElBQUksMkRBQTJEOztBQUd2SCxNQUFJLE1BQU07QUFDUixVQUFNLElBQUksTUFDUiwyQ0FBMkMsTUFBTSxJQUFJLCtDQUErQyxJQUFJLEtBQUs7O0FBR2pILFNBQU8sUUFBUTtBQUNmLFNBQU8sTUFBTTtBQUNiLEVBQUFQLFNBQVEsTUFBTTtBQUNkLEVBQUFDLFdBQVUsTUFBTTtBQUNoQixFQUFBQyxZQUFXLE1BQU07QUFDakIsRUFBQUMsV0FBVSxNQUFNO0FBQ2hCLEVBQUFDLFlBQVcsTUFBTTtBQUNqQixFQUFBQyxRQUFPLE1BQU07QUFDYixFQUFBQyxRQUFPLE1BQU07QUFDYixFQUFBQyxrQkFBaUIsTUFBTTtBQUN2QiwrQkFBNkIsTUFBTTtBQUNuQyxvQkFBa0IsTUFBTTtBQUN4QixpQkFBZSxNQUFNO0FBQ3JCLG1CQUFpQixNQUFNO0FBQ3pCOzs7QUMvRE0sSUFBTyxnQkFBUCxNQUFvQjtFQUN4QixZQUFtQixNQUFTO0FBQVQsU0FBQSxPQUFBO0VBQVk7RUFDL0IsS0FBSyxPQUFPLFdBQVcsSUFBQztBQUN0QixXQUFPO0VBQ1Q7Ozs7QUNBSSxTQUFVLFdBQVcsRUFBRSxpQkFBZ0IsSUFBcUMsQ0FBQSxHQUFFO0FBQ2xGLFFBQU0saUJBQ0osbUJBQ0Usa0NBQ0E7Ozs7QUFLSixNQUFJLFFBQVEsVUFBVSxXQUFXO0FBQ2pDLE1BQUk7QUFFRixhQUFTO0FBRVQsZUFBVztBQUVYLGdCQUFZO0FBRVosZUFBVztXQUNKLE9BQU87QUFDZCxVQUFNLElBQUksTUFDUixpRUFDRyxNQUFjLE9BQ2pCLEtBQUssY0FBYyxFQUFFOztBQUl6QixTQUFPO0lBQ0wsTUFBTTtJQUNOLE9BQU87SUFDUCxTQUFTO0lBQ1QsVUFBVTtJQUNWLFNBQVM7SUFDVDs7TUFFRSxPQUFPLGFBQWEsY0FBYyxXQUNoQyxNQUFNLFNBQVE7O1FBRVosY0FBQTtBQUNFLGdCQUFNLElBQUksTUFDUixxRkFBcUYsY0FBYyxFQUFFO1FBRXpHOzs7SUFHTixNQUNFLE9BQU8sU0FBUyxjQUFjLE9BQzVCLE1BQU0sS0FBSTtNQUNSLGNBQUE7QUFDRSxjQUFNLElBQUksTUFDUixpRkFBaUYsY0FBYyxFQUFFO01BRXJHOztJQUdOOztNQUVFLE9BQU8sU0FBUyxjQUFjLE9BQzVCLE1BQU0sS0FBSTs7UUFFUixjQUFBO0FBQ0UsZ0JBQU0sSUFBSSxNQUNSLGlGQUFpRixjQUFjLEVBQUU7UUFFckc7OztJQUdOOztNQUVFLE9BQU8sbUJBQW1CLGNBQWMsaUJBQ3RDLE1BQU0sZUFBYzs7UUFFbEIsY0FBQTtBQUNFLGdCQUFNLElBQUksTUFDUix1RkFBdUYsY0FBYyxFQUFFO1FBRTNHOzs7SUFHTiw0QkFBNEIsT0FFMUIsTUFDQSxVQUNnQztNQUNoQyxHQUFHO01BQ0gsTUFBTSxJQUFJLGNBQWMsSUFBSTs7SUFFOUIsaUJBQWlCLENBQUMsUUFBZ0I7SUFDbEMsY0FBYyxNQUFLO0FBQ2pCLFlBQU0sSUFBSSxNQUNSLGlLQUFpSztJQUVySztJQUNBLGdCQUFnQixDQUFDLFVBQWU7O0FBRXBDOzs7QUNqR0EsSUFBSSxDQUFPLEtBQU0sQ0FBTSxTQUFjLFdBQVcsR0FBRyxFQUFFLE1BQU0sS0FBSyxDQUFDOzs7QUNEM0QsSUFBTyxpQkFBUCxjQUE4QixNQUFLOztBQUVuQyxJQUFPLFdBQVAsTUFBTyxrQkFBaUIsZUFBYztFQU8xQyxZQUNFLFFBQ0EsT0FDQUMsVUFDQSxTQUE0QjtBQUU1QixVQUFNLEdBQUcsVUFBUyxZQUFZLFFBQVEsT0FBT0EsUUFBTyxDQUFDLEVBQUU7QUFDdkQsU0FBSyxTQUFTO0FBQ2QsU0FBSyxVQUFVO0FBQ2YsU0FBSyxhQUFhLFVBQVUsWUFBWTtBQUN4QyxTQUFLLFFBQVE7RUFDZjtFQUVRLE9BQU8sWUFBWSxRQUE0QixPQUFZQSxVQUEyQjtBQUM1RixVQUFNLE1BQ0osT0FBTyxVQUNMLE9BQU8sTUFBTSxZQUFZLFdBQ3ZCLE1BQU0sVUFDTixLQUFLLFVBQVUsTUFBTSxPQUFPLElBQzlCLFFBQVEsS0FBSyxVQUFVLEtBQUssSUFDNUJBO0FBRUosUUFBSSxVQUFVLEtBQUs7QUFDakIsYUFBTyxHQUFHLE1BQU0sSUFBSSxHQUFHOztBQUV6QixRQUFJLFFBQVE7QUFDVixhQUFPLEdBQUcsTUFBTTs7QUFFbEIsUUFBSSxLQUFLO0FBQ1AsYUFBTzs7QUFFVCxXQUFPO0VBQ1Q7RUFFQSxPQUFPLFNBQ0wsUUFDQSxlQUNBQSxVQUNBLFNBQTRCO0FBRTVCLFFBQUksQ0FBQyxRQUFRO0FBQ1gsYUFBTyxJQUFJLG1CQUFtQixFQUFFLFNBQUFBLFVBQVMsT0FBTyxZQUFZLGFBQWEsRUFBQyxDQUFFOztBQUc5RSxVQUFNLFFBQVE7QUFFZCxRQUFJLFdBQVcsS0FBSztBQUNsQixhQUFPLElBQUksZ0JBQWdCLFFBQVEsT0FBT0EsVUFBUyxPQUFPOztBQUc1RCxRQUFJLFdBQVcsS0FBSztBQUNsQixhQUFPLElBQUksb0JBQW9CLFFBQVEsT0FBT0EsVUFBUyxPQUFPOztBQUdoRSxRQUFJLFdBQVcsS0FBSztBQUNsQixhQUFPLElBQUksc0JBQXNCLFFBQVEsT0FBT0EsVUFBUyxPQUFPOztBQUdsRSxRQUFJLFdBQVcsS0FBSztBQUNsQixhQUFPLElBQUksY0FBYyxRQUFRLE9BQU9BLFVBQVMsT0FBTzs7QUFHMUQsUUFBSSxXQUFXLEtBQUs7QUFDbEIsYUFBTyxJQUFJLGNBQWMsUUFBUSxPQUFPQSxVQUFTLE9BQU87O0FBRzFELFFBQUksV0FBVyxLQUFLO0FBQ2xCLGFBQU8sSUFBSSx5QkFBeUIsUUFBUSxPQUFPQSxVQUFTLE9BQU87O0FBR3JFLFFBQUksV0FBVyxLQUFLO0FBQ2xCLGFBQU8sSUFBSSxlQUFlLFFBQVEsT0FBT0EsVUFBUyxPQUFPOztBQUczRCxRQUFJLFVBQVUsS0FBSztBQUNqQixhQUFPLElBQUksb0JBQW9CLFFBQVEsT0FBT0EsVUFBUyxPQUFPOztBQUdoRSxXQUFPLElBQUksVUFBUyxRQUFRLE9BQU9BLFVBQVMsT0FBTztFQUNyRDs7QUFHSSxJQUFPLG9CQUFQLGNBQWlDLFNBQVE7RUFHN0MsWUFBWSxFQUFFLFNBQUFBLFNBQU8sSUFBMkIsQ0FBQSxHQUFFO0FBQ2hELFVBQU0sUUFBVyxRQUFXQSxZQUFXLHdCQUF3QixNQUFTO0FBSHhELFNBQUEsU0FBb0I7RUFJdEM7O0FBR0ksSUFBTyxxQkFBUCxjQUFrQyxTQUFRO0VBRzlDLFlBQVksRUFBRSxTQUFBQSxVQUFTLE1BQUssR0FBK0Q7QUFDekYsVUFBTSxRQUFXLFFBQVdBLFlBQVcscUJBQXFCLE1BQVM7QUFIckQsU0FBQSxTQUFvQjtBQU1wQyxRQUFJO0FBQU8sV0FBSyxRQUFRO0VBQzFCOztBQUdJLElBQU8sNEJBQVAsY0FBeUMsbUJBQWtCO0VBQy9ELFlBQVksRUFBRSxTQUFBQSxTQUFPLElBQTJCLENBQUEsR0FBRTtBQUNoRCxVQUFNLEVBQUUsU0FBU0EsWUFBVyxxQkFBb0IsQ0FBRTtFQUNwRDs7QUFHSSxJQUFPLGtCQUFQLGNBQStCLFNBQVE7RUFBN0MsY0FBQTs7QUFDb0IsU0FBQSxTQUFjO0VBQ2xDOztBQUVNLElBQU8sc0JBQVAsY0FBbUMsU0FBUTtFQUFqRCxjQUFBOztBQUNvQixTQUFBLFNBQWM7RUFDbEM7O0FBRU0sSUFBTyx3QkFBUCxjQUFxQyxTQUFRO0VBQW5ELGNBQUE7O0FBQ29CLFNBQUEsU0FBYztFQUNsQzs7QUFFTSxJQUFPLGdCQUFQLGNBQTZCLFNBQVE7RUFBM0MsY0FBQTs7QUFDb0IsU0FBQSxTQUFjO0VBQ2xDOztBQUVNLElBQU8sZ0JBQVAsY0FBNkIsU0FBUTtFQUEzQyxjQUFBOztBQUNvQixTQUFBLFNBQWM7RUFDbEM7O0FBRU0sSUFBTywyQkFBUCxjQUF3QyxTQUFRO0VBQXRELGNBQUE7O0FBQ29CLFNBQUEsU0FBYztFQUNsQzs7QUFFTSxJQUFPLGlCQUFQLGNBQThCLFNBQVE7RUFBNUMsY0FBQTs7QUFDb0IsU0FBQSxTQUFjO0VBQ2xDOztBQUVNLElBQU8sc0JBQVAsY0FBbUMsU0FBUTs7OztBQ3RJM0MsSUFBTyxTQUFQLE1BQU8sUUFBTTtFQUdqQixZQUNVLFVBQ1IsWUFBMkI7QUFEbkIsU0FBQSxXQUFBO0FBR1IsU0FBSyxhQUFhO0VBQ3BCO0VBRUEsT0FBTyxnQkFBc0IsVUFBb0IsWUFBMkI7QUFDMUUsUUFBSSxXQUFXO0FBRWYsb0JBQWdCLFdBQVE7QUFDdEIsVUFBSSxVQUFVO0FBQ1osY0FBTSxJQUFJLE1BQU0sMEVBQTBFOztBQUU1RixpQkFBVztBQUNYLFVBQUksT0FBTztBQUNYLFVBQUk7QUFDRix5QkFBaUIsT0FBTyxpQkFBaUIsVUFBVSxVQUFVLEdBQUc7QUFDOUQsY0FBSSxJQUFJLFVBQVUsY0FBYztBQUM5QixnQkFBSTtBQUNGLG9CQUFNLEtBQUssTUFBTSxJQUFJLElBQUk7cUJBQ2xCLEdBQUc7QUFDVixzQkFBUSxNQUFNLHNDQUFzQyxJQUFJLElBQUk7QUFDNUQsc0JBQVEsTUFBTSxlQUFlLElBQUksR0FBRztBQUNwQyxvQkFBTTs7O0FBSVYsY0FDRSxJQUFJLFVBQVUsbUJBQ2QsSUFBSSxVQUFVLG1CQUNkLElBQUksVUFBVSxrQkFDZCxJQUFJLFVBQVUseUJBQ2QsSUFBSSxVQUFVLHlCQUNkLElBQUksVUFBVSxzQkFDZDtBQUNBLGdCQUFJO0FBQ0Ysb0JBQU0sS0FBSyxNQUFNLElBQUksSUFBSTtxQkFDbEIsR0FBRztBQUNWLHNCQUFRLE1BQU0sc0NBQXNDLElBQUksSUFBSTtBQUM1RCxzQkFBUSxNQUFNLGVBQWUsSUFBSSxHQUFHO0FBQ3BDLG9CQUFNOzs7QUFJVixjQUFJLElBQUksVUFBVSxRQUFRO0FBQ3hCOztBQUdGLGNBQUksSUFBSSxVQUFVLFNBQVM7QUFDekIsa0JBQU0sU0FBUyxTQUNiLFFBQ0EsY0FBYyxJQUFJLElBQUksSUFDdEIsSUFBSSxNQUNKLHNCQUFzQixTQUFTLE9BQU8sQ0FBQzs7O0FBSTdDLGVBQU87ZUFDQSxHQUFHO0FBRVYsWUFBSSxhQUFhLFNBQVMsRUFBRSxTQUFTO0FBQWM7QUFDbkQsY0FBTTs7QUFHTixZQUFJLENBQUM7QUFBTSxxQkFBVyxNQUFLOztJQUUvQjtBQUVBLFdBQU8sSUFBSSxRQUFPLFVBQVUsVUFBVTtFQUN4Qzs7Ozs7RUFNQSxPQUFPLG1CQUF5QixnQkFBZ0MsWUFBMkI7QUFDekYsUUFBSSxXQUFXO0FBRWYsb0JBQWdCLFlBQVM7QUFDdkIsWUFBTSxjQUFjLElBQUksWUFBVztBQUVuQyxZQUFNLE9BQU8sNEJBQW1DLGNBQWM7QUFDOUQsdUJBQWlCLFNBQVMsTUFBTTtBQUM5QixtQkFBVyxRQUFRLFlBQVksT0FBTyxLQUFLLEdBQUc7QUFDNUMsZ0JBQU07OztBQUlWLGlCQUFXLFFBQVEsWUFBWSxNQUFLLEdBQUk7QUFDdEMsY0FBTTs7SUFFVjtBQUVBLG9CQUFnQixXQUFRO0FBQ3RCLFVBQUksVUFBVTtBQUNaLGNBQU0sSUFBSSxNQUFNLDBFQUEwRTs7QUFFNUYsaUJBQVc7QUFDWCxVQUFJLE9BQU87QUFDWCxVQUFJO0FBQ0YseUJBQWlCLFFBQVEsVUFBUyxHQUFJO0FBQ3BDLGNBQUk7QUFBTTtBQUNWLGNBQUk7QUFBTSxrQkFBTSxLQUFLLE1BQU0sSUFBSTs7QUFFakMsZUFBTztlQUNBLEdBQUc7QUFFVixZQUFJLGFBQWEsU0FBUyxFQUFFLFNBQVM7QUFBYztBQUNuRCxjQUFNOztBQUdOLFlBQUksQ0FBQztBQUFNLHFCQUFXLE1BQUs7O0lBRS9CO0FBRUEsV0FBTyxJQUFJLFFBQU8sVUFBVSxVQUFVO0VBQ3hDO0VBRUEsQ0FBQyxPQUFPLGFBQWEsSUFBQztBQUNwQixXQUFPLEtBQUssU0FBUTtFQUN0Qjs7Ozs7RUFNQSxNQUFHO0FBQ0QsVUFBTSxPQUE2QyxDQUFBO0FBQ25ELFVBQU0sUUFBOEMsQ0FBQTtBQUNwRCxVQUFNLFdBQVcsS0FBSyxTQUFRO0FBRTlCLFVBQU0sY0FBYyxDQUFDLFVBQW9FO0FBQ3ZGLGFBQU87UUFDTCxNQUFNLE1BQUs7QUFDVCxjQUFJLE1BQU0sV0FBVyxHQUFHO0FBQ3RCLGtCQUFNLFNBQVMsU0FBUyxLQUFJO0FBQzVCLGlCQUFLLEtBQUssTUFBTTtBQUNoQixrQkFBTSxLQUFLLE1BQU07O0FBRW5CLGlCQUFPLE1BQU0sTUFBSztRQUNwQjs7SUFFSjtBQUVBLFdBQU87TUFDTCxJQUFJLFFBQU8sTUFBTSxZQUFZLElBQUksR0FBRyxLQUFLLFVBQVU7TUFDbkQsSUFBSSxRQUFPLE1BQU0sWUFBWSxLQUFLLEdBQUcsS0FBSyxVQUFVOztFQUV4RDs7Ozs7O0VBT0EsbUJBQWdCO0FBQ2QsVUFBTSxPQUFPO0FBQ2IsUUFBSTtBQUNKLFVBQU1DLFdBQVUsSUFBSSxZQUFXO0FBRS9CLFdBQU8sSUFBSUMsZ0JBQWU7TUFDeEIsTUFBTSxRQUFLO0FBQ1QsZUFBTyxLQUFLLE9BQU8sYUFBYSxFQUFDO01BQ25DO01BQ0EsTUFBTSxLQUFLLE1BQVM7QUFDbEIsWUFBSTtBQUNGLGdCQUFNLEVBQUUsT0FBTyxLQUFJLElBQUssTUFBTSxLQUFLLEtBQUk7QUFDdkMsY0FBSTtBQUFNLG1CQUFPLEtBQUssTUFBSztBQUUzQixnQkFBTSxRQUFRRCxTQUFRLE9BQU8sS0FBSyxVQUFVLEtBQUssSUFBSSxJQUFJO0FBRXpELGVBQUssUUFBUSxLQUFLO2lCQUNYLEtBQUs7QUFDWixlQUFLLE1BQU0sR0FBRzs7TUFFbEI7TUFDQSxNQUFNLFNBQU07QUFDVixjQUFNLEtBQUssU0FBUTtNQUNyQjtLQUNEO0VBQ0g7O0FBR0YsZ0JBQXVCLGlCQUNyQixVQUNBLFlBQTJCO0FBRTNCLE1BQUksQ0FBQyxTQUFTLE1BQU07QUFDbEIsZUFBVyxNQUFLO0FBQ2hCLFVBQU0sSUFBSSxlQUFlLG1EQUFtRDs7QUFHOUUsUUFBTSxhQUFhLElBQUksV0FBVTtBQUNqQyxRQUFNLGNBQWMsSUFBSSxZQUFXO0FBRW5DLFFBQU0sT0FBTyw0QkFBbUMsU0FBUyxJQUFJO0FBQzdELG1CQUFpQixZQUFZLGNBQWMsSUFBSSxHQUFHO0FBQ2hELGVBQVcsUUFBUSxZQUFZLE9BQU8sUUFBUSxHQUFHO0FBQy9DLFlBQU0sTUFBTSxXQUFXLE9BQU8sSUFBSTtBQUNsQyxVQUFJO0FBQUssY0FBTTs7O0FBSW5CLGFBQVcsUUFBUSxZQUFZLE1BQUssR0FBSTtBQUN0QyxVQUFNLE1BQU0sV0FBVyxPQUFPLElBQUk7QUFDbEMsUUFBSTtBQUFLLFlBQU07O0FBRW5CO0FBTUEsZ0JBQWdCLGNBQWMsVUFBc0M7QUFDbEUsTUFBSSxPQUFPLElBQUksV0FBVTtBQUV6QixtQkFBaUIsU0FBUyxVQUFVO0FBQ2xDLFFBQUksU0FBUyxNQUFNO0FBQ2pCOztBQUdGLFVBQU0sY0FDSixpQkFBaUIsY0FBYyxJQUFJLFdBQVcsS0FBSyxJQUNqRCxPQUFPLFVBQVUsV0FBVyxJQUFJLFlBQVcsRUFBRyxPQUFPLEtBQUssSUFDMUQ7QUFFSixRQUFJLFVBQVUsSUFBSSxXQUFXLEtBQUssU0FBUyxZQUFZLE1BQU07QUFDN0QsWUFBUSxJQUFJLElBQUk7QUFDaEIsWUFBUSxJQUFJLGFBQWEsS0FBSyxNQUFNO0FBQ3BDLFdBQU87QUFFUCxRQUFJO0FBQ0osWUFBUSxlQUFlLHVCQUF1QixJQUFJLE9BQU8sSUFBSTtBQUMzRCxZQUFNLEtBQUssTUFBTSxHQUFHLFlBQVk7QUFDaEMsYUFBTyxLQUFLLE1BQU0sWUFBWTs7O0FBSWxDLE1BQUksS0FBSyxTQUFTLEdBQUc7QUFDbkIsVUFBTTs7QUFFVjtBQUVBLFNBQVMsdUJBQXVCLFFBQWtCO0FBSWhELFFBQU0sVUFBVTtBQUNoQixRQUFNLFdBQVc7QUFFakIsV0FBUyxJQUFJLEdBQUcsSUFBSSxPQUFPLFNBQVMsR0FBRyxLQUFLO0FBQzFDLFFBQUksT0FBTyxDQUFDLE1BQU0sV0FBVyxPQUFPLElBQUksQ0FBQyxNQUFNLFNBQVM7QUFFdEQsYUFBTyxJQUFJOztBQUViLFFBQUksT0FBTyxDQUFDLE1BQU0sWUFBWSxPQUFPLElBQUksQ0FBQyxNQUFNLFVBQVU7QUFFeEQsYUFBTyxJQUFJOztBQUViLFFBQ0UsT0FBTyxDQUFDLE1BQU0sWUFDZCxPQUFPLElBQUksQ0FBQyxNQUFNLFdBQ2xCLElBQUksSUFBSSxPQUFPLFVBQ2YsT0FBTyxJQUFJLENBQUMsTUFBTSxZQUNsQixPQUFPLElBQUksQ0FBQyxNQUFNLFNBQ2xCO0FBRUEsYUFBTyxJQUFJOzs7QUFJZixTQUFPO0FBQ1Q7QUFFQSxJQUFNLGFBQU4sTUFBZ0I7RUFLZCxjQUFBO0FBQ0UsU0FBSyxRQUFRO0FBQ2IsU0FBSyxPQUFPLENBQUE7QUFDWixTQUFLLFNBQVMsQ0FBQTtFQUNoQjtFQUVBLE9BQU8sTUFBWTtBQUNqQixRQUFJLEtBQUssU0FBUyxJQUFJLEdBQUc7QUFDdkIsYUFBTyxLQUFLLFVBQVUsR0FBRyxLQUFLLFNBQVMsQ0FBQzs7QUFHMUMsUUFBSSxDQUFDLE1BQU07QUFFVCxVQUFJLENBQUMsS0FBSyxTQUFTLENBQUMsS0FBSyxLQUFLO0FBQVEsZUFBTztBQUU3QyxZQUFNLE1BQXVCO1FBQzNCLE9BQU8sS0FBSztRQUNaLE1BQU0sS0FBSyxLQUFLLEtBQUssSUFBSTtRQUN6QixLQUFLLEtBQUs7O0FBR1osV0FBSyxRQUFRO0FBQ2IsV0FBSyxPQUFPLENBQUE7QUFDWixXQUFLLFNBQVMsQ0FBQTtBQUVkLGFBQU87O0FBR1QsU0FBSyxPQUFPLEtBQUssSUFBSTtBQUVyQixRQUFJLEtBQUssV0FBVyxHQUFHLEdBQUc7QUFDeEIsYUFBTzs7QUFHVCxRQUFJLENBQUMsV0FBVyxHQUFHLEtBQUssSUFBSSxVQUFVLE1BQU0sR0FBRztBQUUvQyxRQUFJLE1BQU0sV0FBVyxHQUFHLEdBQUc7QUFDekIsY0FBUSxNQUFNLFVBQVUsQ0FBQzs7QUFHM0IsUUFBSSxjQUFjLFNBQVM7QUFDekIsV0FBSyxRQUFRO2VBQ0osY0FBYyxRQUFRO0FBQy9CLFdBQUssS0FBSyxLQUFLLEtBQUs7O0FBR3RCLFdBQU87RUFDVDs7QUFTRixJQUFNLGNBQU4sTUFBTSxhQUFXO0VBU2YsY0FBQTtBQUNFLFNBQUssU0FBUyxDQUFBO0FBQ2QsU0FBSyxhQUFhO0VBQ3BCO0VBRUEsT0FBTyxPQUFZO0FBQ2pCLFFBQUksT0FBTyxLQUFLLFdBQVcsS0FBSztBQUVoQyxRQUFJLEtBQUssWUFBWTtBQUNuQixhQUFPLE9BQU87QUFDZCxXQUFLLGFBQWE7O0FBRXBCLFFBQUksS0FBSyxTQUFTLElBQUksR0FBRztBQUN2QixXQUFLLGFBQWE7QUFDbEIsYUFBTyxLQUFLLE1BQU0sR0FBRyxFQUFFOztBQUd6QixRQUFJLENBQUMsTUFBTTtBQUNULGFBQU8sQ0FBQTs7QUFHVCxVQUFNLGtCQUFrQixhQUFZLGNBQWMsSUFBSSxLQUFLLEtBQUssU0FBUyxDQUFDLEtBQUssRUFBRTtBQUNqRixRQUFJLFFBQVEsS0FBSyxNQUFNLGFBQVksY0FBYztBQUlqRCxRQUFJLGlCQUFpQjtBQUNuQixZQUFNLElBQUc7O0FBR1gsUUFBSSxNQUFNLFdBQVcsS0FBSyxDQUFDLGlCQUFpQjtBQUMxQyxXQUFLLE9BQU8sS0FBSyxNQUFNLENBQUMsQ0FBRTtBQUMxQixhQUFPLENBQUE7O0FBR1QsUUFBSSxLQUFLLE9BQU8sU0FBUyxHQUFHO0FBQzFCLGNBQVEsQ0FBQyxLQUFLLE9BQU8sS0FBSyxFQUFFLElBQUksTUFBTSxDQUFDLEdBQUcsR0FBRyxNQUFNLE1BQU0sQ0FBQyxDQUFDO0FBQzNELFdBQUssU0FBUyxDQUFBOztBQUdoQixRQUFJLENBQUMsaUJBQWlCO0FBQ3BCLFdBQUssU0FBUyxDQUFDLE1BQU0sSUFBRyxLQUFNLEVBQUU7O0FBR2xDLFdBQU87RUFDVDtFQUVBLFdBQVcsT0FBWTtBQUNyQixRQUFJLFNBQVM7QUFBTSxhQUFPO0FBQzFCLFFBQUksT0FBTyxVQUFVO0FBQVUsYUFBTztBQUd0QyxRQUFJLE9BQU8sV0FBVyxhQUFhO0FBQ2pDLFVBQUksaUJBQWlCLFFBQVE7QUFDM0IsZUFBTyxNQUFNLFNBQVE7O0FBRXZCLFVBQUksaUJBQWlCLFlBQVk7QUFDL0IsZUFBTyxPQUFPLEtBQUssS0FBSyxFQUFFLFNBQVE7O0FBR3BDLFlBQU0sSUFBSSxlQUNSLHdDQUF3QyxNQUFNLFlBQVksSUFBSSxtSUFBbUk7O0FBS3JNLFFBQUksT0FBTyxnQkFBZ0IsYUFBYTtBQUN0QyxVQUFJLGlCQUFpQixjQUFjLGlCQUFpQixhQUFhO0FBQy9ELGFBQUssZ0JBQUwsS0FBSyxjQUFnQixJQUFJLFlBQVksTUFBTTtBQUMzQyxlQUFPLEtBQUssWUFBWSxPQUFPLEtBQUs7O0FBR3RDLFlBQU0sSUFBSSxlQUNSLG9EQUNHLE1BQWMsWUFBWSxJQUM3QixnREFBZ0Q7O0FBSXBELFVBQU0sSUFBSSxlQUNSLGdHQUFnRztFQUVwRztFQUVBLFFBQUs7QUFDSCxRQUFJLENBQUMsS0FBSyxPQUFPLFVBQVUsQ0FBQyxLQUFLLFlBQVk7QUFDM0MsYUFBTyxDQUFBOztBQUdULFVBQU0sUUFBUSxDQUFDLEtBQUssT0FBTyxLQUFLLEVBQUUsQ0FBQztBQUNuQyxTQUFLLFNBQVMsQ0FBQTtBQUNkLFNBQUssYUFBYTtBQUNsQixXQUFPO0VBQ1Q7O0FBcEdPLFlBQUEsZ0JBQWdCLG9CQUFJLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQztBQUNwQyxZQUFBLGlCQUFpQjtBQWlIMUIsU0FBUyxVQUFVLEtBQWEsV0FBaUI7QUFDL0MsUUFBTSxRQUFRLElBQUksUUFBUSxTQUFTO0FBQ25DLE1BQUksVUFBVSxJQUFJO0FBQ2hCLFdBQU8sQ0FBQyxJQUFJLFVBQVUsR0FBRyxLQUFLLEdBQUcsV0FBVyxJQUFJLFVBQVUsUUFBUSxVQUFVLE1BQU0sQ0FBQzs7QUFHckYsU0FBTyxDQUFDLEtBQUssSUFBSSxFQUFFO0FBQ3JCO0FBUU0sU0FBVSw0QkFBK0IsUUFBVztBQUN4RCxNQUFJLE9BQU8sT0FBTyxhQUFhO0FBQUcsV0FBTztBQUV6QyxRQUFNLFNBQVMsT0FBTyxVQUFTO0FBQy9CLFNBQU87SUFDTCxNQUFNLE9BQUk7QUFDUixVQUFJO0FBQ0YsY0FBTSxTQUFTLE1BQU0sT0FBTyxLQUFJO0FBQ2hDLFlBQUksUUFBUTtBQUFNLGlCQUFPLFlBQVc7QUFDcEMsZUFBTztlQUNBLEdBQUc7QUFDVixlQUFPLFlBQVc7QUFDbEIsY0FBTTs7SUFFVjtJQUNBLE1BQU0sU0FBTTtBQUNWLFlBQU0sZ0JBQWdCLE9BQU8sT0FBTTtBQUNuQyxhQUFPLFlBQVc7QUFDbEIsWUFBTTtBQUNOLGFBQU8sRUFBRSxNQUFNLE1BQU0sT0FBTyxPQUFTO0lBQ3ZDO0lBQ0EsQ0FBQyxPQUFPLGFBQWEsSUFBQztBQUNwQixhQUFPO0lBQ1Q7O0FBRUo7OztBQ2hiTyxJQUFNLGFBQWEsQ0FBQyxVQUN6QixTQUFTLFFBQ1QsT0FBTyxVQUFVLFlBQ2pCLE9BQU8sTUFBTSxTQUFTLFlBQ3RCLE9BQU8sTUFBTSxTQUFTLFlBQ3RCLE9BQU8sTUFBTSxTQUFTLGNBQ3RCLE9BQU8sTUFBTSxVQUFVLGNBQ3ZCLE9BQU8sTUFBTSxnQkFBZ0I7QUF5R3hCLElBQU0sa0JBQWtCLENBQUMsU0FDOUIsUUFBUSxPQUFPLFNBQVMsWUFBWSxLQUFLLFFBQVEsS0FBSyxPQUFPLFdBQVcsTUFBTTs7Ozs7Ozs7Ozs7Ozs7O0FDdkpoRixlQUFlLHFCQUF3QixPQUF1QjtBQUM1RCxRQUFNLEVBQUUsU0FBUSxJQUFLO0FBQ3JCLE1BQUksTUFBTSxRQUFRLFFBQVE7QUFDeEIsVUFBTSxZQUFZLFNBQVMsUUFBUSxTQUFTLEtBQUssU0FBUyxTQUFTLFNBQVMsSUFBSTtBQUtoRixRQUFJLE1BQU0sUUFBUSxlQUFlO0FBQy9CLGFBQU8sTUFBTSxRQUFRLGNBQWMsZ0JBQWdCLFVBQVUsTUFBTSxVQUFVOztBQUcvRSxXQUFPLE9BQU8sZ0JBQWdCLFVBQVUsTUFBTSxVQUFVOztBQUkxRCxNQUFJLFNBQVMsV0FBVyxLQUFLO0FBQzNCLFdBQU87O0FBR1QsTUFBSSxNQUFNLFFBQVEsa0JBQWtCO0FBQ2xDLFdBQU87O0FBR1QsUUFBTSxjQUFjLFNBQVMsUUFBUSxJQUFJLGNBQWM7QUFDdkQsUUFBTSxTQUNKLGFBQWEsU0FBUyxrQkFBa0IsS0FBSyxhQUFhLFNBQVMsMEJBQTBCO0FBQy9GLE1BQUksUUFBUTtBQUNWLFVBQU0sT0FBTyxNQUFNLFNBQVMsS0FBSTtBQUVoQyxVQUFNLFlBQVksU0FBUyxRQUFRLFNBQVMsS0FBSyxTQUFTLFNBQVMsSUFBSTtBQUV2RSxXQUFPOztBQUdULFFBQU0sT0FBTyxNQUFNLFNBQVMsS0FBSTtBQUNoQyxRQUFNLFlBQVksU0FBUyxRQUFRLFNBQVMsS0FBSyxTQUFTLFNBQVMsSUFBSTtBQUd2RSxTQUFPO0FBQ1Q7QUFNTSxJQUFPLGFBQVAsTUFBTyxvQkFBc0IsUUFBVTtFQUczQyxZQUNVLGlCQUNBRSxpQkFBZ0Usc0JBQW9CO0FBRTVGLFVBQU0sQ0FBQyxZQUFXO0FBSWhCLGNBQVEsSUFBVztJQUNyQixDQUFDO0FBUk8sU0FBQSxrQkFBQTtBQUNBLFNBQUEsZ0JBQUFBO0VBUVY7RUFFQSxZQUFlLFdBQXlCO0FBQ3RDLFdBQU8sSUFBSSxZQUFXLEtBQUssaUJBQWlCLE9BQU8sVUFBVSxVQUFVLE1BQU0sS0FBSyxjQUFjLEtBQUssQ0FBQyxDQUFDO0VBQ3pHOzs7Ozs7Ozs7Ozs7OztFQWVBLGFBQVU7QUFDUixXQUFPLEtBQUssZ0JBQWdCLEtBQUssQ0FBQyxNQUFNLEVBQUUsUUFBUTtFQUNwRDs7Ozs7Ozs7Ozs7Ozs7RUFjQSxNQUFNLGVBQVk7QUFDaEIsVUFBTSxDQUFDLE1BQU0sUUFBUSxJQUFJLE1BQU0sUUFBUSxJQUFJLENBQUMsS0FBSyxNQUFLLEdBQUksS0FBSyxXQUFVLENBQUUsQ0FBQztBQUM1RSxXQUFPLEVBQUUsTUFBTSxTQUFRO0VBQ3pCO0VBRVEsUUFBSztBQUNYLFFBQUksQ0FBQyxLQUFLLGVBQWU7QUFDdkIsV0FBSyxnQkFBZ0IsS0FBSyxnQkFBZ0IsS0FBSyxLQUFLLGFBQWE7O0FBRW5FLFdBQU8sS0FBSztFQUNkO0VBRVMsS0FDUCxhQUNBLFlBQW1GO0FBRW5GLFdBQU8sS0FBSyxNQUFLLEVBQUcsS0FBSyxhQUFhLFVBQVU7RUFDbEQ7RUFFUyxNQUNQLFlBQWlGO0FBRWpGLFdBQU8sS0FBSyxNQUFLLEVBQUcsTUFBTSxVQUFVO0VBQ3RDO0VBRVMsUUFBUSxXQUEyQztBQUMxRCxXQUFPLEtBQUssTUFBSyxFQUFHLFFBQVEsU0FBUztFQUN2Qzs7QUFHSSxJQUFnQixZQUFoQixNQUF5QjtFQVM3QixZQUFZO0lBQ1Y7SUFDQSxhQUFhO0lBQ2IsVUFBVTs7SUFDVjtJQUNBLE9BQU87RUFBYyxHQU90QjtBQUNDLFNBQUssVUFBVTtBQUNmLFNBQUssYUFBYSx3QkFBd0IsY0FBYyxVQUFVO0FBQ2xFLFNBQUssVUFBVSx3QkFBd0IsV0FBVyxPQUFPO0FBQ3pELFNBQUssWUFBWTtBQUVqQixTQUFLLFFBQVEsa0JBQWtCQztFQUNqQztFQUVVLFlBQVksTUFBeUI7QUFDN0MsV0FBTyxDQUFBO0VBQ1Q7Ozs7Ozs7OztFQVVVLGVBQWUsTUFBeUI7QUFDaEQsV0FBTztNQUNMLFFBQVE7TUFDUixnQkFBZ0I7TUFDaEIsY0FBYyxLQUFLLGFBQVk7TUFDL0IsR0FBRyxtQkFBa0I7TUFDckIsR0FBRyxLQUFLLFlBQVksSUFBSTs7RUFFNUI7Ozs7RUFPVSxnQkFBZ0IsU0FBa0IsZUFBc0I7RUFBRztFQUUzRCx3QkFBcUI7QUFDN0IsV0FBTyx3QkFBd0IsTUFBSyxDQUFFO0VBQ3hDO0VBRUEsSUFBYyxNQUFjLE1BQTBDO0FBQ3BFLFdBQU8sS0FBSyxjQUFjLE9BQU8sTUFBTSxJQUFJO0VBQzdDO0VBRUEsS0FBZSxNQUFjLE1BQTBDO0FBQ3JFLFdBQU8sS0FBSyxjQUFjLFFBQVEsTUFBTSxJQUFJO0VBQzlDO0VBRUEsTUFBZ0IsTUFBYyxNQUEwQztBQUN0RSxXQUFPLEtBQUssY0FBYyxTQUFTLE1BQU0sSUFBSTtFQUMvQztFQUVBLElBQWMsTUFBYyxNQUEwQztBQUNwRSxXQUFPLEtBQUssY0FBYyxPQUFPLE1BQU0sSUFBSTtFQUM3QztFQUVBLE9BQWlCLE1BQWMsTUFBMEM7QUFDdkUsV0FBTyxLQUFLLGNBQWMsVUFBVSxNQUFNLElBQUk7RUFDaEQ7RUFFUSxjQUNOLFFBQ0EsTUFDQSxNQUEwQztBQUUxQyxXQUFPLEtBQUssUUFDVixRQUFRLFFBQVEsSUFBSSxFQUFFLEtBQUssT0FBT0MsVUFBUTtBQUN4QyxZQUFNLE9BQ0pBLFNBQVEsV0FBV0EsT0FBTSxJQUFJLElBQUksSUFBSSxTQUFTLE1BQU1BLE1BQUssS0FBSyxZQUFXLENBQUUsSUFDekVBLE9BQU0sZ0JBQWdCLFdBQVdBLE1BQUssT0FDdENBLE9BQU0sZ0JBQWdCLGNBQWMsSUFBSSxTQUFTQSxNQUFLLElBQUksSUFDMURBLFNBQVEsWUFBWSxPQUFPQSxPQUFNLElBQUksSUFBSSxJQUFJLFNBQVNBLE1BQUssS0FBSyxNQUFNLElBQ3RFQSxPQUFNO0FBQ1YsYUFBTyxFQUFFLFFBQVEsTUFBTSxHQUFHQSxPQUFNLEtBQUk7SUFDdEMsQ0FBQyxDQUFDO0VBRU47RUFFQSxXQUNFLE1BQ0EsTUFDQSxNQUEwQjtBQUUxQixXQUFPLEtBQUssZUFBZSxNQUFNLEVBQUUsUUFBUSxPQUFPLE1BQU0sR0FBRyxLQUFJLENBQUU7RUFDbkU7RUFFUSx1QkFBdUIsTUFBYTtBQUMxQyxRQUFJLE9BQU8sU0FBUyxVQUFVO0FBQzVCLFVBQUksT0FBTyxXQUFXLGFBQWE7QUFDakMsZUFBTyxPQUFPLFdBQVcsTUFBTSxNQUFNLEVBQUUsU0FBUTs7QUFHakQsVUFBSSxPQUFPLGdCQUFnQixhQUFhO0FBQ3RDLGNBQU1DLFdBQVUsSUFBSSxZQUFXO0FBQy9CLGNBQU0sVUFBVUEsU0FBUSxPQUFPLElBQUk7QUFDbkMsZUFBTyxRQUFRLE9BQU8sU0FBUTs7ZUFFdkIsWUFBWSxPQUFPLElBQUksR0FBRztBQUNuQyxhQUFPLEtBQUssV0FBVyxTQUFROztBQUdqQyxXQUFPO0VBQ1Q7RUFFQSxhQUNFLFNBQ0EsRUFBRSxhQUFhLEVBQUMsSUFBOEIsQ0FBQSxHQUFFO0FBRWhELFVBQU0sRUFBRSxRQUFRLE1BQU0sT0FBTyxVQUFtQixDQUFBLEVBQUUsSUFBSztBQUV2RCxVQUFNLE9BQ0osWUFBWSxPQUFPLFFBQVEsSUFBSSxLQUFNLFFBQVEsbUJBQW1CLE9BQU8sUUFBUSxTQUFTLFdBQ3RGLFFBQVEsT0FDUixnQkFBZ0IsUUFBUSxJQUFJLElBQUksUUFBUSxLQUFLLE9BQzdDLFFBQVEsT0FBTyxLQUFLLFVBQVUsUUFBUSxNQUFNLE1BQU0sQ0FBQyxJQUNuRDtBQUNKLFVBQU0sZ0JBQWdCLEtBQUssdUJBQXVCLElBQUk7QUFFdEQsVUFBTSxNQUFNLEtBQUssU0FBUyxNQUFPLEtBQUs7QUFDdEMsUUFBSSxhQUFhO0FBQVMsOEJBQXdCLFdBQVcsUUFBUSxPQUFPO0FBQzVFLFVBQU0sVUFBVSxRQUFRLFdBQVcsS0FBSztBQUN4QyxVQUFNLFlBQVksUUFBUSxhQUFhLEtBQUssYUFBYSxnQkFBZ0IsR0FBRztBQUM1RSxVQUFNLGtCQUFrQixVQUFVO0FBQ2xDLFFBQ0UsT0FBUSxXQUFtQixTQUFTLFlBQVksWUFDaEQsbUJBQW9CLFVBQWtCLFFBQVEsV0FBVyxJQUN6RDtBQUtDLGdCQUFrQixRQUFRLFVBQVU7O0FBR3ZDLFFBQUksS0FBSyxxQkFBcUIsV0FBVyxPQUFPO0FBQzlDLFVBQUksQ0FBQyxRQUFRO0FBQWdCLGdCQUFRLGlCQUFpQixLQUFLLHNCQUFxQjtBQUNoRixjQUFRLEtBQUssaUJBQWlCLElBQUksUUFBUTs7QUFHNUMsVUFBTSxhQUFhLEtBQUssYUFBYSxFQUFFLFNBQVMsU0FBUyxlQUFlLFdBQVUsQ0FBRTtBQUVwRixVQUFNLE1BQW1CO01BQ3ZCO01BQ0EsR0FBSSxRQUFRLEVBQUUsS0FBaUI7TUFDL0IsU0FBUztNQUNULEdBQUksYUFBYSxFQUFFLE9BQU8sVUFBUzs7O01BR25DLFFBQVEsUUFBUSxVQUFVOztBQUc1QixXQUFPLEVBQUUsS0FBSyxLQUFLLFFBQU87RUFDNUI7RUFFUSxhQUFhLEVBQ25CLFNBQ0EsU0FDQSxlQUNBLFdBQVUsR0FNWDtBQUNDLFVBQU0sYUFBcUMsQ0FBQTtBQUMzQyxRQUFJLGVBQWU7QUFDakIsaUJBQVcsZ0JBQWdCLElBQUk7O0FBR2pDLFVBQU0saUJBQWlCLEtBQUssZUFBZSxPQUFPO0FBQ2xELG9CQUFnQixZQUFZLGNBQWM7QUFDMUMsb0JBQWdCLFlBQVksT0FBTztBQUduQyxRQUFJLGdCQUFnQixRQUFRLElBQUksS0FBSyxTQUFjLFFBQVE7QUFDekQsYUFBTyxXQUFXLGNBQWM7O0FBS2xDLFFBQUksVUFBVSxTQUFTLHlCQUF5QixNQUFNLFFBQVc7QUFDL0QsaUJBQVcseUJBQXlCLElBQUksT0FBTyxVQUFVOztBQUczRCxTQUFLLGdCQUFnQixZQUFZLE9BQU87QUFFeEMsV0FBTztFQUNUOzs7O0VBS1UsTUFBTSxlQUFlLFNBQTRCO0VBQWtCOzs7Ozs7O0VBUW5FLE1BQU0sZUFDZCxTQUNBLEVBQUUsS0FBSyxRQUFPLEdBQWlEO0VBQy9DO0VBRVIsYUFBYSxTQUF1QztBQUM1RCxXQUNFLENBQUMsVUFBVSxDQUFBLElBQ1QsT0FBTyxZQUFZLFVBQ25CLE9BQU8sWUFBWSxNQUFNLEtBQUssT0FBNkIsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsSUFDekYsRUFBRSxHQUFHLFFBQU87RUFFbEI7RUFFVSxnQkFDUixRQUNBLE9BQ0FDLFVBQ0EsU0FBNEI7QUFFNUIsV0FBTyxTQUFTLFNBQVMsUUFBUSxPQUFPQSxVQUFTLE9BQU87RUFDMUQ7RUFFQSxRQUNFLFNBQ0EsbUJBQWtDLE1BQUk7QUFFdEMsV0FBTyxJQUFJLFdBQVcsS0FBSyxZQUFZLFNBQVMsZ0JBQWdCLENBQUM7RUFDbkU7RUFFUSxNQUFNLFlBQ1osY0FDQSxrQkFBK0I7QUFFL0IsVUFBTSxVQUFVLE1BQU07QUFDdEIsVUFBTSxhQUFhLFFBQVEsY0FBYyxLQUFLO0FBQzlDLFFBQUksb0JBQW9CLE1BQU07QUFDNUIseUJBQW1COztBQUdyQixVQUFNLEtBQUssZUFBZSxPQUFPO0FBRWpDLFVBQU0sRUFBRSxLQUFLLEtBQUssUUFBTyxJQUFLLEtBQUssYUFBYSxTQUFTLEVBQUUsWUFBWSxhQUFhLGlCQUFnQixDQUFFO0FBRXRHLFVBQU0sS0FBSyxlQUFlLEtBQUssRUFBRSxLQUFLLFFBQU8sQ0FBRTtBQUUvQyxVQUFNLFdBQVcsS0FBSyxTQUFTLElBQUksT0FBTztBQUUxQyxRQUFJLFFBQVEsUUFBUSxTQUFTO0FBQzNCLFlBQU0sSUFBSSxrQkFBaUI7O0FBRzdCLFVBQU0sYUFBYSxJQUFJLGdCQUFlO0FBQ3RDLFVBQU0sV0FBVyxNQUFNLEtBQUssaUJBQWlCLEtBQUssS0FBSyxTQUFTLFVBQVUsRUFBRSxNQUFNLFdBQVc7QUFFN0YsUUFBSSxvQkFBb0IsT0FBTztBQUM3QixVQUFJLFFBQVEsUUFBUSxTQUFTO0FBQzNCLGNBQU0sSUFBSSxrQkFBaUI7O0FBRTdCLFVBQUksa0JBQWtCO0FBQ3BCLGVBQU8sS0FBSyxhQUFhLFNBQVMsZ0JBQWdCOztBQUVwRCxVQUFJLFNBQVMsU0FBUyxjQUFjO0FBQ2xDLGNBQU0sSUFBSSwwQkFBeUI7O0FBRXJDLFlBQU0sSUFBSSxtQkFBbUIsRUFBRSxPQUFPLFNBQVEsQ0FBRTs7QUFHbEQsVUFBTSxrQkFBa0Isc0JBQXNCLFNBQVMsT0FBTztBQUU5RCxRQUFJLENBQUMsU0FBUyxJQUFJO0FBQ2hCLFVBQUksb0JBQW9CLEtBQUssWUFBWSxRQUFRLEdBQUc7QUFDbEQsY0FBTUMsZ0JBQWUsYUFBYSxnQkFBZ0I7QUFDbEQsY0FBTSxvQkFBb0JBLGFBQVksS0FBSyxTQUFTLFFBQVEsS0FBSyxlQUFlO0FBQ2hGLGVBQU8sS0FBSyxhQUFhLFNBQVMsa0JBQWtCLGVBQWU7O0FBR3JFLFlBQU0sVUFBVSxNQUFNLFNBQVMsS0FBSSxFQUFHLE1BQU0sQ0FBQyxNQUFNLFlBQVksQ0FBQyxFQUFFLE9BQU87QUFDekUsWUFBTSxVQUFVLFNBQVMsT0FBTztBQUNoQyxZQUFNLGFBQWEsVUFBVSxTQUFZO0FBQ3pDLFlBQU0sZUFBZSxtQkFBbUIsa0NBQWtDO0FBRTFFLFlBQU0sb0JBQW9CLFlBQVksS0FBSyxTQUFTLFFBQVEsS0FBSyxpQkFBaUIsVUFBVTtBQUU1RixZQUFNLE1BQU0sS0FBSyxnQkFBZ0IsU0FBUyxRQUFRLFNBQVMsWUFBWSxlQUFlO0FBQ3RGLFlBQU07O0FBR1IsV0FBTyxFQUFFLFVBQVUsU0FBUyxXQUFVO0VBQ3hDO0VBRUEsZUFDRSxNQUNBLFNBQTRCO0FBRTVCLFVBQU0sVUFBVSxLQUFLLFlBQVksU0FBUyxJQUFJO0FBQzlDLFdBQU8sSUFBSSxZQUE2QixNQUFNLFNBQVMsSUFBSTtFQUM3RDtFQUVBLFNBQWMsTUFBYyxPQUE2QjtBQUN2RCxVQUFNLE1BQ0osY0FBYyxJQUFJLElBQ2hCLElBQUksSUFBSSxJQUFJLElBQ1osSUFBSSxJQUFJLEtBQUssV0FBVyxLQUFLLFFBQVEsU0FBUyxHQUFHLEtBQUssS0FBSyxXQUFXLEdBQUcsSUFBSSxLQUFLLE1BQU0sQ0FBQyxJQUFJLEtBQUs7QUFFdEcsVUFBTSxlQUFlLEtBQUssYUFBWTtBQUN0QyxRQUFJLENBQUMsV0FBVyxZQUFZLEdBQUc7QUFDN0IsY0FBUSxFQUFFLEdBQUcsY0FBYyxHQUFHLE1BQUs7O0FBR3JDLFFBQUksT0FBTyxVQUFVLFlBQVksU0FBUyxDQUFDLE1BQU0sUUFBUSxLQUFLLEdBQUc7QUFDL0QsVUFBSSxTQUFTLEtBQUssZUFBZSxLQUFnQzs7QUFHbkUsV0FBTyxJQUFJLFNBQVE7RUFDckI7RUFFVSxlQUFlLE9BQThCO0FBQ3JELFdBQU8sT0FBTyxRQUFRLEtBQUssRUFDeEIsT0FBTyxDQUFDLENBQUMsR0FBRyxLQUFLLE1BQU0sT0FBTyxVQUFVLFdBQVcsRUFDbkQsSUFBSSxDQUFDLENBQUMsS0FBSyxLQUFLLE1BQUs7QUFDcEIsVUFBSSxPQUFPLFVBQVUsWUFBWSxPQUFPLFVBQVUsWUFBWSxPQUFPLFVBQVUsV0FBVztBQUN4RixlQUFPLEdBQUcsbUJBQW1CLEdBQUcsQ0FBQyxJQUFJLG1CQUFtQixLQUFLLENBQUM7O0FBRWhFLFVBQUksVUFBVSxNQUFNO0FBQ2xCLGVBQU8sR0FBRyxtQkFBbUIsR0FBRyxDQUFDOztBQUVuQyxZQUFNLElBQUksZUFDUix5QkFBeUIsT0FBTyxLQUFLLG1RQUFtUTtJQUU1UyxDQUFDLEVBQ0EsS0FBSyxHQUFHO0VBQ2I7RUFFQSxNQUFNLGlCQUNKLEtBQ0EsTUFDQSxJQUNBLFlBQTJCO0FBRTNCLFVBQU0sRUFBRSxRQUFRLEdBQUcsUUFBTyxJQUFLLFFBQVEsQ0FBQTtBQUN2QyxRQUFJO0FBQVEsYUFBTyxpQkFBaUIsU0FBUyxNQUFNLFdBQVcsTUFBSyxDQUFFO0FBRXJFLFVBQU0sVUFBVSxXQUFXLE1BQU0sV0FBVyxNQUFLLEdBQUksRUFBRTtBQUV2RCxXQUNFLEtBQUssaUJBQWdCLEVBRWxCLE1BQU0sS0FBSyxRQUFXLEtBQUssRUFBRSxRQUFRLFdBQVcsUUFBZSxHQUFHLFFBQU8sQ0FBRSxFQUMzRSxRQUFRLE1BQUs7QUFDWixtQkFBYSxPQUFPO0lBQ3RCLENBQUM7RUFFUDtFQUVVLG1CQUFnQjtBQUN4QixXQUFPLEVBQUUsT0FBTyxLQUFLLE1BQUs7RUFDNUI7RUFFUSxZQUFZLFVBQWtCO0FBRXBDLFVBQU0sb0JBQW9CLFNBQVMsUUFBUSxJQUFJLGdCQUFnQjtBQUcvRCxRQUFJLHNCQUFzQjtBQUFRLGFBQU87QUFDekMsUUFBSSxzQkFBc0I7QUFBUyxhQUFPO0FBRzFDLFFBQUksU0FBUyxXQUFXO0FBQUssYUFBTztBQUdwQyxRQUFJLFNBQVMsV0FBVztBQUFLLGFBQU87QUFHcEMsUUFBSSxTQUFTLFdBQVc7QUFBSyxhQUFPO0FBR3BDLFFBQUksU0FBUyxVQUFVO0FBQUssYUFBTztBQUVuQyxXQUFPO0VBQ1Q7RUFFUSxNQUFNLGFBQ1osU0FDQSxrQkFDQSxpQkFBcUM7QUFFckMsUUFBSTtBQUdKLFVBQU0seUJBQXlCLGtCQUFrQixnQkFBZ0I7QUFDakUsUUFBSSx3QkFBd0I7QUFDMUIsWUFBTSxZQUFZLFdBQVcsc0JBQXNCO0FBQ25ELFVBQUksQ0FBQyxPQUFPLE1BQU0sU0FBUyxHQUFHO0FBQzVCLHdCQUFnQjs7O0FBS3BCLFVBQU0sbUJBQW1CLGtCQUFrQixhQUFhO0FBQ3hELFFBQUksb0JBQW9CLENBQUMsZUFBZTtBQUN0QyxZQUFNLGlCQUFpQixXQUFXLGdCQUFnQjtBQUNsRCxVQUFJLENBQUMsT0FBTyxNQUFNLGNBQWMsR0FBRztBQUNqQyx3QkFBZ0IsaUJBQWlCO2FBQzVCO0FBQ0wsd0JBQWdCLEtBQUssTUFBTSxnQkFBZ0IsSUFBSSxLQUFLLElBQUc7OztBQU0zRCxRQUFJLEVBQUUsaUJBQWlCLEtBQUssaUJBQWlCLGdCQUFnQixLQUFLLE1BQU87QUFDdkUsWUFBTSxhQUFhLFFBQVEsY0FBYyxLQUFLO0FBQzlDLHNCQUFnQixLQUFLLG1DQUFtQyxrQkFBa0IsVUFBVTs7QUFFdEYsVUFBTSxNQUFNLGFBQWE7QUFFekIsV0FBTyxLQUFLLFlBQVksU0FBUyxtQkFBbUIsQ0FBQztFQUN2RDtFQUVRLG1DQUFtQyxrQkFBMEIsWUFBa0I7QUFDckYsVUFBTSxvQkFBb0I7QUFDMUIsVUFBTSxnQkFBZ0I7QUFFdEIsVUFBTSxhQUFhLGFBQWE7QUFHaEMsVUFBTSxlQUFlLEtBQUssSUFBSSxvQkFBb0IsS0FBSyxJQUFJLEdBQUcsVUFBVSxHQUFHLGFBQWE7QUFHeEYsVUFBTSxTQUFTLElBQUksS0FBSyxPQUFNLElBQUs7QUFFbkMsV0FBTyxlQUFlLFNBQVM7RUFDakM7RUFFUSxlQUFZO0FBQ2xCLFdBQU8sR0FBRyxLQUFLLFlBQVksSUFBSSxPQUFPLE9BQU87RUFDL0M7O0FBS0ksSUFBZ0IsZUFBaEIsTUFBNEI7RUFPaEMsWUFBWSxRQUFtQixVQUFvQixNQUFlLFNBQTRCO0FBTjlGLHlCQUFBLElBQUEsTUFBQSxNQUFBO0FBT0UsMkJBQUEsTUFBSSxzQkFBVyxRQUFNLEdBQUE7QUFDckIsU0FBSyxVQUFVO0FBQ2YsU0FBSyxXQUFXO0FBQ2hCLFNBQUssT0FBTztFQUNkO0VBVUEsY0FBVztBQUNULFVBQU0sUUFBUSxLQUFLLGtCQUFpQjtBQUNwQyxRQUFJLENBQUMsTUFBTTtBQUFRLGFBQU87QUFDMUIsV0FBTyxLQUFLLGFBQVksS0FBTTtFQUNoQztFQUVBLE1BQU0sY0FBVztBQUNmLFVBQU0sV0FBVyxLQUFLLGFBQVk7QUFDbEMsUUFBSSxDQUFDLFVBQVU7QUFDYixZQUFNLElBQUksZUFDUix1RkFBdUY7O0FBRzNGLFVBQU0sY0FBYyxFQUFFLEdBQUcsS0FBSyxRQUFPO0FBQ3JDLFFBQUksWUFBWSxZQUFZLE9BQU8sWUFBWSxVQUFVLFVBQVU7QUFDakUsa0JBQVksUUFBUSxFQUFFLEdBQUcsWUFBWSxPQUFPLEdBQUcsU0FBUyxPQUFNO2VBQ3JELFNBQVMsVUFBVTtBQUM1QixZQUFNLFNBQVMsQ0FBQyxHQUFHLE9BQU8sUUFBUSxZQUFZLFNBQVMsQ0FBQSxDQUFFLEdBQUcsR0FBRyxTQUFTLElBQUksYUFBYSxRQUFPLENBQUU7QUFDbEcsaUJBQVcsQ0FBQyxLQUFLLEtBQUssS0FBSyxRQUFRO0FBQ2pDLGlCQUFTLElBQUksYUFBYSxJQUFJLEtBQUssS0FBWTs7QUFFakQsa0JBQVksUUFBUTtBQUNwQixrQkFBWSxPQUFPLFNBQVMsSUFBSSxTQUFROztBQUUxQyxXQUFPLE1BQU0sdUJBQUEsTUFBSSxzQkFBQSxHQUFBLEVBQVMsZUFBZSxLQUFLLGFBQW9CLFdBQVc7RUFDL0U7RUFFQSxPQUFPLFlBQVM7QUFFZCxRQUFJLE9BQTJCO0FBQy9CLFVBQU07QUFDTixXQUFPLEtBQUssWUFBVyxHQUFJO0FBQ3pCLGFBQU8sTUFBTSxLQUFLLFlBQVc7QUFDN0IsWUFBTTs7RUFFVjtFQUVBLFNBQU8sdUJBQUEsb0JBQUEsUUFBQSxHQUFDLE9BQU8sY0FBYSxJQUFDO0FBQzNCLHFCQUFpQixRQUFRLEtBQUssVUFBUyxHQUFJO0FBQ3pDLGlCQUFXLFFBQVEsS0FBSyxrQkFBaUIsR0FBSTtBQUMzQyxjQUFNOzs7RUFHWjs7QUFZSSxJQUFPLGNBQVAsY0FJSSxXQUFxQjtFQUc3QixZQUNFLFFBQ0EsU0FDQSxNQUE0RTtBQUU1RSxVQUNFLFNBQ0EsT0FBTyxVQUFVLElBQUksS0FBSyxRQUFRLE1BQU0sVUFBVSxNQUFNLHFCQUFxQixLQUFLLEdBQUcsTUFBTSxPQUFPLENBQUM7RUFFdkc7Ozs7Ozs7O0VBU0EsUUFBUSxPQUFPLGFBQWEsSUFBQztBQUMzQixVQUFNLE9BQU8sTUFBTTtBQUNuQixxQkFBaUIsUUFBUSxNQUFNO0FBQzdCLFlBQU07O0VBRVY7O0FBR0ssSUFBTSx3QkFBd0IsQ0FDbkMsWUFDMEI7QUFDMUIsU0FBTyxJQUFJLE1BQ1QsT0FBTzs7SUFFTCxRQUFRLFFBQU87RUFBRSxHQUVuQjtJQUNFLElBQUksUUFBUSxNQUFJO0FBQ2QsWUFBTSxNQUFNLEtBQUssU0FBUTtBQUN6QixhQUFPLE9BQU8sSUFBSSxZQUFXLENBQUUsS0FBSyxPQUFPLEdBQUc7SUFDaEQ7R0FDRDtBQUVMO0FBeUZBLElBQU0sd0JBQXdCLE1BQXlCO0FBQ3JELE1BQUksT0FBTyxTQUFTLGVBQWUsS0FBSyxTQUFTLE1BQU07QUFDckQsV0FBTztNQUNMLG9CQUFvQjtNQUNwQiwrQkFBK0I7TUFDL0Isa0JBQWtCLGtCQUFrQixLQUFLLE1BQU0sRUFBRTtNQUNqRCxvQkFBb0IsY0FBYyxLQUFLLE1BQU0sSUFBSTtNQUNqRCx1QkFBdUI7TUFDdkIsK0JBQ0UsT0FBTyxLQUFLLFlBQVksV0FBVyxLQUFLLFVBQVUsS0FBSyxTQUFTLFFBQVE7OztBQUc5RSxNQUFJLE9BQU8sZ0JBQWdCLGFBQWE7QUFDdEMsV0FBTztNQUNMLG9CQUFvQjtNQUNwQiwrQkFBK0I7TUFDL0Isa0JBQWtCO01BQ2xCLG9CQUFvQixTQUFTLFdBQVc7TUFDeEMsdUJBQXVCO01BQ3ZCLCtCQUErQixRQUFROzs7QUFJM0MsTUFBSSxPQUFPLFVBQVUsU0FBUyxLQUFLLE9BQU8sWUFBWSxjQUFjLFVBQVUsQ0FBQyxNQUFNLG9CQUFvQjtBQUN2RyxXQUFPO01BQ0wsb0JBQW9CO01BQ3BCLCtCQUErQjtNQUMvQixrQkFBa0Isa0JBQWtCLFFBQVEsUUFBUTtNQUNwRCxvQkFBb0IsY0FBYyxRQUFRLElBQUk7TUFDOUMsdUJBQXVCO01BQ3ZCLCtCQUErQixRQUFROzs7QUFJM0MsUUFBTSxjQUFjLGVBQWM7QUFDbEMsTUFBSSxhQUFhO0FBQ2YsV0FBTztNQUNMLG9CQUFvQjtNQUNwQiwrQkFBK0I7TUFDL0Isa0JBQWtCO01BQ2xCLG9CQUFvQjtNQUNwQix1QkFBdUIsV0FBVyxZQUFZLE9BQU87TUFDckQsK0JBQStCLFlBQVk7OztBQUsvQyxTQUFPO0lBQ0wsb0JBQW9CO0lBQ3BCLCtCQUErQjtJQUMvQixrQkFBa0I7SUFDbEIsb0JBQW9CO0lBQ3BCLHVCQUF1QjtJQUN2QiwrQkFBK0I7O0FBRW5DO0FBVUEsU0FBUyxpQkFBYztBQUNyQixNQUFJLE9BQU8sY0FBYyxlQUFlLENBQUMsV0FBVztBQUNsRCxXQUFPOztBQUlULFFBQU0sa0JBQWtCO0lBQ3RCLEVBQUUsS0FBSyxRQUFpQixTQUFTLHVDQUFzQztJQUN2RSxFQUFFLEtBQUssTUFBZSxTQUFTLHVDQUFzQztJQUNyRSxFQUFFLEtBQUssTUFBZSxTQUFTLDZDQUE0QztJQUMzRSxFQUFFLEtBQUssVUFBbUIsU0FBUyx5Q0FBd0M7SUFDM0UsRUFBRSxLQUFLLFdBQW9CLFNBQVMsMENBQXlDO0lBQzdFLEVBQUUsS0FBSyxVQUFtQixTQUFTLG9FQUFtRTs7QUFJeEcsYUFBVyxFQUFFLEtBQUssUUFBTyxLQUFNLGlCQUFpQjtBQUM5QyxVQUFNLFFBQVEsUUFBUSxLQUFLLFVBQVUsU0FBUztBQUM5QyxRQUFJLE9BQU87QUFDVCxZQUFNLFFBQVEsTUFBTSxDQUFDLEtBQUs7QUFDMUIsWUFBTSxRQUFRLE1BQU0sQ0FBQyxLQUFLO0FBQzFCLFlBQU0sUUFBUSxNQUFNLENBQUMsS0FBSztBQUUxQixhQUFPLEVBQUUsU0FBUyxLQUFLLFNBQVMsR0FBRyxLQUFLLElBQUksS0FBSyxJQUFJLEtBQUssR0FBRTs7O0FBSWhFLFNBQU87QUFDVDtBQUVBLElBQU0sZ0JBQWdCLENBQUMsU0FBc0I7QUFLM0MsTUFBSSxTQUFTO0FBQU8sV0FBTztBQUMzQixNQUFJLFNBQVMsWUFBWSxTQUFTO0FBQU8sV0FBTztBQUNoRCxNQUFJLFNBQVM7QUFBTyxXQUFPO0FBQzNCLE1BQUksU0FBUyxhQUFhLFNBQVM7QUFBUyxXQUFPO0FBQ25ELE1BQUk7QUFBTSxXQUFPLFNBQVMsSUFBSTtBQUM5QixTQUFPO0FBQ1Q7QUFFQSxJQUFNLG9CQUFvQixDQUFDLGFBQWtDO0FBTzNELGFBQVcsU0FBUyxZQUFXO0FBTS9CLE1BQUksU0FBUyxTQUFTLEtBQUs7QUFBRyxXQUFPO0FBQ3JDLE1BQUksYUFBYTtBQUFXLFdBQU87QUFDbkMsTUFBSSxhQUFhO0FBQVUsV0FBTztBQUNsQyxNQUFJLGFBQWE7QUFBUyxXQUFPO0FBQ2pDLE1BQUksYUFBYTtBQUFXLFdBQU87QUFDbkMsTUFBSSxhQUFhO0FBQVcsV0FBTztBQUNuQyxNQUFJLGFBQWE7QUFBUyxXQUFPO0FBQ2pDLE1BQUk7QUFBVSxXQUFPLFNBQVMsUUFBUTtBQUN0QyxTQUFPO0FBQ1Q7QUFFQSxJQUFJO0FBQ0osSUFBTSxxQkFBcUIsTUFBSztBQUM5QixTQUFRLHFCQUFBLG1CQUFxQixzQkFBcUI7QUFDcEQ7QUFFTyxJQUFNLFdBQVcsQ0FBQyxTQUFnQjtBQUN2QyxNQUFJO0FBQ0YsV0FBTyxLQUFLLE1BQU0sSUFBSTtXQUNmLEtBQUs7QUFDWixXQUFPOztBQUVYO0FBR0EsSUFBTSx5QkFBeUIsSUFBSSxPQUFPLG1CQUFtQixHQUFHO0FBQ2hFLElBQU0sZ0JBQWdCLENBQUMsUUFBd0I7QUFDN0MsU0FBTyx1QkFBdUIsS0FBSyxHQUFHO0FBQ3hDO0FBRU8sSUFBTSxRQUFRLENBQUMsT0FBZSxJQUFJLFFBQVEsQ0FBQyxZQUFZLFdBQVcsU0FBUyxFQUFFLENBQUM7QUFFckYsSUFBTSwwQkFBMEIsQ0FBQyxNQUFjLE1BQXNCO0FBQ25FLE1BQUksT0FBTyxNQUFNLFlBQVksQ0FBQyxPQUFPLFVBQVUsQ0FBQyxHQUFHO0FBQ2pELFVBQU0sSUFBSSxlQUFlLEdBQUcsSUFBSSxxQkFBcUI7O0FBRXZELE1BQUksSUFBSSxHQUFHO0FBQ1QsVUFBTSxJQUFJLGVBQWUsR0FBRyxJQUFJLDZCQUE2Qjs7QUFFL0QsU0FBTztBQUNUO0FBRU8sSUFBTSxjQUFjLENBQUMsUUFBbUI7QUFDN0MsTUFBSSxlQUFlO0FBQU8sV0FBTztBQUNqQyxNQUFJLE9BQU8sUUFBUSxZQUFZLFFBQVEsTUFBTTtBQUMzQyxRQUFJO0FBQ0YsYUFBTyxJQUFJLE1BQU0sS0FBSyxVQUFVLEdBQUcsQ0FBQztZQUM5QjtJQUFBOztBQUVWLFNBQU8sSUFBSSxNQUFNLE9BQU8sR0FBRyxDQUFDO0FBQzlCO0FBY08sSUFBTSxVQUFVLENBQUMsUUFBbUM7QUFDekQsTUFBSSxPQUFPLFlBQVksYUFBYTtBQUNsQyxXQUFPLFFBQVEsTUFBTSxHQUFHLEdBQUcsS0FBSSxLQUFNOztBQUV2QyxNQUFJLE9BQU8sU0FBUyxhQUFhO0FBQy9CLFdBQU8sS0FBSyxLQUFLLE1BQU0sR0FBRyxHQUFHLEtBQUk7O0FBRW5DLFNBQU87QUFDVDtBQTRDTSxTQUFVLFdBQVcsS0FBOEI7QUFDdkQsTUFBSSxDQUFDO0FBQUssV0FBTztBQUNqQixhQUFXLE1BQU07QUFBSyxXQUFPO0FBQzdCLFNBQU87QUFDVDtBQUdNLFNBQVUsT0FBTyxLQUFhLEtBQVc7QUFDN0MsU0FBTyxPQUFPLFVBQVUsZUFBZSxLQUFLLEtBQUssR0FBRztBQUN0RDtBQVFBLFNBQVMsZ0JBQWdCLGVBQXdCLFlBQW1CO0FBQ2xFLGFBQVcsS0FBSyxZQUFZO0FBQzFCLFFBQUksQ0FBQyxPQUFPLFlBQVksQ0FBQztBQUFHO0FBQzVCLFVBQU0sV0FBVyxFQUFFLFlBQVc7QUFDOUIsUUFBSSxDQUFDO0FBQVU7QUFFZixVQUFNLE1BQU0sV0FBVyxDQUFDO0FBRXhCLFFBQUksUUFBUSxNQUFNO0FBQ2hCLGFBQU8sY0FBYyxRQUFRO2VBQ3BCLFFBQVEsUUFBVztBQUM1QixvQkFBYyxRQUFRLElBQUk7OztBQUdoQztBQUVNLFNBQVUsTUFBTSxXQUFtQixNQUFXO0FBQ2xELE1BQUksT0FBTyxZQUFZLGVBQWUsU0FBUyxNQUFNLE9BQU8sTUFBTSxRQUFRO0FBQ3hFLFlBQVEsSUFBSSxtQkFBbUIsTUFBTSxJQUFJLEdBQUcsSUFBSTs7QUFFcEQ7QUFLQSxJQUFNLFFBQVEsTUFBSztBQUNqQixTQUFPLHVDQUF1QyxRQUFRLFNBQVMsQ0FBQyxNQUFLO0FBQ25FLFVBQU0sSUFBSyxLQUFLLE9BQU0sSUFBSyxLQUFNO0FBQ2pDLFVBQU0sSUFBSSxNQUFNLE1BQU0sSUFBSyxJQUFJLElBQU87QUFDdEMsV0FBTyxFQUFFLFNBQVMsRUFBRTtFQUN0QixDQUFDO0FBQ0g7QUFrQk8sSUFBTSxvQkFBb0IsQ0FBQyxZQUE0QztBQUM1RSxTQUFPLE9BQU8sU0FBUyxRQUFRO0FBQ2pDO0FBVU8sSUFBTSxZQUFZLENBQUMsU0FBZ0MsV0FBc0M7QUFDOUYsUUFBTSxtQkFBbUIsT0FBTyxZQUFXO0FBQzNDLE1BQUksa0JBQWtCLE9BQU8sR0FBRztBQUU5QixVQUFNLGtCQUNKLE9BQU8sQ0FBQyxHQUFHLFlBQVcsSUFDdEIsT0FBTyxVQUFVLENBQUMsRUFBRSxRQUFRLGdCQUFnQixDQUFDLElBQUksSUFBSSxPQUFPLEtBQUssR0FBRyxZQUFXLENBQUU7QUFDbkYsZUFBVyxPQUFPLENBQUMsUUFBUSxrQkFBa0IsT0FBTyxZQUFXLEdBQUksZUFBZSxHQUFHO0FBQ25GLFlBQU0sUUFBUSxRQUFRLElBQUksR0FBRztBQUM3QixVQUFJLE9BQU87QUFDVCxlQUFPOzs7O0FBS2IsYUFBVyxDQUFDLEtBQUssS0FBSyxLQUFLLE9BQU8sUUFBUSxPQUFPLEdBQUc7QUFDbEQsUUFBSSxJQUFJLFlBQVcsTUFBTyxrQkFBa0I7QUFDMUMsVUFBSSxNQUFNLFFBQVEsS0FBSyxHQUFHO0FBQ3hCLFlBQUksTUFBTSxVQUFVO0FBQUcsaUJBQU8sTUFBTSxDQUFDO0FBQ3JDLGdCQUFRLEtBQUssWUFBWSxNQUFNLE1BQU0sb0JBQW9CLE1BQU0saUNBQWlDO0FBQ2hHLGVBQU8sTUFBTSxDQUFDOztBQUVoQixhQUFPOzs7QUFJWCxTQUFPO0FBQ1Q7QUFrQk0sU0FBVSxNQUFNLEtBQVk7QUFDaEMsU0FBTyxPQUFPLFFBQVEsT0FBTyxRQUFRLFlBQVksQ0FBQyxNQUFNLFFBQVEsR0FBRztBQUNyRTs7O0FDanJDTSxJQUFPLGNBQVAsTUFBa0I7RUFHdEIsWUFBWSxRQUFzQjtBQUNoQyxTQUFLLFVBQVU7RUFDakI7Ozs7QUNKRixJQUFNLFdBQVcsQ0FBQyxVQUEwQjtBQUN4QyxNQUFJLFVBQVU7QUFDZCxNQUFJLFNBQWtCLENBQUE7QUFFdEIsU0FBTyxVQUFVLE1BQU0sUUFBUTtBQUM3QixRQUFJLE9BQU8sTUFBTSxPQUFPO0FBRXhCLFFBQUksU0FBUyxNQUFNO0FBQ2pCO0FBQ0E7O0FBR0YsUUFBSSxTQUFTLEtBQUs7QUFDaEIsYUFBTyxLQUFLO1FBQ1YsTUFBTTtRQUNOLE9BQU87T0FDUjtBQUVEO0FBQ0E7O0FBR0YsUUFBSSxTQUFTLEtBQUs7QUFDaEIsYUFBTyxLQUFLO1FBQ1YsTUFBTTtRQUNOLE9BQU87T0FDUjtBQUVEO0FBQ0E7O0FBR0YsUUFBSSxTQUFTLEtBQUs7QUFDaEIsYUFBTyxLQUFLO1FBQ1YsTUFBTTtRQUNOLE9BQU87T0FDUjtBQUVEO0FBQ0E7O0FBR0YsUUFBSSxTQUFTLEtBQUs7QUFDaEIsYUFBTyxLQUFLO1FBQ1YsTUFBTTtRQUNOLE9BQU87T0FDUjtBQUVEO0FBQ0E7O0FBR0YsUUFBSSxTQUFTLEtBQUs7QUFDaEIsYUFBTyxLQUFLO1FBQ1YsTUFBTTtRQUNOLE9BQU87T0FDUjtBQUVEO0FBQ0E7O0FBR0YsUUFBSSxTQUFTLEtBQUs7QUFDaEIsYUFBTyxLQUFLO1FBQ1YsTUFBTTtRQUNOLE9BQU87T0FDUjtBQUVEO0FBQ0E7O0FBR0YsUUFBSSxTQUFTLEtBQUs7QUFDaEIsVUFBSSxRQUFRO0FBQ1osVUFBSSxnQkFBZ0I7QUFFcEIsYUFBTyxNQUFNLEVBQUUsT0FBTztBQUV0QixhQUFPLFNBQVMsS0FBSztBQUNuQixZQUFJLFlBQVksTUFBTSxRQUFRO0FBQzVCLDBCQUFnQjtBQUNoQjs7QUFHRixZQUFJLFNBQVMsTUFBTTtBQUNqQjtBQUNBLGNBQUksWUFBWSxNQUFNLFFBQVE7QUFDNUIsNEJBQWdCO0FBQ2hCOztBQUVGLG1CQUFTLE9BQU8sTUFBTSxPQUFPO0FBQzdCLGlCQUFPLE1BQU0sRUFBRSxPQUFPO2VBQ2pCO0FBQ0wsbUJBQVM7QUFDVCxpQkFBTyxNQUFNLEVBQUUsT0FBTzs7O0FBSTFCLGFBQU8sTUFBTSxFQUFFLE9BQU87QUFFdEIsVUFBSSxDQUFDLGVBQWU7QUFDbEIsZUFBTyxLQUFLO1VBQ1YsTUFBTTtVQUNOO1NBQ0Q7O0FBRUg7O0FBR0YsUUFBSSxhQUFhO0FBQ2pCLFFBQUksUUFBUSxXQUFXLEtBQUssSUFBSSxHQUFHO0FBQ2pDO0FBQ0E7O0FBR0YsUUFBSSxVQUFVO0FBQ2QsUUFBSyxRQUFRLFFBQVEsS0FBSyxJQUFJLEtBQU0sU0FBUyxPQUFPLFNBQVMsS0FBSztBQUNoRSxVQUFJLFFBQVE7QUFFWixVQUFJLFNBQVMsS0FBSztBQUNoQixpQkFBUztBQUNULGVBQU8sTUFBTSxFQUFFLE9BQU87O0FBR3hCLGFBQVEsUUFBUSxRQUFRLEtBQUssSUFBSSxLQUFNLFNBQVMsS0FBSztBQUNuRCxpQkFBUztBQUNULGVBQU8sTUFBTSxFQUFFLE9BQU87O0FBR3hCLGFBQU8sS0FBSztRQUNWLE1BQU07UUFDTjtPQUNEO0FBQ0Q7O0FBR0YsUUFBSSxVQUFVO0FBQ2QsUUFBSSxRQUFRLFFBQVEsS0FBSyxJQUFJLEdBQUc7QUFDOUIsVUFBSSxRQUFRO0FBRVosYUFBTyxRQUFRLFFBQVEsS0FBSyxJQUFJLEdBQUc7QUFDakMsWUFBSSxZQUFZLE1BQU0sUUFBUTtBQUM1Qjs7QUFFRixpQkFBUztBQUNULGVBQU8sTUFBTSxFQUFFLE9BQU87O0FBR3hCLFVBQUksU0FBUyxVQUFVLFNBQVMsV0FBVyxVQUFVLFFBQVE7QUFDM0QsZUFBTyxLQUFLO1VBQ1YsTUFBTTtVQUNOO1NBQ0Q7YUFDSTtBQUVMO0FBQ0E7O0FBRUY7O0FBR0Y7O0FBR0YsU0FBTztBQUNUO0FBcktGLElBc0tFLFFBQVEsQ0FBQyxXQUE0QjtBQUNuQyxNQUFJLE9BQU8sV0FBVyxHQUFHO0FBQ3ZCLFdBQU87O0FBR1QsTUFBSSxZQUFZLE9BQU8sT0FBTyxTQUFTLENBQUM7QUFFeEMsVUFBUSxVQUFVLE1BQU07SUFDdEIsS0FBSztBQUNILGVBQVMsT0FBTyxNQUFNLEdBQUcsT0FBTyxTQUFTLENBQUM7QUFDMUMsYUFBTyxNQUFNLE1BQU07QUFDbkI7SUFDRixLQUFLO0FBQ0gsVUFBSSwyQkFBMkIsVUFBVSxNQUFNLFVBQVUsTUFBTSxTQUFTLENBQUM7QUFDekUsVUFBSSw2QkFBNkIsT0FBTyw2QkFBNkIsS0FBSztBQUN4RSxpQkFBUyxPQUFPLE1BQU0sR0FBRyxPQUFPLFNBQVMsQ0FBQztBQUMxQyxlQUFPLE1BQU0sTUFBTTs7SUFFdkIsS0FBSztBQUNILFVBQUksMEJBQTBCLE9BQU8sT0FBTyxTQUFTLENBQUM7QUFDdEQsVUFBSSx5QkFBeUIsU0FBUyxhQUFhO0FBQ2pELGlCQUFTLE9BQU8sTUFBTSxHQUFHLE9BQU8sU0FBUyxDQUFDO0FBQzFDLGVBQU8sTUFBTSxNQUFNO2lCQUNWLHlCQUF5QixTQUFTLFdBQVcsd0JBQXdCLFVBQVUsS0FBSztBQUM3RixpQkFBUyxPQUFPLE1BQU0sR0FBRyxPQUFPLFNBQVMsQ0FBQztBQUMxQyxlQUFPLE1BQU0sTUFBTTs7QUFFckI7SUFDRixLQUFLO0FBQ0gsZUFBUyxPQUFPLE1BQU0sR0FBRyxPQUFPLFNBQVMsQ0FBQztBQUMxQyxhQUFPLE1BQU0sTUFBTTtBQUNuQjs7QUFHSixTQUFPO0FBQ1Q7QUF6TUYsSUEwTUUsVUFBVSxDQUFDLFdBQTRCO0FBQ3JDLE1BQUksT0FBaUIsQ0FBQTtBQUVyQixTQUFPLElBQUksQ0FBQ0MsV0FBUztBQUNuQixRQUFJQSxPQUFNLFNBQVMsU0FBUztBQUMxQixVQUFJQSxPQUFNLFVBQVUsS0FBSztBQUN2QixhQUFLLEtBQUssR0FBRzthQUNSO0FBQ0wsYUFBSyxPQUFPLEtBQUssWUFBWSxHQUFHLEdBQUcsQ0FBQzs7O0FBR3hDLFFBQUlBLE9BQU0sU0FBUyxTQUFTO0FBQzFCLFVBQUlBLE9BQU0sVUFBVSxLQUFLO0FBQ3ZCLGFBQUssS0FBSyxHQUFHO2FBQ1I7QUFDTCxhQUFLLE9BQU8sS0FBSyxZQUFZLEdBQUcsR0FBRyxDQUFDOzs7RUFHMUMsQ0FBQztBQUVELE1BQUksS0FBSyxTQUFTLEdBQUc7QUFDbkIsU0FBSyxRQUFPLEVBQUcsSUFBSSxDQUFDLFNBQVE7QUFDMUIsVUFBSSxTQUFTLEtBQUs7QUFDaEIsZUFBTyxLQUFLO1VBQ1YsTUFBTTtVQUNOLE9BQU87U0FDUjtpQkFDUSxTQUFTLEtBQUs7QUFDdkIsZUFBTyxLQUFLO1VBQ1YsTUFBTTtVQUNOLE9BQU87U0FDUjs7SUFFTCxDQUFDOztBQUdILFNBQU87QUFDVDtBQS9PRixJQWdQRSxXQUFXLENBQUMsV0FBMkI7QUFDckMsTUFBSSxTQUFTO0FBRWIsU0FBTyxJQUFJLENBQUNBLFdBQVM7QUFDbkIsWUFBUUEsT0FBTSxNQUFNO01BQ2xCLEtBQUs7QUFDSCxrQkFBVSxNQUFNQSxPQUFNLFFBQVE7QUFDOUI7TUFDRjtBQUNFLGtCQUFVQSxPQUFNO0FBQ2hCOztFQUVOLENBQUM7QUFFRCxTQUFPO0FBQ1Q7QUEvUEYsSUFnUUUsZUFBZSxDQUFDLFVBQTJCLEtBQUssTUFBTSxTQUFTLFFBQVEsTUFBTSxTQUFTLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25PakcsSUFBTSxvQkFBb0I7QUFFcEIsSUFBTyxnQkFBUCxNQUFPLGVBQWE7RUFzQnhCLGNBQUE7O0FBckJBLFNBQUEsV0FBMkIsQ0FBQTtBQUMzQixTQUFBLG1CQUE4QixDQUFBO0FBQzlCLDBDQUFBLElBQUEsTUFBQSxNQUFBO0FBRUEsU0FBQSxhQUE4QixJQUFJLGdCQUFlO0FBRWpELG9DQUFBLElBQUEsTUFBQSxNQUFBO0FBQ0EsMkNBQUEsSUFBQSxNQUF1QyxNQUFLO0lBQUUsQ0FBQztBQUMvQywwQ0FBQSxJQUFBLE1BQTJELE1BQUs7SUFBRSxDQUFDO0FBRW5FLDhCQUFBLElBQUEsTUFBQSxNQUFBO0FBQ0EscUNBQUEsSUFBQSxNQUFpQyxNQUFLO0lBQUUsQ0FBQztBQUN6QyxvQ0FBQSxJQUFBLE1BQXFELE1BQUs7SUFBRSxDQUFDO0FBRTdELDZCQUFBLElBQUEsTUFBNEYsQ0FBQSxDQUFFO0FBRTlGLHlCQUFBLElBQUEsTUFBUyxLQUFLO0FBQ2QsMkJBQUEsSUFBQSxNQUFXLEtBQUs7QUFDaEIsMkJBQUEsSUFBQSxNQUFXLEtBQUs7QUFDaEIsMENBQUEsSUFBQSxNQUEwQixLQUFLO0FBeU8vQiwrQkFBQSxJQUFBLE1BQWUsQ0FBQyxVQUFrQjtBQUNoQyxNQUFBQyx3QkFBQSxNQUFJLHdCQUFZLE1BQUksR0FBQTtBQUNwQixVQUFJLGlCQUFpQixTQUFTLE1BQU0sU0FBUyxjQUFjO0FBQ3pELGdCQUFRLElBQUksa0JBQWlCOztBQUUvQixVQUFJLGlCQUFpQixtQkFBbUI7QUFDdEMsUUFBQUEsd0JBQUEsTUFBSSx3QkFBWSxNQUFJLEdBQUE7QUFDcEIsZUFBTyxLQUFLLE1BQU0sU0FBUyxLQUFLOztBQUVsQyxVQUFJLGlCQUFpQixnQkFBZ0I7QUFDbkMsZUFBTyxLQUFLLE1BQU0sU0FBUyxLQUFLOztBQUVsQyxVQUFJLGlCQUFpQixPQUFPO0FBQzFCLGNBQU0saUJBQWlDLElBQUksZUFBZSxNQUFNLE9BQU87QUFFdkUsdUJBQWUsUUFBUTtBQUN2QixlQUFPLEtBQUssTUFBTSxTQUFTLGNBQWM7O0FBRTNDLGFBQU8sS0FBSyxNQUFNLFNBQVMsSUFBSSxlQUFlLE9BQU8sS0FBSyxDQUFDLENBQUM7SUFDOUQsQ0FBQztBQXpQQyxJQUFBQSx3QkFBQSxNQUFJLGlDQUFxQixJQUFJLFFBQWMsQ0FBQyxTQUFTLFdBQVU7QUFDN0QsTUFBQUEsd0JBQUEsTUFBSSx3Q0FBNEIsU0FBTyxHQUFBO0FBQ3ZDLE1BQUFBLHdCQUFBLE1BQUksdUNBQTJCLFFBQU0sR0FBQTtJQUN2QyxDQUFDLEdBQUMsR0FBQTtBQUVGLElBQUFBLHdCQUFBLE1BQUksMkJBQWUsSUFBSSxRQUFjLENBQUMsU0FBUyxXQUFVO0FBQ3ZELE1BQUFBLHdCQUFBLE1BQUksa0NBQXNCLFNBQU8sR0FBQTtBQUNqQyxNQUFBQSx3QkFBQSxNQUFJLGlDQUFxQixRQUFNLEdBQUE7SUFDakMsQ0FBQyxHQUFDLEdBQUE7QUFNRixJQUFBQyx3QkFBQSxNQUFJLGlDQUFBLEdBQUEsRUFBbUIsTUFBTSxNQUFLO0lBQUUsQ0FBQztBQUNyQyxJQUFBQSx3QkFBQSxNQUFJLDJCQUFBLEdBQUEsRUFBYSxNQUFNLE1BQUs7SUFBRSxDQUFDO0VBQ2pDOzs7Ozs7OztFQVNBLE9BQU8sbUJBQW1CLFFBQXNCO0FBQzlDLFVBQU0sU0FBUyxJQUFJLGVBQWE7QUFDaEMsV0FBTyxLQUFLLE1BQU0sT0FBTyxvQkFBb0IsTUFBTSxDQUFDO0FBQ3BELFdBQU87RUFDVDtFQUVBLE9BQU8sY0FDTCxVQUNBLFFBQ0EsU0FBNkI7QUFFN0IsVUFBTSxTQUFTLElBQUksZUFBYTtBQUNoQyxlQUFXQyxZQUFXLE9BQU8sVUFBVTtBQUNyQyxhQUFPLGlCQUFpQkEsUUFBTzs7QUFFakMsV0FBTyxLQUFLLE1BQ1YsT0FBTyxlQUNMLFVBQ0EsRUFBRSxHQUFHLFFBQVEsUUFBUSxLQUFJLEdBQ3pCLEVBQUUsR0FBRyxTQUFTLFNBQVMsRUFBRSxHQUFHLFNBQVMsU0FBUyw2QkFBNkIsU0FBUSxFQUFFLENBQUUsQ0FDeEY7QUFFSCxXQUFPO0VBQ1Q7RUFFVSxLQUFLLFVBQTRCO0FBQ3pDLGFBQVEsRUFBRyxLQUFLLE1BQUs7QUFDbkIsV0FBSyxXQUFVO0FBQ2YsV0FBSyxNQUFNLEtBQUs7SUFDbEIsR0FBR0Qsd0JBQUEsTUFBSSw0QkFBQSxHQUFBLENBQWE7RUFDdEI7RUFFVSxpQkFBaUJDLFVBQXFCO0FBQzlDLFNBQUssU0FBUyxLQUFLQSxRQUFPO0VBQzVCO0VBRVUsWUFBWUEsVUFBa0IsT0FBTyxNQUFJO0FBQ2pELFNBQUssaUJBQWlCLEtBQUtBLFFBQU87QUFDbEMsUUFBSSxNQUFNO0FBQ1IsV0FBSyxNQUFNLFdBQVdBLFFBQU87O0VBRWpDO0VBRVUsTUFBTSxlQUNkLFVBQ0EsUUFDQSxTQUE2QjtBQUU3QixVQUFNLFNBQVMsU0FBUztBQUN4QixRQUFJLFFBQVE7QUFDVixVQUFJLE9BQU87QUFBUyxhQUFLLFdBQVcsTUFBSztBQUN6QyxhQUFPLGlCQUFpQixTQUFTLE1BQU0sS0FBSyxXQUFXLE1BQUssQ0FBRTs7QUFFaEUsSUFBQUQsd0JBQUEsTUFBSSwwQkFBQSxLQUFBLDJCQUFBLEVBQWMsS0FBbEIsSUFBSTtBQUNKLFVBQU0sU0FBUyxNQUFNLFNBQVMsT0FDNUIsRUFBRSxHQUFHLFFBQVEsUUFBUSxLQUFJLEdBQ3pCLEVBQUUsR0FBRyxTQUFTLFFBQVEsS0FBSyxXQUFXLE9BQU0sQ0FBRTtBQUVoRCxTQUFLLFdBQVU7QUFDZixxQkFBaUIsU0FBUyxRQUFRO0FBQ2hDLE1BQUFBLHdCQUFBLE1BQUksMEJBQUEsS0FBQSw2QkFBQSxFQUFnQixLQUFwQixNQUFxQixLQUFLOztBQUU1QixRQUFJLE9BQU8sV0FBVyxRQUFRLFNBQVM7QUFDckMsWUFBTSxJQUFJLGtCQUFpQjs7QUFFN0IsSUFBQUEsd0JBQUEsTUFBSSwwQkFBQSxLQUFBLHlCQUFBLEVBQVksS0FBaEIsSUFBSTtFQUNOO0VBRVUsYUFBVTtBQUNsQixRQUFJLEtBQUs7QUFBTztBQUNoQixJQUFBQSx3QkFBQSxNQUFJLHdDQUFBLEdBQUEsRUFBeUIsS0FBN0IsSUFBSTtBQUNKLFNBQUssTUFBTSxTQUFTO0VBQ3RCO0VBRUEsSUFBSSxRQUFLO0FBQ1AsV0FBT0Esd0JBQUEsTUFBSSxzQkFBQSxHQUFBO0VBQ2I7RUFFQSxJQUFJLFVBQU87QUFDVCxXQUFPQSx3QkFBQSxNQUFJLHdCQUFBLEdBQUE7RUFDYjtFQUVBLElBQUksVUFBTztBQUNULFdBQU9BLHdCQUFBLE1BQUksd0JBQUEsR0FBQTtFQUNiO0VBRUEsUUFBSztBQUNILFNBQUssV0FBVyxNQUFLO0VBQ3ZCOzs7Ozs7OztFQVNBLEdBQTRDLE9BQWMsVUFBb0M7QUFDNUYsVUFBTSxZQUNKQSx3QkFBQSxNQUFJLDBCQUFBLEdBQUEsRUFBWSxLQUFLLE1BQU1BLHdCQUFBLE1BQUksMEJBQUEsR0FBQSxFQUFZLEtBQUssSUFBSSxDQUFBO0FBQ3RELGNBQVUsS0FBSyxFQUFFLFNBQVEsQ0FBRTtBQUMzQixXQUFPO0VBQ1Q7Ozs7Ozs7O0VBU0EsSUFBNkMsT0FBYyxVQUFvQztBQUM3RixVQUFNLFlBQVlBLHdCQUFBLE1BQUksMEJBQUEsR0FBQSxFQUFZLEtBQUs7QUFDdkMsUUFBSSxDQUFDO0FBQVcsYUFBTztBQUN2QixVQUFNLFFBQVEsVUFBVSxVQUFVLENBQUMsTUFBTSxFQUFFLGFBQWEsUUFBUTtBQUNoRSxRQUFJLFNBQVM7QUFBRyxnQkFBVSxPQUFPLE9BQU8sQ0FBQztBQUN6QyxXQUFPO0VBQ1Q7Ozs7OztFQU9BLEtBQThDLE9BQWMsVUFBb0M7QUFDOUYsVUFBTSxZQUNKQSx3QkFBQSxNQUFJLDBCQUFBLEdBQUEsRUFBWSxLQUFLLE1BQU1BLHdCQUFBLE1BQUksMEJBQUEsR0FBQSxFQUFZLEtBQUssSUFBSSxDQUFBO0FBQ3RELGNBQVUsS0FBSyxFQUFFLFVBQVUsTUFBTSxLQUFJLENBQUU7QUFDdkMsV0FBTztFQUNUOzs7Ozs7Ozs7Ozs7RUFhQSxRQUNFLE9BQVk7QUFNWixXQUFPLElBQUksUUFBUSxDQUFDLFNBQVMsV0FBVTtBQUNyQyxNQUFBRCx3QkFBQSxNQUFJLHVDQUEyQixNQUFJLEdBQUE7QUFDbkMsVUFBSSxVQUFVO0FBQVMsYUFBSyxLQUFLLFNBQVMsTUFBTTtBQUNoRCxXQUFLLEtBQUssT0FBTyxPQUFjO0lBQ2pDLENBQUM7RUFDSDtFQUVBLE1BQU0sT0FBSTtBQUNSLElBQUFBLHdCQUFBLE1BQUksdUNBQTJCLE1BQUksR0FBQTtBQUNuQyxVQUFNQyx3QkFBQSxNQUFJLDJCQUFBLEdBQUE7RUFDWjtFQUVBLElBQUksaUJBQWM7QUFDaEIsV0FBT0Esd0JBQUEsTUFBSSx1Q0FBQSxHQUFBO0VBQ2I7Ozs7O0VBYUEsTUFBTSxlQUFZO0FBQ2hCLFVBQU0sS0FBSyxLQUFJO0FBQ2YsV0FBT0Esd0JBQUEsTUFBSSwwQkFBQSxLQUFBLDhCQUFBLEVBQWlCLEtBQXJCLElBQUk7RUFDYjs7Ozs7O0VBcUJBLE1BQU0sWUFBUztBQUNiLFVBQU0sS0FBSyxLQUFJO0FBQ2YsV0FBT0Esd0JBQUEsTUFBSSwwQkFBQSxLQUFBLDJCQUFBLEVBQWMsS0FBbEIsSUFBSTtFQUNiO0VBdUJVLE1BQ1IsVUFDRyxNQUE0QztBQUcvQyxRQUFJQSx3QkFBQSxNQUFJLHNCQUFBLEdBQUE7QUFBUztBQUVqQixRQUFJLFVBQVUsT0FBTztBQUNuQixNQUFBRCx3QkFBQSxNQUFJLHNCQUFVLE1BQUksR0FBQTtBQUNsQixNQUFBQyx3QkFBQSxNQUFJLGtDQUFBLEdBQUEsRUFBbUIsS0FBdkIsSUFBSTs7QUFHTixVQUFNLFlBQTREQSx3QkFBQSxNQUFJLDBCQUFBLEdBQUEsRUFBWSxLQUFLO0FBQ3ZGLFFBQUksV0FBVztBQUNiLE1BQUFBLHdCQUFBLE1BQUksMEJBQUEsR0FBQSxFQUFZLEtBQUssSUFBSSxVQUFVLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRSxJQUFJO0FBQ3hELGdCQUFVLFFBQVEsQ0FBQyxFQUFFLFNBQVEsTUFBWSxTQUFTLEdBQUcsSUFBSSxDQUFDOztBQUc1RCxRQUFJLFVBQVUsU0FBUztBQUNyQixZQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLFVBQUksQ0FBQ0Esd0JBQUEsTUFBSSx1Q0FBQSxHQUFBLEtBQTRCLENBQUMsV0FBVyxRQUFRO0FBQ3ZELGdCQUFRLE9BQU8sS0FBSzs7QUFFdEIsTUFBQUEsd0JBQUEsTUFBSSx1Q0FBQSxHQUFBLEVBQXdCLEtBQTVCLE1BQTZCLEtBQUs7QUFDbEMsTUFBQUEsd0JBQUEsTUFBSSxpQ0FBQSxHQUFBLEVBQWtCLEtBQXRCLE1BQXVCLEtBQUs7QUFDNUIsV0FBSyxNQUFNLEtBQUs7QUFDaEI7O0FBR0YsUUFBSSxVQUFVLFNBQVM7QUFHckIsWUFBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixVQUFJLENBQUNBLHdCQUFBLE1BQUksdUNBQUEsR0FBQSxLQUE0QixDQUFDLFdBQVcsUUFBUTtBQU92RCxnQkFBUSxPQUFPLEtBQUs7O0FBRXRCLE1BQUFBLHdCQUFBLE1BQUksdUNBQUEsR0FBQSxFQUF3QixLQUE1QixNQUE2QixLQUFLO0FBQ2xDLE1BQUFBLHdCQUFBLE1BQUksaUNBQUEsR0FBQSxFQUFrQixLQUF0QixNQUF1QixLQUFLO0FBQzVCLFdBQUssTUFBTSxLQUFLOztFQUVwQjtFQUVVLGFBQVU7QUFDbEIsVUFBTSxlQUFlLEtBQUssaUJBQWlCLEdBQUcsRUFBRTtBQUNoRCxRQUFJLGNBQWM7QUFDaEIsV0FBSyxNQUFNLGdCQUFnQkEsd0JBQUEsTUFBSSwwQkFBQSxLQUFBLDhCQUFBLEVBQWlCLEtBQXJCLElBQUksQ0FBbUI7O0VBRXREO0VBcURVLE1BQU0sb0JBQ2QsZ0JBQ0EsU0FBNkI7QUFFN0IsVUFBTSxTQUFTLFNBQVM7QUFDeEIsUUFBSSxRQUFRO0FBQ1YsVUFBSSxPQUFPO0FBQVMsYUFBSyxXQUFXLE1BQUs7QUFDekMsYUFBTyxpQkFBaUIsU0FBUyxNQUFNLEtBQUssV0FBVyxNQUFLLENBQUU7O0FBRWhFLElBQUFBLHdCQUFBLE1BQUksMEJBQUEsS0FBQSwyQkFBQSxFQUFjLEtBQWxCLElBQUk7QUFDSixTQUFLLFdBQVU7QUFDZixVQUFNLFNBQVMsT0FBTyxtQkFBdUMsZ0JBQWdCLEtBQUssVUFBVTtBQUM1RixxQkFBaUIsU0FBUyxRQUFRO0FBQ2hDLE1BQUFBLHdCQUFBLE1BQUksMEJBQUEsS0FBQSw2QkFBQSxFQUFnQixLQUFwQixNQUFxQixLQUFLOztBQUU1QixRQUFJLE9BQU8sV0FBVyxRQUFRLFNBQVM7QUFDckMsWUFBTSxJQUFJLGtCQUFpQjs7QUFFN0IsSUFBQUEsd0JBQUEsTUFBSSwwQkFBQSxLQUFBLHlCQUFBLEVBQVksS0FBaEIsSUFBSTtFQUNOO0VBNERBLEVBQUEsd0NBQUEsb0JBQUEsUUFBQSxHQUFBLGtDQUFBLG9CQUFBLFFBQUEsR0FBQSx5Q0FBQSxvQkFBQSxRQUFBLEdBQUEsd0NBQUEsb0JBQUEsUUFBQSxHQUFBLDRCQUFBLG9CQUFBLFFBQUEsR0FBQSxtQ0FBQSxvQkFBQSxRQUFBLEdBQUEsa0NBQUEsb0JBQUEsUUFBQSxHQUFBLDJCQUFBLG9CQUFBLFFBQUEsR0FBQSx1QkFBQSxvQkFBQSxRQUFBLEdBQUEseUJBQUEsb0JBQUEsUUFBQSxHQUFBLHlCQUFBLG9CQUFBLFFBQUEsR0FBQSx3Q0FBQSxvQkFBQSxRQUFBLEdBQUEsNkJBQUEsb0JBQUEsUUFBQSxHQUFBLDJCQUFBLG9CQUFBLFFBQUEsR0FBQSxpQ0FBQSxTQUFBRSxrQ0FBQTtBQXJQRSxRQUFJLEtBQUssaUJBQWlCLFdBQVcsR0FBRztBQUN0QyxZQUFNLElBQUksZUFBZSw4REFBOEQ7O0FBRXpGLFdBQU8sS0FBSyxpQkFBaUIsR0FBRyxFQUFFO0VBQ3BDLEdBQUMsOEJBQUEsU0FBQUMsK0JBQUE7QUFZQyxRQUFJLEtBQUssaUJBQWlCLFdBQVcsR0FBRztBQUN0QyxZQUFNLElBQUksZUFBZSw4REFBOEQ7O0FBRXpGLFVBQU0sYUFBYSxLQUFLLGlCQUNyQixHQUFHLEVBQUUsRUFDTCxRQUFRLE9BQU8sQ0FBQyxVQUE4QixNQUFNLFNBQVMsTUFBTSxFQUNuRSxJQUFJLENBQUMsVUFBVSxNQUFNLElBQUk7QUFDNUIsUUFBSSxXQUFXLFdBQVcsR0FBRztBQUMzQixZQUFNLElBQUksZUFBZSwrREFBK0Q7O0FBRTFGLFdBQU8sV0FBVyxLQUFLLEdBQUc7RUFDNUIsR0FBQyw4QkFBQSxTQUFBQywrQkFBQTtBQXlGQyxRQUFJLEtBQUs7QUFBTztBQUNoQixJQUFBTCx3QkFBQSxNQUFJLHVDQUEyQixRQUFTLEdBQUE7RUFDMUMsR0FBQyxnQ0FBQSxTQUFBTSwrQkFDZSxPQUF5QjtBQUN2QyxRQUFJLEtBQUs7QUFBTztBQUNoQixVQUFNLGtCQUFrQkwsd0JBQUEsTUFBSSwwQkFBQSxLQUFBLGdDQUFBLEVBQW1CLEtBQXZCLE1BQXdCLEtBQUs7QUFDckQsU0FBSyxNQUFNLGVBQWUsT0FBTyxlQUFlO0FBRWhELFlBQVEsTUFBTSxNQUFNO01BQ2xCLEtBQUssdUJBQXVCO0FBQzFCLGNBQU0sVUFBVSxnQkFBZ0IsUUFBUSxHQUFHLEVBQUU7QUFDN0MsWUFBSSxNQUFNLE1BQU0sU0FBUyxnQkFBZ0IsUUFBUSxTQUFTLFFBQVE7QUFDaEUsZUFBSyxNQUFNLFFBQVEsTUFBTSxNQUFNLE1BQU0sUUFBUSxRQUFRLEVBQUU7bUJBQzlDLE1BQU0sTUFBTSxTQUFTLHNCQUFzQixRQUFRLFNBQVMsWUFBWTtBQUNqRixjQUFJLFFBQVEsT0FBTztBQUNqQixpQkFBSyxNQUFNLGFBQWEsTUFBTSxNQUFNLGNBQWMsUUFBUSxLQUFLOzs7QUFHbkU7O01BRUYsS0FBSyxnQkFBZ0I7QUFDbkIsYUFBSyxpQkFBaUIsZUFBZTtBQUNyQyxhQUFLLFlBQVksaUJBQWlCLElBQUk7QUFDdEM7O01BRUYsS0FBSyxzQkFBc0I7QUFDekIsYUFBSyxNQUFNLGdCQUFnQixnQkFBZ0IsUUFBUSxHQUFHLEVBQUUsQ0FBRTtBQUMxRDs7TUFFRixLQUFLLGlCQUFpQjtBQUNwQixRQUFBRCx3QkFBQSxNQUFJLHVDQUEyQixpQkFBZSxHQUFBO0FBQzlDOztNQUVGLEtBQUs7TUFDTCxLQUFLO0FBQ0g7O0VBRU4sR0FBQyw0QkFBQSxTQUFBTyw2QkFBQTtBQUVDLFFBQUksS0FBSyxPQUFPO0FBQ2QsWUFBTSxJQUFJLGVBQWUseUNBQXlDOztBQUVwRSxVQUFNLFdBQVdOLHdCQUFBLE1BQUksdUNBQUEsR0FBQTtBQUNyQixRQUFJLENBQUMsVUFBVTtBQUNiLFlBQU0sSUFBSSxlQUFlLDBDQUEwQzs7QUFFckUsSUFBQUQsd0JBQUEsTUFBSSx1Q0FBMkIsUUFBUyxHQUFBO0FBQ3hDLFdBQU87RUFDVCxHQUFDLG1DQUFBLFNBQUFRLGtDQTRCa0IsT0FBeUI7QUFDMUMsUUFBSSxXQUFXUCx3QkFBQSxNQUFJLHVDQUFBLEdBQUE7QUFFbkIsUUFBSSxNQUFNLFNBQVMsaUJBQWlCO0FBQ2xDLFVBQUksVUFBVTtBQUNaLGNBQU0sSUFBSSxlQUFlLCtCQUErQixNQUFNLElBQUksa0NBQWtDOztBQUV0RyxhQUFPLE1BQU07O0FBR2YsUUFBSSxDQUFDLFVBQVU7QUFDYixZQUFNLElBQUksZUFBZSwrQkFBK0IsTUFBTSxJQUFJLHlCQUF5Qjs7QUFHN0YsWUFBUSxNQUFNLE1BQU07TUFDbEIsS0FBSztBQUNILGVBQU87TUFDVCxLQUFLO0FBQ0gsaUJBQVMsY0FBYyxNQUFNLE1BQU07QUFDbkMsaUJBQVMsZ0JBQWdCLE1BQU0sTUFBTTtBQUNyQyxpQkFBUyxNQUFNLGdCQUFnQixNQUFNLE1BQU07QUFDM0MsZUFBTztNQUNULEtBQUs7QUFDSCxpQkFBUyxRQUFRLEtBQUssTUFBTSxhQUFhO0FBQ3pDLGVBQU87TUFDVCxLQUFLLHVCQUF1QjtBQUMxQixjQUFNLGtCQUFrQixTQUFTLFFBQVEsR0FBRyxNQUFNLEtBQUs7QUFDdkQsWUFBSSxpQkFBaUIsU0FBUyxVQUFVLE1BQU0sTUFBTSxTQUFTLGNBQWM7QUFDekUsMEJBQWdCLFFBQVEsTUFBTSxNQUFNO21CQUMzQixpQkFBaUIsU0FBUyxjQUFjLE1BQU0sTUFBTSxTQUFTLG9CQUFvQjtBQUkxRixjQUFJLFVBQVcsZ0JBQXdCLGlCQUFpQixLQUFLO0FBQzdELHFCQUFXLE1BQU0sTUFBTTtBQUV2QixpQkFBTyxlQUFlLGlCQUFpQixtQkFBbUI7WUFDeEQsT0FBTztZQUNQLFlBQVk7WUFDWixVQUFVO1dBQ1g7QUFFRCxjQUFJLFNBQVM7QUFDWCw0QkFBZ0IsUUFBUSxhQUFhLE9BQU87OztBQUdoRCxlQUFPOztNQUVULEtBQUs7QUFDSCxlQUFPOztFQUViLEdBRUMsT0FBTyxjQUFhLElBQUM7QUFDcEIsVUFBTSxZQUFrQyxDQUFBO0FBQ3hDLFVBQU0sWUFHQSxDQUFBO0FBQ04sUUFBSSxPQUFPO0FBRVgsU0FBSyxHQUFHLGVBQWUsQ0FBQyxVQUFTO0FBQy9CLFlBQU0sU0FBUyxVQUFVLE1BQUs7QUFDOUIsVUFBSSxRQUFRO0FBQ1YsZUFBTyxRQUFRLEtBQUs7YUFDZjtBQUNMLGtCQUFVLEtBQUssS0FBSzs7SUFFeEIsQ0FBQztBQUVELFNBQUssR0FBRyxPQUFPLE1BQUs7QUFDbEIsYUFBTztBQUNQLGlCQUFXLFVBQVUsV0FBVztBQUM5QixlQUFPLFFBQVEsTUFBUzs7QUFFMUIsZ0JBQVUsU0FBUztJQUNyQixDQUFDO0FBRUQsU0FBSyxHQUFHLFNBQVMsQ0FBQyxRQUFPO0FBQ3ZCLGFBQU87QUFDUCxpQkFBVyxVQUFVLFdBQVc7QUFDOUIsZUFBTyxPQUFPLEdBQUc7O0FBRW5CLGdCQUFVLFNBQVM7SUFDckIsQ0FBQztBQUVELFNBQUssR0FBRyxTQUFTLENBQUMsUUFBTztBQUN2QixhQUFPO0FBQ1AsaUJBQVcsVUFBVSxXQUFXO0FBQzlCLGVBQU8sT0FBTyxHQUFHOztBQUVuQixnQkFBVSxTQUFTO0lBQ3JCLENBQUM7QUFFRCxXQUFPO01BQ0wsTUFBTSxZQUF3RDtBQUM1RCxZQUFJLENBQUMsVUFBVSxRQUFRO0FBQ3JCLGNBQUksTUFBTTtBQUNSLG1CQUFPLEVBQUUsT0FBTyxRQUFXLE1BQU0sS0FBSTs7QUFFdkMsaUJBQU8sSUFBSSxRQUF3QyxDQUFDLFNBQVMsV0FDM0QsVUFBVSxLQUFLLEVBQUUsU0FBUyxPQUFNLENBQUUsQ0FBQyxFQUNuQyxLQUFLLENBQUNRLFdBQVdBLFNBQVEsRUFBRSxPQUFPQSxRQUFPLE1BQU0sTUFBSyxJQUFLLEVBQUUsT0FBTyxRQUFXLE1BQU0sS0FBSSxDQUFHOztBQUU5RixjQUFNLFFBQVEsVUFBVSxNQUFLO0FBQzdCLGVBQU8sRUFBRSxPQUFPLE9BQU8sTUFBTSxNQUFLO01BQ3BDO01BQ0EsUUFBUSxZQUFXO0FBQ2pCLGFBQUssTUFBSztBQUNWLGVBQU8sRUFBRSxPQUFPLFFBQVcsTUFBTSxLQUFJO01BQ3ZDOztFQUVKO0VBRUEsbUJBQWdCO0FBQ2QsVUFBTSxTQUFTLElBQUksT0FBTyxLQUFLLE9BQU8sYUFBYSxFQUFFLEtBQUssSUFBSSxHQUFHLEtBQUssVUFBVTtBQUNoRixXQUFPLE9BQU8saUJBQWdCO0VBQ2hDOzs7O0FDcGlCSSxJQUFPLFdBQVAsY0FBd0IsWUFBVztFQW1CdkMsT0FDRSxNQUNBLFNBQTZCO0FBRTdCLFFBQUksS0FBSyxTQUFTLG1CQUFtQjtBQUNuQyxjQUFRLEtBQ04sY0FBYyxLQUFLLEtBQUssaURBQ3RCLGtCQUFrQixLQUFLLEtBQUssQ0FDOUI7NkhBQWdJOztBQUdwSSxXQUFPLEtBQUssUUFBUSxLQUFLLGdCQUFnQjtNQUN2QztNQUNBLFNBQVUsS0FBSyxRQUFnQixTQUFTLFdBQVc7TUFDbkQsR0FBRztNQUNILFFBQVEsS0FBSyxVQUFVO0tBQ3hCO0VBQ0g7Ozs7RUFLQSxPQUFPLE1BQTJCLFNBQTZCO0FBQzdELFdBQU8sY0FBYyxjQUFjLE1BQU0sTUFBTSxPQUFPO0VBQ3hEOztBQW9MRixJQUFNLG9CQUEwQztFQUM5QyxjQUFjO0VBQ2QsbUJBQW1CO0VBQ25CLHNCQUFzQjtFQUN0QiwyQkFBMkI7RUFDM0Isc0JBQXNCOztBQTRnQnhCLDBCQUFpQkMsV0FBUTtBQW1DekIsR0FuQ2lCLGFBQUEsV0FBUSxDQUFBLEVBQUE7OztBQzN2QnpCLElBQU8sb0JBQVE7QUFDUixJQUFNLGNBQWMsQ0FBQyxRQUFRLGVBQWU7OztBQ0E1QyxJQUFNLFVBQVUsSUFBSSxZQUFZO0FBQ2hDLElBQU0sVUFBVSxJQUFJLFlBQVk7QUFDdkMsSUFBTSxZQUFZLEtBQUs7QUFDaEIsU0FBUyxVQUFVLFNBQVM7QUFDL0IsUUFBTSxPQUFPLFFBQVEsT0FBTyxDQUFDLEtBQUssRUFBRSxPQUFPLE1BQU0sTUFBTSxRQUFRLENBQUM7QUFDaEUsUUFBTSxNQUFNLElBQUksV0FBVyxJQUFJO0FBQy9CLE1BQUksSUFBSTtBQUNSLGFBQVcsVUFBVSxTQUFTO0FBQzFCLFFBQUksSUFBSSxRQUFRLENBQUM7QUFDakIsU0FBSyxPQUFPO0FBQUEsRUFDaEI7QUFDQSxTQUFPO0FBQ1g7OztBQ1pPLElBQU0sZUFBZSxDQUFDLFVBQVU7QUFDbkMsTUFBSSxZQUFZO0FBQ2hCLE1BQUksT0FBTyxjQUFjLFVBQVU7QUFDL0IsZ0JBQVksUUFBUSxPQUFPLFNBQVM7QUFBQSxFQUN4QztBQUNBLFFBQU0sYUFBYTtBQUNuQixRQUFNLE1BQU0sQ0FBQztBQUNiLFdBQVMsSUFBSSxHQUFHLElBQUksVUFBVSxRQUFRLEtBQUssWUFBWTtBQUNuRCxRQUFJLEtBQUssT0FBTyxhQUFhLE1BQU0sTUFBTSxVQUFVLFNBQVMsR0FBRyxJQUFJLFVBQVUsQ0FBQyxDQUFDO0FBQUEsRUFDbkY7QUFDQSxTQUFPLEtBQUssSUFBSSxLQUFLLEVBQUUsQ0FBQztBQUM1QjtBQUNPLElBQU0sU0FBUyxDQUFDLFVBQVU7QUFDN0IsU0FBTyxhQUFhLEtBQUssRUFBRSxRQUFRLE1BQU0sRUFBRSxFQUFFLFFBQVEsT0FBTyxHQUFHLEVBQUUsUUFBUSxPQUFPLEdBQUc7QUFDdkY7QUFDTyxJQUFNLGVBQWUsQ0FBQyxZQUFZO0FBQ3JDLFFBQU0sU0FBUyxLQUFLLE9BQU87QUFDM0IsUUFBTSxRQUFRLElBQUksV0FBVyxPQUFPLE1BQU07QUFDMUMsV0FBUyxJQUFJLEdBQUcsSUFBSSxPQUFPLFFBQVEsS0FBSztBQUNwQyxVQUFNLENBQUMsSUFBSSxPQUFPLFdBQVcsQ0FBQztBQUFBLEVBQ2xDO0FBQ0EsU0FBTztBQUNYO0FBQ08sSUFBTSxTQUFTLENBQUMsVUFBVTtBQUM3QixNQUFJLFVBQVU7QUFDZCxNQUFJLG1CQUFtQixZQUFZO0FBQy9CLGNBQVUsUUFBUSxPQUFPLE9BQU87QUFBQSxFQUNwQztBQUNBLFlBQVUsUUFBUSxRQUFRLE1BQU0sR0FBRyxFQUFFLFFBQVEsTUFBTSxHQUFHLEVBQUUsUUFBUSxPQUFPLEVBQUU7QUFDekUsTUFBSTtBQUNBLFdBQU8sYUFBYSxPQUFPO0FBQUEsRUFDL0IsUUFDTTtBQUNGLFVBQU0sSUFBSSxVQUFVLG1EQUFtRDtBQUFBLEVBQzNFO0FBQ0o7OztBQ3BDTyxJQUFNLFlBQU4sY0FBd0IsTUFBTTtBQUFBLEVBQ2pDLFdBQVcsT0FBTztBQUNkLFdBQU87QUFBQSxFQUNYO0FBQUEsRUFDQSxZQUFZQyxVQUFTO0FBQ2pCLFVBQU1BLFFBQU87QUFDYixTQUFLLE9BQU87QUFDWixTQUFLLE9BQU8sS0FBSyxZQUFZO0FBQzdCLFVBQU0sb0JBQW9CLE1BQU0sS0FBSyxXQUFXO0FBQUEsRUFDcEQ7QUFDSjtBQWtDTyxJQUFNLG1CQUFOLGNBQStCLFVBQVU7QUFBQSxFQUM1QyxjQUFjO0FBQ1YsVUFBTSxHQUFHLFNBQVM7QUFDbEIsU0FBSyxPQUFPO0FBQUEsRUFDaEI7QUFBQSxFQUNBLFdBQVcsT0FBTztBQUNkLFdBQU87QUFBQSxFQUNYO0FBQ0o7QUFvQk8sSUFBTSxhQUFOLGNBQXlCLFVBQVU7QUFBQSxFQUN0QyxjQUFjO0FBQ1YsVUFBTSxHQUFHLFNBQVM7QUFDbEIsU0FBSyxPQUFPO0FBQUEsRUFDaEI7QUFBQSxFQUNBLFdBQVcsT0FBTztBQUNkLFdBQU87QUFBQSxFQUNYO0FBQ0o7QUFDTyxJQUFNLGFBQU4sY0FBeUIsVUFBVTtBQUFBLEVBQ3RDLGNBQWM7QUFDVixVQUFNLEdBQUcsU0FBUztBQUNsQixTQUFLLE9BQU87QUFBQSxFQUNoQjtBQUFBLEVBQ0EsV0FBVyxPQUFPO0FBQ2QsV0FBTztBQUFBLEVBQ1g7QUFDSjs7O0FDekZBLFNBQVMsU0FBUyxNQUFNLE9BQU8sa0JBQWtCO0FBQzdDLFNBQU8sSUFBSSxVQUFVLGtEQUFrRCxJQUFJLFlBQVksSUFBSSxFQUFFO0FBQ2pHO0FBQ0EsU0FBUyxZQUFZLFdBQVcsTUFBTTtBQUNsQyxTQUFPLFVBQVUsU0FBUztBQUM5QjtBQUNBLFNBQVMsY0FBYyxNQUFNO0FBQ3pCLFNBQU8sU0FBUyxLQUFLLEtBQUssTUFBTSxDQUFDLEdBQUcsRUFBRTtBQUMxQztBQUNBLFNBQVMsY0FBYyxLQUFLO0FBQ3hCLFVBQVEsS0FBSztBQUFBLElBQ1QsS0FBSztBQUNELGFBQU87QUFBQSxJQUNYLEtBQUs7QUFDRCxhQUFPO0FBQUEsSUFDWCxLQUFLO0FBQ0QsYUFBTztBQUFBLElBQ1g7QUFDSSxZQUFNLElBQUksTUFBTSxhQUFhO0FBQUEsRUFDckM7QUFDSjtBQUNBLFNBQVMsV0FBVyxLQUFLLFFBQVE7QUFDN0IsTUFBSSxPQUFPLFVBQVUsQ0FBQyxPQUFPLEtBQUssQ0FBQyxhQUFhLElBQUksT0FBTyxTQUFTLFFBQVEsQ0FBQyxHQUFHO0FBQzVFLFFBQUksTUFBTTtBQUNWLFFBQUksT0FBTyxTQUFTLEdBQUc7QUFDbkIsWUFBTSxPQUFPLE9BQU8sSUFBSTtBQUN4QixhQUFPLFVBQVUsT0FBTyxLQUFLLElBQUksQ0FBQyxRQUFRLElBQUk7QUFBQSxJQUNsRCxXQUNTLE9BQU8sV0FBVyxHQUFHO0FBQzFCLGFBQU8sVUFBVSxPQUFPLENBQUMsQ0FBQyxPQUFPLE9BQU8sQ0FBQyxDQUFDO0FBQUEsSUFDOUMsT0FDSztBQUNELGFBQU8sR0FBRyxPQUFPLENBQUMsQ0FBQztBQUFBLElBQ3ZCO0FBQ0EsVUFBTSxJQUFJLFVBQVUsR0FBRztBQUFBLEVBQzNCO0FBQ0o7QUFDTyxTQUFTLGtCQUFrQixLQUFLLFFBQVEsUUFBUTtBQUNuRCxVQUFRLEtBQUs7QUFBQSxJQUNULEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUssU0FBUztBQUNWLFVBQUksQ0FBQyxZQUFZLElBQUksV0FBVyxNQUFNO0FBQ2xDLGNBQU0sU0FBUyxNQUFNO0FBQ3pCLFlBQU0sV0FBVyxTQUFTLElBQUksTUFBTSxDQUFDLEdBQUcsRUFBRTtBQUMxQyxZQUFNLFNBQVMsY0FBYyxJQUFJLFVBQVUsSUFBSTtBQUMvQyxVQUFJLFdBQVc7QUFDWCxjQUFNLFNBQVMsT0FBTyxRQUFRLElBQUksZ0JBQWdCO0FBQ3REO0FBQUEsSUFDSjtBQUFBLElBQ0EsS0FBSztBQUFBLElBQ0wsS0FBSztBQUFBLElBQ0wsS0FBSyxTQUFTO0FBQ1YsVUFBSSxDQUFDLFlBQVksSUFBSSxXQUFXLG1CQUFtQjtBQUMvQyxjQUFNLFNBQVMsbUJBQW1CO0FBQ3RDLFlBQU0sV0FBVyxTQUFTLElBQUksTUFBTSxDQUFDLEdBQUcsRUFBRTtBQUMxQyxZQUFNLFNBQVMsY0FBYyxJQUFJLFVBQVUsSUFBSTtBQUMvQyxVQUFJLFdBQVc7QUFDWCxjQUFNLFNBQVMsT0FBTyxRQUFRLElBQUksZ0JBQWdCO0FBQ3REO0FBQUEsSUFDSjtBQUFBLElBQ0EsS0FBSztBQUFBLElBQ0wsS0FBSztBQUFBLElBQ0wsS0FBSyxTQUFTO0FBQ1YsVUFBSSxDQUFDLFlBQVksSUFBSSxXQUFXLFNBQVM7QUFDckMsY0FBTSxTQUFTLFNBQVM7QUFDNUIsWUFBTSxXQUFXLFNBQVMsSUFBSSxNQUFNLENBQUMsR0FBRyxFQUFFO0FBQzFDLFlBQU0sU0FBUyxjQUFjLElBQUksVUFBVSxJQUFJO0FBQy9DLFVBQUksV0FBVztBQUNYLGNBQU0sU0FBUyxPQUFPLFFBQVEsSUFBSSxnQkFBZ0I7QUFDdEQ7QUFBQSxJQUNKO0FBQUEsSUFDQSxLQUFLLFNBQVM7QUFDVixVQUFJLElBQUksVUFBVSxTQUFTLGFBQWEsSUFBSSxVQUFVLFNBQVMsU0FBUztBQUNwRSxjQUFNLFNBQVMsa0JBQWtCO0FBQUEsTUFDckM7QUFDQTtBQUFBLElBQ0o7QUFBQSxJQUNBLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUssU0FBUztBQUNWLFVBQUksQ0FBQyxZQUFZLElBQUksV0FBVyxPQUFPO0FBQ25DLGNBQU0sU0FBUyxPQUFPO0FBQzFCLFlBQU0sV0FBVyxjQUFjLEdBQUc7QUFDbEMsWUFBTSxTQUFTLElBQUksVUFBVTtBQUM3QixVQUFJLFdBQVc7QUFDWCxjQUFNLFNBQVMsVUFBVSxzQkFBc0I7QUFDbkQ7QUFBQSxJQUNKO0FBQUEsSUFDQTtBQUNJLFlBQU0sSUFBSSxVQUFVLDJDQUEyQztBQUFBLEVBQ3ZFO0FBQ0EsYUFBVyxLQUFLLE1BQU07QUFDMUI7OztBQzdGQSxTQUFTLFFBQVEsS0FBSyxXQUFXQyxRQUFPO0FBQ3BDLEVBQUFBLFNBQVFBLE9BQU0sT0FBTyxPQUFPO0FBQzVCLE1BQUlBLE9BQU0sU0FBUyxHQUFHO0FBQ2xCLFVBQU0sT0FBT0EsT0FBTSxJQUFJO0FBQ3ZCLFdBQU8sZUFBZUEsT0FBTSxLQUFLLElBQUksQ0FBQyxRQUFRLElBQUk7QUFBQSxFQUN0RCxXQUNTQSxPQUFNLFdBQVcsR0FBRztBQUN6QixXQUFPLGVBQWVBLE9BQU0sQ0FBQyxDQUFDLE9BQU9BLE9BQU0sQ0FBQyxDQUFDO0FBQUEsRUFDakQsT0FDSztBQUNELFdBQU8sV0FBV0EsT0FBTSxDQUFDLENBQUM7QUFBQSxFQUM5QjtBQUNBLE1BQUksVUFBVSxNQUFNO0FBQ2hCLFdBQU8sYUFBYSxNQUFNO0FBQUEsRUFDOUIsV0FDUyxPQUFPLFdBQVcsY0FBYyxPQUFPLE1BQU07QUFDbEQsV0FBTyxzQkFBc0IsT0FBTyxJQUFJO0FBQUEsRUFDNUMsV0FDUyxPQUFPLFdBQVcsWUFBWSxVQUFVLE1BQU07QUFDbkQsUUFBSSxPQUFPLGFBQWEsTUFBTTtBQUMxQixhQUFPLDRCQUE0QixPQUFPLFlBQVksSUFBSTtBQUFBLElBQzlEO0FBQUEsRUFDSjtBQUNBLFNBQU87QUFDWDtBQUNBLElBQU8sNEJBQVEsQ0FBQyxXQUFXQSxXQUFVO0FBQ2pDLFNBQU8sUUFBUSxnQkFBZ0IsUUFBUSxHQUFHQSxNQUFLO0FBQ25EO0FBQ08sU0FBUyxRQUFRLEtBQUssV0FBV0EsUUFBTztBQUMzQyxTQUFPLFFBQVEsZUFBZSxHQUFHLHVCQUF1QixRQUFRLEdBQUdBLE1BQUs7QUFDNUU7OztBQzdCQSxJQUFPLHNCQUFRLENBQUMsUUFBUTtBQUNwQixNQUFJLFlBQVksR0FBRyxHQUFHO0FBQ2xCLFdBQU87QUFBQSxFQUNYO0FBQ0EsU0FBTyxNQUFNLE9BQU8sV0FBVyxNQUFNO0FBQ3pDO0FBQ08sSUFBTSxRQUFRLENBQUMsV0FBVzs7O0FDUGpDLElBQU0sYUFBYSxJQUFJLFlBQVk7QUFDL0IsUUFBTSxVQUFVLFFBQVEsT0FBTyxPQUFPO0FBQ3RDLE1BQUksUUFBUSxXQUFXLEtBQUssUUFBUSxXQUFXLEdBQUc7QUFDOUMsV0FBTztBQUFBLEVBQ1g7QUFDQSxNQUFJO0FBQ0osYUFBVyxVQUFVLFNBQVM7QUFDMUIsVUFBTSxhQUFhLE9BQU8sS0FBSyxNQUFNO0FBQ3JDLFFBQUksQ0FBQyxPQUFPLElBQUksU0FBUyxHQUFHO0FBQ3hCLFlBQU0sSUFBSSxJQUFJLFVBQVU7QUFDeEI7QUFBQSxJQUNKO0FBQ0EsZUFBVyxhQUFhLFlBQVk7QUFDaEMsVUFBSSxJQUFJLElBQUksU0FBUyxHQUFHO0FBQ3BCLGVBQU87QUFBQSxNQUNYO0FBQ0EsVUFBSSxJQUFJLFNBQVM7QUFBQSxJQUNyQjtBQUFBLEVBQ0o7QUFDQSxTQUFPO0FBQ1g7QUFDQSxJQUFPLHNCQUFROzs7QUNyQmYsU0FBUyxhQUFhLE9BQU87QUFDekIsU0FBTyxPQUFPLFVBQVUsWUFBWSxVQUFVO0FBQ2xEO0FBQ2UsU0FBUixTQUEwQixPQUFPO0FBQ3BDLE1BQUksQ0FBQyxhQUFhLEtBQUssS0FBSyxPQUFPLFVBQVUsU0FBUyxLQUFLLEtBQUssTUFBTSxtQkFBbUI7QUFDckYsV0FBTztBQUFBLEVBQ1g7QUFDQSxNQUFJLE9BQU8sZUFBZSxLQUFLLE1BQU0sTUFBTTtBQUN2QyxXQUFPO0FBQUEsRUFDWDtBQUNBLE1BQUksUUFBUTtBQUNaLFNBQU8sT0FBTyxlQUFlLEtBQUssTUFBTSxNQUFNO0FBQzFDLFlBQVEsT0FBTyxlQUFlLEtBQUs7QUFBQSxFQUN2QztBQUNBLFNBQU8sT0FBTyxlQUFlLEtBQUssTUFBTTtBQUM1Qzs7O0FDZkEsSUFBTywyQkFBUSxDQUFDLEtBQUssUUFBUTtBQUN6QixNQUFJLElBQUksV0FBVyxJQUFJLEtBQUssSUFBSSxXQUFXLElBQUksR0FBRztBQUM5QyxVQUFNLEVBQUUsY0FBYyxJQUFJLElBQUk7QUFDOUIsUUFBSSxPQUFPLGtCQUFrQixZQUFZLGdCQUFnQixNQUFNO0FBQzNELFlBQU0sSUFBSSxVQUFVLEdBQUcsR0FBRyx1REFBdUQ7QUFBQSxJQUNyRjtBQUFBLEVBQ0o7QUFDSjs7O0FDTk8sU0FBUyxNQUFNLEtBQUs7QUFDdkIsU0FBTyxTQUFTLEdBQUcsS0FBSyxPQUFPLElBQUksUUFBUTtBQUMvQztBQUNPLFNBQVMsYUFBYSxLQUFLO0FBQzlCLFNBQU8sSUFBSSxRQUFRLFNBQVMsT0FBTyxJQUFJLE1BQU07QUFDakQ7QUFDTyxTQUFTLFlBQVksS0FBSztBQUM3QixTQUFPLElBQUksUUFBUSxTQUFTLE9BQU8sSUFBSSxNQUFNO0FBQ2pEO0FBQ08sU0FBUyxZQUFZLEtBQUs7QUFDN0IsU0FBTyxNQUFNLEdBQUcsS0FBSyxJQUFJLFFBQVEsU0FBUyxPQUFPLElBQUksTUFBTTtBQUMvRDs7O0FDVkEsU0FBUyxjQUFjLEtBQUs7QUFDeEIsTUFBSTtBQUNKLE1BQUk7QUFDSixVQUFRLElBQUksS0FBSztBQUFBLElBQ2IsS0FBSyxPQUFPO0FBQ1IsY0FBUSxJQUFJLEtBQUs7QUFBQSxRQUNiLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFDRCxzQkFBWSxFQUFFLE1BQU0sV0FBVyxNQUFNLE9BQU8sSUFBSSxJQUFJLE1BQU0sRUFBRSxDQUFDLEdBQUc7QUFDaEUsc0JBQVksSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsUUFBUTtBQUN4QztBQUFBLFFBQ0osS0FBSztBQUFBLFFBQ0wsS0FBSztBQUFBLFFBQ0wsS0FBSztBQUNELHNCQUFZLEVBQUUsTUFBTSxxQkFBcUIsTUFBTSxPQUFPLElBQUksSUFBSSxNQUFNLEVBQUUsQ0FBQyxHQUFHO0FBQzFFLHNCQUFZLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLFFBQVE7QUFDeEM7QUFBQSxRQUNKLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFDRCxzQkFBWTtBQUFBLFlBQ1IsTUFBTTtBQUFBLFlBQ04sTUFBTSxPQUFPLFNBQVMsSUFBSSxJQUFJLE1BQU0sRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDO0FBQUEsVUFDckQ7QUFDQSxzQkFBWSxJQUFJLElBQUksQ0FBQyxXQUFXLFdBQVcsSUFBSSxDQUFDLFdBQVcsU0FBUztBQUNwRTtBQUFBLFFBQ0o7QUFDSSxnQkFBTSxJQUFJLGlCQUFpQiw4REFBOEQ7QUFBQSxNQUNqRztBQUNBO0FBQUEsSUFDSjtBQUFBLElBQ0EsS0FBSyxNQUFNO0FBQ1AsY0FBUSxJQUFJLEtBQUs7QUFBQSxRQUNiLEtBQUs7QUFDRCxzQkFBWSxFQUFFLE1BQU0sU0FBUyxZQUFZLFFBQVE7QUFDakQsc0JBQVksSUFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsUUFBUTtBQUN4QztBQUFBLFFBQ0osS0FBSztBQUNELHNCQUFZLEVBQUUsTUFBTSxTQUFTLFlBQVksUUFBUTtBQUNqRCxzQkFBWSxJQUFJLElBQUksQ0FBQyxNQUFNLElBQUksQ0FBQyxRQUFRO0FBQ3hDO0FBQUEsUUFDSixLQUFLO0FBQ0Qsc0JBQVksRUFBRSxNQUFNLFNBQVMsWUFBWSxRQUFRO0FBQ2pELHNCQUFZLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLFFBQVE7QUFDeEM7QUFBQSxRQUNKLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFDRCxzQkFBWSxFQUFFLE1BQU0sUUFBUSxZQUFZLElBQUksSUFBSTtBQUNoRCxzQkFBWSxJQUFJLElBQUksQ0FBQyxZQUFZLElBQUksQ0FBQztBQUN0QztBQUFBLFFBQ0o7QUFDSSxnQkFBTSxJQUFJLGlCQUFpQiw4REFBOEQ7QUFBQSxNQUNqRztBQUNBO0FBQUEsSUFDSjtBQUFBLElBQ0EsS0FBSyxPQUFPO0FBQ1IsY0FBUSxJQUFJLEtBQUs7QUFBQSxRQUNiLEtBQUs7QUFDRCxzQkFBWSxFQUFFLE1BQU0sSUFBSSxJQUFJO0FBQzVCLHNCQUFZLElBQUksSUFBSSxDQUFDLE1BQU0sSUFBSSxDQUFDLFFBQVE7QUFDeEM7QUFBQSxRQUNKLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFBQSxRQUNMLEtBQUs7QUFDRCxzQkFBWSxFQUFFLE1BQU0sSUFBSSxJQUFJO0FBQzVCLHNCQUFZLElBQUksSUFBSSxDQUFDLFlBQVksSUFBSSxDQUFDO0FBQ3RDO0FBQUEsUUFDSjtBQUNJLGdCQUFNLElBQUksaUJBQWlCLDhEQUE4RDtBQUFBLE1BQ2pHO0FBQ0E7QUFBQSxJQUNKO0FBQUEsSUFDQTtBQUNJLFlBQU0sSUFBSSxpQkFBaUIsNkRBQTZEO0FBQUEsRUFDaEc7QUFDQSxTQUFPLEVBQUUsV0FBVyxVQUFVO0FBQ2xDO0FBQ0EsSUFBTSxRQUFRLE9BQU8sUUFBUTtBQUN6QixNQUFJLENBQUMsSUFBSSxLQUFLO0FBQ1YsVUFBTSxJQUFJLFVBQVUsMERBQTBEO0FBQUEsRUFDbEY7QUFDQSxRQUFNLEVBQUUsV0FBVyxVQUFVLElBQUksY0FBYyxHQUFHO0FBQ2xELFFBQU0sT0FBTztBQUFBLElBQ1Q7QUFBQSxJQUNBLElBQUksT0FBTztBQUFBLElBQ1gsSUFBSSxXQUFXO0FBQUEsRUFDbkI7QUFDQSxRQUFNLFVBQVUsRUFBRSxHQUFHLElBQUk7QUFDekIsU0FBTyxRQUFRO0FBQ2YsU0FBTyxRQUFRO0FBQ2YsU0FBTyxrQkFBTyxPQUFPLFVBQVUsT0FBTyxTQUFTLEdBQUcsSUFBSTtBQUMxRDtBQUNBLElBQU8scUJBQVE7OztBQ2hHZixJQUFNLGlCQUFpQixDQUFDLE1BQU0sT0FBTyxDQUFDO0FBQ3RDLElBQUk7QUFDSixJQUFJO0FBQ0osSUFBTSxjQUFjLENBQUMsUUFBUTtBQUN6QixTQUFPLE1BQU0sT0FBTyxXQUFXLE1BQU07QUFDekM7QUFDQSxJQUFNLGlCQUFpQixPQUFPLE9BQU8sS0FBSyxLQUFLLEtBQUssU0FBUyxVQUFVO0FBQ25FLE1BQUksU0FBUyxNQUFNLElBQUksR0FBRztBQUMxQixNQUFJLFNBQVMsR0FBRyxHQUFHO0FBQ2YsV0FBTyxPQUFPLEdBQUc7QUFBQSxFQUNyQjtBQUNBLFFBQU0sWUFBWSxNQUFNLG1CQUFVLEVBQUUsR0FBRyxLQUFLLElBQUksQ0FBQztBQUNqRCxNQUFJO0FBQ0EsV0FBTyxPQUFPLEdBQUc7QUFDckIsTUFBSSxDQUFDLFFBQVE7QUFDVCxVQUFNLElBQUksS0FBSyxFQUFFLENBQUMsR0FBRyxHQUFHLFVBQVUsQ0FBQztBQUFBLEVBQ3ZDLE9BQ0s7QUFDRCxXQUFPLEdBQUcsSUFBSTtBQUFBLEVBQ2xCO0FBQ0EsU0FBTztBQUNYO0FBQ0EsSUFBTSxxQkFBcUIsQ0FBQyxLQUFLLFFBQVE7QUFDckMsTUFBSSxZQUFZLEdBQUcsR0FBRztBQUNsQixRQUFJLE1BQU0sSUFBSSxPQUFPLEVBQUUsUUFBUSxNQUFNLENBQUM7QUFDdEMsV0FBTyxJQUFJO0FBQ1gsV0FBTyxJQUFJO0FBQ1gsV0FBTyxJQUFJO0FBQ1gsV0FBTyxJQUFJO0FBQ1gsV0FBTyxJQUFJO0FBQ1gsV0FBTyxJQUFJO0FBQ1gsUUFBSSxJQUFJLEdBQUc7QUFDUCxhQUFPLGVBQWUsSUFBSSxDQUFDO0FBQUEsSUFDL0I7QUFDQSxpQkFBYSxXQUFXLG9CQUFJLFFBQVE7QUFDcEMsV0FBTyxlQUFlLFVBQVUsS0FBSyxLQUFLLEdBQUc7QUFBQSxFQUNqRDtBQUNBLE1BQUksTUFBTSxHQUFHLEdBQUc7QUFDWixRQUFJLElBQUk7QUFDSixhQUFPLE9BQU8sSUFBSSxDQUFDO0FBQ3ZCLGlCQUFhLFdBQVcsb0JBQUksUUFBUTtBQUNwQyxVQUFNLFlBQVksZUFBZSxVQUFVLEtBQUssS0FBSyxLQUFLLElBQUk7QUFDOUQsV0FBTztBQUFBLEVBQ1g7QUFDQSxTQUFPO0FBQ1g7QUFDQSxJQUFNLHNCQUFzQixDQUFDLEtBQUssUUFBUTtBQUN0QyxNQUFJLFlBQVksR0FBRyxHQUFHO0FBQ2xCLFFBQUksTUFBTSxJQUFJLE9BQU8sRUFBRSxRQUFRLE1BQU0sQ0FBQztBQUN0QyxRQUFJLElBQUksR0FBRztBQUNQLGFBQU8sZUFBZSxJQUFJLENBQUM7QUFBQSxJQUMvQjtBQUNBLGtCQUFjLFlBQVksb0JBQUksUUFBUTtBQUN0QyxXQUFPLGVBQWUsV0FBVyxLQUFLLEtBQUssR0FBRztBQUFBLEVBQ2xEO0FBQ0EsTUFBSSxNQUFNLEdBQUcsR0FBRztBQUNaLFFBQUksSUFBSTtBQUNKLGFBQU8sT0FBTyxJQUFJLENBQUM7QUFDdkIsa0JBQWMsWUFBWSxvQkFBSSxRQUFRO0FBQ3RDLFVBQU0sWUFBWSxlQUFlLFdBQVcsS0FBSyxLQUFLLEtBQUssSUFBSTtBQUMvRCxXQUFPO0FBQUEsRUFDWDtBQUNBLFNBQU87QUFDWDtBQUNBLElBQU8sd0JBQVEsRUFBRSxvQkFBb0Isb0JBQW9COzs7QUMzQ3pELElBQU0sVUFBVSxDQUFDLFNBQVMsS0FBSyxPQUFPLE1BQU07QUFDeEMsTUFBSSxTQUFTLEdBQUc7QUFDWixRQUFJLFFBQVEsSUFBSSxNQUFNO0FBQ3RCLFFBQUksUUFBUSxDQUFJO0FBQUEsRUFDcEI7QUFDQSxRQUFNLElBQUksUUFBUSxRQUFRLElBQUksQ0FBQyxHQUFHLElBQUk7QUFDdEMsTUFBSSxNQUFNO0FBQ04sV0FBTztBQUNYLFFBQU0sTUFBTSxRQUFRLFNBQVMsR0FBRyxJQUFJLElBQUksTUFBTTtBQUM5QyxNQUFJLElBQUksV0FBVyxJQUFJO0FBQ25CLFdBQU87QUFDWCxTQUFPLElBQUksTUFBTSxDQUFDLE9BQU8sVUFBVSxVQUFVLElBQUksS0FBSyxDQUFDLEtBQUssUUFBUSxTQUFTLEtBQUssSUFBSSxDQUFDO0FBQzNGO0FBQ0EsSUFBTUMsaUJBQWdCLENBQUMsWUFBWTtBQUMvQixVQUFRLE1BQU07QUFBQSxJQUNWLEtBQUssUUFBUSxTQUFTLENBQUMsSUFBTSxLQUFNLElBQU0sS0FBTSxJQUFNLEdBQU0sR0FBTSxDQUFJLENBQUM7QUFDbEUsYUFBTztBQUFBLElBQ1gsS0FBSyxRQUFRLFNBQVMsQ0FBQyxJQUFNLEtBQU0sR0FBTSxHQUFNLEVBQUksQ0FBQztBQUNoRCxhQUFPO0FBQUEsSUFDWCxLQUFLLFFBQVEsU0FBUyxDQUFDLElBQU0sS0FBTSxHQUFNLEdBQU0sRUFBSSxDQUFDO0FBQ2hELGFBQU87QUFBQSxJQUNYLEtBQUssUUFBUSxTQUFTLENBQUMsSUFBTSxLQUFNLEdBQUksQ0FBQztBQUNwQyxhQUFPO0FBQUEsSUFDWCxLQUFLLFFBQVEsU0FBUyxDQUFDLElBQU0sS0FBTSxHQUFJLENBQUM7QUFDcEMsYUFBTztBQUFBLElBQ1gsS0FBSyxRQUFRLFNBQVMsQ0FBQyxJQUFNLEtBQU0sR0FBSSxDQUFDO0FBQ3BDLGFBQU87QUFBQSxJQUNYLEtBQUssUUFBUSxTQUFTLENBQUMsSUFBTSxLQUFNLEdBQUksQ0FBQztBQUNwQyxhQUFPO0FBQUEsSUFDWDtBQUNJLFlBQU0sSUFBSSxpQkFBaUIseURBQXlEO0FBQUEsRUFDNUY7QUFDSjtBQUNBLElBQU0sZ0JBQWdCLE9BQU8sU0FBUyxXQUFXLEtBQUssS0FBSyxZQUFZO0FBQ25FLE1BQUk7QUFDSixNQUFJO0FBQ0osUUFBTSxVQUFVLElBQUksV0FBVyxLQUFLLElBQUksUUFBUSxTQUFTLEVBQUUsQ0FBQyxFQUN2RCxNQUFNLEVBQUUsRUFDUixJQUFJLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxDQUFDLENBQUM7QUFDaEMsUUFBTSxXQUFXLGNBQWM7QUFDL0IsVUFBUSxLQUFLO0FBQUEsSUFDVCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQ0Qsa0JBQVksRUFBRSxNQUFNLFdBQVcsTUFBTSxPQUFPLElBQUksTUFBTSxFQUFFLENBQUMsR0FBRztBQUM1RCxrQkFBWSxXQUFXLENBQUMsUUFBUSxJQUFJLENBQUMsTUFBTTtBQUMzQztBQUFBLElBQ0osS0FBSztBQUFBLElBQ0wsS0FBSztBQUFBLElBQ0wsS0FBSztBQUNELGtCQUFZLEVBQUUsTUFBTSxxQkFBcUIsTUFBTSxPQUFPLElBQUksTUFBTSxFQUFFLENBQUMsR0FBRztBQUN0RSxrQkFBWSxXQUFXLENBQUMsUUFBUSxJQUFJLENBQUMsTUFBTTtBQUMzQztBQUFBLElBQ0osS0FBSztBQUFBLElBQ0wsS0FBSztBQUFBLElBQ0wsS0FBSztBQUFBLElBQ0wsS0FBSztBQUNELGtCQUFZO0FBQUEsUUFDUixNQUFNO0FBQUEsUUFDTixNQUFNLE9BQU8sU0FBUyxJQUFJLE1BQU0sRUFBRSxHQUFHLEVBQUUsS0FBSyxDQUFDO0FBQUEsTUFDakQ7QUFDQSxrQkFBWSxXQUFXLENBQUMsV0FBVyxTQUFTLElBQUksQ0FBQyxXQUFXLFdBQVc7QUFDdkU7QUFBQSxJQUNKLEtBQUs7QUFDRCxrQkFBWSxFQUFFLE1BQU0sU0FBUyxZQUFZLFFBQVE7QUFDakQsa0JBQVksV0FBVyxDQUFDLFFBQVEsSUFBSSxDQUFDLE1BQU07QUFDM0M7QUFBQSxJQUNKLEtBQUs7QUFDRCxrQkFBWSxFQUFFLE1BQU0sU0FBUyxZQUFZLFFBQVE7QUFDakQsa0JBQVksV0FBVyxDQUFDLFFBQVEsSUFBSSxDQUFDLE1BQU07QUFDM0M7QUFBQSxJQUNKLEtBQUs7QUFDRCxrQkFBWSxFQUFFLE1BQU0sU0FBUyxZQUFZLFFBQVE7QUFDakQsa0JBQVksV0FBVyxDQUFDLFFBQVEsSUFBSSxDQUFDLE1BQU07QUFDM0M7QUFBQSxJQUNKLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUssa0JBQWtCO0FBQ25CLFlBQU0sYUFBYUEsZUFBYyxPQUFPO0FBQ3hDLGtCQUFZLFdBQVcsV0FBVyxJQUFJLElBQUksRUFBRSxNQUFNLFFBQVEsV0FBVyxJQUFJLEVBQUUsTUFBTSxXQUFXO0FBQzVGLGtCQUFZLFdBQVcsQ0FBQyxJQUFJLENBQUMsWUFBWTtBQUN6QztBQUFBLElBQ0o7QUFBQSxJQUNBLEtBQUs7QUFDRCxrQkFBWSxFQUFFLE1BQU1BLGVBQWMsT0FBTyxFQUFFO0FBQzNDLGtCQUFZLFdBQVcsQ0FBQyxRQUFRLElBQUksQ0FBQyxNQUFNO0FBQzNDO0FBQUEsSUFDSjtBQUNJLFlBQU0sSUFBSSxpQkFBaUIsZ0RBQWdEO0FBQUEsRUFDbkY7QUFDQSxTQUFPLGtCQUFPLE9BQU8sVUFBVSxXQUFXLFNBQVMsV0FBVyxTQUFTLGVBQWUsT0FBTyxTQUFTO0FBQzFHO0FBQ08sSUFBTSxZQUFZLENBQUMsS0FBSyxLQUFLLFlBQVk7QUFDNUMsU0FBTyxjQUFjLCtDQUErQyxTQUFTLEtBQUssS0FBSyxPQUFPO0FBQ2xHOzs7QUN0R0EsZUFBc0IsWUFBWSxPQUFPLEtBQUssU0FBUztBQUNuRCxNQUFJLE9BQU8sVUFBVSxZQUFZLE1BQU0sUUFBUSw2QkFBNkIsTUFBTSxHQUFHO0FBQ2pGLFVBQU0sSUFBSSxVQUFVLHlDQUF5QztBQUFBLEVBQ2pFO0FBQ0EsU0FBTyxVQUFVLE9BQU8sS0FBSyxPQUFPO0FBQ3hDOzs7QUNuQkEsSUFBTSxNQUFNLENBQUMsUUFBUSxNQUFNLE9BQU8sV0FBVztBQUM3QyxJQUFNLGVBQWUsQ0FBQyxLQUFLLEtBQUssVUFBVTtBQUN0QyxNQUFJLElBQUksUUFBUSxVQUFhLElBQUksUUFBUSxPQUFPO0FBQzVDLFVBQU0sSUFBSSxVQUFVLGtFQUFrRTtBQUFBLEVBQzFGO0FBQ0EsTUFBSSxJQUFJLFlBQVksVUFBYSxJQUFJLFFBQVEsV0FBVyxLQUFLLE1BQU0sTUFBTTtBQUNyRSxVQUFNLElBQUksVUFBVSx5RUFBeUUsS0FBSyxFQUFFO0FBQUEsRUFDeEc7QUFDQSxNQUFJLElBQUksUUFBUSxVQUFhLElBQUksUUFBUSxLQUFLO0FBQzFDLFVBQU0sSUFBSSxVQUFVLGdFQUFnRSxHQUFHLEVBQUU7QUFBQSxFQUM3RjtBQUNBLFNBQU87QUFDWDtBQUNBLElBQU0scUJBQXFCLENBQUMsS0FBSyxLQUFLLE9BQU8sYUFBYTtBQUN0RCxNQUFJLGVBQWU7QUFDZjtBQUNKLE1BQUksWUFBZ0IsTUFBTSxHQUFHLEdBQUc7QUFDNUIsUUFBUSxZQUFZLEdBQUcsS0FBSyxhQUFhLEtBQUssS0FBSyxLQUFLO0FBQ3BEO0FBQ0osVUFBTSxJQUFJLFVBQVUseUhBQXlIO0FBQUEsRUFDako7QUFDQSxNQUFJLENBQUMsb0JBQVUsR0FBRyxHQUFHO0FBQ2pCLFVBQU0sSUFBSSxVQUFVLFFBQWdCLEtBQUssS0FBSyxHQUFHLE9BQU8sY0FBYyxXQUFXLGlCQUFpQixJQUFJLENBQUM7QUFBQSxFQUMzRztBQUNBLE1BQUksSUFBSSxTQUFTLFVBQVU7QUFDdkIsVUFBTSxJQUFJLFVBQVUsR0FBRyxJQUFJLEdBQUcsQ0FBQyw4REFBOEQ7QUFBQSxFQUNqRztBQUNKO0FBQ0EsSUFBTSxzQkFBc0IsQ0FBQyxLQUFLLEtBQUssT0FBTyxhQUFhO0FBQ3ZELE1BQUksWUFBZ0IsTUFBTSxHQUFHLEdBQUc7QUFDNUIsWUFBUSxPQUFPO0FBQUEsTUFDWCxLQUFLO0FBQ0QsWUFBUSxhQUFhLEdBQUcsS0FBSyxhQUFhLEtBQUssS0FBSyxLQUFLO0FBQ3JEO0FBQ0osY0FBTSxJQUFJLFVBQVUsa0RBQWtEO0FBQUEsTUFDMUUsS0FBSztBQUNELFlBQVEsWUFBWSxHQUFHLEtBQUssYUFBYSxLQUFLLEtBQUssS0FBSztBQUNwRDtBQUNKLGNBQU0sSUFBSSxVQUFVLGlEQUFpRDtBQUFBLElBQzdFO0FBQUEsRUFDSjtBQUNBLE1BQUksQ0FBQyxvQkFBVSxHQUFHLEdBQUc7QUFDakIsVUFBTSxJQUFJLFVBQVUsUUFBZ0IsS0FBSyxLQUFLLEdBQUcsT0FBTyxXQUFXLGlCQUFpQixJQUFJLENBQUM7QUFBQSxFQUM3RjtBQUNBLE1BQUksSUFBSSxTQUFTLFVBQVU7QUFDdkIsVUFBTSxJQUFJLFVBQVUsR0FBRyxJQUFJLEdBQUcsQ0FBQyxtRUFBbUU7QUFBQSxFQUN0RztBQUNBLE1BQUksVUFBVSxVQUFVLElBQUksU0FBUyxVQUFVO0FBQzNDLFVBQU0sSUFBSSxVQUFVLEdBQUcsSUFBSSxHQUFHLENBQUMsdUVBQXVFO0FBQUEsRUFDMUc7QUFDQSxNQUFJLFVBQVUsYUFBYSxJQUFJLFNBQVMsVUFBVTtBQUM5QyxVQUFNLElBQUksVUFBVSxHQUFHLElBQUksR0FBRyxDQUFDLDBFQUEwRTtBQUFBLEVBQzdHO0FBQ0EsTUFBSSxJQUFJLGFBQWEsVUFBVSxZQUFZLElBQUksU0FBUyxXQUFXO0FBQy9ELFVBQU0sSUFBSSxVQUFVLEdBQUcsSUFBSSxHQUFHLENBQUMsd0VBQXdFO0FBQUEsRUFDM0c7QUFDQSxNQUFJLElBQUksYUFBYSxVQUFVLGFBQWEsSUFBSSxTQUFTLFdBQVc7QUFDaEUsVUFBTSxJQUFJLFVBQVUsR0FBRyxJQUFJLEdBQUcsQ0FBQyx5RUFBeUU7QUFBQSxFQUM1RztBQUNKO0FBQ0EsU0FBUyxhQUFhLFVBQVUsS0FBSyxLQUFLLE9BQU87QUFDN0MsUUFBTSxZQUFZLElBQUksV0FBVyxJQUFJLEtBQ2pDLFFBQVEsU0FDUixJQUFJLFdBQVcsT0FBTyxLQUN0QixxQkFBcUIsS0FBSyxHQUFHO0FBQ2pDLE1BQUksV0FBVztBQUNYLHVCQUFtQixLQUFLLEtBQUssT0FBTyxRQUFRO0FBQUEsRUFDaEQsT0FDSztBQUNELHdCQUFvQixLQUFLLEtBQUssT0FBTyxRQUFRO0FBQUEsRUFDakQ7QUFDSjtBQUNBLElBQU8seUJBQVEsYUFBYSxLQUFLLFFBQVcsS0FBSztBQUMxQyxJQUFNLHNCQUFzQixhQUFhLEtBQUssUUFBVyxJQUFJOzs7QUMzRXBFLFNBQVMsYUFBYSxLQUFLLG1CQUFtQixrQkFBa0IsaUJBQWlCLFlBQVk7QUFDekYsTUFBSSxXQUFXLFNBQVMsVUFBYSxpQkFBaUIsU0FBUyxRQUFXO0FBQ3RFLFVBQU0sSUFBSSxJQUFJLGdFQUFnRTtBQUFBLEVBQ2xGO0FBQ0EsTUFBSSxDQUFDLG1CQUFtQixnQkFBZ0IsU0FBUyxRQUFXO0FBQ3hELFdBQU8sb0JBQUksSUFBSTtBQUFBLEVBQ25CO0FBQ0EsTUFBSSxDQUFDLE1BQU0sUUFBUSxnQkFBZ0IsSUFBSSxLQUNuQyxnQkFBZ0IsS0FBSyxXQUFXLEtBQ2hDLGdCQUFnQixLQUFLLEtBQUssQ0FBQyxVQUFVLE9BQU8sVUFBVSxZQUFZLE1BQU0sV0FBVyxDQUFDLEdBQUc7QUFDdkYsVUFBTSxJQUFJLElBQUksdUZBQXVGO0FBQUEsRUFDekc7QUFDQSxNQUFJO0FBQ0osTUFBSSxxQkFBcUIsUUFBVztBQUNoQyxpQkFBYSxJQUFJLElBQUksQ0FBQyxHQUFHLE9BQU8sUUFBUSxnQkFBZ0IsR0FBRyxHQUFHLGtCQUFrQixRQUFRLENBQUMsQ0FBQztBQUFBLEVBQzlGLE9BQ0s7QUFDRCxpQkFBYTtBQUFBLEVBQ2pCO0FBQ0EsYUFBVyxhQUFhLGdCQUFnQixNQUFNO0FBQzFDLFFBQUksQ0FBQyxXQUFXLElBQUksU0FBUyxHQUFHO0FBQzVCLFlBQU0sSUFBSSxpQkFBaUIsK0JBQStCLFNBQVMscUJBQXFCO0FBQUEsSUFDNUY7QUFDQSxRQUFJLFdBQVcsU0FBUyxNQUFNLFFBQVc7QUFDckMsWUFBTSxJQUFJLElBQUksK0JBQStCLFNBQVMsY0FBYztBQUFBLElBQ3hFO0FBQ0EsUUFBSSxXQUFXLElBQUksU0FBUyxLQUFLLGdCQUFnQixTQUFTLE1BQU0sUUFBVztBQUN2RSxZQUFNLElBQUksSUFBSSwrQkFBK0IsU0FBUywrQkFBK0I7QUFBQSxJQUN6RjtBQUFBLEVBQ0o7QUFDQSxTQUFPLElBQUksSUFBSSxnQkFBZ0IsSUFBSTtBQUN2QztBQUNBLElBQU8sd0JBQVE7OztBQ2hDQSxTQUFSLFVBQTJCLEtBQUssV0FBVztBQUM5QyxRQUFNLE9BQU8sT0FBTyxJQUFJLE1BQU0sRUFBRSxDQUFDO0FBQ2pDLFVBQVEsS0FBSztBQUFBLElBQ1QsS0FBSztBQUFBLElBQ0wsS0FBSztBQUFBLElBQ0wsS0FBSztBQUNELGFBQU8sRUFBRSxNQUFNLE1BQU0sT0FBTztBQUFBLElBQ2hDLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFDRCxhQUFPLEVBQUUsTUFBTSxNQUFNLFdBQVcsWUFBWSxJQUFJLE1BQU0sRUFBRSxLQUFLLEVBQUU7QUFBQSxJQUNuRSxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQ0QsYUFBTyxFQUFFLE1BQU0sTUFBTSxvQkFBb0I7QUFBQSxJQUM3QyxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQ0QsYUFBTyxFQUFFLE1BQU0sTUFBTSxTQUFTLFlBQVksVUFBVSxXQUFXO0FBQUEsSUFDbkUsS0FBSztBQUNELGFBQU8sRUFBRSxNQUFNLFVBQVUsS0FBSztBQUFBLElBQ2xDO0FBQ0ksWUFBTSxJQUFJLGlCQUFpQixPQUFPLEdBQUcsNkRBQTZEO0FBQUEsRUFDMUc7QUFDSjs7O0FDcEJBLGVBQU8sYUFBb0MsS0FBSyxLQUFLLE9BQU87QUFDeEQsTUFBSSxVQUFVLFFBQVE7QUFDbEIsVUFBTSxNQUFNLHNCQUFVLG9CQUFvQixLQUFLLEdBQUc7QUFBQSxFQUN0RDtBQUNBLE1BQUksVUFBVSxVQUFVO0FBQ3BCLFVBQU0sTUFBTSxzQkFBVSxtQkFBbUIsS0FBSyxHQUFHO0FBQUEsRUFDckQ7QUFDQSxNQUFJLFlBQVksR0FBRyxHQUFHO0FBQ2xCLHNCQUFrQixLQUFLLEtBQUssS0FBSztBQUNqQyxXQUFPO0FBQUEsRUFDWDtBQUNBLE1BQUksZUFBZSxZQUFZO0FBQzNCLFFBQUksQ0FBQyxJQUFJLFdBQVcsSUFBSSxHQUFHO0FBQ3ZCLFlBQU0sSUFBSSxVQUFVLDBCQUFnQixLQUFLLEdBQUcsS0FBSyxDQUFDO0FBQUEsSUFDdEQ7QUFDQSxXQUFPLGtCQUFPLE9BQU8sVUFBVSxPQUFPLEtBQUssRUFBRSxNQUFNLE9BQU8sSUFBSSxNQUFNLEVBQUUsQ0FBQyxJQUFJLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxLQUFLLENBQUM7QUFBQSxFQUM3RztBQUNBLFFBQU0sSUFBSSxVQUFVLDBCQUFnQixLQUFLLEdBQUcsT0FBTyxjQUFjLGNBQWMsQ0FBQztBQUNwRjs7O0FDdkJBLElBQU8sZ0JBQVEsQ0FBQyxTQUFTLEtBQUssTUFBTSxLQUFLLFFBQVEsSUFBSSxHQUFJOzs7QUNBekQsSUFBTSxTQUFTO0FBQ2YsSUFBTSxPQUFPLFNBQVM7QUFDdEIsSUFBTSxNQUFNLE9BQU87QUFDbkIsSUFBTSxPQUFPLE1BQU07QUFDbkIsSUFBTSxPQUFPLE1BQU07QUFDbkIsSUFBTSxRQUFRO0FBQ2QsSUFBTyxlQUFRLENBQUMsUUFBUTtBQUNwQixRQUFNLFVBQVUsTUFBTSxLQUFLLEdBQUc7QUFDOUIsTUFBSSxDQUFDLFdBQVksUUFBUSxDQUFDLEtBQUssUUFBUSxDQUFDLEdBQUk7QUFDeEMsVUFBTSxJQUFJLFVBQVUsNEJBQTRCO0FBQUEsRUFDcEQ7QUFDQSxRQUFNLFFBQVEsV0FBVyxRQUFRLENBQUMsQ0FBQztBQUNuQyxRQUFNLE9BQU8sUUFBUSxDQUFDLEVBQUUsWUFBWTtBQUNwQyxNQUFJO0FBQ0osVUFBUSxNQUFNO0FBQUEsSUFDVixLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQ0Qsb0JBQWMsS0FBSyxNQUFNLEtBQUs7QUFDOUI7QUFBQSxJQUNKLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFDRCxvQkFBYyxLQUFLLE1BQU0sUUFBUSxNQUFNO0FBQ3ZDO0FBQUEsSUFDSixLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQUEsSUFDTCxLQUFLO0FBQ0Qsb0JBQWMsS0FBSyxNQUFNLFFBQVEsSUFBSTtBQUNyQztBQUFBLElBQ0osS0FBSztBQUFBLElBQ0wsS0FBSztBQUFBLElBQ0wsS0FBSztBQUNELG9CQUFjLEtBQUssTUFBTSxRQUFRLEdBQUc7QUFDcEM7QUFBQSxJQUNKLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFBQSxJQUNMLEtBQUs7QUFDRCxvQkFBYyxLQUFLLE1BQU0sUUFBUSxJQUFJO0FBQ3JDO0FBQUEsSUFDSjtBQUNJLG9CQUFjLEtBQUssTUFBTSxRQUFRLElBQUk7QUFDckM7QUFBQSxFQUNSO0FBQ0EsTUFBSSxRQUFRLENBQUMsTUFBTSxPQUFPLFFBQVEsQ0FBQyxNQUFNLE9BQU87QUFDNUMsV0FBTyxDQUFDO0FBQUEsRUFDWjtBQUNBLFNBQU87QUFDWDs7O0FDbERBLElBQU0sT0FBTyxPQUFPLEtBQUssS0FBSyxTQUFTO0FBQ25DLFFBQU0sWUFBWSxNQUFNLGFBQVcsS0FBSyxLQUFLLE1BQU07QUFDbkQsMkJBQWUsS0FBSyxTQUFTO0FBQzdCLFFBQU0sWUFBWSxNQUFNLGtCQUFPLE9BQU8sS0FBSyxVQUFnQixLQUFLLFVBQVUsU0FBUyxHQUFHLFdBQVcsSUFBSTtBQUNyRyxTQUFPLElBQUksV0FBVyxTQUFTO0FBQ25DO0FBQ0EsSUFBTyxlQUFROzs7QUNIUixJQUFNLGdCQUFOLE1BQW9CO0FBQUEsRUFDdkIsWUFBWSxTQUFTO0FBQ2pCLFFBQUksRUFBRSxtQkFBbUIsYUFBYTtBQUNsQyxZQUFNLElBQUksVUFBVSwyQ0FBMkM7QUFBQSxJQUNuRTtBQUNBLFNBQUssV0FBVztBQUFBLEVBQ3BCO0FBQUEsRUFDQSxtQkFBbUIsaUJBQWlCO0FBQ2hDLFFBQUksS0FBSyxrQkFBa0I7QUFDdkIsWUFBTSxJQUFJLFVBQVUsNENBQTRDO0FBQUEsSUFDcEU7QUFDQSxTQUFLLG1CQUFtQjtBQUN4QixXQUFPO0FBQUEsRUFDWDtBQUFBLEVBQ0EscUJBQXFCLG1CQUFtQjtBQUNwQyxRQUFJLEtBQUssb0JBQW9CO0FBQ3pCLFlBQU0sSUFBSSxVQUFVLDhDQUE4QztBQUFBLElBQ3RFO0FBQ0EsU0FBSyxxQkFBcUI7QUFDMUIsV0FBTztBQUFBLEVBQ1g7QUFBQSxFQUNBLE1BQU0sS0FBSyxLQUFLLFNBQVM7QUFDckIsUUFBSSxDQUFDLEtBQUssb0JBQW9CLENBQUMsS0FBSyxvQkFBb0I7QUFDcEQsWUFBTSxJQUFJLFdBQVcsaUZBQWlGO0FBQUEsSUFDMUc7QUFDQSxRQUFJLENBQUMsb0JBQVcsS0FBSyxrQkFBa0IsS0FBSyxrQkFBa0IsR0FBRztBQUM3RCxZQUFNLElBQUksV0FBVywyRUFBMkU7QUFBQSxJQUNwRztBQUNBLFVBQU0sYUFBYTtBQUFBLE1BQ2YsR0FBRyxLQUFLO0FBQUEsTUFDUixHQUFHLEtBQUs7QUFBQSxJQUNaO0FBQ0EsVUFBTSxhQUFhLHNCQUFhLFlBQVksb0JBQUksSUFBSSxDQUFDLENBQUMsT0FBTyxJQUFJLENBQUMsQ0FBQyxHQUFHLFNBQVMsTUFBTSxLQUFLLGtCQUFrQixVQUFVO0FBQ3RILFFBQUksTUFBTTtBQUNWLFFBQUksV0FBVyxJQUFJLEtBQUssR0FBRztBQUN2QixZQUFNLEtBQUssaUJBQWlCO0FBQzVCLFVBQUksT0FBTyxRQUFRLFdBQVc7QUFDMUIsY0FBTSxJQUFJLFdBQVcseUVBQXlFO0FBQUEsTUFDbEc7QUFBQSxJQUNKO0FBQ0EsVUFBTSxFQUFFLElBQUksSUFBSTtBQUNoQixRQUFJLE9BQU8sUUFBUSxZQUFZLENBQUMsS0FBSztBQUNqQyxZQUFNLElBQUksV0FBVywyREFBMkQ7QUFBQSxJQUNwRjtBQUNBLHdCQUFvQixLQUFLLEtBQUssTUFBTTtBQUNwQyxRQUFJLFVBQVUsS0FBSztBQUNuQixRQUFJLEtBQUs7QUFDTCxnQkFBVSxRQUFRLE9BQU8sT0FBVSxPQUFPLENBQUM7QUFBQSxJQUMvQztBQUNBLFFBQUk7QUFDSixRQUFJLEtBQUssa0JBQWtCO0FBQ3ZCLHdCQUFrQixRQUFRLE9BQU8sT0FBVSxLQUFLLFVBQVUsS0FBSyxnQkFBZ0IsQ0FBQyxDQUFDO0FBQUEsSUFDckYsT0FDSztBQUNELHdCQUFrQixRQUFRLE9BQU8sRUFBRTtBQUFBLElBQ3ZDO0FBQ0EsVUFBTSxPQUFPLE9BQU8saUJBQWlCLFFBQVEsT0FBTyxHQUFHLEdBQUcsT0FBTztBQUNqRSxVQUFNLFlBQVksTUFBTSxhQUFLLEtBQUssS0FBSyxJQUFJO0FBQzNDLFVBQU0sTUFBTTtBQUFBLE1BQ1IsV0FBVyxPQUFVLFNBQVM7QUFBQSxNQUM5QixTQUFTO0FBQUEsSUFDYjtBQUNBLFFBQUksS0FBSztBQUNMLFVBQUksVUFBVSxRQUFRLE9BQU8sT0FBTztBQUFBLElBQ3hDO0FBQ0EsUUFBSSxLQUFLLG9CQUFvQjtBQUN6QixVQUFJLFNBQVMsS0FBSztBQUFBLElBQ3RCO0FBQ0EsUUFBSSxLQUFLLGtCQUFrQjtBQUN2QixVQUFJLFlBQVksUUFBUSxPQUFPLGVBQWU7QUFBQSxJQUNsRDtBQUNBLFdBQU87QUFBQSxFQUNYO0FBQ0o7OztBQy9FTyxJQUFNLGNBQU4sTUFBa0I7QUFBQSxFQUNyQixZQUFZLFNBQVM7QUFDakIsU0FBSyxhQUFhLElBQUksY0FBYyxPQUFPO0FBQUEsRUFDL0M7QUFBQSxFQUNBLG1CQUFtQixpQkFBaUI7QUFDaEMsU0FBSyxXQUFXLG1CQUFtQixlQUFlO0FBQ2xELFdBQU87QUFBQSxFQUNYO0FBQUEsRUFDQSxNQUFNLEtBQUssS0FBSyxTQUFTO0FBQ3JCLFVBQU0sTUFBTSxNQUFNLEtBQUssV0FBVyxLQUFLLEtBQUssT0FBTztBQUNuRCxRQUFJLElBQUksWUFBWSxRQUFXO0FBQzNCLFlBQU0sSUFBSSxVQUFVLDJEQUEyRDtBQUFBLElBQ25GO0FBQ0EsV0FBTyxHQUFHLElBQUksU0FBUyxJQUFJLElBQUksT0FBTyxJQUFJLElBQUksU0FBUztBQUFBLEVBQzNEO0FBQ0o7OztBQ2JBLFNBQVMsY0FBYyxPQUFPLE9BQU87QUFDakMsTUFBSSxDQUFDLE9BQU8sU0FBUyxLQUFLLEdBQUc7QUFDekIsVUFBTSxJQUFJLFVBQVUsV0FBVyxLQUFLLFFBQVE7QUFBQSxFQUNoRDtBQUNBLFNBQU87QUFDWDtBQUNPLElBQU0sYUFBTixNQUFpQjtBQUFBLEVBQ3BCLFlBQVksVUFBVSxDQUFDLEdBQUc7QUFDdEIsUUFBSSxDQUFDLFNBQVMsT0FBTyxHQUFHO0FBQ3BCLFlBQU0sSUFBSSxVQUFVLGtDQUFrQztBQUFBLElBQzFEO0FBQ0EsU0FBSyxXQUFXO0FBQUEsRUFDcEI7QUFBQSxFQUNBLFVBQVUsUUFBUTtBQUNkLFNBQUssV0FBVyxFQUFFLEdBQUcsS0FBSyxVQUFVLEtBQUssT0FBTztBQUNoRCxXQUFPO0FBQUEsRUFDWDtBQUFBLEVBQ0EsV0FBVyxTQUFTO0FBQ2hCLFNBQUssV0FBVyxFQUFFLEdBQUcsS0FBSyxVQUFVLEtBQUssUUFBUTtBQUNqRCxXQUFPO0FBQUEsRUFDWDtBQUFBLEVBQ0EsWUFBWSxVQUFVO0FBQ2xCLFNBQUssV0FBVyxFQUFFLEdBQUcsS0FBSyxVQUFVLEtBQUssU0FBUztBQUNsRCxXQUFPO0FBQUEsRUFDWDtBQUFBLEVBQ0EsT0FBTyxPQUFPO0FBQ1YsU0FBSyxXQUFXLEVBQUUsR0FBRyxLQUFLLFVBQVUsS0FBSyxNQUFNO0FBQy9DLFdBQU87QUFBQSxFQUNYO0FBQUEsRUFDQSxhQUFhLE9BQU87QUFDaEIsUUFBSSxPQUFPLFVBQVUsVUFBVTtBQUMzQixXQUFLLFdBQVcsRUFBRSxHQUFHLEtBQUssVUFBVSxLQUFLLGNBQWMsZ0JBQWdCLEtBQUssRUFBRTtBQUFBLElBQ2xGLFdBQ1MsaUJBQWlCLE1BQU07QUFDNUIsV0FBSyxXQUFXLEVBQUUsR0FBRyxLQUFLLFVBQVUsS0FBSyxjQUFjLGdCQUFnQixjQUFNLEtBQUssQ0FBQyxFQUFFO0FBQUEsSUFDekYsT0FDSztBQUNELFdBQUssV0FBVyxFQUFFLEdBQUcsS0FBSyxVQUFVLEtBQUssY0FBTSxvQkFBSSxLQUFLLENBQUMsSUFBSSxhQUFLLEtBQUssRUFBRTtBQUFBLElBQzdFO0FBQ0EsV0FBTztBQUFBLEVBQ1g7QUFBQSxFQUNBLGtCQUFrQixPQUFPO0FBQ3JCLFFBQUksT0FBTyxVQUFVLFVBQVU7QUFDM0IsV0FBSyxXQUFXLEVBQUUsR0FBRyxLQUFLLFVBQVUsS0FBSyxjQUFjLHFCQUFxQixLQUFLLEVBQUU7QUFBQSxJQUN2RixXQUNTLGlCQUFpQixNQUFNO0FBQzVCLFdBQUssV0FBVyxFQUFFLEdBQUcsS0FBSyxVQUFVLEtBQUssY0FBYyxxQkFBcUIsY0FBTSxLQUFLLENBQUMsRUFBRTtBQUFBLElBQzlGLE9BQ0s7QUFDRCxXQUFLLFdBQVcsRUFBRSxHQUFHLEtBQUssVUFBVSxLQUFLLGNBQU0sb0JBQUksS0FBSyxDQUFDLElBQUksYUFBSyxLQUFLLEVBQUU7QUFBQSxJQUM3RTtBQUNBLFdBQU87QUFBQSxFQUNYO0FBQUEsRUFDQSxZQUFZLE9BQU87QUFDZixRQUFJLE9BQU8sVUFBVSxhQUFhO0FBQzlCLFdBQUssV0FBVyxFQUFFLEdBQUcsS0FBSyxVQUFVLEtBQUssY0FBTSxvQkFBSSxLQUFLLENBQUMsRUFBRTtBQUFBLElBQy9ELFdBQ1MsaUJBQWlCLE1BQU07QUFDNUIsV0FBSyxXQUFXLEVBQUUsR0FBRyxLQUFLLFVBQVUsS0FBSyxjQUFjLGVBQWUsY0FBTSxLQUFLLENBQUMsRUFBRTtBQUFBLElBQ3hGLFdBQ1MsT0FBTyxVQUFVLFVBQVU7QUFDaEMsV0FBSyxXQUFXO0FBQUEsUUFDWixHQUFHLEtBQUs7QUFBQSxRQUNSLEtBQUssY0FBYyxlQUFlLGNBQU0sb0JBQUksS0FBSyxDQUFDLElBQUksYUFBSyxLQUFLLENBQUM7QUFBQSxNQUNyRTtBQUFBLElBQ0osT0FDSztBQUNELFdBQUssV0FBVyxFQUFFLEdBQUcsS0FBSyxVQUFVLEtBQUssY0FBYyxlQUFlLEtBQUssRUFBRTtBQUFBLElBQ2pGO0FBQ0EsV0FBTztBQUFBLEVBQ1g7QUFDSjs7O0FDdEVPLElBQU0sVUFBTixjQUFzQixXQUFXO0FBQUEsRUFDcEMsbUJBQW1CLGlCQUFpQjtBQUNoQyxTQUFLLG1CQUFtQjtBQUN4QixXQUFPO0FBQUEsRUFDWDtBQUFBLEVBQ0EsTUFBTSxLQUFLLEtBQUssU0FBUztBQUNyQixVQUFNLE1BQU0sSUFBSSxZQUFZLFFBQVEsT0FBTyxLQUFLLFVBQVUsS0FBSyxRQUFRLENBQUMsQ0FBQztBQUN6RSxRQUFJLG1CQUFtQixLQUFLLGdCQUFnQjtBQUM1QyxRQUFJLE1BQU0sUUFBUSxLQUFLLGtCQUFrQixJQUFJLEtBQ3pDLEtBQUssaUJBQWlCLEtBQUssU0FBUyxLQUFLLEtBQ3pDLEtBQUssaUJBQWlCLFFBQVEsT0FBTztBQUNyQyxZQUFNLElBQUksV0FBVyxxQ0FBcUM7QUFBQSxJQUM5RDtBQUNBLFdBQU8sSUFBSSxLQUFLLEtBQUssT0FBTztBQUFBLEVBQ2hDO0FBQ0o7OztBQ1BBLElBQUksUUFBb0M7QUFFeEMsZUFBZSxZQUFZLFNBR3hCO0FBQ0QsUUFBTSxnQkFBZ0IsUUFBUSxXQUFXLFFBQVEsUUFBUSxJQUFJO0FBQzdELFFBQU0sYUFBYSxNQUFNLFlBQVksZUFBZSxPQUFPO0FBRTNELFFBQU0sVUFBVTtBQUFBLElBQ2QsS0FBSyxRQUFRO0FBQUEsSUFDYixPQUFPO0FBQUEsSUFDUCxLQUFLO0FBQUEsSUFDTCxLQUFLLEtBQUssTUFBTSxLQUFLLElBQUksSUFBSSxHQUFJLElBQUksS0FBSztBQUFBLElBQzFDLEtBQUssS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUk7QUFBQSxFQUNuQztBQUNBLFFBQU1DLFNBQVEsTUFBTSxJQUFJLFFBQVEsT0FBTyxFQUNwQyxtQkFBbUIsRUFBRSxLQUFLLFFBQVEsQ0FBQyxFQUNuQyxZQUFZLEVBQ1osVUFBVSxRQUFRLFdBQVcsRUFDN0IsWUFBWSw0Q0FBNEMsRUFDeEQsa0JBQWtCLElBQUksRUFDdEIsS0FBSyxVQUFVO0FBR2xCLFFBQU0sT0FBTztBQUFBLElBQ1gsWUFBWTtBQUFBLElBQ1osV0FBV0E7QUFBQSxFQUNiO0FBR0EsUUFBTSxnQkFBZ0IsTUFBTTtBQUFBLElBQzFCO0FBQUEsSUFDQTtBQUFBLE1BQ0UsUUFBUTtBQUFBLE1BQ1IsTUFBTSxLQUFLLFVBQVUsSUFBSTtBQUFBLE1BQ3pCLFNBQVMsRUFBRSxnQkFBZ0IsbUJBQW1CO0FBQUEsSUFDaEQ7QUFBQSxFQUNGO0FBRUEsUUFBTSxPQUFRLE1BQU0sY0FBYyxLQUFLO0FBRXZDLFNBQU87QUFBQSxJQUNMLEdBQUc7QUFBQSxJQUNILFlBQVksS0FBSyxNQUFNLEtBQUssSUFBSSxJQUFJLEdBQUksSUFBSSxLQUFLO0FBQUEsRUFDbkQ7QUFDRjtBQUVBLGVBQXNCLGFBQWEsU0FHaEI7QUFDakIsTUFBSSxDQUFDLFFBQVEsZUFBZSxDQUFDLFFBQVEsWUFBWTtBQUMvQyxVQUFNLElBQUksTUFBTSx5Q0FBeUM7QUFBQSxFQUMzRDtBQUNBLE1BQUksVUFBVSxNQUFNO0FBQ2xCLFlBQVEsTUFBTSxZQUFZLE9BQU87QUFBQSxFQUNuQyxXQUFXLE1BQU0sYUFBYSxLQUFLLE1BQU0sS0FBSyxJQUFJLElBQUksR0FBSSxHQUFHO0FBQzNELFlBQVEsTUFBTSxZQUFZLE9BQU87QUFBQSxFQUNuQztBQUNBLFNBQU87QUFDVDs7O0FDbkVBLElBQU0sa0JBQWtCO0FBVWpCLElBQU0scUJBQU4sY0FBc0MsVUFBVTtBQUFBLEVBQ3JEO0FBQUEsRUFDQTtBQUFBLEVBQ0E7QUFBQSxFQUVRO0FBQUEsRUFFUixZQUFZO0FBQUEsSUFDVixVQUFlLFFBQVEsMkJBQTJCO0FBQUEsSUFDbEQsU0FBYyxRQUFRLGlCQUFpQixLQUFLO0FBQUEsSUFDNUMsWUFBaUIsUUFBUSw2QkFBNkIsS0FBSztBQUFBLElBQzNELGNBQW1CLFFBQVEsK0JBQStCLEtBQUs7QUFBQSxJQUMvRCxjQUFtQixRQUFRLCtCQUErQixLQUFLO0FBQUEsSUFDL0QsYUFBa0IsUUFBUSw4QkFBOEIsS0FBSztBQUFBLElBQzdELEdBQUc7QUFBQSxFQUNMLElBQW1CLENBQUMsR0FBRztBQUNyQixRQUFJLENBQUMsUUFBUTtBQUNYLFlBQU0sSUFBSTtBQUFBLFFBQ1I7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUVBLFVBQU0sVUFBeUI7QUFBQSxNQUM3QixHQUFHO0FBQUEsTUFDSCxTQUFTLFdBQVcsV0FBVyxNQUFNO0FBQUEsTUFDckM7QUFBQSxNQUNBO0FBQUEsSUFDRjtBQUVBLFVBQU07QUFBQSxNQUNKLFNBQVMsUUFBUTtBQUFBLE1BQ2pCLFNBQVMsUUFBUSxXQUFXO0FBQUEsTUFDNUIsV0FBVyxRQUFRO0FBQUEsTUFDbkIsWUFBWSxRQUFRO0FBQUEsTUFDcEIsT0FBTyxRQUFRO0FBQUEsSUFDakIsQ0FBQztBQUNELFNBQUssV0FBVztBQUVoQixTQUFLLFNBQVM7QUFDZCxTQUFLLFlBQVk7QUFDakIsU0FBSyxjQUFjO0FBQUEsRUFDckI7QUFBQSxFQUVBLFdBQStCLElBQWMsU0FBUyxJQUFJO0FBQUEsRUFFdkMsZUFBOEM7QUFDL0QsV0FBTyxLQUFLLFNBQVM7QUFBQSxFQUN2QjtBQUFBLEVBRW1CLGVBQ2pCLE1BQ2M7QUFDZCxXQUFPO0FBQUEsTUFDTCxHQUFHLE1BQU0sZUFBZSxJQUFJO0FBQUEsTUFDNUIsR0FBRyxLQUFLLFNBQVM7QUFBQSxJQUNuQjtBQUFBLEVBQ0Y7QUFBQSxFQUVBLE1BQXlCLGVBQ3ZCLFNBQ2U7QUFDZixRQUFJLENBQUMsS0FBSyxhQUFhO0FBQ3JCLFVBQUksQ0FBQyxLQUFLLFNBQVMsZUFBZSxDQUFDLEtBQUssU0FBUyxZQUFZO0FBQzNELGNBQU0sSUFBSTtBQUFBLFVBQ1I7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLFdBQUssZUFDSCxNQUFNLGFBQWE7QUFBQSxRQUNqQixhQUFhLEtBQUssU0FBUztBQUFBLFFBQzNCLFlBQVksS0FBSyxTQUFTO0FBQUEsTUFDNUIsQ0FBQyxHQUNEO0FBQUEsSUFDSjtBQUVBLFlBQVEsVUFBVTtBQUFBLE1BQ2hCLEdBQUcsUUFBUTtBQUFBLE1BQ1gsZUFBZSxVQUFVLEtBQUssV0FBVztBQUFBLE1BQ3pDLHVCQUF1QixLQUFLO0FBQUEsSUFDOUI7QUFBQSxFQUNGO0FBQUEsRUFFUyxhQUFhLFNBSXBCO0FBQ0EsUUFBUyxNQUFNLFFBQVEsSUFBSSxHQUFHO0FBQzVCLFVBQUksQ0FBQyxRQUFRLEtBQUssbUJBQW1CLEdBQUc7QUFDdEMsZ0JBQVEsS0FBSyxtQkFBbUIsSUFBSTtBQUFBLE1BQ3RDO0FBQUEsSUFDRjtBQUVBLFFBQUksUUFBUSxTQUFTLGtCQUFrQixRQUFRLFdBQVcsUUFBUTtBQUNoRSxVQUFJLENBQUMsS0FBSyxXQUFXO0FBQ25CLGNBQU0sSUFBSTtBQUFBLFVBQ1I7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBLFVBQUksQ0FBTSxNQUFNLFFBQVEsSUFBSSxHQUFHO0FBQzdCLGNBQU0sSUFBSTtBQUFBLFVBQ1I7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUVBLFlBQU1DLFNBQVEsUUFBUSxLQUFLLE9BQU87QUFDbEMsY0FBUSxLQUFLLE9BQU8sSUFBSTtBQUV4QixZQUFNLFNBQVMsUUFBUSxLQUFLLFFBQVEsS0FBSztBQUV6QyxZQUFNLFlBQVksU0FBUyxxQkFBcUI7QUFFaEQsY0FBUSxPQUFPLGFBQWEsS0FBSyxTQUFTLGNBQWMsS0FBSyxNQUFNLGdDQUFnQ0EsTUFBSyxJQUFJLFNBQVM7QUFBQSxJQUN2SDtBQUVBLFdBQU8sTUFBTSxhQUFhLE9BQU87QUFBQSxFQUNuQztBQUNGOzs7QTFDaklBLGVBQWUsZ0JBQ2IsVUFDcUU7QUFDckUsU0FBTyxRQUFRO0FBQUEsSUFDYixTQUFTLElBQUksT0FBTyxPQUFPO0FBQ3pCLFVBQUksQ0FBQyxHQUFHLFNBQVM7QUFDZixjQUFNLElBQUksTUFBTSxxQkFBcUI7QUFBQSxNQUN2QztBQUNBLFVBQUksQ0FBQyxHQUFHLGFBQWE7QUFDbkIsZUFBTztBQUFBLFVBQ0wsTUFBTSxHQUFHO0FBQUEsVUFDVCxTQUFTLEdBQUc7QUFBQSxRQUNkO0FBQUEsTUFDRjtBQUNBLGFBQU87QUFBQSxRQUNMLE1BQU0sR0FBRztBQUFBLFFBQ1QsU0FBUztBQUFBLFVBQ1A7QUFBQSxZQUNFLE1BQU07QUFBQSxZQUNOLE1BQU0sR0FBRztBQUFBLFVBQ1g7QUFBQSxVQUNBLEdBQUksTUFBTSxRQUFRO0FBQUEsWUFDaEIsR0FBRyxZQUFZLElBQUksT0FBT0MsUUFBTztBQUMvQixxQkFBTztBQUFBLGdCQUNMLE1BQU07QUFBQSxnQkFDTixRQUFRO0FBQUEsa0JBQ04sTUFBTTtBQUFBLGtCQUNOLEdBQUksTUFBTSxpQkFBaUJBLElBQUcsR0FBRztBQUFBLGdCQUNuQztBQUFBLGNBQ0Y7QUFBQSxZQUNGLENBQUM7QUFBQSxVQUNIO0FBQUEsUUFDRjtBQUFBLE1BQ0Y7QUFBQSxJQUNGLENBQUM7QUFBQSxFQUNIO0FBQ0Y7QUFFQSxTQUFTLGtCQUFrQkMsUUFBdUI7QUFDaEQsTUFBSUEsT0FBTSxXQUFXLFlBQVksR0FBRztBQUNsQyxXQUFPO0FBQUEsRUFDVDtBQUNBLFNBQU87QUFDVDtBQUVBLGVBQWUsU0FDYixLQUNBLFFBQzZDO0FBQzdDLFNBQU87QUFBQSxJQUNMLFVBQVUsTUFBTTtBQUFBLE1BQ2QsSUFBSSxTQUFTO0FBQUEsUUFBTyxDQUFDLE9BRWpCO0FBQUEsVUFDRTtBQUFBLFVBQ0E7QUFBQSxRQUNGLEVBQ0EsU0FBUyxHQUFHLElBQUk7QUFBQSxNQUNwQjtBQUFBLElBQ0Y7QUFBQSxJQUNBLFlBQVksa0JBQWtCLElBQUksS0FBSztBQUFBLElBQ3ZDO0FBQUEsSUFDQSxPQUFPLElBQUk7QUFBQSxJQUNYLFFBQVEsSUFBSSxTQUFTLEtBQUssQ0FBQyxPQUFPLEdBQUcsU0FBUyxRQUFRLEdBQUc7QUFBQSxFQUMzRDtBQUNGO0FBRUEsU0FBUyxjQUNQLE1BQ3dCO0FBQ3hCLE1BQUksS0FBSyxRQUFRLFdBQVcsR0FBRztBQUM3QixZQUFRLE1BQU0sd0JBQXdCLEtBQUssT0FBTztBQUNsRCxVQUFNLElBQUksTUFBTSxzQkFBc0I7QUFBQSxFQUN4QztBQUNBLFNBQU87QUFBQSxJQUNMLFNBQVUsS0FBSyxRQUFRLENBQUMsRUFBK0I7QUFBQSxFQUN6RDtBQUNGO0FBRUEsZUFBc0IsU0FBUyxTQUFpQztBQUM5RCxRQUFNLGVBQWUsWUFBWTtBQUMvQixVQUFNLENBQUMsYUFBYSxZQUFZLFFBQVEsU0FBUyxJQUFJLE1BQU0sUUFBUSxJQUFJO0FBQUEsTUFDNUQsaUJBQVEsSUFBSSxxQ0FBcUM7QUFBQSxNQUNqRCxpQkFBUSxJQUFJLG9DQUFvQztBQUFBLE1BQ2hELGlCQUFRLElBQUksd0JBQXdCO0FBQUEsTUFDcEMsaUJBQVEsSUFBSSwyQkFBMkI7QUFBQSxJQUNsRCxDQUFDO0FBQ0QsV0FBTyxJQUFJLG1CQUFtQjtBQUFBLE1BQzVCO0FBQUEsTUFDQTtBQUFBLE1BQ0E7QUFBQSxNQUNBO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQWUsZUFBTSxpQkFBaUI7QUFBQSxJQUNwQyxNQUFNO0FBQUEsSUFDTixRQUFRO0FBQUEsTUFDTixFQUFFLElBQUksaUNBQWlDLE1BQU0sdUJBQXVCO0FBQUEsTUFDcEUsRUFBRSxJQUFJLDhCQUE4QixNQUFNLG9CQUFvQjtBQUFBLE1BQzlELEVBQUUsSUFBSSwyQkFBMkIsTUFBTSxpQkFBaUI7QUFBQSxNQUN4RCxFQUFFLElBQUksMEJBQTBCLE1BQU0sZ0JBQWdCO0FBQUEsTUFDdEQsRUFBRSxJQUFJLDRCQUE0QixNQUFNLGtCQUFrQjtBQUFBLElBQzVEO0FBQUEsSUFDQSxNQUFNLE9BQU8sT0FBTztBQUNsQixZQUFNLFNBQVMsTUFBTSxhQUFhO0FBQ2xDLGFBQU87QUFBQSxRQUNMLE1BQU0sT0FBTyxTQUFTO0FBQUEsVUFDbkIsTUFBTTtBQUFBLFlBQ0w7QUFBQSxZQUNBO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0EsT0FBTyxPQUFPLE9BQU87QUFDbkIsWUFBTSxTQUFTLE1BQU0sYUFBYTtBQUNsQyxZQUFNLFNBQVMsTUFBTSxPQUFPLFNBQVM7QUFBQSxRQUNsQyxNQUFNO0FBQUEsVUFDTDtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLHVCQUFpQixNQUFNLFFBQVE7QUFDN0IsWUFBSSxHQUFHLFNBQVMsdUJBQXVCO0FBQ3JDLGNBQUksR0FBRyxNQUFNLFNBQVMsY0FBYztBQUNsQyxrQkFBTSxJQUFJLE1BQU0sd0JBQXdCO0FBQUEsVUFDMUM7QUFDQSxnQkFBTTtBQUFBLFlBQ0osU0FBUyxHQUFHLE1BQU07QUFBQSxVQUNwQjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0YsQ0FBQztBQUNIOyIsCiAgIm5hbWVzIjogWyJmZXRjaCIsICJSZXF1ZXN0IiwgIlJlc3BvbnNlIiwgIkhlYWRlcnMiLCAiRm9ybURhdGEiLCAiQmxvYiIsICJGaWxlIiwgIlJlYWRhYmxlU3RyZWFtIiwgIm1lc3NhZ2UiLCAiZW5jb2RlciIsICJSZWFkYWJsZVN0cmVhbSIsICJwYXJzZVJlc3BvbnNlIiwgImZldGNoIiwgIm9wdHMiLCAiZW5jb2RlciIsICJtZXNzYWdlIiwgInJldHJ5TWVzc2FnZSIsICJ0b2tlbiIsICJfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0IiwgIl9fY2xhc3NQcml2YXRlRmllbGRHZXQiLCAibWVzc2FnZSIsICJfTWVzc2FnZVN0cmVhbV9nZXRGaW5hbE1lc3NhZ2UiLCAiX01lc3NhZ2VTdHJlYW1fZ2V0RmluYWxUZXh0IiwgIl9NZXNzYWdlU3RyZWFtX2JlZ2luUmVxdWVzdCIsICJfTWVzc2FnZVN0cmVhbV9hZGRTdHJlYW1FdmVudCIsICJfTWVzc2FnZVN0cmVhbV9lbmRSZXF1ZXN0IiwgIl9NZXNzYWdlU3RyZWFtX2FjY3VtdWxhdGVNZXNzYWdlIiwgImNodW5rIiwgIk1lc3NhZ2VzIiwgIm1lc3NhZ2UiLCAidHlwZXMiLCAiZ2V0TmFtZWRDdXJ2ZSIsICJ0b2tlbiIsICJtb2RlbCIsICJpdCIsICJtb2RlbCJdCn0K

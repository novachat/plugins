// src/index.ts
import * as novachat from "@novachat/plugin";

// ../../node_modules/.pnpm/whatwg-fetch@3.6.20/node_modules/whatwg-fetch/fetch.js
var g = typeof globalThis !== "undefined" && globalThis || typeof self !== "undefined" && self || // eslint-disable-next-line no-undef
typeof global !== "undefined" && global || {};
var support = {
  searchParams: "URLSearchParams" in g,
  iterable: "Symbol" in g && "iterator" in Symbol,
  blob: "FileReader" in g && "Blob" in g && function() {
    try {
      new Blob();
      return true;
    } catch (e) {
      return false;
    }
  }(),
  formData: "FormData" in g,
  arrayBuffer: "ArrayBuffer" in g
};
function isDataView(obj) {
  return obj && DataView.prototype.isPrototypeOf(obj);
}
if (support.arrayBuffer) {
  viewClasses = [
    "[object Int8Array]",
    "[object Uint8Array]",
    "[object Uint8ClampedArray]",
    "[object Int16Array]",
    "[object Uint16Array]",
    "[object Int32Array]",
    "[object Uint32Array]",
    "[object Float32Array]",
    "[object Float64Array]"
  ];
  isArrayBufferView = ArrayBuffer.isView || function(obj) {
    return obj && viewClasses.indexOf(Object.prototype.toString.call(obj)) > -1;
  };
}
var viewClasses;
var isArrayBufferView;
function normalizeName(name) {
  if (typeof name !== "string") {
    name = String(name);
  }
  if (/[^a-z0-9\-#$%&'*+.^_`|~!]/i.test(name) || name === "") {
    throw new TypeError('Invalid character in header field name: "' + name + '"');
  }
  return name.toLowerCase();
}
function normalizeValue(value) {
  if (typeof value !== "string") {
    value = String(value);
  }
  return value;
}
function iteratorFor(items) {
  var iterator = {
    next: function() {
      var value = items.shift();
      return { done: value === void 0, value };
    }
  };
  if (support.iterable) {
    iterator[Symbol.iterator] = function() {
      return iterator;
    };
  }
  return iterator;
}
function Headers(headers) {
  this.map = {};
  if (headers instanceof Headers) {
    headers.forEach(function(value, name) {
      this.append(name, value);
    }, this);
  } else if (Array.isArray(headers)) {
    headers.forEach(function(header) {
      if (header.length != 2) {
        throw new TypeError("Headers constructor: expected name/value pair to be length 2, found" + header.length);
      }
      this.append(header[0], header[1]);
    }, this);
  } else if (headers) {
    Object.getOwnPropertyNames(headers).forEach(function(name) {
      this.append(name, headers[name]);
    }, this);
  }
}
Headers.prototype.append = function(name, value) {
  name = normalizeName(name);
  value = normalizeValue(value);
  var oldValue = this.map[name];
  this.map[name] = oldValue ? oldValue + ", " + value : value;
};
Headers.prototype["delete"] = function(name) {
  delete this.map[normalizeName(name)];
};
Headers.prototype.get = function(name) {
  name = normalizeName(name);
  return this.has(name) ? this.map[name] : null;
};
Headers.prototype.has = function(name) {
  return this.map.hasOwnProperty(normalizeName(name));
};
Headers.prototype.set = function(name, value) {
  this.map[normalizeName(name)] = normalizeValue(value);
};
Headers.prototype.forEach = function(callback, thisArg) {
  for (var name in this.map) {
    if (this.map.hasOwnProperty(name)) {
      callback.call(thisArg, this.map[name], name, this);
    }
  }
};
Headers.prototype.keys = function() {
  var items = [];
  this.forEach(function(value, name) {
    items.push(name);
  });
  return iteratorFor(items);
};
Headers.prototype.values = function() {
  var items = [];
  this.forEach(function(value) {
    items.push(value);
  });
  return iteratorFor(items);
};
Headers.prototype.entries = function() {
  var items = [];
  this.forEach(function(value, name) {
    items.push([name, value]);
  });
  return iteratorFor(items);
};
if (support.iterable) {
  Headers.prototype[Symbol.iterator] = Headers.prototype.entries;
}
function consumed(body) {
  if (body._noBody) return;
  if (body.bodyUsed) {
    return Promise.reject(new TypeError("Already read"));
  }
  body.bodyUsed = true;
}
function fileReaderReady(reader) {
  return new Promise(function(resolve, reject) {
    reader.onload = function() {
      resolve(reader.result);
    };
    reader.onerror = function() {
      reject(reader.error);
    };
  });
}
function readBlobAsArrayBuffer(blob) {
  var reader = new FileReader();
  var promise = fileReaderReady(reader);
  reader.readAsArrayBuffer(blob);
  return promise;
}
function readBlobAsText(blob) {
  var reader = new FileReader();
  var promise = fileReaderReady(reader);
  var match = /charset=([A-Za-z0-9_-]+)/.exec(blob.type);
  var encoding = match ? match[1] : "utf-8";
  reader.readAsText(blob, encoding);
  return promise;
}
function readArrayBufferAsText(buf) {
  var view = new Uint8Array(buf);
  var chars = new Array(view.length);
  for (var i = 0; i < view.length; i++) {
    chars[i] = String.fromCharCode(view[i]);
  }
  return chars.join("");
}
function bufferClone(buf) {
  if (buf.slice) {
    return buf.slice(0);
  } else {
    var view = new Uint8Array(buf.byteLength);
    view.set(new Uint8Array(buf));
    return view.buffer;
  }
}
function Body() {
  this.bodyUsed = false;
  this._initBody = function(body) {
    this.bodyUsed = this.bodyUsed;
    this._bodyInit = body;
    if (!body) {
      this._noBody = true;
      this._bodyText = "";
    } else if (typeof body === "string") {
      this._bodyText = body;
    } else if (support.blob && Blob.prototype.isPrototypeOf(body)) {
      this._bodyBlob = body;
    } else if (support.formData && FormData.prototype.isPrototypeOf(body)) {
      this._bodyFormData = body;
    } else if (support.searchParams && URLSearchParams.prototype.isPrototypeOf(body)) {
      this._bodyText = body.toString();
    } else if (support.arrayBuffer && support.blob && isDataView(body)) {
      this._bodyArrayBuffer = bufferClone(body.buffer);
      this._bodyInit = new Blob([this._bodyArrayBuffer]);
    } else if (support.arrayBuffer && (ArrayBuffer.prototype.isPrototypeOf(body) || isArrayBufferView(body))) {
      this._bodyArrayBuffer = bufferClone(body);
    } else {
      this._bodyText = body = Object.prototype.toString.call(body);
    }
    if (!this.headers.get("content-type")) {
      if (typeof body === "string") {
        this.headers.set("content-type", "text/plain;charset=UTF-8");
      } else if (this._bodyBlob && this._bodyBlob.type) {
        this.headers.set("content-type", this._bodyBlob.type);
      } else if (support.searchParams && URLSearchParams.prototype.isPrototypeOf(body)) {
        this.headers.set("content-type", "application/x-www-form-urlencoded;charset=UTF-8");
      }
    }
  };
  if (support.blob) {
    this.blob = function() {
      var rejected = consumed(this);
      if (rejected) {
        return rejected;
      }
      if (this._bodyBlob) {
        return Promise.resolve(this._bodyBlob);
      } else if (this._bodyArrayBuffer) {
        return Promise.resolve(new Blob([this._bodyArrayBuffer]));
      } else if (this._bodyFormData) {
        throw new Error("could not read FormData body as blob");
      } else {
        return Promise.resolve(new Blob([this._bodyText]));
      }
    };
  }
  this.arrayBuffer = function() {
    if (this._bodyArrayBuffer) {
      var isConsumed = consumed(this);
      if (isConsumed) {
        return isConsumed;
      } else if (ArrayBuffer.isView(this._bodyArrayBuffer)) {
        return Promise.resolve(
          this._bodyArrayBuffer.buffer.slice(
            this._bodyArrayBuffer.byteOffset,
            this._bodyArrayBuffer.byteOffset + this._bodyArrayBuffer.byteLength
          )
        );
      } else {
        return Promise.resolve(this._bodyArrayBuffer);
      }
    } else if (support.blob) {
      return this.blob().then(readBlobAsArrayBuffer);
    } else {
      throw new Error("could not read as ArrayBuffer");
    }
  };
  this.text = function() {
    var rejected = consumed(this);
    if (rejected) {
      return rejected;
    }
    if (this._bodyBlob) {
      return readBlobAsText(this._bodyBlob);
    } else if (this._bodyArrayBuffer) {
      return Promise.resolve(readArrayBufferAsText(this._bodyArrayBuffer));
    } else if (this._bodyFormData) {
      throw new Error("could not read FormData body as text");
    } else {
      return Promise.resolve(this._bodyText);
    }
  };
  if (support.formData) {
    this.formData = function() {
      return this.text().then(decode);
    };
  }
  this.json = function() {
    return this.text().then(JSON.parse);
  };
  return this;
}
var methods = ["CONNECT", "DELETE", "GET", "HEAD", "OPTIONS", "PATCH", "POST", "PUT", "TRACE"];
function normalizeMethod(method) {
  var upcased = method.toUpperCase();
  return methods.indexOf(upcased) > -1 ? upcased : method;
}
function Request(input, options) {
  if (!(this instanceof Request)) {
    throw new TypeError('Please use the "new" operator, this DOM object constructor cannot be called as a function.');
  }
  options = options || {};
  var body = options.body;
  if (input instanceof Request) {
    if (input.bodyUsed) {
      throw new TypeError("Already read");
    }
    this.url = input.url;
    this.credentials = input.credentials;
    if (!options.headers) {
      this.headers = new Headers(input.headers);
    }
    this.method = input.method;
    this.mode = input.mode;
    this.signal = input.signal;
    if (!body && input._bodyInit != null) {
      body = input._bodyInit;
      input.bodyUsed = true;
    }
  } else {
    this.url = String(input);
  }
  this.credentials = options.credentials || this.credentials || "same-origin";
  if (options.headers || !this.headers) {
    this.headers = new Headers(options.headers);
  }
  this.method = normalizeMethod(options.method || this.method || "GET");
  this.mode = options.mode || this.mode || null;
  this.signal = options.signal || this.signal || function() {
    if ("AbortController" in g) {
      var ctrl = new AbortController();
      return ctrl.signal;
    }
  }();
  this.referrer = null;
  if ((this.method === "GET" || this.method === "HEAD") && body) {
    throw new TypeError("Body not allowed for GET or HEAD requests");
  }
  this._initBody(body);
  if (this.method === "GET" || this.method === "HEAD") {
    if (options.cache === "no-store" || options.cache === "no-cache") {
      var reParamSearch = /([?&])_=[^&]*/;
      if (reParamSearch.test(this.url)) {
        this.url = this.url.replace(reParamSearch, "$1_=" + (/* @__PURE__ */ new Date()).getTime());
      } else {
        var reQueryString = /\?/;
        this.url += (reQueryString.test(this.url) ? "&" : "?") + "_=" + (/* @__PURE__ */ new Date()).getTime();
      }
    }
  }
}
Request.prototype.clone = function() {
  return new Request(this, { body: this._bodyInit });
};
function decode(body) {
  var form = new FormData();
  body.trim().split("&").forEach(function(bytes) {
    if (bytes) {
      var split = bytes.split("=");
      var name = split.shift().replace(/\+/g, " ");
      var value = split.join("=").replace(/\+/g, " ");
      form.append(decodeURIComponent(name), decodeURIComponent(value));
    }
  });
  return form;
}
function parseHeaders(rawHeaders) {
  var headers = new Headers();
  var preProcessedHeaders = rawHeaders.replace(/\r?\n[\t ]+/g, " ");
  preProcessedHeaders.split("\r").map(function(header) {
    return header.indexOf("\n") === 0 ? header.substr(1, header.length) : header;
  }).forEach(function(line) {
    var parts = line.split(":");
    var key = parts.shift().trim();
    if (key) {
      var value = parts.join(":").trim();
      try {
        headers.append(key, value);
      } catch (error) {
        console.warn("Response " + error.message);
      }
    }
  });
  return headers;
}
Body.call(Request.prototype);
function Response(bodyInit, options) {
  if (!(this instanceof Response)) {
    throw new TypeError('Please use the "new" operator, this DOM object constructor cannot be called as a function.');
  }
  if (!options) {
    options = {};
  }
  this.type = "default";
  this.status = options.status === void 0 ? 200 : options.status;
  if (this.status < 200 || this.status > 599) {
    throw new RangeError("Failed to construct 'Response': The status provided (0) is outside the range [200, 599].");
  }
  this.ok = this.status >= 200 && this.status < 300;
  this.statusText = options.statusText === void 0 ? "" : "" + options.statusText;
  this.headers = new Headers(options.headers);
  this.url = options.url || "";
  this._initBody(bodyInit);
}
Body.call(Response.prototype);
Response.prototype.clone = function() {
  return new Response(this._bodyInit, {
    status: this.status,
    statusText: this.statusText,
    headers: new Headers(this.headers),
    url: this.url
  });
};
Response.error = function() {
  var response = new Response(null, { status: 200, statusText: "" });
  response.ok = false;
  response.status = 0;
  response.type = "error";
  return response;
};
var redirectStatuses = [301, 302, 303, 307, 308];
Response.redirect = function(url, status) {
  if (redirectStatuses.indexOf(status) === -1) {
    throw new RangeError("Invalid status code");
  }
  return new Response(null, { status, headers: { location: url } });
};
var DOMException = g.DOMException;
try {
  new DOMException();
} catch (err) {
  DOMException = function(message, name) {
    this.message = message;
    this.name = name;
    var error = Error(message);
    this.stack = error.stack;
  };
  DOMException.prototype = Object.create(Error.prototype);
  DOMException.prototype.constructor = DOMException;
}
function fetch2(input, init) {
  return new Promise(function(resolve, reject) {
    var request = new Request(input, init);
    if (request.signal && request.signal.aborted) {
      return reject(new DOMException("Aborted", "AbortError"));
    }
    var xhr = new XMLHttpRequest();
    function abortXhr() {
      xhr.abort();
    }
    xhr.onload = function() {
      var options = {
        statusText: xhr.statusText,
        headers: parseHeaders(xhr.getAllResponseHeaders() || "")
      };
      if (request.url.indexOf("file://") === 0 && (xhr.status < 200 || xhr.status > 599)) {
        options.status = 200;
      } else {
        options.status = xhr.status;
      }
      options.url = "responseURL" in xhr ? xhr.responseURL : options.headers.get("X-Request-URL");
      var body = "response" in xhr ? xhr.response : xhr.responseText;
      setTimeout(function() {
        resolve(new Response(body, options));
      }, 0);
    };
    xhr.onerror = function() {
      setTimeout(function() {
        reject(new TypeError("Network request failed"));
      }, 0);
    };
    xhr.ontimeout = function() {
      setTimeout(function() {
        reject(new TypeError("Network request timed out"));
      }, 0);
    };
    xhr.onabort = function() {
      setTimeout(function() {
        reject(new DOMException("Aborted", "AbortError"));
      }, 0);
    };
    function fixUrl(url) {
      try {
        return url === "" && g.location.href ? g.location.href : url;
      } catch (e) {
        return url;
      }
    }
    xhr.open(request.method, fixUrl(request.url), true);
    if (request.credentials === "include") {
      xhr.withCredentials = true;
    } else if (request.credentials === "omit") {
      xhr.withCredentials = false;
    }
    if ("responseType" in xhr) {
      if (support.blob) {
        xhr.responseType = "blob";
      } else if (support.arrayBuffer) {
        xhr.responseType = "arraybuffer";
      }
    }
    if (init && typeof init.headers === "object" && !(init.headers instanceof Headers || g.Headers && init.headers instanceof g.Headers)) {
      var names = [];
      Object.getOwnPropertyNames(init.headers).forEach(function(name) {
        names.push(normalizeName(name));
        xhr.setRequestHeader(name, normalizeValue(init.headers[name]));
      });
      request.headers.forEach(function(value, name) {
        if (names.indexOf(name) === -1) {
          xhr.setRequestHeader(name, value);
        }
      });
    } else {
      request.headers.forEach(function(value, name) {
        xhr.setRequestHeader(name, value);
      });
    }
    if (request.signal) {
      request.signal.addEventListener("abort", abortXhr);
      xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
          request.signal.removeEventListener("abort", abortXhr);
        }
      };
    }
    xhr.send(typeof request._bodyInit === "undefined" ? null : request._bodyInit);
  });
}
fetch2.polyfill = true;
if (!g.fetch) {
  g.fetch = fetch2;
  g.Headers = Headers;
  g.Request = Request;
  g.Response = Response;
}

// ../../node_modules/.pnpm/ollama@0.5.9/node_modules/ollama/dist/shared/ollama.133b951a.mjs
var version = "0.5.9";
var __defProp$1 = Object.defineProperty;
var __defNormalProp$1 = (obj, key, value) => key in obj ? __defProp$1(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField$1 = (obj, key, value) => {
  __defNormalProp$1(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
var ResponseError = class _ResponseError extends Error {
  constructor(error, status_code) {
    super(error);
    this.error = error;
    this.status_code = status_code;
    this.name = "ResponseError";
    if (Error.captureStackTrace) {
      Error.captureStackTrace(this, _ResponseError);
    }
  }
};
var AbortableAsyncIterator = class {
  constructor(abortController, itr, doneCallback) {
    __publicField$1(this, "abortController");
    __publicField$1(this, "itr");
    __publicField$1(this, "doneCallback");
    this.abortController = abortController;
    this.itr = itr;
    this.doneCallback = doneCallback;
  }
  abort() {
    this.abortController.abort();
  }
  async *[Symbol.asyncIterator]() {
    for await (const message of this.itr) {
      if ("error" in message) {
        throw new Error(message.error);
      }
      yield message;
      if (message.done || message.status === "success") {
        this.doneCallback();
        return;
      }
    }
    throw new Error("Did not receive done or success response in stream.");
  }
};
var checkOk = async (response) => {
  if (response.ok) {
    return;
  }
  let message = `Error ${response.status}: ${response.statusText}`;
  let errorData = null;
  if (response.headers.get("content-type")?.includes("application/json")) {
    try {
      errorData = await response.json();
      message = errorData.error || message;
    } catch (error) {
      console.log("Failed to parse error response as JSON");
    }
  } else {
    try {
      console.log("Getting text from response");
      const textResponse = await response.text();
      message = textResponse || message;
    } catch (error) {
      console.log("Failed to get text from error response");
    }
  }
  throw new ResponseError(message, response.status);
};
function getPlatform() {
  if (typeof window !== "undefined" && window.navigator) {
    return `${window.navigator.platform.toLowerCase()} Browser/${navigator.userAgent};`;
  } else if (typeof process !== "undefined") {
    return `${process.arch} ${process.platform} Node.js/${process.version}`;
  }
  return "";
}
var fetchWithHeaders = async (fetch3, url, options = {}) => {
  const defaultHeaders = {
    "Content-Type": "application/json",
    Accept: "application/json",
    "User-Agent": `ollama-js/${version} (${getPlatform()})`
  };
  if (!options.headers) {
    options.headers = {};
  }
  options.headers = {
    ...defaultHeaders,
    ...options.headers
  };
  return fetch3(url, options);
};
var get = async (fetch3, host) => {
  const response = await fetchWithHeaders(fetch3, host);
  await checkOk(response);
  return response;
};
var post = async (fetch3, host, data, options) => {
  const isRecord = (input) => {
    return input !== null && typeof input === "object" && !Array.isArray(input);
  };
  const formattedData = isRecord(data) ? JSON.stringify(data) : data;
  const response = await fetchWithHeaders(fetch3, host, {
    method: "POST",
    body: formattedData,
    signal: options?.signal,
    headers: options?.headers
  });
  await checkOk(response);
  return response;
};
var del = async (fetch3, host, data) => {
  const response = await fetchWithHeaders(fetch3, host, {
    method: "DELETE",
    body: JSON.stringify(data)
  });
  await checkOk(response);
  return response;
};
var parseJSON = async function* (itr) {
  const decoder = new TextDecoder("utf-8");
  let buffer = "";
  const reader = itr.getReader();
  while (true) {
    const { done, value: chunk } = await reader.read();
    if (done) {
      break;
    }
    buffer += decoder.decode(chunk);
    const parts = buffer.split("\n");
    buffer = parts.pop() ?? "";
    for (const part of parts) {
      try {
        yield JSON.parse(part);
      } catch (error) {
        console.warn("invalid json: ", part);
      }
    }
  }
  for (const part of buffer.split("\n").filter((p) => p !== "")) {
    try {
      yield JSON.parse(part);
    } catch (error) {
      console.warn("invalid json: ", part);
    }
  }
};
var formatHost = (host) => {
  if (!host) {
    return "http://127.0.0.1:11434";
  }
  let isExplicitProtocol = host.includes("://");
  if (host.startsWith(":")) {
    host = `http://127.0.0.1${host}`;
    isExplicitProtocol = true;
  }
  if (!isExplicitProtocol) {
    host = `http://${host}`;
  }
  const url = new URL(host);
  let port = url.port;
  if (!port) {
    if (!isExplicitProtocol) {
      port = "11434";
    } else {
      port = url.protocol === "https:" ? "443" : "80";
    }
  }
  let formattedHost = `${url.protocol}//${url.hostname}:${port}${url.pathname}`;
  if (formattedHost.endsWith("/")) {
    formattedHost = formattedHost.slice(0, -1);
  }
  return formattedHost;
};
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
var __publicField = (obj, key, value) => {
  __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
  return value;
};
var Ollama$1 = class Ollama {
  constructor(config) {
    __publicField(this, "config");
    __publicField(this, "fetch");
    __publicField(this, "ongoingStreamedRequests", []);
    this.config = {
      host: ""
    };
    if (!config?.proxy) {
      this.config.host = formatHost(config?.host ?? "http://127.0.0.1:11434");
    }
    this.fetch = fetch;
    if (config?.fetch != null) {
      this.fetch = config.fetch;
    }
  }
  // Abort any ongoing streamed requests to Ollama
  abort() {
    for (const request of this.ongoingStreamedRequests) {
      request.abort();
    }
    this.ongoingStreamedRequests.length = 0;
  }
  /**
   * Processes a request to the Ollama server. If the request is streamable, it will return a
   * AbortableAsyncIterator that yields the response messages. Otherwise, it will return the response
   * object.
   * @param endpoint {string} - The endpoint to send the request to.
   * @param request {object} - The request object to send to the endpoint.
   * @protected {T | AbortableAsyncIterator<T>} - The response object or a AbortableAsyncIterator that yields
   * response messages.
   * @throws {Error} - If the response body is missing or if the response is an error.
   * @returns {Promise<T | AbortableAsyncIterator<T>>} - The response object or a AbortableAsyncIterator that yields the streamed response.
   */
  async processStreamableRequest(endpoint, request) {
    request.stream = request.stream ?? false;
    const host = `${this.config.host}/api/${endpoint}`;
    if (request.stream) {
      const abortController = new AbortController();
      const response2 = await post(this.fetch, host, request, {
        signal: abortController.signal,
        headers: this.config.headers
      });
      if (!response2.body) {
        throw new Error("Missing body");
      }
      const itr = parseJSON(response2.body);
      const abortableAsyncIterator = new AbortableAsyncIterator(
        abortController,
        itr,
        () => {
          const i = this.ongoingStreamedRequests.indexOf(abortableAsyncIterator);
          if (i > -1) {
            this.ongoingStreamedRequests.splice(i, 1);
          }
        }
      );
      this.ongoingStreamedRequests.push(abortableAsyncIterator);
      return abortableAsyncIterator;
    }
    const response = await post(this.fetch, host, request, {
      headers: this.config.headers
    });
    return await response.json();
  }
  /**
  * Encodes an image to base64 if it is a Uint8Array.
  * @param image {Uint8Array | string} - The image to encode.
  * @returns {Promise<string>} - The base64 encoded image.
  */
  async encodeImage(image) {
    if (typeof image !== "string") {
      const uint8Array = new Uint8Array(image);
      let byteString = "";
      const len = uint8Array.byteLength;
      for (let i = 0; i < len; i++) {
        byteString += String.fromCharCode(uint8Array[i]);
      }
      return btoa(byteString);
    }
    return image;
  }
  /**
   * Generates a response from a text prompt.
   * @param request {GenerateRequest} - The request object.
   * @returns {Promise<GenerateResponse | AbortableAsyncIterator<GenerateResponse>>} - The response object or
   * an AbortableAsyncIterator that yields response messages.
   */
  async generate(request) {
    if (request.images) {
      request.images = await Promise.all(request.images.map(this.encodeImage.bind(this)));
    }
    return this.processStreamableRequest("generate", request);
  }
  /**
   * Chats with the model. The request object can contain messages with images that are either
   * Uint8Arrays or base64 encoded strings. The images will be base64 encoded before sending the
   * request.
   * @param request {ChatRequest} - The request object.
   * @returns {Promise<ChatResponse | AbortableAsyncIterator<ChatResponse>>} - The response object or an
   * AbortableAsyncIterator that yields response messages.
   */
  async chat(request) {
    if (request.messages) {
      for (const message of request.messages) {
        if (message.images) {
          message.images = await Promise.all(
            message.images.map(this.encodeImage.bind(this))
          );
        }
      }
    }
    return this.processStreamableRequest("chat", request);
  }
  /**
   * Creates a new model from a stream of data.
   * @param request {CreateRequest} - The request object.
   * @returns {Promise<ProgressResponse | AbortableAsyncIterator<ProgressResponse>>} - The response object or a stream of progress responses.
   */
  async create(request) {
    return this.processStreamableRequest("create", {
      name: request.model,
      stream: request.stream,
      modelfile: request.modelfile,
      quantize: request.quantize
    });
  }
  /**
   * Pulls a model from the Ollama registry. The request object can contain a stream flag to indicate if the
   * response should be streamed.
   * @param request {PullRequest} - The request object.
   * @returns {Promise<ProgressResponse | AbortableAsyncIterator<ProgressResponse>>} - The response object or
   * an AbortableAsyncIterator that yields response messages.
   */
  async pull(request) {
    return this.processStreamableRequest("pull", {
      name: request.model,
      stream: request.stream,
      insecure: request.insecure
    });
  }
  /**
   * Pushes a model to the Ollama registry. The request object can contain a stream flag to indicate if the
   * response should be streamed.
   * @param request {PushRequest} - The request object.
   * @returns {Promise<ProgressResponse | AbortableAsyncIterator<ProgressResponse>>} - The response object or
   * an AbortableAsyncIterator that yields response messages.
   */
  async push(request) {
    return this.processStreamableRequest("push", {
      name: request.model,
      stream: request.stream,
      insecure: request.insecure
    });
  }
  /**
   * Deletes a model from the server. The request object should contain the name of the model to
   * delete.
   * @param request {DeleteRequest} - The request object.
   * @returns {Promise<StatusResponse>} - The response object.
   */
  async delete(request) {
    await del(this.fetch, `${this.config.host}/api/delete`, {
      name: request.model
    });
    return { status: "success" };
  }
  /**
   * Copies a model from one name to another. The request object should contain the name of the
   * model to copy and the new name.
   * @param request {CopyRequest} - The request object.
   * @returns {Promise<StatusResponse>} - The response object.
   */
  async copy(request) {
    await post(this.fetch, `${this.config.host}/api/copy`, { ...request });
    return { status: "success" };
  }
  /**
   * Lists the models on the server.
   * @returns {Promise<ListResponse>} - The response object.
   * @throws {Error} - If the response body is missing.
   */
  async list() {
    const response = await get(this.fetch, `${this.config.host}/api/tags`);
    return await response.json();
  }
  /**
   * Shows the metadata of a model. The request object should contain the name of the model.
   * @param request {ShowRequest} - The request object.
   * @returns {Promise<ShowResponse>} - The response object.
   */
  async show(request) {
    const response = await post(this.fetch, `${this.config.host}/api/show`, {
      ...request
    });
    return await response.json();
  }
  /**
   * Embeds text input into vectors.
   * @param request {EmbedRequest} - The request object.
   * @returns {Promise<EmbedResponse>} - The response object.
   */
  async embed(request) {
    const response = await post(this.fetch, `${this.config.host}/api/embed`, {
      ...request
    });
    return await response.json();
  }
  /**
   * Embeds a text prompt into a vector.
   * @param request {EmbeddingsRequest} - The request object.
   * @returns {Promise<EmbeddingsResponse>} - The response object.
   */
  async embeddings(request) {
    const response = await post(this.fetch, `${this.config.host}/api/embeddings`, {
      ...request
    });
    return await response.json();
  }
  /**
   * Lists the running models on the server
   * @returns {Promise<ListResponse>} - The response object.
   * @throws {Error} - If the response body is missing.
   */
  async ps() {
    const response = await get(this.fetch, `${this.config.host}/api/ps`);
    return await response.json();
  }
};
var browser = new Ollama$1();

// src/index.ts
function convertMessages(messages) {
  return messages.map((it) => ({
    role: it.role,
    content: it.content,
    images: it.attachments?.map((it2) => it2.url)
  }));
}
async function activate() {
  const list = await browser.list();
  await novachat.model.registerProvider({
    name: "Ollama",
    models: list.models.map((it) => ({ id: it.name, name: it.name })),
    async invoke(query) {
      const r = await browser.chat({
        model: query.model,
        messages: convertMessages(query.messages)
      });
      return {
        content: r.message.content
      };
    },
    async *stream(query) {
      const r = await browser.chat({
        model: query.model,
        messages: convertMessages(query.messages),
        stream: true
      });
      for await (const it of r) {
        yield {
          content: it.message.content
        };
      }
    }
  });
}
export {
  activate
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2luZGV4LnRzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS93aGF0d2ctZmV0Y2hAMy42LjIwL25vZGVfbW9kdWxlcy93aGF0d2ctZmV0Y2gvZmV0Y2guanMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL29sbGFtYUAwLjUuOS9ub2RlX21vZHVsZXMvb2xsYW1hL2Rpc3Qvc2hhcmVkL29sbGFtYS4xMzNiOTUxYS5tanMiXSwKICAic291cmNlc0NvbnRlbnQiOiBbImltcG9ydCAqIGFzIG5vdmFjaGF0IGZyb20gJ0Bub3ZhY2hhdC9wbHVnaW4nXG5pbXBvcnQgb2xsYW1hIGZyb20gJ29sbGFtYS9icm93c2VyJ1xuXG5mdW5jdGlvbiBjb252ZXJ0TWVzc2FnZXMobWVzc2FnZXM6IG5vdmFjaGF0LlF1ZXJ5UmVxdWVzdFsnbWVzc2FnZXMnXSkge1xuICByZXR1cm4gbWVzc2FnZXMubWFwKChpdCkgPT4gKHtcbiAgICByb2xlOiBpdC5yb2xlLFxuICAgIGNvbnRlbnQ6IGl0LmNvbnRlbnQsXG4gICAgaW1hZ2VzOiBpdC5hdHRhY2htZW50cz8ubWFwKChpdCkgPT4gaXQudXJsKSxcbiAgfSkpXG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBhY3RpdmF0ZSgpIHtcbiAgY29uc3QgbGlzdCA9IGF3YWl0IG9sbGFtYS5saXN0KClcbiAgYXdhaXQgbm92YWNoYXQubW9kZWwucmVnaXN0ZXJQcm92aWRlcih7XG4gICAgbmFtZTogJ09sbGFtYScsXG4gICAgbW9kZWxzOiBsaXN0Lm1vZGVscy5tYXAoKGl0KSA9PiAoeyBpZDogaXQubmFtZSwgbmFtZTogaXQubmFtZSB9KSksXG4gICAgYXN5bmMgaW52b2tlKHF1ZXJ5KSB7XG4gICAgICBjb25zdCByID0gYXdhaXQgb2xsYW1hLmNoYXQoe1xuICAgICAgICBtb2RlbDogcXVlcnkubW9kZWwsXG4gICAgICAgIG1lc3NhZ2VzOiBjb252ZXJ0TWVzc2FnZXMocXVlcnkubWVzc2FnZXMpLFxuICAgICAgfSlcbiAgICAgIHJldHVybiB7XG4gICAgICAgIGNvbnRlbnQ6IHIubWVzc2FnZS5jb250ZW50LFxuICAgICAgfVxuICAgIH0sXG4gICAgYXN5bmMgKnN0cmVhbShxdWVyeSkge1xuICAgICAgY29uc3QgciA9IGF3YWl0IG9sbGFtYS5jaGF0KHtcbiAgICAgICAgbW9kZWw6IHF1ZXJ5Lm1vZGVsLFxuICAgICAgICBtZXNzYWdlczogY29udmVydE1lc3NhZ2VzKHF1ZXJ5Lm1lc3NhZ2VzKSxcbiAgICAgICAgc3RyZWFtOiB0cnVlLFxuICAgICAgfSlcbiAgICAgIGZvciBhd2FpdCAoY29uc3QgaXQgb2Ygcikge1xuICAgICAgICB5aWVsZCB7XG4gICAgICAgICAgY29udGVudDogaXQubWVzc2FnZS5jb250ZW50LFxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSxcbiAgfSlcbn1cbiIsICIvKiBlc2xpbnQtZGlzYWJsZSBuby1wcm90b3R5cGUtYnVpbHRpbnMgKi9cbnZhciBnID1cbiAgKHR5cGVvZiBnbG9iYWxUaGlzICE9PSAndW5kZWZpbmVkJyAmJiBnbG9iYWxUaGlzKSB8fFxuICAodHlwZW9mIHNlbGYgIT09ICd1bmRlZmluZWQnICYmIHNlbGYpIHx8XG4gIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby11bmRlZlxuICAodHlwZW9mIGdsb2JhbCAhPT0gJ3VuZGVmaW5lZCcgJiYgZ2xvYmFsKSB8fFxuICB7fVxuXG52YXIgc3VwcG9ydCA9IHtcbiAgc2VhcmNoUGFyYW1zOiAnVVJMU2VhcmNoUGFyYW1zJyBpbiBnLFxuICBpdGVyYWJsZTogJ1N5bWJvbCcgaW4gZyAmJiAnaXRlcmF0b3InIGluIFN5bWJvbCxcbiAgYmxvYjpcbiAgICAnRmlsZVJlYWRlcicgaW4gZyAmJlxuICAgICdCbG9iJyBpbiBnICYmXG4gICAgKGZ1bmN0aW9uKCkge1xuICAgICAgdHJ5IHtcbiAgICAgICAgbmV3IEJsb2IoKVxuICAgICAgICByZXR1cm4gdHJ1ZVxuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICByZXR1cm4gZmFsc2VcbiAgICAgIH1cbiAgICB9KSgpLFxuICBmb3JtRGF0YTogJ0Zvcm1EYXRhJyBpbiBnLFxuICBhcnJheUJ1ZmZlcjogJ0FycmF5QnVmZmVyJyBpbiBnXG59XG5cbmZ1bmN0aW9uIGlzRGF0YVZpZXcob2JqKSB7XG4gIHJldHVybiBvYmogJiYgRGF0YVZpZXcucHJvdG90eXBlLmlzUHJvdG90eXBlT2Yob2JqKVxufVxuXG5pZiAoc3VwcG9ydC5hcnJheUJ1ZmZlcikge1xuICB2YXIgdmlld0NsYXNzZXMgPSBbXG4gICAgJ1tvYmplY3QgSW50OEFycmF5XScsXG4gICAgJ1tvYmplY3QgVWludDhBcnJheV0nLFxuICAgICdbb2JqZWN0IFVpbnQ4Q2xhbXBlZEFycmF5XScsXG4gICAgJ1tvYmplY3QgSW50MTZBcnJheV0nLFxuICAgICdbb2JqZWN0IFVpbnQxNkFycmF5XScsXG4gICAgJ1tvYmplY3QgSW50MzJBcnJheV0nLFxuICAgICdbb2JqZWN0IFVpbnQzMkFycmF5XScsXG4gICAgJ1tvYmplY3QgRmxvYXQzMkFycmF5XScsXG4gICAgJ1tvYmplY3QgRmxvYXQ2NEFycmF5XSdcbiAgXVxuXG4gIHZhciBpc0FycmF5QnVmZmVyVmlldyA9XG4gICAgQXJyYXlCdWZmZXIuaXNWaWV3IHx8XG4gICAgZnVuY3Rpb24ob2JqKSB7XG4gICAgICByZXR1cm4gb2JqICYmIHZpZXdDbGFzc2VzLmluZGV4T2YoT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKG9iaikpID4gLTFcbiAgICB9XG59XG5cbmZ1bmN0aW9uIG5vcm1hbGl6ZU5hbWUobmFtZSkge1xuICBpZiAodHlwZW9mIG5hbWUgIT09ICdzdHJpbmcnKSB7XG4gICAgbmFtZSA9IFN0cmluZyhuYW1lKVxuICB9XG4gIGlmICgvW15hLXowLTlcXC0jJCUmJyorLl5fYHx+IV0vaS50ZXN0KG5hbWUpIHx8IG5hbWUgPT09ICcnKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignSW52YWxpZCBjaGFyYWN0ZXIgaW4gaGVhZGVyIGZpZWxkIG5hbWU6IFwiJyArIG5hbWUgKyAnXCInKVxuICB9XG4gIHJldHVybiBuYW1lLnRvTG93ZXJDYXNlKClcbn1cblxuZnVuY3Rpb24gbm9ybWFsaXplVmFsdWUodmFsdWUpIHtcbiAgaWYgKHR5cGVvZiB2YWx1ZSAhPT0gJ3N0cmluZycpIHtcbiAgICB2YWx1ZSA9IFN0cmluZyh2YWx1ZSlcbiAgfVxuICByZXR1cm4gdmFsdWVcbn1cblxuLy8gQnVpbGQgYSBkZXN0cnVjdGl2ZSBpdGVyYXRvciBmb3IgdGhlIHZhbHVlIGxpc3RcbmZ1bmN0aW9uIGl0ZXJhdG9yRm9yKGl0ZW1zKSB7XG4gIHZhciBpdGVyYXRvciA9IHtcbiAgICBuZXh0OiBmdW5jdGlvbigpIHtcbiAgICAgIHZhciB2YWx1ZSA9IGl0ZW1zLnNoaWZ0KClcbiAgICAgIHJldHVybiB7ZG9uZTogdmFsdWUgPT09IHVuZGVmaW5lZCwgdmFsdWU6IHZhbHVlfVxuICAgIH1cbiAgfVxuXG4gIGlmIChzdXBwb3J0Lml0ZXJhYmxlKSB7XG4gICAgaXRlcmF0b3JbU3ltYm9sLml0ZXJhdG9yXSA9IGZ1bmN0aW9uKCkge1xuICAgICAgcmV0dXJuIGl0ZXJhdG9yXG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGl0ZXJhdG9yXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBIZWFkZXJzKGhlYWRlcnMpIHtcbiAgdGhpcy5tYXAgPSB7fVxuXG4gIGlmIChoZWFkZXJzIGluc3RhbmNlb2YgSGVhZGVycykge1xuICAgIGhlYWRlcnMuZm9yRWFjaChmdW5jdGlvbih2YWx1ZSwgbmFtZSkge1xuICAgICAgdGhpcy5hcHBlbmQobmFtZSwgdmFsdWUpXG4gICAgfSwgdGhpcylcbiAgfSBlbHNlIGlmIChBcnJheS5pc0FycmF5KGhlYWRlcnMpKSB7XG4gICAgaGVhZGVycy5mb3JFYWNoKGZ1bmN0aW9uKGhlYWRlcikge1xuICAgICAgaWYgKGhlYWRlci5sZW5ndGggIT0gMikge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdIZWFkZXJzIGNvbnN0cnVjdG9yOiBleHBlY3RlZCBuYW1lL3ZhbHVlIHBhaXIgdG8gYmUgbGVuZ3RoIDIsIGZvdW5kJyArIGhlYWRlci5sZW5ndGgpXG4gICAgICB9XG4gICAgICB0aGlzLmFwcGVuZChoZWFkZXJbMF0sIGhlYWRlclsxXSlcbiAgICB9LCB0aGlzKVxuICB9IGVsc2UgaWYgKGhlYWRlcnMpIHtcbiAgICBPYmplY3QuZ2V0T3duUHJvcGVydHlOYW1lcyhoZWFkZXJzKS5mb3JFYWNoKGZ1bmN0aW9uKG5hbWUpIHtcbiAgICAgIHRoaXMuYXBwZW5kKG5hbWUsIGhlYWRlcnNbbmFtZV0pXG4gICAgfSwgdGhpcylcbiAgfVxufVxuXG5IZWFkZXJzLnByb3RvdHlwZS5hcHBlbmQgPSBmdW5jdGlvbihuYW1lLCB2YWx1ZSkge1xuICBuYW1lID0gbm9ybWFsaXplTmFtZShuYW1lKVxuICB2YWx1ZSA9IG5vcm1hbGl6ZVZhbHVlKHZhbHVlKVxuICB2YXIgb2xkVmFsdWUgPSB0aGlzLm1hcFtuYW1lXVxuICB0aGlzLm1hcFtuYW1lXSA9IG9sZFZhbHVlID8gb2xkVmFsdWUgKyAnLCAnICsgdmFsdWUgOiB2YWx1ZVxufVxuXG5IZWFkZXJzLnByb3RvdHlwZVsnZGVsZXRlJ10gPSBmdW5jdGlvbihuYW1lKSB7XG4gIGRlbGV0ZSB0aGlzLm1hcFtub3JtYWxpemVOYW1lKG5hbWUpXVxufVxuXG5IZWFkZXJzLnByb3RvdHlwZS5nZXQgPSBmdW5jdGlvbihuYW1lKSB7XG4gIG5hbWUgPSBub3JtYWxpemVOYW1lKG5hbWUpXG4gIHJldHVybiB0aGlzLmhhcyhuYW1lKSA/IHRoaXMubWFwW25hbWVdIDogbnVsbFxufVxuXG5IZWFkZXJzLnByb3RvdHlwZS5oYXMgPSBmdW5jdGlvbihuYW1lKSB7XG4gIHJldHVybiB0aGlzLm1hcC5oYXNPd25Qcm9wZXJ0eShub3JtYWxpemVOYW1lKG5hbWUpKVxufVxuXG5IZWFkZXJzLnByb3RvdHlwZS5zZXQgPSBmdW5jdGlvbihuYW1lLCB2YWx1ZSkge1xuICB0aGlzLm1hcFtub3JtYWxpemVOYW1lKG5hbWUpXSA9IG5vcm1hbGl6ZVZhbHVlKHZhbHVlKVxufVxuXG5IZWFkZXJzLnByb3RvdHlwZS5mb3JFYWNoID0gZnVuY3Rpb24oY2FsbGJhY2ssIHRoaXNBcmcpIHtcbiAgZm9yICh2YXIgbmFtZSBpbiB0aGlzLm1hcCkge1xuICAgIGlmICh0aGlzLm1hcC5oYXNPd25Qcm9wZXJ0eShuYW1lKSkge1xuICAgICAgY2FsbGJhY2suY2FsbCh0aGlzQXJnLCB0aGlzLm1hcFtuYW1lXSwgbmFtZSwgdGhpcylcbiAgICB9XG4gIH1cbn1cblxuSGVhZGVycy5wcm90b3R5cGUua2V5cyA9IGZ1bmN0aW9uKCkge1xuICB2YXIgaXRlbXMgPSBbXVxuICB0aGlzLmZvckVhY2goZnVuY3Rpb24odmFsdWUsIG5hbWUpIHtcbiAgICBpdGVtcy5wdXNoKG5hbWUpXG4gIH0pXG4gIHJldHVybiBpdGVyYXRvckZvcihpdGVtcylcbn1cblxuSGVhZGVycy5wcm90b3R5cGUudmFsdWVzID0gZnVuY3Rpb24oKSB7XG4gIHZhciBpdGVtcyA9IFtdXG4gIHRoaXMuZm9yRWFjaChmdW5jdGlvbih2YWx1ZSkge1xuICAgIGl0ZW1zLnB1c2godmFsdWUpXG4gIH0pXG4gIHJldHVybiBpdGVyYXRvckZvcihpdGVtcylcbn1cblxuSGVhZGVycy5wcm90b3R5cGUuZW50cmllcyA9IGZ1bmN0aW9uKCkge1xuICB2YXIgaXRlbXMgPSBbXVxuICB0aGlzLmZvckVhY2goZnVuY3Rpb24odmFsdWUsIG5hbWUpIHtcbiAgICBpdGVtcy5wdXNoKFtuYW1lLCB2YWx1ZV0pXG4gIH0pXG4gIHJldHVybiBpdGVyYXRvckZvcihpdGVtcylcbn1cblxuaWYgKHN1cHBvcnQuaXRlcmFibGUpIHtcbiAgSGVhZGVycy5wcm90b3R5cGVbU3ltYm9sLml0ZXJhdG9yXSA9IEhlYWRlcnMucHJvdG90eXBlLmVudHJpZXNcbn1cblxuZnVuY3Rpb24gY29uc3VtZWQoYm9keSkge1xuICBpZiAoYm9keS5fbm9Cb2R5KSByZXR1cm5cbiAgaWYgKGJvZHkuYm9keVVzZWQpIHtcbiAgICByZXR1cm4gUHJvbWlzZS5yZWplY3QobmV3IFR5cGVFcnJvcignQWxyZWFkeSByZWFkJykpXG4gIH1cbiAgYm9keS5ib2R5VXNlZCA9IHRydWVcbn1cblxuZnVuY3Rpb24gZmlsZVJlYWRlclJlYWR5KHJlYWRlcikge1xuICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24ocmVzb2x2ZSwgcmVqZWN0KSB7XG4gICAgcmVhZGVyLm9ubG9hZCA9IGZ1bmN0aW9uKCkge1xuICAgICAgcmVzb2x2ZShyZWFkZXIucmVzdWx0KVxuICAgIH1cbiAgICByZWFkZXIub25lcnJvciA9IGZ1bmN0aW9uKCkge1xuICAgICAgcmVqZWN0KHJlYWRlci5lcnJvcilcbiAgICB9XG4gIH0pXG59XG5cbmZ1bmN0aW9uIHJlYWRCbG9iQXNBcnJheUJ1ZmZlcihibG9iKSB7XG4gIHZhciByZWFkZXIgPSBuZXcgRmlsZVJlYWRlcigpXG4gIHZhciBwcm9taXNlID0gZmlsZVJlYWRlclJlYWR5KHJlYWRlcilcbiAgcmVhZGVyLnJlYWRBc0FycmF5QnVmZmVyKGJsb2IpXG4gIHJldHVybiBwcm9taXNlXG59XG5cbmZ1bmN0aW9uIHJlYWRCbG9iQXNUZXh0KGJsb2IpIHtcbiAgdmFyIHJlYWRlciA9IG5ldyBGaWxlUmVhZGVyKClcbiAgdmFyIHByb21pc2UgPSBmaWxlUmVhZGVyUmVhZHkocmVhZGVyKVxuICB2YXIgbWF0Y2ggPSAvY2hhcnNldD0oW0EtWmEtejAtOV8tXSspLy5leGVjKGJsb2IudHlwZSlcbiAgdmFyIGVuY29kaW5nID0gbWF0Y2ggPyBtYXRjaFsxXSA6ICd1dGYtOCdcbiAgcmVhZGVyLnJlYWRBc1RleHQoYmxvYiwgZW5jb2RpbmcpXG4gIHJldHVybiBwcm9taXNlXG59XG5cbmZ1bmN0aW9uIHJlYWRBcnJheUJ1ZmZlckFzVGV4dChidWYpIHtcbiAgdmFyIHZpZXcgPSBuZXcgVWludDhBcnJheShidWYpXG4gIHZhciBjaGFycyA9IG5ldyBBcnJheSh2aWV3Lmxlbmd0aClcblxuICBmb3IgKHZhciBpID0gMDsgaSA8IHZpZXcubGVuZ3RoOyBpKyspIHtcbiAgICBjaGFyc1tpXSA9IFN0cmluZy5mcm9tQ2hhckNvZGUodmlld1tpXSlcbiAgfVxuICByZXR1cm4gY2hhcnMuam9pbignJylcbn1cblxuZnVuY3Rpb24gYnVmZmVyQ2xvbmUoYnVmKSB7XG4gIGlmIChidWYuc2xpY2UpIHtcbiAgICByZXR1cm4gYnVmLnNsaWNlKDApXG4gIH0gZWxzZSB7XG4gICAgdmFyIHZpZXcgPSBuZXcgVWludDhBcnJheShidWYuYnl0ZUxlbmd0aClcbiAgICB2aWV3LnNldChuZXcgVWludDhBcnJheShidWYpKVxuICAgIHJldHVybiB2aWV3LmJ1ZmZlclxuICB9XG59XG5cbmZ1bmN0aW9uIEJvZHkoKSB7XG4gIHRoaXMuYm9keVVzZWQgPSBmYWxzZVxuXG4gIHRoaXMuX2luaXRCb2R5ID0gZnVuY3Rpb24oYm9keSkge1xuICAgIC8qXG4gICAgICBmZXRjaC1tb2NrIHdyYXBzIHRoZSBSZXNwb25zZSBvYmplY3QgaW4gYW4gRVM2IFByb3h5IHRvXG4gICAgICBwcm92aWRlIHVzZWZ1bCB0ZXN0IGhhcm5lc3MgZmVhdHVyZXMgc3VjaCBhcyBmbHVzaC4gSG93ZXZlciwgb25cbiAgICAgIEVTNSBicm93c2VycyB3aXRob3V0IGZldGNoIG9yIFByb3h5IHN1cHBvcnQgcG9sbHlmaWxscyBtdXN0IGJlIHVzZWQ7XG4gICAgICB0aGUgcHJveHktcG9sbHlmaWxsIGlzIHVuYWJsZSB0byBwcm94eSBhbiBhdHRyaWJ1dGUgdW5sZXNzIGl0IGV4aXN0c1xuICAgICAgb24gdGhlIG9iamVjdCBiZWZvcmUgdGhlIFByb3h5IGlzIGNyZWF0ZWQuIFRoaXMgY2hhbmdlIGVuc3VyZXNcbiAgICAgIFJlc3BvbnNlLmJvZHlVc2VkIGV4aXN0cyBvbiB0aGUgaW5zdGFuY2UsIHdoaWxlIG1haW50YWluaW5nIHRoZVxuICAgICAgc2VtYW50aWMgb2Ygc2V0dGluZyBSZXF1ZXN0LmJvZHlVc2VkIGluIHRoZSBjb25zdHJ1Y3RvciBiZWZvcmVcbiAgICAgIF9pbml0Qm9keSBpcyBjYWxsZWQuXG4gICAgKi9cbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tc2VsZi1hc3NpZ25cbiAgICB0aGlzLmJvZHlVc2VkID0gdGhpcy5ib2R5VXNlZFxuICAgIHRoaXMuX2JvZHlJbml0ID0gYm9keVxuICAgIGlmICghYm9keSkge1xuICAgICAgdGhpcy5fbm9Cb2R5ID0gdHJ1ZTtcbiAgICAgIHRoaXMuX2JvZHlUZXh0ID0gJydcbiAgICB9IGVsc2UgaWYgKHR5cGVvZiBib2R5ID09PSAnc3RyaW5nJykge1xuICAgICAgdGhpcy5fYm9keVRleHQgPSBib2R5XG4gICAgfSBlbHNlIGlmIChzdXBwb3J0LmJsb2IgJiYgQmxvYi5wcm90b3R5cGUuaXNQcm90b3R5cGVPZihib2R5KSkge1xuICAgICAgdGhpcy5fYm9keUJsb2IgPSBib2R5XG4gICAgfSBlbHNlIGlmIChzdXBwb3J0LmZvcm1EYXRhICYmIEZvcm1EYXRhLnByb3RvdHlwZS5pc1Byb3RvdHlwZU9mKGJvZHkpKSB7XG4gICAgICB0aGlzLl9ib2R5Rm9ybURhdGEgPSBib2R5XG4gICAgfSBlbHNlIGlmIChzdXBwb3J0LnNlYXJjaFBhcmFtcyAmJiBVUkxTZWFyY2hQYXJhbXMucHJvdG90eXBlLmlzUHJvdG90eXBlT2YoYm9keSkpIHtcbiAgICAgIHRoaXMuX2JvZHlUZXh0ID0gYm9keS50b1N0cmluZygpXG4gICAgfSBlbHNlIGlmIChzdXBwb3J0LmFycmF5QnVmZmVyICYmIHN1cHBvcnQuYmxvYiAmJiBpc0RhdGFWaWV3KGJvZHkpKSB7XG4gICAgICB0aGlzLl9ib2R5QXJyYXlCdWZmZXIgPSBidWZmZXJDbG9uZShib2R5LmJ1ZmZlcilcbiAgICAgIC8vIElFIDEwLTExIGNhbid0IGhhbmRsZSBhIERhdGFWaWV3IGJvZHkuXG4gICAgICB0aGlzLl9ib2R5SW5pdCA9IG5ldyBCbG9iKFt0aGlzLl9ib2R5QXJyYXlCdWZmZXJdKVxuICAgIH0gZWxzZSBpZiAoc3VwcG9ydC5hcnJheUJ1ZmZlciAmJiAoQXJyYXlCdWZmZXIucHJvdG90eXBlLmlzUHJvdG90eXBlT2YoYm9keSkgfHwgaXNBcnJheUJ1ZmZlclZpZXcoYm9keSkpKSB7XG4gICAgICB0aGlzLl9ib2R5QXJyYXlCdWZmZXIgPSBidWZmZXJDbG9uZShib2R5KVxuICAgIH0gZWxzZSB7XG4gICAgICB0aGlzLl9ib2R5VGV4dCA9IGJvZHkgPSBPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwoYm9keSlcbiAgICB9XG5cbiAgICBpZiAoIXRoaXMuaGVhZGVycy5nZXQoJ2NvbnRlbnQtdHlwZScpKSB7XG4gICAgICBpZiAodHlwZW9mIGJvZHkgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIHRoaXMuaGVhZGVycy5zZXQoJ2NvbnRlbnQtdHlwZScsICd0ZXh0L3BsYWluO2NoYXJzZXQ9VVRGLTgnKVxuICAgICAgfSBlbHNlIGlmICh0aGlzLl9ib2R5QmxvYiAmJiB0aGlzLl9ib2R5QmxvYi50eXBlKSB7XG4gICAgICAgIHRoaXMuaGVhZGVycy5zZXQoJ2NvbnRlbnQtdHlwZScsIHRoaXMuX2JvZHlCbG9iLnR5cGUpXG4gICAgICB9IGVsc2UgaWYgKHN1cHBvcnQuc2VhcmNoUGFyYW1zICYmIFVSTFNlYXJjaFBhcmFtcy5wcm90b3R5cGUuaXNQcm90b3R5cGVPZihib2R5KSkge1xuICAgICAgICB0aGlzLmhlYWRlcnMuc2V0KCdjb250ZW50LXR5cGUnLCAnYXBwbGljYXRpb24veC13d3ctZm9ybS11cmxlbmNvZGVkO2NoYXJzZXQ9VVRGLTgnKVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGlmIChzdXBwb3J0LmJsb2IpIHtcbiAgICB0aGlzLmJsb2IgPSBmdW5jdGlvbigpIHtcbiAgICAgIHZhciByZWplY3RlZCA9IGNvbnN1bWVkKHRoaXMpXG4gICAgICBpZiAocmVqZWN0ZWQpIHtcbiAgICAgICAgcmV0dXJuIHJlamVjdGVkXG4gICAgICB9XG5cbiAgICAgIGlmICh0aGlzLl9ib2R5QmxvYikge1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHRoaXMuX2JvZHlCbG9iKVxuICAgICAgfSBlbHNlIGlmICh0aGlzLl9ib2R5QXJyYXlCdWZmZXIpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShuZXcgQmxvYihbdGhpcy5fYm9keUFycmF5QnVmZmVyXSkpXG4gICAgICB9IGVsc2UgaWYgKHRoaXMuX2JvZHlGb3JtRGF0YSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2NvdWxkIG5vdCByZWFkIEZvcm1EYXRhIGJvZHkgYXMgYmxvYicpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKG5ldyBCbG9iKFt0aGlzLl9ib2R5VGV4dF0pKVxuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIHRoaXMuYXJyYXlCdWZmZXIgPSBmdW5jdGlvbigpIHtcbiAgICBpZiAodGhpcy5fYm9keUFycmF5QnVmZmVyKSB7XG4gICAgICB2YXIgaXNDb25zdW1lZCA9IGNvbnN1bWVkKHRoaXMpXG4gICAgICBpZiAoaXNDb25zdW1lZCkge1xuICAgICAgICByZXR1cm4gaXNDb25zdW1lZFxuICAgICAgfSBlbHNlIGlmIChBcnJheUJ1ZmZlci5pc1ZpZXcodGhpcy5fYm9keUFycmF5QnVmZmVyKSkge1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKFxuICAgICAgICAgIHRoaXMuX2JvZHlBcnJheUJ1ZmZlci5idWZmZXIuc2xpY2UoXG4gICAgICAgICAgICB0aGlzLl9ib2R5QXJyYXlCdWZmZXIuYnl0ZU9mZnNldCxcbiAgICAgICAgICAgIHRoaXMuX2JvZHlBcnJheUJ1ZmZlci5ieXRlT2Zmc2V0ICsgdGhpcy5fYm9keUFycmF5QnVmZmVyLmJ5dGVMZW5ndGhcbiAgICAgICAgICApXG4gICAgICAgIClcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUodGhpcy5fYm9keUFycmF5QnVmZmVyKVxuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoc3VwcG9ydC5ibG9iKSB7XG4gICAgICByZXR1cm4gdGhpcy5ibG9iKCkudGhlbihyZWFkQmxvYkFzQXJyYXlCdWZmZXIpXG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignY291bGQgbm90IHJlYWQgYXMgQXJyYXlCdWZmZXInKVxuICAgIH1cbiAgfVxuXG4gIHRoaXMudGV4dCA9IGZ1bmN0aW9uKCkge1xuICAgIHZhciByZWplY3RlZCA9IGNvbnN1bWVkKHRoaXMpXG4gICAgaWYgKHJlamVjdGVkKSB7XG4gICAgICByZXR1cm4gcmVqZWN0ZWRcbiAgICB9XG5cbiAgICBpZiAodGhpcy5fYm9keUJsb2IpIHtcbiAgICAgIHJldHVybiByZWFkQmxvYkFzVGV4dCh0aGlzLl9ib2R5QmxvYilcbiAgICB9IGVsc2UgaWYgKHRoaXMuX2JvZHlBcnJheUJ1ZmZlcikge1xuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShyZWFkQXJyYXlCdWZmZXJBc1RleHQodGhpcy5fYm9keUFycmF5QnVmZmVyKSlcbiAgICB9IGVsc2UgaWYgKHRoaXMuX2JvZHlGb3JtRGF0YSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKCdjb3VsZCBub3QgcmVhZCBGb3JtRGF0YSBib2R5IGFzIHRleHQnKVxuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHRoaXMuX2JvZHlUZXh0KVxuICAgIH1cbiAgfVxuXG4gIGlmIChzdXBwb3J0LmZvcm1EYXRhKSB7XG4gICAgdGhpcy5mb3JtRGF0YSA9IGZ1bmN0aW9uKCkge1xuICAgICAgcmV0dXJuIHRoaXMudGV4dCgpLnRoZW4oZGVjb2RlKVxuICAgIH1cbiAgfVxuXG4gIHRoaXMuanNvbiA9IGZ1bmN0aW9uKCkge1xuICAgIHJldHVybiB0aGlzLnRleHQoKS50aGVuKEpTT04ucGFyc2UpXG4gIH1cblxuICByZXR1cm4gdGhpc1xufVxuXG4vLyBIVFRQIG1ldGhvZHMgd2hvc2UgY2FwaXRhbGl6YXRpb24gc2hvdWxkIGJlIG5vcm1hbGl6ZWRcbnZhciBtZXRob2RzID0gWydDT05ORUNUJywgJ0RFTEVURScsICdHRVQnLCAnSEVBRCcsICdPUFRJT05TJywgJ1BBVENIJywgJ1BPU1QnLCAnUFVUJywgJ1RSQUNFJ11cblxuZnVuY3Rpb24gbm9ybWFsaXplTWV0aG9kKG1ldGhvZCkge1xuICB2YXIgdXBjYXNlZCA9IG1ldGhvZC50b1VwcGVyQ2FzZSgpXG4gIHJldHVybiBtZXRob2RzLmluZGV4T2YodXBjYXNlZCkgPiAtMSA/IHVwY2FzZWQgOiBtZXRob2Rcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIFJlcXVlc3QoaW5wdXQsIG9wdGlvbnMpIHtcbiAgaWYgKCEodGhpcyBpbnN0YW5jZW9mIFJlcXVlc3QpKSB7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcignUGxlYXNlIHVzZSB0aGUgXCJuZXdcIiBvcGVyYXRvciwgdGhpcyBET00gb2JqZWN0IGNvbnN0cnVjdG9yIGNhbm5vdCBiZSBjYWxsZWQgYXMgYSBmdW5jdGlvbi4nKVxuICB9XG5cbiAgb3B0aW9ucyA9IG9wdGlvbnMgfHwge31cbiAgdmFyIGJvZHkgPSBvcHRpb25zLmJvZHlcblxuICBpZiAoaW5wdXQgaW5zdGFuY2VvZiBSZXF1ZXN0KSB7XG4gICAgaWYgKGlucHV0LmJvZHlVc2VkKSB7XG4gICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdBbHJlYWR5IHJlYWQnKVxuICAgIH1cbiAgICB0aGlzLnVybCA9IGlucHV0LnVybFxuICAgIHRoaXMuY3JlZGVudGlhbHMgPSBpbnB1dC5jcmVkZW50aWFsc1xuICAgIGlmICghb3B0aW9ucy5oZWFkZXJzKSB7XG4gICAgICB0aGlzLmhlYWRlcnMgPSBuZXcgSGVhZGVycyhpbnB1dC5oZWFkZXJzKVxuICAgIH1cbiAgICB0aGlzLm1ldGhvZCA9IGlucHV0Lm1ldGhvZFxuICAgIHRoaXMubW9kZSA9IGlucHV0Lm1vZGVcbiAgICB0aGlzLnNpZ25hbCA9IGlucHV0LnNpZ25hbFxuICAgIGlmICghYm9keSAmJiBpbnB1dC5fYm9keUluaXQgIT0gbnVsbCkge1xuICAgICAgYm9keSA9IGlucHV0Ll9ib2R5SW5pdFxuICAgICAgaW5wdXQuYm9keVVzZWQgPSB0cnVlXG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHRoaXMudXJsID0gU3RyaW5nKGlucHV0KVxuICB9XG5cbiAgdGhpcy5jcmVkZW50aWFscyA9IG9wdGlvbnMuY3JlZGVudGlhbHMgfHwgdGhpcy5jcmVkZW50aWFscyB8fCAnc2FtZS1vcmlnaW4nXG4gIGlmIChvcHRpb25zLmhlYWRlcnMgfHwgIXRoaXMuaGVhZGVycykge1xuICAgIHRoaXMuaGVhZGVycyA9IG5ldyBIZWFkZXJzKG9wdGlvbnMuaGVhZGVycylcbiAgfVxuICB0aGlzLm1ldGhvZCA9IG5vcm1hbGl6ZU1ldGhvZChvcHRpb25zLm1ldGhvZCB8fCB0aGlzLm1ldGhvZCB8fCAnR0VUJylcbiAgdGhpcy5tb2RlID0gb3B0aW9ucy5tb2RlIHx8IHRoaXMubW9kZSB8fCBudWxsXG4gIHRoaXMuc2lnbmFsID0gb3B0aW9ucy5zaWduYWwgfHwgdGhpcy5zaWduYWwgfHwgKGZ1bmN0aW9uICgpIHtcbiAgICBpZiAoJ0Fib3J0Q29udHJvbGxlcicgaW4gZykge1xuICAgICAgdmFyIGN0cmwgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgICByZXR1cm4gY3RybC5zaWduYWw7XG4gICAgfVxuICB9KCkpO1xuICB0aGlzLnJlZmVycmVyID0gbnVsbFxuXG4gIGlmICgodGhpcy5tZXRob2QgPT09ICdHRVQnIHx8IHRoaXMubWV0aG9kID09PSAnSEVBRCcpICYmIGJvZHkpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdCb2R5IG5vdCBhbGxvd2VkIGZvciBHRVQgb3IgSEVBRCByZXF1ZXN0cycpXG4gIH1cbiAgdGhpcy5faW5pdEJvZHkoYm9keSlcblxuICBpZiAodGhpcy5tZXRob2QgPT09ICdHRVQnIHx8IHRoaXMubWV0aG9kID09PSAnSEVBRCcpIHtcbiAgICBpZiAob3B0aW9ucy5jYWNoZSA9PT0gJ25vLXN0b3JlJyB8fCBvcHRpb25zLmNhY2hlID09PSAnbm8tY2FjaGUnKSB7XG4gICAgICAvLyBTZWFyY2ggZm9yIGEgJ18nIHBhcmFtZXRlciBpbiB0aGUgcXVlcnkgc3RyaW5nXG4gICAgICB2YXIgcmVQYXJhbVNlYXJjaCA9IC8oWz8mXSlfPVteJl0qL1xuICAgICAgaWYgKHJlUGFyYW1TZWFyY2gudGVzdCh0aGlzLnVybCkpIHtcbiAgICAgICAgLy8gSWYgaXQgYWxyZWFkeSBleGlzdHMgdGhlbiBzZXQgdGhlIHZhbHVlIHdpdGggdGhlIGN1cnJlbnQgdGltZVxuICAgICAgICB0aGlzLnVybCA9IHRoaXMudXJsLnJlcGxhY2UocmVQYXJhbVNlYXJjaCwgJyQxXz0nICsgbmV3IERhdGUoKS5nZXRUaW1lKCkpXG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyBPdGhlcndpc2UgYWRkIGEgbmV3ICdfJyBwYXJhbWV0ZXIgdG8gdGhlIGVuZCB3aXRoIHRoZSBjdXJyZW50IHRpbWVcbiAgICAgICAgdmFyIHJlUXVlcnlTdHJpbmcgPSAvXFw/L1xuICAgICAgICB0aGlzLnVybCArPSAocmVRdWVyeVN0cmluZy50ZXN0KHRoaXMudXJsKSA/ICcmJyA6ICc/JykgKyAnXz0nICsgbmV3IERhdGUoKS5nZXRUaW1lKClcbiAgICAgIH1cbiAgICB9XG4gIH1cbn1cblxuUmVxdWVzdC5wcm90b3R5cGUuY2xvbmUgPSBmdW5jdGlvbigpIHtcbiAgcmV0dXJuIG5ldyBSZXF1ZXN0KHRoaXMsIHtib2R5OiB0aGlzLl9ib2R5SW5pdH0pXG59XG5cbmZ1bmN0aW9uIGRlY29kZShib2R5KSB7XG4gIHZhciBmb3JtID0gbmV3IEZvcm1EYXRhKClcbiAgYm9keVxuICAgIC50cmltKClcbiAgICAuc3BsaXQoJyYnKVxuICAgIC5mb3JFYWNoKGZ1bmN0aW9uKGJ5dGVzKSB7XG4gICAgICBpZiAoYnl0ZXMpIHtcbiAgICAgICAgdmFyIHNwbGl0ID0gYnl0ZXMuc3BsaXQoJz0nKVxuICAgICAgICB2YXIgbmFtZSA9IHNwbGl0LnNoaWZ0KCkucmVwbGFjZSgvXFwrL2csICcgJylcbiAgICAgICAgdmFyIHZhbHVlID0gc3BsaXQuam9pbignPScpLnJlcGxhY2UoL1xcKy9nLCAnICcpXG4gICAgICAgIGZvcm0uYXBwZW5kKGRlY29kZVVSSUNvbXBvbmVudChuYW1lKSwgZGVjb2RlVVJJQ29tcG9uZW50KHZhbHVlKSlcbiAgICAgIH1cbiAgICB9KVxuICByZXR1cm4gZm9ybVxufVxuXG5mdW5jdGlvbiBwYXJzZUhlYWRlcnMocmF3SGVhZGVycykge1xuICB2YXIgaGVhZGVycyA9IG5ldyBIZWFkZXJzKClcbiAgLy8gUmVwbGFjZSBpbnN0YW5jZXMgb2YgXFxyXFxuIGFuZCBcXG4gZm9sbG93ZWQgYnkgYXQgbGVhc3Qgb25lIHNwYWNlIG9yIGhvcml6b250YWwgdGFiIHdpdGggYSBzcGFjZVxuICAvLyBodHRwczovL3Rvb2xzLmlldGYub3JnL2h0bWwvcmZjNzIzMCNzZWN0aW9uLTMuMlxuICB2YXIgcHJlUHJvY2Vzc2VkSGVhZGVycyA9IHJhd0hlYWRlcnMucmVwbGFjZSgvXFxyP1xcbltcXHQgXSsvZywgJyAnKVxuICAvLyBBdm9pZGluZyBzcGxpdCB2aWEgcmVnZXggdG8gd29yayBhcm91bmQgYSBjb21tb24gSUUxMSBidWcgd2l0aCB0aGUgY29yZS1qcyAzLjYuMCByZWdleCBwb2x5ZmlsbFxuICAvLyBodHRwczovL2dpdGh1Yi5jb20vZ2l0aHViL2ZldGNoL2lzc3Vlcy83NDhcbiAgLy8gaHR0cHM6Ly9naXRodWIuY29tL3psb2lyb2NrL2NvcmUtanMvaXNzdWVzLzc1MVxuICBwcmVQcm9jZXNzZWRIZWFkZXJzXG4gICAgLnNwbGl0KCdcXHInKVxuICAgIC5tYXAoZnVuY3Rpb24oaGVhZGVyKSB7XG4gICAgICByZXR1cm4gaGVhZGVyLmluZGV4T2YoJ1xcbicpID09PSAwID8gaGVhZGVyLnN1YnN0cigxLCBoZWFkZXIubGVuZ3RoKSA6IGhlYWRlclxuICAgIH0pXG4gICAgLmZvckVhY2goZnVuY3Rpb24obGluZSkge1xuICAgICAgdmFyIHBhcnRzID0gbGluZS5zcGxpdCgnOicpXG4gICAgICB2YXIga2V5ID0gcGFydHMuc2hpZnQoKS50cmltKClcbiAgICAgIGlmIChrZXkpIHtcbiAgICAgICAgdmFyIHZhbHVlID0gcGFydHMuam9pbignOicpLnRyaW0oKVxuICAgICAgICB0cnkge1xuICAgICAgICAgIGhlYWRlcnMuYXBwZW5kKGtleSwgdmFsdWUpXG4gICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgY29uc29sZS53YXJuKCdSZXNwb25zZSAnICsgZXJyb3IubWVzc2FnZSlcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0pXG4gIHJldHVybiBoZWFkZXJzXG59XG5cbkJvZHkuY2FsbChSZXF1ZXN0LnByb3RvdHlwZSlcblxuZXhwb3J0IGZ1bmN0aW9uIFJlc3BvbnNlKGJvZHlJbml0LCBvcHRpb25zKSB7XG4gIGlmICghKHRoaXMgaW5zdGFuY2VvZiBSZXNwb25zZSkpIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdQbGVhc2UgdXNlIHRoZSBcIm5ld1wiIG9wZXJhdG9yLCB0aGlzIERPTSBvYmplY3QgY29uc3RydWN0b3IgY2Fubm90IGJlIGNhbGxlZCBhcyBhIGZ1bmN0aW9uLicpXG4gIH1cbiAgaWYgKCFvcHRpb25zKSB7XG4gICAgb3B0aW9ucyA9IHt9XG4gIH1cblxuICB0aGlzLnR5cGUgPSAnZGVmYXVsdCdcbiAgdGhpcy5zdGF0dXMgPSBvcHRpb25zLnN0YXR1cyA9PT0gdW5kZWZpbmVkID8gMjAwIDogb3B0aW9ucy5zdGF0dXNcbiAgaWYgKHRoaXMuc3RhdHVzIDwgMjAwIHx8IHRoaXMuc3RhdHVzID4gNTk5KSB7XG4gICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoXCJGYWlsZWQgdG8gY29uc3RydWN0ICdSZXNwb25zZSc6IFRoZSBzdGF0dXMgcHJvdmlkZWQgKDApIGlzIG91dHNpZGUgdGhlIHJhbmdlIFsyMDAsIDU5OV0uXCIpXG4gIH1cbiAgdGhpcy5vayA9IHRoaXMuc3RhdHVzID49IDIwMCAmJiB0aGlzLnN0YXR1cyA8IDMwMFxuICB0aGlzLnN0YXR1c1RleHQgPSBvcHRpb25zLnN0YXR1c1RleHQgPT09IHVuZGVmaW5lZCA/ICcnIDogJycgKyBvcHRpb25zLnN0YXR1c1RleHRcbiAgdGhpcy5oZWFkZXJzID0gbmV3IEhlYWRlcnMob3B0aW9ucy5oZWFkZXJzKVxuICB0aGlzLnVybCA9IG9wdGlvbnMudXJsIHx8ICcnXG4gIHRoaXMuX2luaXRCb2R5KGJvZHlJbml0KVxufVxuXG5Cb2R5LmNhbGwoUmVzcG9uc2UucHJvdG90eXBlKVxuXG5SZXNwb25zZS5wcm90b3R5cGUuY2xvbmUgPSBmdW5jdGlvbigpIHtcbiAgcmV0dXJuIG5ldyBSZXNwb25zZSh0aGlzLl9ib2R5SW5pdCwge1xuICAgIHN0YXR1czogdGhpcy5zdGF0dXMsXG4gICAgc3RhdHVzVGV4dDogdGhpcy5zdGF0dXNUZXh0LFxuICAgIGhlYWRlcnM6IG5ldyBIZWFkZXJzKHRoaXMuaGVhZGVycyksXG4gICAgdXJsOiB0aGlzLnVybFxuICB9KVxufVxuXG5SZXNwb25zZS5lcnJvciA9IGZ1bmN0aW9uKCkge1xuICB2YXIgcmVzcG9uc2UgPSBuZXcgUmVzcG9uc2UobnVsbCwge3N0YXR1czogMjAwLCBzdGF0dXNUZXh0OiAnJ30pXG4gIHJlc3BvbnNlLm9rID0gZmFsc2VcbiAgcmVzcG9uc2Uuc3RhdHVzID0gMFxuICByZXNwb25zZS50eXBlID0gJ2Vycm9yJ1xuICByZXR1cm4gcmVzcG9uc2Vcbn1cblxudmFyIHJlZGlyZWN0U3RhdHVzZXMgPSBbMzAxLCAzMDIsIDMwMywgMzA3LCAzMDhdXG5cblJlc3BvbnNlLnJlZGlyZWN0ID0gZnVuY3Rpb24odXJsLCBzdGF0dXMpIHtcbiAgaWYgKHJlZGlyZWN0U3RhdHVzZXMuaW5kZXhPZihzdGF0dXMpID09PSAtMSkge1xuICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdJbnZhbGlkIHN0YXR1cyBjb2RlJylcbiAgfVxuXG4gIHJldHVybiBuZXcgUmVzcG9uc2UobnVsbCwge3N0YXR1czogc3RhdHVzLCBoZWFkZXJzOiB7bG9jYXRpb246IHVybH19KVxufVxuXG5leHBvcnQgdmFyIERPTUV4Y2VwdGlvbiA9IGcuRE9NRXhjZXB0aW9uXG50cnkge1xuICBuZXcgRE9NRXhjZXB0aW9uKClcbn0gY2F0Y2ggKGVycikge1xuICBET01FeGNlcHRpb24gPSBmdW5jdGlvbihtZXNzYWdlLCBuYW1lKSB7XG4gICAgdGhpcy5tZXNzYWdlID0gbWVzc2FnZVxuICAgIHRoaXMubmFtZSA9IG5hbWVcbiAgICB2YXIgZXJyb3IgPSBFcnJvcihtZXNzYWdlKVxuICAgIHRoaXMuc3RhY2sgPSBlcnJvci5zdGFja1xuICB9XG4gIERPTUV4Y2VwdGlvbi5wcm90b3R5cGUgPSBPYmplY3QuY3JlYXRlKEVycm9yLnByb3RvdHlwZSlcbiAgRE9NRXhjZXB0aW9uLnByb3RvdHlwZS5jb25zdHJ1Y3RvciA9IERPTUV4Y2VwdGlvblxufVxuXG5leHBvcnQgZnVuY3Rpb24gZmV0Y2goaW5wdXQsIGluaXQpIHtcbiAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uKHJlc29sdmUsIHJlamVjdCkge1xuICAgIHZhciByZXF1ZXN0ID0gbmV3IFJlcXVlc3QoaW5wdXQsIGluaXQpXG5cbiAgICBpZiAocmVxdWVzdC5zaWduYWwgJiYgcmVxdWVzdC5zaWduYWwuYWJvcnRlZCkge1xuICAgICAgcmV0dXJuIHJlamVjdChuZXcgRE9NRXhjZXB0aW9uKCdBYm9ydGVkJywgJ0Fib3J0RXJyb3InKSlcbiAgICB9XG5cbiAgICB2YXIgeGhyID0gbmV3IFhNTEh0dHBSZXF1ZXN0KClcblxuICAgIGZ1bmN0aW9uIGFib3J0WGhyKCkge1xuICAgICAgeGhyLmFib3J0KClcbiAgICB9XG5cbiAgICB4aHIub25sb2FkID0gZnVuY3Rpb24oKSB7XG4gICAgICB2YXIgb3B0aW9ucyA9IHtcbiAgICAgICAgc3RhdHVzVGV4dDogeGhyLnN0YXR1c1RleHQsXG4gICAgICAgIGhlYWRlcnM6IHBhcnNlSGVhZGVycyh4aHIuZ2V0QWxsUmVzcG9uc2VIZWFkZXJzKCkgfHwgJycpXG4gICAgICB9XG4gICAgICAvLyBUaGlzIGNoZWNrIGlmIHNwZWNpZmljYWxseSBmb3Igd2hlbiBhIHVzZXIgZmV0Y2hlcyBhIGZpbGUgbG9jYWxseSBmcm9tIHRoZSBmaWxlIHN5c3RlbVxuICAgICAgLy8gT25seSBpZiB0aGUgc3RhdHVzIGlzIG91dCBvZiBhIG5vcm1hbCByYW5nZVxuICAgICAgaWYgKHJlcXVlc3QudXJsLmluZGV4T2YoJ2ZpbGU6Ly8nKSA9PT0gMCAmJiAoeGhyLnN0YXR1cyA8IDIwMCB8fCB4aHIuc3RhdHVzID4gNTk5KSkge1xuICAgICAgICBvcHRpb25zLnN0YXR1cyA9IDIwMDtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG9wdGlvbnMuc3RhdHVzID0geGhyLnN0YXR1cztcbiAgICAgIH1cbiAgICAgIG9wdGlvbnMudXJsID0gJ3Jlc3BvbnNlVVJMJyBpbiB4aHIgPyB4aHIucmVzcG9uc2VVUkwgOiBvcHRpb25zLmhlYWRlcnMuZ2V0KCdYLVJlcXVlc3QtVVJMJylcbiAgICAgIHZhciBib2R5ID0gJ3Jlc3BvbnNlJyBpbiB4aHIgPyB4aHIucmVzcG9uc2UgOiB4aHIucmVzcG9uc2VUZXh0XG4gICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgICByZXNvbHZlKG5ldyBSZXNwb25zZShib2R5LCBvcHRpb25zKSlcbiAgICAgIH0sIDApXG4gICAgfVxuXG4gICAgeGhyLm9uZXJyb3IgPSBmdW5jdGlvbigpIHtcbiAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgIHJlamVjdChuZXcgVHlwZUVycm9yKCdOZXR3b3JrIHJlcXVlc3QgZmFpbGVkJykpXG4gICAgICB9LCAwKVxuICAgIH1cblxuICAgIHhoci5vbnRpbWVvdXQgPSBmdW5jdGlvbigpIHtcbiAgICAgIHNldFRpbWVvdXQoZnVuY3Rpb24oKSB7XG4gICAgICAgIHJlamVjdChuZXcgVHlwZUVycm9yKCdOZXR3b3JrIHJlcXVlc3QgdGltZWQgb3V0JykpXG4gICAgICB9LCAwKVxuICAgIH1cblxuICAgIHhoci5vbmFib3J0ID0gZnVuY3Rpb24oKSB7XG4gICAgICBzZXRUaW1lb3V0KGZ1bmN0aW9uKCkge1xuICAgICAgICByZWplY3QobmV3IERPTUV4Y2VwdGlvbignQWJvcnRlZCcsICdBYm9ydEVycm9yJykpXG4gICAgICB9LCAwKVxuICAgIH1cblxuICAgIGZ1bmN0aW9uIGZpeFVybCh1cmwpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIHJldHVybiB1cmwgPT09ICcnICYmIGcubG9jYXRpb24uaHJlZiA/IGcubG9jYXRpb24uaHJlZiA6IHVybFxuICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICByZXR1cm4gdXJsXG4gICAgICB9XG4gICAgfVxuXG4gICAgeGhyLm9wZW4ocmVxdWVzdC5tZXRob2QsIGZpeFVybChyZXF1ZXN0LnVybCksIHRydWUpXG5cbiAgICBpZiAocmVxdWVzdC5jcmVkZW50aWFscyA9PT0gJ2luY2x1ZGUnKSB7XG4gICAgICB4aHIud2l0aENyZWRlbnRpYWxzID0gdHJ1ZVxuICAgIH0gZWxzZSBpZiAocmVxdWVzdC5jcmVkZW50aWFscyA9PT0gJ29taXQnKSB7XG4gICAgICB4aHIud2l0aENyZWRlbnRpYWxzID0gZmFsc2VcbiAgICB9XG5cbiAgICBpZiAoJ3Jlc3BvbnNlVHlwZScgaW4geGhyKSB7XG4gICAgICBpZiAoc3VwcG9ydC5ibG9iKSB7XG4gICAgICAgIHhoci5yZXNwb25zZVR5cGUgPSAnYmxvYidcbiAgICAgIH0gZWxzZSBpZiAoXG4gICAgICAgIHN1cHBvcnQuYXJyYXlCdWZmZXJcbiAgICAgICkge1xuICAgICAgICB4aHIucmVzcG9uc2VUeXBlID0gJ2FycmF5YnVmZmVyJ1xuICAgICAgfVxuICAgIH1cblxuICAgIGlmIChpbml0ICYmIHR5cGVvZiBpbml0LmhlYWRlcnMgPT09ICdvYmplY3QnICYmICEoaW5pdC5oZWFkZXJzIGluc3RhbmNlb2YgSGVhZGVycyB8fCAoZy5IZWFkZXJzICYmIGluaXQuaGVhZGVycyBpbnN0YW5jZW9mIGcuSGVhZGVycykpKSB7XG4gICAgICB2YXIgbmFtZXMgPSBbXTtcbiAgICAgIE9iamVjdC5nZXRPd25Qcm9wZXJ0eU5hbWVzKGluaXQuaGVhZGVycykuZm9yRWFjaChmdW5jdGlvbihuYW1lKSB7XG4gICAgICAgIG5hbWVzLnB1c2gobm9ybWFsaXplTmFtZShuYW1lKSlcbiAgICAgICAgeGhyLnNldFJlcXVlc3RIZWFkZXIobmFtZSwgbm9ybWFsaXplVmFsdWUoaW5pdC5oZWFkZXJzW25hbWVdKSlcbiAgICAgIH0pXG4gICAgICByZXF1ZXN0LmhlYWRlcnMuZm9yRWFjaChmdW5jdGlvbih2YWx1ZSwgbmFtZSkge1xuICAgICAgICBpZiAobmFtZXMuaW5kZXhPZihuYW1lKSA9PT0gLTEpIHtcbiAgICAgICAgICB4aHIuc2V0UmVxdWVzdEhlYWRlcihuYW1lLCB2YWx1ZSlcbiAgICAgICAgfVxuICAgICAgfSlcbiAgICB9IGVsc2Uge1xuICAgICAgcmVxdWVzdC5oZWFkZXJzLmZvckVhY2goZnVuY3Rpb24odmFsdWUsIG5hbWUpIHtcbiAgICAgICAgeGhyLnNldFJlcXVlc3RIZWFkZXIobmFtZSwgdmFsdWUpXG4gICAgICB9KVxuICAgIH1cblxuICAgIGlmIChyZXF1ZXN0LnNpZ25hbCkge1xuICAgICAgcmVxdWVzdC5zaWduYWwuYWRkRXZlbnRMaXN0ZW5lcignYWJvcnQnLCBhYm9ydFhocilcblxuICAgICAgeGhyLm9ucmVhZHlzdGF0ZWNoYW5nZSA9IGZ1bmN0aW9uKCkge1xuICAgICAgICAvLyBET05FIChzdWNjZXNzIG9yIGZhaWx1cmUpXG4gICAgICAgIGlmICh4aHIucmVhZHlTdGF0ZSA9PT0gNCkge1xuICAgICAgICAgIHJlcXVlc3Quc2lnbmFsLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2Fib3J0JywgYWJvcnRYaHIpXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICB4aHIuc2VuZCh0eXBlb2YgcmVxdWVzdC5fYm9keUluaXQgPT09ICd1bmRlZmluZWQnID8gbnVsbCA6IHJlcXVlc3QuX2JvZHlJbml0KVxuICB9KVxufVxuXG5mZXRjaC5wb2x5ZmlsbCA9IHRydWVcblxuaWYgKCFnLmZldGNoKSB7XG4gIGcuZmV0Y2ggPSBmZXRjaFxuICBnLkhlYWRlcnMgPSBIZWFkZXJzXG4gIGcuUmVxdWVzdCA9IFJlcXVlc3RcbiAgZy5SZXNwb25zZSA9IFJlc3BvbnNlXG59XG4iLCAiaW1wb3J0ICd3aGF0d2ctZmV0Y2gnO1xuXG5jb25zdCB2ZXJzaW9uID0gXCIwLjUuOVwiO1xuXG52YXIgX19kZWZQcm9wJDEgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19kZWZOb3JtYWxQcm9wJDEgPSAob2JqLCBrZXksIHZhbHVlKSA9PiBrZXkgaW4gb2JqID8gX19kZWZQcm9wJDEob2JqLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgY29uZmlndXJhYmxlOiB0cnVlLCB3cml0YWJsZTogdHJ1ZSwgdmFsdWUgfSkgOiBvYmpba2V5XSA9IHZhbHVlO1xudmFyIF9fcHVibGljRmllbGQkMSA9IChvYmosIGtleSwgdmFsdWUpID0+IHtcbiAgX19kZWZOb3JtYWxQcm9wJDEob2JqLCB0eXBlb2Yga2V5ICE9PSBcInN5bWJvbFwiID8ga2V5ICsgXCJcIiA6IGtleSwgdmFsdWUpO1xuICByZXR1cm4gdmFsdWU7XG59O1xuY2xhc3MgUmVzcG9uc2VFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgY29uc3RydWN0b3IoZXJyb3IsIHN0YXR1c19jb2RlKSB7XG4gICAgc3VwZXIoZXJyb3IpO1xuICAgIHRoaXMuZXJyb3IgPSBlcnJvcjtcbiAgICB0aGlzLnN0YXR1c19jb2RlID0gc3RhdHVzX2NvZGU7XG4gICAgdGhpcy5uYW1lID0gXCJSZXNwb25zZUVycm9yXCI7XG4gICAgaWYgKEVycm9yLmNhcHR1cmVTdGFja1RyYWNlKSB7XG4gICAgICBFcnJvci5jYXB0dXJlU3RhY2tUcmFjZSh0aGlzLCBSZXNwb25zZUVycm9yKTtcbiAgICB9XG4gIH1cbn1cbmNsYXNzIEFib3J0YWJsZUFzeW5jSXRlcmF0b3Ige1xuICBjb25zdHJ1Y3RvcihhYm9ydENvbnRyb2xsZXIsIGl0ciwgZG9uZUNhbGxiYWNrKSB7XG4gICAgX19wdWJsaWNGaWVsZCQxKHRoaXMsIFwiYWJvcnRDb250cm9sbGVyXCIpO1xuICAgIF9fcHVibGljRmllbGQkMSh0aGlzLCBcIml0clwiKTtcbiAgICBfX3B1YmxpY0ZpZWxkJDEodGhpcywgXCJkb25lQ2FsbGJhY2tcIik7XG4gICAgdGhpcy5hYm9ydENvbnRyb2xsZXIgPSBhYm9ydENvbnRyb2xsZXI7XG4gICAgdGhpcy5pdHIgPSBpdHI7XG4gICAgdGhpcy5kb25lQ2FsbGJhY2sgPSBkb25lQ2FsbGJhY2s7XG4gIH1cbiAgYWJvcnQoKSB7XG4gICAgdGhpcy5hYm9ydENvbnRyb2xsZXIuYWJvcnQoKTtcbiAgfVxuICBhc3luYyAqW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSgpIHtcbiAgICBmb3IgYXdhaXQgKGNvbnN0IG1lc3NhZ2Ugb2YgdGhpcy5pdHIpIHtcbiAgICAgIGlmIChcImVycm9yXCIgaW4gbWVzc2FnZSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IobWVzc2FnZS5lcnJvcik7XG4gICAgICB9XG4gICAgICB5aWVsZCBtZXNzYWdlO1xuICAgICAgaWYgKG1lc3NhZ2UuZG9uZSB8fCBtZXNzYWdlLnN0YXR1cyA9PT0gXCJzdWNjZXNzXCIpIHtcbiAgICAgICAgdGhpcy5kb25lQ2FsbGJhY2soKTtcbiAgICAgICAgcmV0dXJuO1xuICAgICAgfVxuICAgIH1cbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJEaWQgbm90IHJlY2VpdmUgZG9uZSBvciBzdWNjZXNzIHJlc3BvbnNlIGluIHN0cmVhbS5cIik7XG4gIH1cbn1cbmNvbnN0IGNoZWNrT2sgPSBhc3luYyAocmVzcG9uc2UpID0+IHtcbiAgaWYgKHJlc3BvbnNlLm9rKSB7XG4gICAgcmV0dXJuO1xuICB9XG4gIGxldCBtZXNzYWdlID0gYEVycm9yICR7cmVzcG9uc2Uuc3RhdHVzfTogJHtyZXNwb25zZS5zdGF0dXNUZXh0fWA7XG4gIGxldCBlcnJvckRhdGEgPSBudWxsO1xuICBpZiAocmVzcG9uc2UuaGVhZGVycy5nZXQoXCJjb250ZW50LXR5cGVcIik/LmluY2x1ZGVzKFwiYXBwbGljYXRpb24vanNvblwiKSkge1xuICAgIHRyeSB7XG4gICAgICBlcnJvckRhdGEgPSBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gICAgICBtZXNzYWdlID0gZXJyb3JEYXRhLmVycm9yIHx8IG1lc3NhZ2U7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUubG9nKFwiRmFpbGVkIHRvIHBhcnNlIGVycm9yIHJlc3BvbnNlIGFzIEpTT05cIik7XG4gICAgfVxuICB9IGVsc2Uge1xuICAgIHRyeSB7XG4gICAgICBjb25zb2xlLmxvZyhcIkdldHRpbmcgdGV4dCBmcm9tIHJlc3BvbnNlXCIpO1xuICAgICAgY29uc3QgdGV4dFJlc3BvbnNlID0gYXdhaXQgcmVzcG9uc2UudGV4dCgpO1xuICAgICAgbWVzc2FnZSA9IHRleHRSZXNwb25zZSB8fCBtZXNzYWdlO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmxvZyhcIkZhaWxlZCB0byBnZXQgdGV4dCBmcm9tIGVycm9yIHJlc3BvbnNlXCIpO1xuICAgIH1cbiAgfVxuICB0aHJvdyBuZXcgUmVzcG9uc2VFcnJvcihtZXNzYWdlLCByZXNwb25zZS5zdGF0dXMpO1xufTtcbmZ1bmN0aW9uIGdldFBsYXRmb3JtKCkge1xuICBpZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIiAmJiB3aW5kb3cubmF2aWdhdG9yKSB7XG4gICAgcmV0dXJuIGAke3dpbmRvdy5uYXZpZ2F0b3IucGxhdGZvcm0udG9Mb3dlckNhc2UoKX0gQnJvd3Nlci8ke25hdmlnYXRvci51c2VyQWdlbnR9O2A7XG4gIH0gZWxzZSBpZiAodHlwZW9mIHByb2Nlc3MgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICByZXR1cm4gYCR7cHJvY2Vzcy5hcmNofSAke3Byb2Nlc3MucGxhdGZvcm19IE5vZGUuanMvJHtwcm9jZXNzLnZlcnNpb259YDtcbiAgfVxuICByZXR1cm4gXCJcIjtcbn1cbmNvbnN0IGZldGNoV2l0aEhlYWRlcnMgPSBhc3luYyAoZmV0Y2gsIHVybCwgb3B0aW9ucyA9IHt9KSA9PiB7XG4gIGNvbnN0IGRlZmF1bHRIZWFkZXJzID0ge1xuICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgIEFjY2VwdDogXCJhcHBsaWNhdGlvbi9qc29uXCIsXG4gICAgXCJVc2VyLUFnZW50XCI6IGBvbGxhbWEtanMvJHt2ZXJzaW9ufSAoJHtnZXRQbGF0Zm9ybSgpfSlgXG4gIH07XG4gIGlmICghb3B0aW9ucy5oZWFkZXJzKSB7XG4gICAgb3B0aW9ucy5oZWFkZXJzID0ge307XG4gIH1cbiAgb3B0aW9ucy5oZWFkZXJzID0ge1xuICAgIC4uLmRlZmF1bHRIZWFkZXJzLFxuICAgIC4uLm9wdGlvbnMuaGVhZGVyc1xuICB9O1xuICByZXR1cm4gZmV0Y2godXJsLCBvcHRpb25zKTtcbn07XG5jb25zdCBnZXQgPSBhc3luYyAoZmV0Y2gsIGhvc3QpID0+IHtcbiAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaFdpdGhIZWFkZXJzKGZldGNoLCBob3N0KTtcbiAgYXdhaXQgY2hlY2tPayhyZXNwb25zZSk7XG4gIHJldHVybiByZXNwb25zZTtcbn07XG5jb25zdCBoZWFkID0gYXN5bmMgKGZldGNoLCBob3N0KSA9PiB7XG4gIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2hXaXRoSGVhZGVycyhmZXRjaCwgaG9zdCwge1xuICAgIG1ldGhvZDogXCJIRUFEXCJcbiAgfSk7XG4gIGF3YWl0IGNoZWNrT2socmVzcG9uc2UpO1xuICByZXR1cm4gcmVzcG9uc2U7XG59O1xuY29uc3QgcG9zdCA9IGFzeW5jIChmZXRjaCwgaG9zdCwgZGF0YSwgb3B0aW9ucykgPT4ge1xuICBjb25zdCBpc1JlY29yZCA9IChpbnB1dCkgPT4ge1xuICAgIHJldHVybiBpbnB1dCAhPT0gbnVsbCAmJiB0eXBlb2YgaW5wdXQgPT09IFwib2JqZWN0XCIgJiYgIUFycmF5LmlzQXJyYXkoaW5wdXQpO1xuICB9O1xuICBjb25zdCBmb3JtYXR0ZWREYXRhID0gaXNSZWNvcmQoZGF0YSkgPyBKU09OLnN0cmluZ2lmeShkYXRhKSA6IGRhdGE7XG4gIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2hXaXRoSGVhZGVycyhmZXRjaCwgaG9zdCwge1xuICAgIG1ldGhvZDogXCJQT1NUXCIsXG4gICAgYm9keTogZm9ybWF0dGVkRGF0YSxcbiAgICBzaWduYWw6IG9wdGlvbnM/LnNpZ25hbCxcbiAgICBoZWFkZXJzOiBvcHRpb25zPy5oZWFkZXJzXG4gIH0pO1xuICBhd2FpdCBjaGVja09rKHJlc3BvbnNlKTtcbiAgcmV0dXJuIHJlc3BvbnNlO1xufTtcbmNvbnN0IGRlbCA9IGFzeW5jIChmZXRjaCwgaG9zdCwgZGF0YSkgPT4ge1xuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoV2l0aEhlYWRlcnMoZmV0Y2gsIGhvc3QsIHtcbiAgICBtZXRob2Q6IFwiREVMRVRFXCIsXG4gICAgYm9keTogSlNPTi5zdHJpbmdpZnkoZGF0YSlcbiAgfSk7XG4gIGF3YWl0IGNoZWNrT2socmVzcG9uc2UpO1xuICByZXR1cm4gcmVzcG9uc2U7XG59O1xuY29uc3QgcGFyc2VKU09OID0gYXN5bmMgZnVuY3Rpb24qIChpdHIpIHtcbiAgY29uc3QgZGVjb2RlciA9IG5ldyBUZXh0RGVjb2RlcihcInV0Zi04XCIpO1xuICBsZXQgYnVmZmVyID0gXCJcIjtcbiAgY29uc3QgcmVhZGVyID0gaXRyLmdldFJlYWRlcigpO1xuICB3aGlsZSAodHJ1ZSkge1xuICAgIGNvbnN0IHsgZG9uZSwgdmFsdWU6IGNodW5rIH0gPSBhd2FpdCByZWFkZXIucmVhZCgpO1xuICAgIGlmIChkb25lKSB7XG4gICAgICBicmVhaztcbiAgICB9XG4gICAgYnVmZmVyICs9IGRlY29kZXIuZGVjb2RlKGNodW5rKTtcbiAgICBjb25zdCBwYXJ0cyA9IGJ1ZmZlci5zcGxpdChcIlxcblwiKTtcbiAgICBidWZmZXIgPSBwYXJ0cy5wb3AoKSA/PyBcIlwiO1xuICAgIGZvciAoY29uc3QgcGFydCBvZiBwYXJ0cykge1xuICAgICAgdHJ5IHtcbiAgICAgICAgeWllbGQgSlNPTi5wYXJzZShwYXJ0KTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihcImludmFsaWQganNvbjogXCIsIHBhcnQpO1xuICAgICAgfVxuICAgIH1cbiAgfVxuICBmb3IgKGNvbnN0IHBhcnQgb2YgYnVmZmVyLnNwbGl0KFwiXFxuXCIpLmZpbHRlcigocCkgPT4gcCAhPT0gXCJcIikpIHtcbiAgICB0cnkge1xuICAgICAgeWllbGQgSlNPTi5wYXJzZShwYXJ0KTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS53YXJuKFwiaW52YWxpZCBqc29uOiBcIiwgcGFydCk7XG4gICAgfVxuICB9XG59O1xuY29uc3QgZm9ybWF0SG9zdCA9IChob3N0KSA9PiB7XG4gIGlmICghaG9zdCkge1xuICAgIHJldHVybiBcImh0dHA6Ly8xMjcuMC4wLjE6MTE0MzRcIjtcbiAgfVxuICBsZXQgaXNFeHBsaWNpdFByb3RvY29sID0gaG9zdC5pbmNsdWRlcyhcIjovL1wiKTtcbiAgaWYgKGhvc3Quc3RhcnRzV2l0aChcIjpcIikpIHtcbiAgICBob3N0ID0gYGh0dHA6Ly8xMjcuMC4wLjEke2hvc3R9YDtcbiAgICBpc0V4cGxpY2l0UHJvdG9jb2wgPSB0cnVlO1xuICB9XG4gIGlmICghaXNFeHBsaWNpdFByb3RvY29sKSB7XG4gICAgaG9zdCA9IGBodHRwOi8vJHtob3N0fWA7XG4gIH1cbiAgY29uc3QgdXJsID0gbmV3IFVSTChob3N0KTtcbiAgbGV0IHBvcnQgPSB1cmwucG9ydDtcbiAgaWYgKCFwb3J0KSB7XG4gICAgaWYgKCFpc0V4cGxpY2l0UHJvdG9jb2wpIHtcbiAgICAgIHBvcnQgPSBcIjExNDM0XCI7XG4gICAgfSBlbHNlIHtcbiAgICAgIHBvcnQgPSB1cmwucHJvdG9jb2wgPT09IFwiaHR0cHM6XCIgPyBcIjQ0M1wiIDogXCI4MFwiO1xuICAgIH1cbiAgfVxuICBsZXQgZm9ybWF0dGVkSG9zdCA9IGAke3VybC5wcm90b2NvbH0vLyR7dXJsLmhvc3RuYW1lfToke3BvcnR9JHt1cmwucGF0aG5hbWV9YDtcbiAgaWYgKGZvcm1hdHRlZEhvc3QuZW5kc1dpdGgoXCIvXCIpKSB7XG4gICAgZm9ybWF0dGVkSG9zdCA9IGZvcm1hdHRlZEhvc3Quc2xpY2UoMCwgLTEpO1xuICB9XG4gIHJldHVybiBmb3JtYXR0ZWRIb3N0O1xufTtcblxudmFyIF9fZGVmUHJvcCA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBfX2RlZk5vcm1hbFByb3AgPSAob2JqLCBrZXksIHZhbHVlKSA9PiBrZXkgaW4gb2JqID8gX19kZWZQcm9wKG9iaiwga2V5LCB7IGVudW1lcmFibGU6IHRydWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSwgd3JpdGFibGU6IHRydWUsIHZhbHVlIH0pIDogb2JqW2tleV0gPSB2YWx1ZTtcbnZhciBfX3B1YmxpY0ZpZWxkID0gKG9iaiwga2V5LCB2YWx1ZSkgPT4ge1xuICBfX2RlZk5vcm1hbFByb3Aob2JqLCB0eXBlb2Yga2V5ICE9PSBcInN5bWJvbFwiID8ga2V5ICsgXCJcIiA6IGtleSwgdmFsdWUpO1xuICByZXR1cm4gdmFsdWU7XG59O1xubGV0IE9sbGFtYSQxID0gY2xhc3MgT2xsYW1hIHtcbiAgY29uc3RydWN0b3IoY29uZmlnKSB7XG4gICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcImNvbmZpZ1wiKTtcbiAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwiZmV0Y2hcIik7XG4gICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcIm9uZ29pbmdTdHJlYW1lZFJlcXVlc3RzXCIsIFtdKTtcbiAgICB0aGlzLmNvbmZpZyA9IHtcbiAgICAgIGhvc3Q6IFwiXCJcbiAgICB9O1xuICAgIGlmICghY29uZmlnPy5wcm94eSkge1xuICAgICAgdGhpcy5jb25maWcuaG9zdCA9IGZvcm1hdEhvc3QoY29uZmlnPy5ob3N0ID8/IFwiaHR0cDovLzEyNy4wLjAuMToxMTQzNFwiKTtcbiAgICB9XG4gICAgdGhpcy5mZXRjaCA9IGZldGNoO1xuICAgIGlmIChjb25maWc/LmZldGNoICE9IG51bGwpIHtcbiAgICAgIHRoaXMuZmV0Y2ggPSBjb25maWcuZmV0Y2g7XG4gICAgfVxuICB9XG4gIC8vIEFib3J0IGFueSBvbmdvaW5nIHN0cmVhbWVkIHJlcXVlc3RzIHRvIE9sbGFtYVxuICBhYm9ydCgpIHtcbiAgICBmb3IgKGNvbnN0IHJlcXVlc3Qgb2YgdGhpcy5vbmdvaW5nU3RyZWFtZWRSZXF1ZXN0cykge1xuICAgICAgcmVxdWVzdC5hYm9ydCgpO1xuICAgIH1cbiAgICB0aGlzLm9uZ29pbmdTdHJlYW1lZFJlcXVlc3RzLmxlbmd0aCA9IDA7XG4gIH1cbiAgLyoqXG4gICAqIFByb2Nlc3NlcyBhIHJlcXVlc3QgdG8gdGhlIE9sbGFtYSBzZXJ2ZXIuIElmIHRoZSByZXF1ZXN0IGlzIHN0cmVhbWFibGUsIGl0IHdpbGwgcmV0dXJuIGFcbiAgICogQWJvcnRhYmxlQXN5bmNJdGVyYXRvciB0aGF0IHlpZWxkcyB0aGUgcmVzcG9uc2UgbWVzc2FnZXMuIE90aGVyd2lzZSwgaXQgd2lsbCByZXR1cm4gdGhlIHJlc3BvbnNlXG4gICAqIG9iamVjdC5cbiAgICogQHBhcmFtIGVuZHBvaW50IHtzdHJpbmd9IC0gVGhlIGVuZHBvaW50IHRvIHNlbmQgdGhlIHJlcXVlc3QgdG8uXG4gICAqIEBwYXJhbSByZXF1ZXN0IHtvYmplY3R9IC0gVGhlIHJlcXVlc3Qgb2JqZWN0IHRvIHNlbmQgdG8gdGhlIGVuZHBvaW50LlxuICAgKiBAcHJvdGVjdGVkIHtUIHwgQWJvcnRhYmxlQXN5bmNJdGVyYXRvcjxUPn0gLSBUaGUgcmVzcG9uc2Ugb2JqZWN0IG9yIGEgQWJvcnRhYmxlQXN5bmNJdGVyYXRvciB0aGF0IHlpZWxkc1xuICAgKiByZXNwb25zZSBtZXNzYWdlcy5cbiAgICogQHRocm93cyB7RXJyb3J9IC0gSWYgdGhlIHJlc3BvbnNlIGJvZHkgaXMgbWlzc2luZyBvciBpZiB0aGUgcmVzcG9uc2UgaXMgYW4gZXJyb3IuXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPFQgfCBBYm9ydGFibGVBc3luY0l0ZXJhdG9yPFQ+Pn0gLSBUaGUgcmVzcG9uc2Ugb2JqZWN0IG9yIGEgQWJvcnRhYmxlQXN5bmNJdGVyYXRvciB0aGF0IHlpZWxkcyB0aGUgc3RyZWFtZWQgcmVzcG9uc2UuXG4gICAqL1xuICBhc3luYyBwcm9jZXNzU3RyZWFtYWJsZVJlcXVlc3QoZW5kcG9pbnQsIHJlcXVlc3QpIHtcbiAgICByZXF1ZXN0LnN0cmVhbSA9IHJlcXVlc3Quc3RyZWFtID8/IGZhbHNlO1xuICAgIGNvbnN0IGhvc3QgPSBgJHt0aGlzLmNvbmZpZy5ob3N0fS9hcGkvJHtlbmRwb2ludH1gO1xuICAgIGlmIChyZXF1ZXN0LnN0cmVhbSkge1xuICAgICAgY29uc3QgYWJvcnRDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuICAgICAgY29uc3QgcmVzcG9uc2UyID0gYXdhaXQgcG9zdCh0aGlzLmZldGNoLCBob3N0LCByZXF1ZXN0LCB7XG4gICAgICAgIHNpZ25hbDogYWJvcnRDb250cm9sbGVyLnNpZ25hbCxcbiAgICAgICAgaGVhZGVyczogdGhpcy5jb25maWcuaGVhZGVyc1xuICAgICAgfSk7XG4gICAgICBpZiAoIXJlc3BvbnNlMi5ib2R5KSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIk1pc3NpbmcgYm9keVwiKTtcbiAgICAgIH1cbiAgICAgIGNvbnN0IGl0ciA9IHBhcnNlSlNPTihyZXNwb25zZTIuYm9keSk7XG4gICAgICBjb25zdCBhYm9ydGFibGVBc3luY0l0ZXJhdG9yID0gbmV3IEFib3J0YWJsZUFzeW5jSXRlcmF0b3IoXG4gICAgICAgIGFib3J0Q29udHJvbGxlcixcbiAgICAgICAgaXRyLFxuICAgICAgICAoKSA9PiB7XG4gICAgICAgICAgY29uc3QgaSA9IHRoaXMub25nb2luZ1N0cmVhbWVkUmVxdWVzdHMuaW5kZXhPZihhYm9ydGFibGVBc3luY0l0ZXJhdG9yKTtcbiAgICAgICAgICBpZiAoaSA+IC0xKSB7XG4gICAgICAgICAgICB0aGlzLm9uZ29pbmdTdHJlYW1lZFJlcXVlc3RzLnNwbGljZShpLCAxKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgICB0aGlzLm9uZ29pbmdTdHJlYW1lZFJlcXVlc3RzLnB1c2goYWJvcnRhYmxlQXN5bmNJdGVyYXRvcik7XG4gICAgICByZXR1cm4gYWJvcnRhYmxlQXN5bmNJdGVyYXRvcjtcbiAgICB9XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBwb3N0KHRoaXMuZmV0Y2gsIGhvc3QsIHJlcXVlc3QsIHtcbiAgICAgIGhlYWRlcnM6IHRoaXMuY29uZmlnLmhlYWRlcnNcbiAgICB9KTtcbiAgICByZXR1cm4gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICB9XG4gIC8qKlxuICAqIEVuY29kZXMgYW4gaW1hZ2UgdG8gYmFzZTY0IGlmIGl0IGlzIGEgVWludDhBcnJheS5cbiAgKiBAcGFyYW0gaW1hZ2Uge1VpbnQ4QXJyYXkgfCBzdHJpbmd9IC0gVGhlIGltYWdlIHRvIGVuY29kZS5cbiAgKiBAcmV0dXJucyB7UHJvbWlzZTxzdHJpbmc+fSAtIFRoZSBiYXNlNjQgZW5jb2RlZCBpbWFnZS5cbiAgKi9cbiAgYXN5bmMgZW5jb2RlSW1hZ2UoaW1hZ2UpIHtcbiAgICBpZiAodHlwZW9mIGltYWdlICE9PSBcInN0cmluZ1wiKSB7XG4gICAgICBjb25zdCB1aW50OEFycmF5ID0gbmV3IFVpbnQ4QXJyYXkoaW1hZ2UpO1xuICAgICAgbGV0IGJ5dGVTdHJpbmcgPSBcIlwiO1xuICAgICAgY29uc3QgbGVuID0gdWludDhBcnJheS5ieXRlTGVuZ3RoO1xuICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBsZW47IGkrKykge1xuICAgICAgICBieXRlU3RyaW5nICs9IFN0cmluZy5mcm9tQ2hhckNvZGUodWludDhBcnJheVtpXSk7XG4gICAgICB9XG4gICAgICByZXR1cm4gYnRvYShieXRlU3RyaW5nKTtcbiAgICB9XG4gICAgcmV0dXJuIGltYWdlO1xuICB9XG4gIC8qKlxuICAgKiBHZW5lcmF0ZXMgYSByZXNwb25zZSBmcm9tIGEgdGV4dCBwcm9tcHQuXG4gICAqIEBwYXJhbSByZXF1ZXN0IHtHZW5lcmF0ZVJlcXVlc3R9IC0gVGhlIHJlcXVlc3Qgb2JqZWN0LlxuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxHZW5lcmF0ZVJlc3BvbnNlIHwgQWJvcnRhYmxlQXN5bmNJdGVyYXRvcjxHZW5lcmF0ZVJlc3BvbnNlPj59IC0gVGhlIHJlc3BvbnNlIG9iamVjdCBvclxuICAgKiBhbiBBYm9ydGFibGVBc3luY0l0ZXJhdG9yIHRoYXQgeWllbGRzIHJlc3BvbnNlIG1lc3NhZ2VzLlxuICAgKi9cbiAgYXN5bmMgZ2VuZXJhdGUocmVxdWVzdCkge1xuICAgIGlmIChyZXF1ZXN0LmltYWdlcykge1xuICAgICAgcmVxdWVzdC5pbWFnZXMgPSBhd2FpdCBQcm9taXNlLmFsbChyZXF1ZXN0LmltYWdlcy5tYXAodGhpcy5lbmNvZGVJbWFnZS5iaW5kKHRoaXMpKSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnByb2Nlc3NTdHJlYW1hYmxlUmVxdWVzdChcImdlbmVyYXRlXCIsIHJlcXVlc3QpO1xuICB9XG4gIC8qKlxuICAgKiBDaGF0cyB3aXRoIHRoZSBtb2RlbC4gVGhlIHJlcXVlc3Qgb2JqZWN0IGNhbiBjb250YWluIG1lc3NhZ2VzIHdpdGggaW1hZ2VzIHRoYXQgYXJlIGVpdGhlclxuICAgKiBVaW50OEFycmF5cyBvciBiYXNlNjQgZW5jb2RlZCBzdHJpbmdzLiBUaGUgaW1hZ2VzIHdpbGwgYmUgYmFzZTY0IGVuY29kZWQgYmVmb3JlIHNlbmRpbmcgdGhlXG4gICAqIHJlcXVlc3QuXG4gICAqIEBwYXJhbSByZXF1ZXN0IHtDaGF0UmVxdWVzdH0gLSBUaGUgcmVxdWVzdCBvYmplY3QuXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPENoYXRSZXNwb25zZSB8IEFib3J0YWJsZUFzeW5jSXRlcmF0b3I8Q2hhdFJlc3BvbnNlPj59IC0gVGhlIHJlc3BvbnNlIG9iamVjdCBvciBhblxuICAgKiBBYm9ydGFibGVBc3luY0l0ZXJhdG9yIHRoYXQgeWllbGRzIHJlc3BvbnNlIG1lc3NhZ2VzLlxuICAgKi9cbiAgYXN5bmMgY2hhdChyZXF1ZXN0KSB7XG4gICAgaWYgKHJlcXVlc3QubWVzc2FnZXMpIHtcbiAgICAgIGZvciAoY29uc3QgbWVzc2FnZSBvZiByZXF1ZXN0Lm1lc3NhZ2VzKSB7XG4gICAgICAgIGlmIChtZXNzYWdlLmltYWdlcykge1xuICAgICAgICAgIG1lc3NhZ2UuaW1hZ2VzID0gYXdhaXQgUHJvbWlzZS5hbGwoXG4gICAgICAgICAgICBtZXNzYWdlLmltYWdlcy5tYXAodGhpcy5lbmNvZGVJbWFnZS5iaW5kKHRoaXMpKVxuICAgICAgICAgICk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHRoaXMucHJvY2Vzc1N0cmVhbWFibGVSZXF1ZXN0KFwiY2hhdFwiLCByZXF1ZXN0KTtcbiAgfVxuICAvKipcbiAgICogQ3JlYXRlcyBhIG5ldyBtb2RlbCBmcm9tIGEgc3RyZWFtIG9mIGRhdGEuXG4gICAqIEBwYXJhbSByZXF1ZXN0IHtDcmVhdGVSZXF1ZXN0fSAtIFRoZSByZXF1ZXN0IG9iamVjdC5cbiAgICogQHJldHVybnMge1Byb21pc2U8UHJvZ3Jlc3NSZXNwb25zZSB8IEFib3J0YWJsZUFzeW5jSXRlcmF0b3I8UHJvZ3Jlc3NSZXNwb25zZT4+fSAtIFRoZSByZXNwb25zZSBvYmplY3Qgb3IgYSBzdHJlYW0gb2YgcHJvZ3Jlc3MgcmVzcG9uc2VzLlxuICAgKi9cbiAgYXN5bmMgY3JlYXRlKHJlcXVlc3QpIHtcbiAgICByZXR1cm4gdGhpcy5wcm9jZXNzU3RyZWFtYWJsZVJlcXVlc3QoXCJjcmVhdGVcIiwge1xuICAgICAgbmFtZTogcmVxdWVzdC5tb2RlbCxcbiAgICAgIHN0cmVhbTogcmVxdWVzdC5zdHJlYW0sXG4gICAgICBtb2RlbGZpbGU6IHJlcXVlc3QubW9kZWxmaWxlLFxuICAgICAgcXVhbnRpemU6IHJlcXVlc3QucXVhbnRpemVcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogUHVsbHMgYSBtb2RlbCBmcm9tIHRoZSBPbGxhbWEgcmVnaXN0cnkuIFRoZSByZXF1ZXN0IG9iamVjdCBjYW4gY29udGFpbiBhIHN0cmVhbSBmbGFnIHRvIGluZGljYXRlIGlmIHRoZVxuICAgKiByZXNwb25zZSBzaG91bGQgYmUgc3RyZWFtZWQuXG4gICAqIEBwYXJhbSByZXF1ZXN0IHtQdWxsUmVxdWVzdH0gLSBUaGUgcmVxdWVzdCBvYmplY3QuXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPFByb2dyZXNzUmVzcG9uc2UgfCBBYm9ydGFibGVBc3luY0l0ZXJhdG9yPFByb2dyZXNzUmVzcG9uc2U+Pn0gLSBUaGUgcmVzcG9uc2Ugb2JqZWN0IG9yXG4gICAqIGFuIEFib3J0YWJsZUFzeW5jSXRlcmF0b3IgdGhhdCB5aWVsZHMgcmVzcG9uc2UgbWVzc2FnZXMuXG4gICAqL1xuICBhc3luYyBwdWxsKHJlcXVlc3QpIHtcbiAgICByZXR1cm4gdGhpcy5wcm9jZXNzU3RyZWFtYWJsZVJlcXVlc3QoXCJwdWxsXCIsIHtcbiAgICAgIG5hbWU6IHJlcXVlc3QubW9kZWwsXG4gICAgICBzdHJlYW06IHJlcXVlc3Quc3RyZWFtLFxuICAgICAgaW5zZWN1cmU6IHJlcXVlc3QuaW5zZWN1cmVcbiAgICB9KTtcbiAgfVxuICAvKipcbiAgICogUHVzaGVzIGEgbW9kZWwgdG8gdGhlIE9sbGFtYSByZWdpc3RyeS4gVGhlIHJlcXVlc3Qgb2JqZWN0IGNhbiBjb250YWluIGEgc3RyZWFtIGZsYWcgdG8gaW5kaWNhdGUgaWYgdGhlXG4gICAqIHJlc3BvbnNlIHNob3VsZCBiZSBzdHJlYW1lZC5cbiAgICogQHBhcmFtIHJlcXVlc3Qge1B1c2hSZXF1ZXN0fSAtIFRoZSByZXF1ZXN0IG9iamVjdC5cbiAgICogQHJldHVybnMge1Byb21pc2U8UHJvZ3Jlc3NSZXNwb25zZSB8IEFib3J0YWJsZUFzeW5jSXRlcmF0b3I8UHJvZ3Jlc3NSZXNwb25zZT4+fSAtIFRoZSByZXNwb25zZSBvYmplY3Qgb3JcbiAgICogYW4gQWJvcnRhYmxlQXN5bmNJdGVyYXRvciB0aGF0IHlpZWxkcyByZXNwb25zZSBtZXNzYWdlcy5cbiAgICovXG4gIGFzeW5jIHB1c2gocmVxdWVzdCkge1xuICAgIHJldHVybiB0aGlzLnByb2Nlc3NTdHJlYW1hYmxlUmVxdWVzdChcInB1c2hcIiwge1xuICAgICAgbmFtZTogcmVxdWVzdC5tb2RlbCxcbiAgICAgIHN0cmVhbTogcmVxdWVzdC5zdHJlYW0sXG4gICAgICBpbnNlY3VyZTogcmVxdWVzdC5pbnNlY3VyZVxuICAgIH0pO1xuICB9XG4gIC8qKlxuICAgKiBEZWxldGVzIGEgbW9kZWwgZnJvbSB0aGUgc2VydmVyLiBUaGUgcmVxdWVzdCBvYmplY3Qgc2hvdWxkIGNvbnRhaW4gdGhlIG5hbWUgb2YgdGhlIG1vZGVsIHRvXG4gICAqIGRlbGV0ZS5cbiAgICogQHBhcmFtIHJlcXVlc3Qge0RlbGV0ZVJlcXVlc3R9IC0gVGhlIHJlcXVlc3Qgb2JqZWN0LlxuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxTdGF0dXNSZXNwb25zZT59IC0gVGhlIHJlc3BvbnNlIG9iamVjdC5cbiAgICovXG4gIGFzeW5jIGRlbGV0ZShyZXF1ZXN0KSB7XG4gICAgYXdhaXQgZGVsKHRoaXMuZmV0Y2gsIGAke3RoaXMuY29uZmlnLmhvc3R9L2FwaS9kZWxldGVgLCB7XG4gICAgICBuYW1lOiByZXF1ZXN0Lm1vZGVsXG4gICAgfSk7XG4gICAgcmV0dXJuIHsgc3RhdHVzOiBcInN1Y2Nlc3NcIiB9O1xuICB9XG4gIC8qKlxuICAgKiBDb3BpZXMgYSBtb2RlbCBmcm9tIG9uZSBuYW1lIHRvIGFub3RoZXIuIFRoZSByZXF1ZXN0IG9iamVjdCBzaG91bGQgY29udGFpbiB0aGUgbmFtZSBvZiB0aGVcbiAgICogbW9kZWwgdG8gY29weSBhbmQgdGhlIG5ldyBuYW1lLlxuICAgKiBAcGFyYW0gcmVxdWVzdCB7Q29weVJlcXVlc3R9IC0gVGhlIHJlcXVlc3Qgb2JqZWN0LlxuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxTdGF0dXNSZXNwb25zZT59IC0gVGhlIHJlc3BvbnNlIG9iamVjdC5cbiAgICovXG4gIGFzeW5jIGNvcHkocmVxdWVzdCkge1xuICAgIGF3YWl0IHBvc3QodGhpcy5mZXRjaCwgYCR7dGhpcy5jb25maWcuaG9zdH0vYXBpL2NvcHlgLCB7IC4uLnJlcXVlc3QgfSk7XG4gICAgcmV0dXJuIHsgc3RhdHVzOiBcInN1Y2Nlc3NcIiB9O1xuICB9XG4gIC8qKlxuICAgKiBMaXN0cyB0aGUgbW9kZWxzIG9uIHRoZSBzZXJ2ZXIuXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPExpc3RSZXNwb25zZT59IC0gVGhlIHJlc3BvbnNlIG9iamVjdC5cbiAgICogQHRocm93cyB7RXJyb3J9IC0gSWYgdGhlIHJlc3BvbnNlIGJvZHkgaXMgbWlzc2luZy5cbiAgICovXG4gIGFzeW5jIGxpc3QoKSB7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBnZXQodGhpcy5mZXRjaCwgYCR7dGhpcy5jb25maWcuaG9zdH0vYXBpL3RhZ3NgKTtcbiAgICByZXR1cm4gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICB9XG4gIC8qKlxuICAgKiBTaG93cyB0aGUgbWV0YWRhdGEgb2YgYSBtb2RlbC4gVGhlIHJlcXVlc3Qgb2JqZWN0IHNob3VsZCBjb250YWluIHRoZSBuYW1lIG9mIHRoZSBtb2RlbC5cbiAgICogQHBhcmFtIHJlcXVlc3Qge1Nob3dSZXF1ZXN0fSAtIFRoZSByZXF1ZXN0IG9iamVjdC5cbiAgICogQHJldHVybnMge1Byb21pc2U8U2hvd1Jlc3BvbnNlPn0gLSBUaGUgcmVzcG9uc2Ugb2JqZWN0LlxuICAgKi9cbiAgYXN5bmMgc2hvdyhyZXF1ZXN0KSB7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBwb3N0KHRoaXMuZmV0Y2gsIGAke3RoaXMuY29uZmlnLmhvc3R9L2FwaS9zaG93YCwge1xuICAgICAgLi4ucmVxdWVzdFxuICAgIH0pO1xuICAgIHJldHVybiBhd2FpdCByZXNwb25zZS5qc29uKCk7XG4gIH1cbiAgLyoqXG4gICAqIEVtYmVkcyB0ZXh0IGlucHV0IGludG8gdmVjdG9ycy5cbiAgICogQHBhcmFtIHJlcXVlc3Qge0VtYmVkUmVxdWVzdH0gLSBUaGUgcmVxdWVzdCBvYmplY3QuXG4gICAqIEByZXR1cm5zIHtQcm9taXNlPEVtYmVkUmVzcG9uc2U+fSAtIFRoZSByZXNwb25zZSBvYmplY3QuXG4gICAqL1xuICBhc3luYyBlbWJlZChyZXF1ZXN0KSB7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBwb3N0KHRoaXMuZmV0Y2gsIGAke3RoaXMuY29uZmlnLmhvc3R9L2FwaS9lbWJlZGAsIHtcbiAgICAgIC4uLnJlcXVlc3RcbiAgICB9KTtcbiAgICByZXR1cm4gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICB9XG4gIC8qKlxuICAgKiBFbWJlZHMgYSB0ZXh0IHByb21wdCBpbnRvIGEgdmVjdG9yLlxuICAgKiBAcGFyYW0gcmVxdWVzdCB7RW1iZWRkaW5nc1JlcXVlc3R9IC0gVGhlIHJlcXVlc3Qgb2JqZWN0LlxuICAgKiBAcmV0dXJucyB7UHJvbWlzZTxFbWJlZGRpbmdzUmVzcG9uc2U+fSAtIFRoZSByZXNwb25zZSBvYmplY3QuXG4gICAqL1xuICBhc3luYyBlbWJlZGRpbmdzKHJlcXVlc3QpIHtcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHBvc3QodGhpcy5mZXRjaCwgYCR7dGhpcy5jb25maWcuaG9zdH0vYXBpL2VtYmVkZGluZ3NgLCB7XG4gICAgICAuLi5yZXF1ZXN0XG4gICAgfSk7XG4gICAgcmV0dXJuIGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgfVxuICAvKipcbiAgICogTGlzdHMgdGhlIHJ1bm5pbmcgbW9kZWxzIG9uIHRoZSBzZXJ2ZXJcbiAgICogQHJldHVybnMge1Byb21pc2U8TGlzdFJlc3BvbnNlPn0gLSBUaGUgcmVzcG9uc2Ugb2JqZWN0LlxuICAgKiBAdGhyb3dzIHtFcnJvcn0gLSBJZiB0aGUgcmVzcG9uc2UgYm9keSBpcyBtaXNzaW5nLlxuICAgKi9cbiAgYXN5bmMgcHMoKSB7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBnZXQodGhpcy5mZXRjaCwgYCR7dGhpcy5jb25maWcuaG9zdH0vYXBpL3BzYCk7XG4gICAgcmV0dXJuIGF3YWl0IHJlc3BvbnNlLmpzb24oKTtcbiAgfVxufTtcbmNvbnN0IGJyb3dzZXIgPSBuZXcgT2xsYW1hJDEoKTtcblxuZXhwb3J0IHsgT2xsYW1hJDEgYXMgTywgYnJvd3NlciBhcyBiLCBoZWFkIGFzIGgsIHBvc3QgYXMgcCB9O1xuIl0sCiAgIm1hcHBpbmdzIjogIjtBQUFBLFlBQVksY0FBYzs7O0FDQzFCLElBQUksSUFDRCxPQUFPLGVBQWUsZUFBZSxjQUNyQyxPQUFPLFNBQVMsZUFBZTtBQUUvQixPQUFPLFdBQVcsZUFBZSxVQUNsQyxDQUFDO0FBRUgsSUFBSSxVQUFVO0FBQUEsRUFDWixjQUFjLHFCQUFxQjtBQUFBLEVBQ25DLFVBQVUsWUFBWSxLQUFLLGNBQWM7QUFBQSxFQUN6QyxNQUNFLGdCQUFnQixLQUNoQixVQUFVLEtBQ1QsV0FBVztBQUNWLFFBQUk7QUFDRixVQUFJLEtBQUs7QUFDVCxhQUFPO0FBQUEsSUFDVCxTQUFTLEdBQUc7QUFDVixhQUFPO0FBQUEsSUFDVDtBQUFBLEVBQ0YsRUFBRztBQUFBLEVBQ0wsVUFBVSxjQUFjO0FBQUEsRUFDeEIsYUFBYSxpQkFBaUI7QUFDaEM7QUFFQSxTQUFTLFdBQVcsS0FBSztBQUN2QixTQUFPLE9BQU8sU0FBUyxVQUFVLGNBQWMsR0FBRztBQUNwRDtBQUVBLElBQUksUUFBUSxhQUFhO0FBQ25CLGdCQUFjO0FBQUEsSUFDaEI7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLElBQ0E7QUFBQSxJQUNBO0FBQUEsSUFDQTtBQUFBLEVBQ0Y7QUFFSSxzQkFDRixZQUFZLFVBQ1osU0FBUyxLQUFLO0FBQ1osV0FBTyxPQUFPLFlBQVksUUFBUSxPQUFPLFVBQVUsU0FBUyxLQUFLLEdBQUcsQ0FBQyxJQUFJO0FBQUEsRUFDM0U7QUFDSjtBQWpCTTtBQVlBO0FBT04sU0FBUyxjQUFjLE1BQU07QUFDM0IsTUFBSSxPQUFPLFNBQVMsVUFBVTtBQUM1QixXQUFPLE9BQU8sSUFBSTtBQUFBLEVBQ3BCO0FBQ0EsTUFBSSw2QkFBNkIsS0FBSyxJQUFJLEtBQUssU0FBUyxJQUFJO0FBQzFELFVBQU0sSUFBSSxVQUFVLDhDQUE4QyxPQUFPLEdBQUc7QUFBQSxFQUM5RTtBQUNBLFNBQU8sS0FBSyxZQUFZO0FBQzFCO0FBRUEsU0FBUyxlQUFlLE9BQU87QUFDN0IsTUFBSSxPQUFPLFVBQVUsVUFBVTtBQUM3QixZQUFRLE9BQU8sS0FBSztBQUFBLEVBQ3RCO0FBQ0EsU0FBTztBQUNUO0FBR0EsU0FBUyxZQUFZLE9BQU87QUFDMUIsTUFBSSxXQUFXO0FBQUEsSUFDYixNQUFNLFdBQVc7QUFDZixVQUFJLFFBQVEsTUFBTSxNQUFNO0FBQ3hCLGFBQU8sRUFBQyxNQUFNLFVBQVUsUUFBVyxNQUFZO0FBQUEsSUFDakQ7QUFBQSxFQUNGO0FBRUEsTUFBSSxRQUFRLFVBQVU7QUFDcEIsYUFBUyxPQUFPLFFBQVEsSUFBSSxXQUFXO0FBQ3JDLGFBQU87QUFBQSxJQUNUO0FBQUEsRUFDRjtBQUVBLFNBQU87QUFDVDtBQUVPLFNBQVMsUUFBUSxTQUFTO0FBQy9CLE9BQUssTUFBTSxDQUFDO0FBRVosTUFBSSxtQkFBbUIsU0FBUztBQUM5QixZQUFRLFFBQVEsU0FBUyxPQUFPLE1BQU07QUFDcEMsV0FBSyxPQUFPLE1BQU0sS0FBSztBQUFBLElBQ3pCLEdBQUcsSUFBSTtBQUFBLEVBQ1QsV0FBVyxNQUFNLFFBQVEsT0FBTyxHQUFHO0FBQ2pDLFlBQVEsUUFBUSxTQUFTLFFBQVE7QUFDL0IsVUFBSSxPQUFPLFVBQVUsR0FBRztBQUN0QixjQUFNLElBQUksVUFBVSx3RUFBd0UsT0FBTyxNQUFNO0FBQUEsTUFDM0c7QUFDQSxXQUFLLE9BQU8sT0FBTyxDQUFDLEdBQUcsT0FBTyxDQUFDLENBQUM7QUFBQSxJQUNsQyxHQUFHLElBQUk7QUFBQSxFQUNULFdBQVcsU0FBUztBQUNsQixXQUFPLG9CQUFvQixPQUFPLEVBQUUsUUFBUSxTQUFTLE1BQU07QUFDekQsV0FBSyxPQUFPLE1BQU0sUUFBUSxJQUFJLENBQUM7QUFBQSxJQUNqQyxHQUFHLElBQUk7QUFBQSxFQUNUO0FBQ0Y7QUFFQSxRQUFRLFVBQVUsU0FBUyxTQUFTLE1BQU0sT0FBTztBQUMvQyxTQUFPLGNBQWMsSUFBSTtBQUN6QixVQUFRLGVBQWUsS0FBSztBQUM1QixNQUFJLFdBQVcsS0FBSyxJQUFJLElBQUk7QUFDNUIsT0FBSyxJQUFJLElBQUksSUFBSSxXQUFXLFdBQVcsT0FBTyxRQUFRO0FBQ3hEO0FBRUEsUUFBUSxVQUFVLFFBQVEsSUFBSSxTQUFTLE1BQU07QUFDM0MsU0FBTyxLQUFLLElBQUksY0FBYyxJQUFJLENBQUM7QUFDckM7QUFFQSxRQUFRLFVBQVUsTUFBTSxTQUFTLE1BQU07QUFDckMsU0FBTyxjQUFjLElBQUk7QUFDekIsU0FBTyxLQUFLLElBQUksSUFBSSxJQUFJLEtBQUssSUFBSSxJQUFJLElBQUk7QUFDM0M7QUFFQSxRQUFRLFVBQVUsTUFBTSxTQUFTLE1BQU07QUFDckMsU0FBTyxLQUFLLElBQUksZUFBZSxjQUFjLElBQUksQ0FBQztBQUNwRDtBQUVBLFFBQVEsVUFBVSxNQUFNLFNBQVMsTUFBTSxPQUFPO0FBQzVDLE9BQUssSUFBSSxjQUFjLElBQUksQ0FBQyxJQUFJLGVBQWUsS0FBSztBQUN0RDtBQUVBLFFBQVEsVUFBVSxVQUFVLFNBQVMsVUFBVSxTQUFTO0FBQ3RELFdBQVMsUUFBUSxLQUFLLEtBQUs7QUFDekIsUUFBSSxLQUFLLElBQUksZUFBZSxJQUFJLEdBQUc7QUFDakMsZUFBUyxLQUFLLFNBQVMsS0FBSyxJQUFJLElBQUksR0FBRyxNQUFNLElBQUk7QUFBQSxJQUNuRDtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFFBQVEsVUFBVSxPQUFPLFdBQVc7QUFDbEMsTUFBSSxRQUFRLENBQUM7QUFDYixPQUFLLFFBQVEsU0FBUyxPQUFPLE1BQU07QUFDakMsVUFBTSxLQUFLLElBQUk7QUFBQSxFQUNqQixDQUFDO0FBQ0QsU0FBTyxZQUFZLEtBQUs7QUFDMUI7QUFFQSxRQUFRLFVBQVUsU0FBUyxXQUFXO0FBQ3BDLE1BQUksUUFBUSxDQUFDO0FBQ2IsT0FBSyxRQUFRLFNBQVMsT0FBTztBQUMzQixVQUFNLEtBQUssS0FBSztBQUFBLEVBQ2xCLENBQUM7QUFDRCxTQUFPLFlBQVksS0FBSztBQUMxQjtBQUVBLFFBQVEsVUFBVSxVQUFVLFdBQVc7QUFDckMsTUFBSSxRQUFRLENBQUM7QUFDYixPQUFLLFFBQVEsU0FBUyxPQUFPLE1BQU07QUFDakMsVUFBTSxLQUFLLENBQUMsTUFBTSxLQUFLLENBQUM7QUFBQSxFQUMxQixDQUFDO0FBQ0QsU0FBTyxZQUFZLEtBQUs7QUFDMUI7QUFFQSxJQUFJLFFBQVEsVUFBVTtBQUNwQixVQUFRLFVBQVUsT0FBTyxRQUFRLElBQUksUUFBUSxVQUFVO0FBQ3pEO0FBRUEsU0FBUyxTQUFTLE1BQU07QUFDdEIsTUFBSSxLQUFLLFFBQVM7QUFDbEIsTUFBSSxLQUFLLFVBQVU7QUFDakIsV0FBTyxRQUFRLE9BQU8sSUFBSSxVQUFVLGNBQWMsQ0FBQztBQUFBLEVBQ3JEO0FBQ0EsT0FBSyxXQUFXO0FBQ2xCO0FBRUEsU0FBUyxnQkFBZ0IsUUFBUTtBQUMvQixTQUFPLElBQUksUUFBUSxTQUFTLFNBQVMsUUFBUTtBQUMzQyxXQUFPLFNBQVMsV0FBVztBQUN6QixjQUFRLE9BQU8sTUFBTTtBQUFBLElBQ3ZCO0FBQ0EsV0FBTyxVQUFVLFdBQVc7QUFDMUIsYUFBTyxPQUFPLEtBQUs7QUFBQSxJQUNyQjtBQUFBLEVBQ0YsQ0FBQztBQUNIO0FBRUEsU0FBUyxzQkFBc0IsTUFBTTtBQUNuQyxNQUFJLFNBQVMsSUFBSSxXQUFXO0FBQzVCLE1BQUksVUFBVSxnQkFBZ0IsTUFBTTtBQUNwQyxTQUFPLGtCQUFrQixJQUFJO0FBQzdCLFNBQU87QUFDVDtBQUVBLFNBQVMsZUFBZSxNQUFNO0FBQzVCLE1BQUksU0FBUyxJQUFJLFdBQVc7QUFDNUIsTUFBSSxVQUFVLGdCQUFnQixNQUFNO0FBQ3BDLE1BQUksUUFBUSwyQkFBMkIsS0FBSyxLQUFLLElBQUk7QUFDckQsTUFBSSxXQUFXLFFBQVEsTUFBTSxDQUFDLElBQUk7QUFDbEMsU0FBTyxXQUFXLE1BQU0sUUFBUTtBQUNoQyxTQUFPO0FBQ1Q7QUFFQSxTQUFTLHNCQUFzQixLQUFLO0FBQ2xDLE1BQUksT0FBTyxJQUFJLFdBQVcsR0FBRztBQUM3QixNQUFJLFFBQVEsSUFBSSxNQUFNLEtBQUssTUFBTTtBQUVqQyxXQUFTLElBQUksR0FBRyxJQUFJLEtBQUssUUFBUSxLQUFLO0FBQ3BDLFVBQU0sQ0FBQyxJQUFJLE9BQU8sYUFBYSxLQUFLLENBQUMsQ0FBQztBQUFBLEVBQ3hDO0FBQ0EsU0FBTyxNQUFNLEtBQUssRUFBRTtBQUN0QjtBQUVBLFNBQVMsWUFBWSxLQUFLO0FBQ3hCLE1BQUksSUFBSSxPQUFPO0FBQ2IsV0FBTyxJQUFJLE1BQU0sQ0FBQztBQUFBLEVBQ3BCLE9BQU87QUFDTCxRQUFJLE9BQU8sSUFBSSxXQUFXLElBQUksVUFBVTtBQUN4QyxTQUFLLElBQUksSUFBSSxXQUFXLEdBQUcsQ0FBQztBQUM1QixXQUFPLEtBQUs7QUFBQSxFQUNkO0FBQ0Y7QUFFQSxTQUFTLE9BQU87QUFDZCxPQUFLLFdBQVc7QUFFaEIsT0FBSyxZQUFZLFNBQVMsTUFBTTtBQVk5QixTQUFLLFdBQVcsS0FBSztBQUNyQixTQUFLLFlBQVk7QUFDakIsUUFBSSxDQUFDLE1BQU07QUFDVCxXQUFLLFVBQVU7QUFDZixXQUFLLFlBQVk7QUFBQSxJQUNuQixXQUFXLE9BQU8sU0FBUyxVQUFVO0FBQ25DLFdBQUssWUFBWTtBQUFBLElBQ25CLFdBQVcsUUFBUSxRQUFRLEtBQUssVUFBVSxjQUFjLElBQUksR0FBRztBQUM3RCxXQUFLLFlBQVk7QUFBQSxJQUNuQixXQUFXLFFBQVEsWUFBWSxTQUFTLFVBQVUsY0FBYyxJQUFJLEdBQUc7QUFDckUsV0FBSyxnQkFBZ0I7QUFBQSxJQUN2QixXQUFXLFFBQVEsZ0JBQWdCLGdCQUFnQixVQUFVLGNBQWMsSUFBSSxHQUFHO0FBQ2hGLFdBQUssWUFBWSxLQUFLLFNBQVM7QUFBQSxJQUNqQyxXQUFXLFFBQVEsZUFBZSxRQUFRLFFBQVEsV0FBVyxJQUFJLEdBQUc7QUFDbEUsV0FBSyxtQkFBbUIsWUFBWSxLQUFLLE1BQU07QUFFL0MsV0FBSyxZQUFZLElBQUksS0FBSyxDQUFDLEtBQUssZ0JBQWdCLENBQUM7QUFBQSxJQUNuRCxXQUFXLFFBQVEsZ0JBQWdCLFlBQVksVUFBVSxjQUFjLElBQUksS0FBSyxrQkFBa0IsSUFBSSxJQUFJO0FBQ3hHLFdBQUssbUJBQW1CLFlBQVksSUFBSTtBQUFBLElBQzFDLE9BQU87QUFDTCxXQUFLLFlBQVksT0FBTyxPQUFPLFVBQVUsU0FBUyxLQUFLLElBQUk7QUFBQSxJQUM3RDtBQUVBLFFBQUksQ0FBQyxLQUFLLFFBQVEsSUFBSSxjQUFjLEdBQUc7QUFDckMsVUFBSSxPQUFPLFNBQVMsVUFBVTtBQUM1QixhQUFLLFFBQVEsSUFBSSxnQkFBZ0IsMEJBQTBCO0FBQUEsTUFDN0QsV0FBVyxLQUFLLGFBQWEsS0FBSyxVQUFVLE1BQU07QUFDaEQsYUFBSyxRQUFRLElBQUksZ0JBQWdCLEtBQUssVUFBVSxJQUFJO0FBQUEsTUFDdEQsV0FBVyxRQUFRLGdCQUFnQixnQkFBZ0IsVUFBVSxjQUFjLElBQUksR0FBRztBQUNoRixhQUFLLFFBQVEsSUFBSSxnQkFBZ0IsaURBQWlEO0FBQUEsTUFDcEY7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLE1BQUksUUFBUSxNQUFNO0FBQ2hCLFNBQUssT0FBTyxXQUFXO0FBQ3JCLFVBQUksV0FBVyxTQUFTLElBQUk7QUFDNUIsVUFBSSxVQUFVO0FBQ1osZUFBTztBQUFBLE1BQ1Q7QUFFQSxVQUFJLEtBQUssV0FBVztBQUNsQixlQUFPLFFBQVEsUUFBUSxLQUFLLFNBQVM7QUFBQSxNQUN2QyxXQUFXLEtBQUssa0JBQWtCO0FBQ2hDLGVBQU8sUUFBUSxRQUFRLElBQUksS0FBSyxDQUFDLEtBQUssZ0JBQWdCLENBQUMsQ0FBQztBQUFBLE1BQzFELFdBQVcsS0FBSyxlQUFlO0FBQzdCLGNBQU0sSUFBSSxNQUFNLHNDQUFzQztBQUFBLE1BQ3hELE9BQU87QUFDTCxlQUFPLFFBQVEsUUFBUSxJQUFJLEtBQUssQ0FBQyxLQUFLLFNBQVMsQ0FBQyxDQUFDO0FBQUEsTUFDbkQ7QUFBQSxJQUNGO0FBQUEsRUFDRjtBQUVBLE9BQUssY0FBYyxXQUFXO0FBQzVCLFFBQUksS0FBSyxrQkFBa0I7QUFDekIsVUFBSSxhQUFhLFNBQVMsSUFBSTtBQUM5QixVQUFJLFlBQVk7QUFDZCxlQUFPO0FBQUEsTUFDVCxXQUFXLFlBQVksT0FBTyxLQUFLLGdCQUFnQixHQUFHO0FBQ3BELGVBQU8sUUFBUTtBQUFBLFVBQ2IsS0FBSyxpQkFBaUIsT0FBTztBQUFBLFlBQzNCLEtBQUssaUJBQWlCO0FBQUEsWUFDdEIsS0FBSyxpQkFBaUIsYUFBYSxLQUFLLGlCQUFpQjtBQUFBLFVBQzNEO0FBQUEsUUFDRjtBQUFBLE1BQ0YsT0FBTztBQUNMLGVBQU8sUUFBUSxRQUFRLEtBQUssZ0JBQWdCO0FBQUEsTUFDOUM7QUFBQSxJQUNGLFdBQVcsUUFBUSxNQUFNO0FBQ3ZCLGFBQU8sS0FBSyxLQUFLLEVBQUUsS0FBSyxxQkFBcUI7QUFBQSxJQUMvQyxPQUFPO0FBQ0wsWUFBTSxJQUFJLE1BQU0sK0JBQStCO0FBQUEsSUFDakQ7QUFBQSxFQUNGO0FBRUEsT0FBSyxPQUFPLFdBQVc7QUFDckIsUUFBSSxXQUFXLFNBQVMsSUFBSTtBQUM1QixRQUFJLFVBQVU7QUFDWixhQUFPO0FBQUEsSUFDVDtBQUVBLFFBQUksS0FBSyxXQUFXO0FBQ2xCLGFBQU8sZUFBZSxLQUFLLFNBQVM7QUFBQSxJQUN0QyxXQUFXLEtBQUssa0JBQWtCO0FBQ2hDLGFBQU8sUUFBUSxRQUFRLHNCQUFzQixLQUFLLGdCQUFnQixDQUFDO0FBQUEsSUFDckUsV0FBVyxLQUFLLGVBQWU7QUFDN0IsWUFBTSxJQUFJLE1BQU0sc0NBQXNDO0FBQUEsSUFDeEQsT0FBTztBQUNMLGFBQU8sUUFBUSxRQUFRLEtBQUssU0FBUztBQUFBLElBQ3ZDO0FBQUEsRUFDRjtBQUVBLE1BQUksUUFBUSxVQUFVO0FBQ3BCLFNBQUssV0FBVyxXQUFXO0FBQ3pCLGFBQU8sS0FBSyxLQUFLLEVBQUUsS0FBSyxNQUFNO0FBQUEsSUFDaEM7QUFBQSxFQUNGO0FBRUEsT0FBSyxPQUFPLFdBQVc7QUFDckIsV0FBTyxLQUFLLEtBQUssRUFBRSxLQUFLLEtBQUssS0FBSztBQUFBLEVBQ3BDO0FBRUEsU0FBTztBQUNUO0FBR0EsSUFBSSxVQUFVLENBQUMsV0FBVyxVQUFVLE9BQU8sUUFBUSxXQUFXLFNBQVMsUUFBUSxPQUFPLE9BQU87QUFFN0YsU0FBUyxnQkFBZ0IsUUFBUTtBQUMvQixNQUFJLFVBQVUsT0FBTyxZQUFZO0FBQ2pDLFNBQU8sUUFBUSxRQUFRLE9BQU8sSUFBSSxLQUFLLFVBQVU7QUFDbkQ7QUFFTyxTQUFTLFFBQVEsT0FBTyxTQUFTO0FBQ3RDLE1BQUksRUFBRSxnQkFBZ0IsVUFBVTtBQUM5QixVQUFNLElBQUksVUFBVSw0RkFBNEY7QUFBQSxFQUNsSDtBQUVBLFlBQVUsV0FBVyxDQUFDO0FBQ3RCLE1BQUksT0FBTyxRQUFRO0FBRW5CLE1BQUksaUJBQWlCLFNBQVM7QUFDNUIsUUFBSSxNQUFNLFVBQVU7QUFDbEIsWUFBTSxJQUFJLFVBQVUsY0FBYztBQUFBLElBQ3BDO0FBQ0EsU0FBSyxNQUFNLE1BQU07QUFDakIsU0FBSyxjQUFjLE1BQU07QUFDekIsUUFBSSxDQUFDLFFBQVEsU0FBUztBQUNwQixXQUFLLFVBQVUsSUFBSSxRQUFRLE1BQU0sT0FBTztBQUFBLElBQzFDO0FBQ0EsU0FBSyxTQUFTLE1BQU07QUFDcEIsU0FBSyxPQUFPLE1BQU07QUFDbEIsU0FBSyxTQUFTLE1BQU07QUFDcEIsUUFBSSxDQUFDLFFBQVEsTUFBTSxhQUFhLE1BQU07QUFDcEMsYUFBTyxNQUFNO0FBQ2IsWUFBTSxXQUFXO0FBQUEsSUFDbkI7QUFBQSxFQUNGLE9BQU87QUFDTCxTQUFLLE1BQU0sT0FBTyxLQUFLO0FBQUEsRUFDekI7QUFFQSxPQUFLLGNBQWMsUUFBUSxlQUFlLEtBQUssZUFBZTtBQUM5RCxNQUFJLFFBQVEsV0FBVyxDQUFDLEtBQUssU0FBUztBQUNwQyxTQUFLLFVBQVUsSUFBSSxRQUFRLFFBQVEsT0FBTztBQUFBLEVBQzVDO0FBQ0EsT0FBSyxTQUFTLGdCQUFnQixRQUFRLFVBQVUsS0FBSyxVQUFVLEtBQUs7QUFDcEUsT0FBSyxPQUFPLFFBQVEsUUFBUSxLQUFLLFFBQVE7QUFDekMsT0FBSyxTQUFTLFFBQVEsVUFBVSxLQUFLLFVBQVcsV0FBWTtBQUMxRCxRQUFJLHFCQUFxQixHQUFHO0FBQzFCLFVBQUksT0FBTyxJQUFJLGdCQUFnQjtBQUMvQixhQUFPLEtBQUs7QUFBQSxJQUNkO0FBQUEsRUFDRixFQUFFO0FBQ0YsT0FBSyxXQUFXO0FBRWhCLE9BQUssS0FBSyxXQUFXLFNBQVMsS0FBSyxXQUFXLFdBQVcsTUFBTTtBQUM3RCxVQUFNLElBQUksVUFBVSwyQ0FBMkM7QUFBQSxFQUNqRTtBQUNBLE9BQUssVUFBVSxJQUFJO0FBRW5CLE1BQUksS0FBSyxXQUFXLFNBQVMsS0FBSyxXQUFXLFFBQVE7QUFDbkQsUUFBSSxRQUFRLFVBQVUsY0FBYyxRQUFRLFVBQVUsWUFBWTtBQUVoRSxVQUFJLGdCQUFnQjtBQUNwQixVQUFJLGNBQWMsS0FBSyxLQUFLLEdBQUcsR0FBRztBQUVoQyxhQUFLLE1BQU0sS0FBSyxJQUFJLFFBQVEsZUFBZSxVQUFTLG9CQUFJLEtBQUssR0FBRSxRQUFRLENBQUM7QUFBQSxNQUMxRSxPQUFPO0FBRUwsWUFBSSxnQkFBZ0I7QUFDcEIsYUFBSyxRQUFRLGNBQWMsS0FBSyxLQUFLLEdBQUcsSUFBSSxNQUFNLE9BQU8sUUFBTyxvQkFBSSxLQUFLLEdBQUUsUUFBUTtBQUFBLE1BQ3JGO0FBQUEsSUFDRjtBQUFBLEVBQ0Y7QUFDRjtBQUVBLFFBQVEsVUFBVSxRQUFRLFdBQVc7QUFDbkMsU0FBTyxJQUFJLFFBQVEsTUFBTSxFQUFDLE1BQU0sS0FBSyxVQUFTLENBQUM7QUFDakQ7QUFFQSxTQUFTLE9BQU8sTUFBTTtBQUNwQixNQUFJLE9BQU8sSUFBSSxTQUFTO0FBQ3hCLE9BQ0csS0FBSyxFQUNMLE1BQU0sR0FBRyxFQUNULFFBQVEsU0FBUyxPQUFPO0FBQ3ZCLFFBQUksT0FBTztBQUNULFVBQUksUUFBUSxNQUFNLE1BQU0sR0FBRztBQUMzQixVQUFJLE9BQU8sTUFBTSxNQUFNLEVBQUUsUUFBUSxPQUFPLEdBQUc7QUFDM0MsVUFBSSxRQUFRLE1BQU0sS0FBSyxHQUFHLEVBQUUsUUFBUSxPQUFPLEdBQUc7QUFDOUMsV0FBSyxPQUFPLG1CQUFtQixJQUFJLEdBQUcsbUJBQW1CLEtBQUssQ0FBQztBQUFBLElBQ2pFO0FBQUEsRUFDRixDQUFDO0FBQ0gsU0FBTztBQUNUO0FBRUEsU0FBUyxhQUFhLFlBQVk7QUFDaEMsTUFBSSxVQUFVLElBQUksUUFBUTtBQUcxQixNQUFJLHNCQUFzQixXQUFXLFFBQVEsZ0JBQWdCLEdBQUc7QUFJaEUsc0JBQ0csTUFBTSxJQUFJLEVBQ1YsSUFBSSxTQUFTLFFBQVE7QUFDcEIsV0FBTyxPQUFPLFFBQVEsSUFBSSxNQUFNLElBQUksT0FBTyxPQUFPLEdBQUcsT0FBTyxNQUFNLElBQUk7QUFBQSxFQUN4RSxDQUFDLEVBQ0EsUUFBUSxTQUFTLE1BQU07QUFDdEIsUUFBSSxRQUFRLEtBQUssTUFBTSxHQUFHO0FBQzFCLFFBQUksTUFBTSxNQUFNLE1BQU0sRUFBRSxLQUFLO0FBQzdCLFFBQUksS0FBSztBQUNQLFVBQUksUUFBUSxNQUFNLEtBQUssR0FBRyxFQUFFLEtBQUs7QUFDakMsVUFBSTtBQUNGLGdCQUFRLE9BQU8sS0FBSyxLQUFLO0FBQUEsTUFDM0IsU0FBUyxPQUFPO0FBQ2QsZ0JBQVEsS0FBSyxjQUFjLE1BQU0sT0FBTztBQUFBLE1BQzFDO0FBQUEsSUFDRjtBQUFBLEVBQ0YsQ0FBQztBQUNILFNBQU87QUFDVDtBQUVBLEtBQUssS0FBSyxRQUFRLFNBQVM7QUFFcEIsU0FBUyxTQUFTLFVBQVUsU0FBUztBQUMxQyxNQUFJLEVBQUUsZ0JBQWdCLFdBQVc7QUFDL0IsVUFBTSxJQUFJLFVBQVUsNEZBQTRGO0FBQUEsRUFDbEg7QUFDQSxNQUFJLENBQUMsU0FBUztBQUNaLGNBQVUsQ0FBQztBQUFBLEVBQ2I7QUFFQSxPQUFLLE9BQU87QUFDWixPQUFLLFNBQVMsUUFBUSxXQUFXLFNBQVksTUFBTSxRQUFRO0FBQzNELE1BQUksS0FBSyxTQUFTLE9BQU8sS0FBSyxTQUFTLEtBQUs7QUFDMUMsVUFBTSxJQUFJLFdBQVcsMEZBQTBGO0FBQUEsRUFDakg7QUFDQSxPQUFLLEtBQUssS0FBSyxVQUFVLE9BQU8sS0FBSyxTQUFTO0FBQzlDLE9BQUssYUFBYSxRQUFRLGVBQWUsU0FBWSxLQUFLLEtBQUssUUFBUTtBQUN2RSxPQUFLLFVBQVUsSUFBSSxRQUFRLFFBQVEsT0FBTztBQUMxQyxPQUFLLE1BQU0sUUFBUSxPQUFPO0FBQzFCLE9BQUssVUFBVSxRQUFRO0FBQ3pCO0FBRUEsS0FBSyxLQUFLLFNBQVMsU0FBUztBQUU1QixTQUFTLFVBQVUsUUFBUSxXQUFXO0FBQ3BDLFNBQU8sSUFBSSxTQUFTLEtBQUssV0FBVztBQUFBLElBQ2xDLFFBQVEsS0FBSztBQUFBLElBQ2IsWUFBWSxLQUFLO0FBQUEsSUFDakIsU0FBUyxJQUFJLFFBQVEsS0FBSyxPQUFPO0FBQUEsSUFDakMsS0FBSyxLQUFLO0FBQUEsRUFDWixDQUFDO0FBQ0g7QUFFQSxTQUFTLFFBQVEsV0FBVztBQUMxQixNQUFJLFdBQVcsSUFBSSxTQUFTLE1BQU0sRUFBQyxRQUFRLEtBQUssWUFBWSxHQUFFLENBQUM7QUFDL0QsV0FBUyxLQUFLO0FBQ2QsV0FBUyxTQUFTO0FBQ2xCLFdBQVMsT0FBTztBQUNoQixTQUFPO0FBQ1Q7QUFFQSxJQUFJLG1CQUFtQixDQUFDLEtBQUssS0FBSyxLQUFLLEtBQUssR0FBRztBQUUvQyxTQUFTLFdBQVcsU0FBUyxLQUFLLFFBQVE7QUFDeEMsTUFBSSxpQkFBaUIsUUFBUSxNQUFNLE1BQU0sSUFBSTtBQUMzQyxVQUFNLElBQUksV0FBVyxxQkFBcUI7QUFBQSxFQUM1QztBQUVBLFNBQU8sSUFBSSxTQUFTLE1BQU0sRUFBQyxRQUFnQixTQUFTLEVBQUMsVUFBVSxJQUFHLEVBQUMsQ0FBQztBQUN0RTtBQUVPLElBQUksZUFBZSxFQUFFO0FBQzVCLElBQUk7QUFDRixNQUFJLGFBQWE7QUFDbkIsU0FBUyxLQUFLO0FBQ1osaUJBQWUsU0FBUyxTQUFTLE1BQU07QUFDckMsU0FBSyxVQUFVO0FBQ2YsU0FBSyxPQUFPO0FBQ1osUUFBSSxRQUFRLE1BQU0sT0FBTztBQUN6QixTQUFLLFFBQVEsTUFBTTtBQUFBLEVBQ3JCO0FBQ0EsZUFBYSxZQUFZLE9BQU8sT0FBTyxNQUFNLFNBQVM7QUFDdEQsZUFBYSxVQUFVLGNBQWM7QUFDdkM7QUFFTyxTQUFTQSxPQUFNLE9BQU8sTUFBTTtBQUNqQyxTQUFPLElBQUksUUFBUSxTQUFTLFNBQVMsUUFBUTtBQUMzQyxRQUFJLFVBQVUsSUFBSSxRQUFRLE9BQU8sSUFBSTtBQUVyQyxRQUFJLFFBQVEsVUFBVSxRQUFRLE9BQU8sU0FBUztBQUM1QyxhQUFPLE9BQU8sSUFBSSxhQUFhLFdBQVcsWUFBWSxDQUFDO0FBQUEsSUFDekQ7QUFFQSxRQUFJLE1BQU0sSUFBSSxlQUFlO0FBRTdCLGFBQVMsV0FBVztBQUNsQixVQUFJLE1BQU07QUFBQSxJQUNaO0FBRUEsUUFBSSxTQUFTLFdBQVc7QUFDdEIsVUFBSSxVQUFVO0FBQUEsUUFDWixZQUFZLElBQUk7QUFBQSxRQUNoQixTQUFTLGFBQWEsSUFBSSxzQkFBc0IsS0FBSyxFQUFFO0FBQUEsTUFDekQ7QUFHQSxVQUFJLFFBQVEsSUFBSSxRQUFRLFNBQVMsTUFBTSxNQUFNLElBQUksU0FBUyxPQUFPLElBQUksU0FBUyxNQUFNO0FBQ2xGLGdCQUFRLFNBQVM7QUFBQSxNQUNuQixPQUFPO0FBQ0wsZ0JBQVEsU0FBUyxJQUFJO0FBQUEsTUFDdkI7QUFDQSxjQUFRLE1BQU0saUJBQWlCLE1BQU0sSUFBSSxjQUFjLFFBQVEsUUFBUSxJQUFJLGVBQWU7QUFDMUYsVUFBSSxPQUFPLGNBQWMsTUFBTSxJQUFJLFdBQVcsSUFBSTtBQUNsRCxpQkFBVyxXQUFXO0FBQ3BCLGdCQUFRLElBQUksU0FBUyxNQUFNLE9BQU8sQ0FBQztBQUFBLE1BQ3JDLEdBQUcsQ0FBQztBQUFBLElBQ047QUFFQSxRQUFJLFVBQVUsV0FBVztBQUN2QixpQkFBVyxXQUFXO0FBQ3BCLGVBQU8sSUFBSSxVQUFVLHdCQUF3QixDQUFDO0FBQUEsTUFDaEQsR0FBRyxDQUFDO0FBQUEsSUFDTjtBQUVBLFFBQUksWUFBWSxXQUFXO0FBQ3pCLGlCQUFXLFdBQVc7QUFDcEIsZUFBTyxJQUFJLFVBQVUsMkJBQTJCLENBQUM7QUFBQSxNQUNuRCxHQUFHLENBQUM7QUFBQSxJQUNOO0FBRUEsUUFBSSxVQUFVLFdBQVc7QUFDdkIsaUJBQVcsV0FBVztBQUNwQixlQUFPLElBQUksYUFBYSxXQUFXLFlBQVksQ0FBQztBQUFBLE1BQ2xELEdBQUcsQ0FBQztBQUFBLElBQ047QUFFQSxhQUFTLE9BQU8sS0FBSztBQUNuQixVQUFJO0FBQ0YsZUFBTyxRQUFRLE1BQU0sRUFBRSxTQUFTLE9BQU8sRUFBRSxTQUFTLE9BQU87QUFBQSxNQUMzRCxTQUFTLEdBQUc7QUFDVixlQUFPO0FBQUEsTUFDVDtBQUFBLElBQ0Y7QUFFQSxRQUFJLEtBQUssUUFBUSxRQUFRLE9BQU8sUUFBUSxHQUFHLEdBQUcsSUFBSTtBQUVsRCxRQUFJLFFBQVEsZ0JBQWdCLFdBQVc7QUFDckMsVUFBSSxrQkFBa0I7QUFBQSxJQUN4QixXQUFXLFFBQVEsZ0JBQWdCLFFBQVE7QUFDekMsVUFBSSxrQkFBa0I7QUFBQSxJQUN4QjtBQUVBLFFBQUksa0JBQWtCLEtBQUs7QUFDekIsVUFBSSxRQUFRLE1BQU07QUFDaEIsWUFBSSxlQUFlO0FBQUEsTUFDckIsV0FDRSxRQUFRLGFBQ1I7QUFDQSxZQUFJLGVBQWU7QUFBQSxNQUNyQjtBQUFBLElBQ0Y7QUFFQSxRQUFJLFFBQVEsT0FBTyxLQUFLLFlBQVksWUFBWSxFQUFFLEtBQUssbUJBQW1CLFdBQVksRUFBRSxXQUFXLEtBQUssbUJBQW1CLEVBQUUsVUFBVztBQUN0SSxVQUFJLFFBQVEsQ0FBQztBQUNiLGFBQU8sb0JBQW9CLEtBQUssT0FBTyxFQUFFLFFBQVEsU0FBUyxNQUFNO0FBQzlELGNBQU0sS0FBSyxjQUFjLElBQUksQ0FBQztBQUM5QixZQUFJLGlCQUFpQixNQUFNLGVBQWUsS0FBSyxRQUFRLElBQUksQ0FBQyxDQUFDO0FBQUEsTUFDL0QsQ0FBQztBQUNELGNBQVEsUUFBUSxRQUFRLFNBQVMsT0FBTyxNQUFNO0FBQzVDLFlBQUksTUFBTSxRQUFRLElBQUksTUFBTSxJQUFJO0FBQzlCLGNBQUksaUJBQWlCLE1BQU0sS0FBSztBQUFBLFFBQ2xDO0FBQUEsTUFDRixDQUFDO0FBQUEsSUFDSCxPQUFPO0FBQ0wsY0FBUSxRQUFRLFFBQVEsU0FBUyxPQUFPLE1BQU07QUFDNUMsWUFBSSxpQkFBaUIsTUFBTSxLQUFLO0FBQUEsTUFDbEMsQ0FBQztBQUFBLElBQ0g7QUFFQSxRQUFJLFFBQVEsUUFBUTtBQUNsQixjQUFRLE9BQU8saUJBQWlCLFNBQVMsUUFBUTtBQUVqRCxVQUFJLHFCQUFxQixXQUFXO0FBRWxDLFlBQUksSUFBSSxlQUFlLEdBQUc7QUFDeEIsa0JBQVEsT0FBTyxvQkFBb0IsU0FBUyxRQUFRO0FBQUEsUUFDdEQ7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUVBLFFBQUksS0FBSyxPQUFPLFFBQVEsY0FBYyxjQUFjLE9BQU8sUUFBUSxTQUFTO0FBQUEsRUFDOUUsQ0FBQztBQUNIO0FBRUFBLE9BQU0sV0FBVztBQUVqQixJQUFJLENBQUMsRUFBRSxPQUFPO0FBQ1osSUFBRSxRQUFRQTtBQUNWLElBQUUsVUFBVTtBQUNaLElBQUUsVUFBVTtBQUNaLElBQUUsV0FBVztBQUNmOzs7QUMvbkJBLElBQU0sVUFBVTtBQUVoQixJQUFJLGNBQWMsT0FBTztBQUN6QixJQUFJLG9CQUFvQixDQUFDLEtBQUssS0FBSyxVQUFVLE9BQU8sTUFBTSxZQUFZLEtBQUssS0FBSyxFQUFFLFlBQVksTUFBTSxjQUFjLE1BQU0sVUFBVSxNQUFNLE1BQU0sQ0FBQyxJQUFJLElBQUksR0FBRyxJQUFJO0FBQzlKLElBQUksa0JBQWtCLENBQUMsS0FBSyxLQUFLLFVBQVU7QUFDekMsb0JBQWtCLEtBQUssT0FBTyxRQUFRLFdBQVcsTUFBTSxLQUFLLEtBQUssS0FBSztBQUN0RSxTQUFPO0FBQ1Q7QUFDQSxJQUFNLGdCQUFOLE1BQU0sdUJBQXNCLE1BQU07QUFBQSxFQUNoQyxZQUFZLE9BQU8sYUFBYTtBQUM5QixVQUFNLEtBQUs7QUFDWCxTQUFLLFFBQVE7QUFDYixTQUFLLGNBQWM7QUFDbkIsU0FBSyxPQUFPO0FBQ1osUUFBSSxNQUFNLG1CQUFtQjtBQUMzQixZQUFNLGtCQUFrQixNQUFNLGNBQWE7QUFBQSxJQUM3QztBQUFBLEVBQ0Y7QUFDRjtBQUNBLElBQU0seUJBQU4sTUFBNkI7QUFBQSxFQUMzQixZQUFZLGlCQUFpQixLQUFLLGNBQWM7QUFDOUMsb0JBQWdCLE1BQU0saUJBQWlCO0FBQ3ZDLG9CQUFnQixNQUFNLEtBQUs7QUFDM0Isb0JBQWdCLE1BQU0sY0FBYztBQUNwQyxTQUFLLGtCQUFrQjtBQUN2QixTQUFLLE1BQU07QUFDWCxTQUFLLGVBQWU7QUFBQSxFQUN0QjtBQUFBLEVBQ0EsUUFBUTtBQUNOLFNBQUssZ0JBQWdCLE1BQU07QUFBQSxFQUM3QjtBQUFBLEVBQ0EsUUFBUSxPQUFPLGFBQWEsSUFBSTtBQUM5QixxQkFBaUIsV0FBVyxLQUFLLEtBQUs7QUFDcEMsVUFBSSxXQUFXLFNBQVM7QUFDdEIsY0FBTSxJQUFJLE1BQU0sUUFBUSxLQUFLO0FBQUEsTUFDL0I7QUFDQSxZQUFNO0FBQ04sVUFBSSxRQUFRLFFBQVEsUUFBUSxXQUFXLFdBQVc7QUFDaEQsYUFBSyxhQUFhO0FBQ2xCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxVQUFNLElBQUksTUFBTSxxREFBcUQ7QUFBQSxFQUN2RTtBQUNGO0FBQ0EsSUFBTSxVQUFVLE9BQU8sYUFBYTtBQUNsQyxNQUFJLFNBQVMsSUFBSTtBQUNmO0FBQUEsRUFDRjtBQUNBLE1BQUksVUFBVSxTQUFTLFNBQVMsTUFBTSxLQUFLLFNBQVMsVUFBVTtBQUM5RCxNQUFJLFlBQVk7QUFDaEIsTUFBSSxTQUFTLFFBQVEsSUFBSSxjQUFjLEdBQUcsU0FBUyxrQkFBa0IsR0FBRztBQUN0RSxRQUFJO0FBQ0Ysa0JBQVksTUFBTSxTQUFTLEtBQUs7QUFDaEMsZ0JBQVUsVUFBVSxTQUFTO0FBQUEsSUFDL0IsU0FBUyxPQUFPO0FBQ2QsY0FBUSxJQUFJLHdDQUF3QztBQUFBLElBQ3REO0FBQUEsRUFDRixPQUFPO0FBQ0wsUUFBSTtBQUNGLGNBQVEsSUFBSSw0QkFBNEI7QUFDeEMsWUFBTSxlQUFlLE1BQU0sU0FBUyxLQUFLO0FBQ3pDLGdCQUFVLGdCQUFnQjtBQUFBLElBQzVCLFNBQVMsT0FBTztBQUNkLGNBQVEsSUFBSSx3Q0FBd0M7QUFBQSxJQUN0RDtBQUFBLEVBQ0Y7QUFDQSxRQUFNLElBQUksY0FBYyxTQUFTLFNBQVMsTUFBTTtBQUNsRDtBQUNBLFNBQVMsY0FBYztBQUNyQixNQUFJLE9BQU8sV0FBVyxlQUFlLE9BQU8sV0FBVztBQUNyRCxXQUFPLEdBQUcsT0FBTyxVQUFVLFNBQVMsWUFBWSxDQUFDLFlBQVksVUFBVSxTQUFTO0FBQUEsRUFDbEYsV0FBVyxPQUFPLFlBQVksYUFBYTtBQUN6QyxXQUFPLEdBQUcsUUFBUSxJQUFJLElBQUksUUFBUSxRQUFRLFlBQVksUUFBUSxPQUFPO0FBQUEsRUFDdkU7QUFDQSxTQUFPO0FBQ1Q7QUFDQSxJQUFNLG1CQUFtQixPQUFPQyxRQUFPLEtBQUssVUFBVSxDQUFDLE1BQU07QUFDM0QsUUFBTSxpQkFBaUI7QUFBQSxJQUNyQixnQkFBZ0I7QUFBQSxJQUNoQixRQUFRO0FBQUEsSUFDUixjQUFjLGFBQWEsT0FBTyxLQUFLLFlBQVksQ0FBQztBQUFBLEVBQ3REO0FBQ0EsTUFBSSxDQUFDLFFBQVEsU0FBUztBQUNwQixZQUFRLFVBQVUsQ0FBQztBQUFBLEVBQ3JCO0FBQ0EsVUFBUSxVQUFVO0FBQUEsSUFDaEIsR0FBRztBQUFBLElBQ0gsR0FBRyxRQUFRO0FBQUEsRUFDYjtBQUNBLFNBQU9BLE9BQU0sS0FBSyxPQUFPO0FBQzNCO0FBQ0EsSUFBTSxNQUFNLE9BQU9BLFFBQU8sU0FBUztBQUNqQyxRQUFNLFdBQVcsTUFBTSxpQkFBaUJBLFFBQU8sSUFBSTtBQUNuRCxRQUFNLFFBQVEsUUFBUTtBQUN0QixTQUFPO0FBQ1Q7QUFRQSxJQUFNLE9BQU8sT0FBT0MsUUFBTyxNQUFNLE1BQU0sWUFBWTtBQUNqRCxRQUFNLFdBQVcsQ0FBQyxVQUFVO0FBQzFCLFdBQU8sVUFBVSxRQUFRLE9BQU8sVUFBVSxZQUFZLENBQUMsTUFBTSxRQUFRLEtBQUs7QUFBQSxFQUM1RTtBQUNBLFFBQU0sZ0JBQWdCLFNBQVMsSUFBSSxJQUFJLEtBQUssVUFBVSxJQUFJLElBQUk7QUFDOUQsUUFBTSxXQUFXLE1BQU0saUJBQWlCQSxRQUFPLE1BQU07QUFBQSxJQUNuRCxRQUFRO0FBQUEsSUFDUixNQUFNO0FBQUEsSUFDTixRQUFRLFNBQVM7QUFBQSxJQUNqQixTQUFTLFNBQVM7QUFBQSxFQUNwQixDQUFDO0FBQ0QsUUFBTSxRQUFRLFFBQVE7QUFDdEIsU0FBTztBQUNUO0FBQ0EsSUFBTSxNQUFNLE9BQU9BLFFBQU8sTUFBTSxTQUFTO0FBQ3ZDLFFBQU0sV0FBVyxNQUFNLGlCQUFpQkEsUUFBTyxNQUFNO0FBQUEsSUFDbkQsUUFBUTtBQUFBLElBQ1IsTUFBTSxLQUFLLFVBQVUsSUFBSTtBQUFBLEVBQzNCLENBQUM7QUFDRCxRQUFNLFFBQVEsUUFBUTtBQUN0QixTQUFPO0FBQ1Q7QUFDQSxJQUFNLFlBQVksaUJBQWlCLEtBQUs7QUFDdEMsUUFBTSxVQUFVLElBQUksWUFBWSxPQUFPO0FBQ3ZDLE1BQUksU0FBUztBQUNiLFFBQU0sU0FBUyxJQUFJLFVBQVU7QUFDN0IsU0FBTyxNQUFNO0FBQ1gsVUFBTSxFQUFFLE1BQU0sT0FBTyxNQUFNLElBQUksTUFBTSxPQUFPLEtBQUs7QUFDakQsUUFBSSxNQUFNO0FBQ1I7QUFBQSxJQUNGO0FBQ0EsY0FBVSxRQUFRLE9BQU8sS0FBSztBQUM5QixVQUFNLFFBQVEsT0FBTyxNQUFNLElBQUk7QUFDL0IsYUFBUyxNQUFNLElBQUksS0FBSztBQUN4QixlQUFXLFFBQVEsT0FBTztBQUN4QixVQUFJO0FBQ0YsY0FBTSxLQUFLLE1BQU0sSUFBSTtBQUFBLE1BQ3ZCLFNBQVMsT0FBTztBQUNkLGdCQUFRLEtBQUssa0JBQWtCLElBQUk7QUFBQSxNQUNyQztBQUFBLElBQ0Y7QUFBQSxFQUNGO0FBQ0EsYUFBVyxRQUFRLE9BQU8sTUFBTSxJQUFJLEVBQUUsT0FBTyxDQUFDLE1BQU0sTUFBTSxFQUFFLEdBQUc7QUFDN0QsUUFBSTtBQUNGLFlBQU0sS0FBSyxNQUFNLElBQUk7QUFBQSxJQUN2QixTQUFTLE9BQU87QUFDZCxjQUFRLEtBQUssa0JBQWtCLElBQUk7QUFBQSxJQUNyQztBQUFBLEVBQ0Y7QUFDRjtBQUNBLElBQU0sYUFBYSxDQUFDLFNBQVM7QUFDM0IsTUFBSSxDQUFDLE1BQU07QUFDVCxXQUFPO0FBQUEsRUFDVDtBQUNBLE1BQUkscUJBQXFCLEtBQUssU0FBUyxLQUFLO0FBQzVDLE1BQUksS0FBSyxXQUFXLEdBQUcsR0FBRztBQUN4QixXQUFPLG1CQUFtQixJQUFJO0FBQzlCLHlCQUFxQjtBQUFBLEVBQ3ZCO0FBQ0EsTUFBSSxDQUFDLG9CQUFvQjtBQUN2QixXQUFPLFVBQVUsSUFBSTtBQUFBLEVBQ3ZCO0FBQ0EsUUFBTSxNQUFNLElBQUksSUFBSSxJQUFJO0FBQ3hCLE1BQUksT0FBTyxJQUFJO0FBQ2YsTUFBSSxDQUFDLE1BQU07QUFDVCxRQUFJLENBQUMsb0JBQW9CO0FBQ3ZCLGFBQU87QUFBQSxJQUNULE9BQU87QUFDTCxhQUFPLElBQUksYUFBYSxXQUFXLFFBQVE7QUFBQSxJQUM3QztBQUFBLEVBQ0Y7QUFDQSxNQUFJLGdCQUFnQixHQUFHLElBQUksUUFBUSxLQUFLLElBQUksUUFBUSxJQUFJLElBQUksR0FBRyxJQUFJLFFBQVE7QUFDM0UsTUFBSSxjQUFjLFNBQVMsR0FBRyxHQUFHO0FBQy9CLG9CQUFnQixjQUFjLE1BQU0sR0FBRyxFQUFFO0FBQUEsRUFDM0M7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxJQUFJLFlBQVksT0FBTztBQUN2QixJQUFJLGtCQUFrQixDQUFDLEtBQUssS0FBSyxVQUFVLE9BQU8sTUFBTSxVQUFVLEtBQUssS0FBSyxFQUFFLFlBQVksTUFBTSxjQUFjLE1BQU0sVUFBVSxNQUFNLE1BQU0sQ0FBQyxJQUFJLElBQUksR0FBRyxJQUFJO0FBQzFKLElBQUksZ0JBQWdCLENBQUMsS0FBSyxLQUFLLFVBQVU7QUFDdkMsa0JBQWdCLEtBQUssT0FBTyxRQUFRLFdBQVcsTUFBTSxLQUFLLEtBQUssS0FBSztBQUNwRSxTQUFPO0FBQ1Q7QUFDQSxJQUFJLFdBQVcsTUFBTSxPQUFPO0FBQUEsRUFDMUIsWUFBWSxRQUFRO0FBQ2xCLGtCQUFjLE1BQU0sUUFBUTtBQUM1QixrQkFBYyxNQUFNLE9BQU87QUFDM0Isa0JBQWMsTUFBTSwyQkFBMkIsQ0FBQyxDQUFDO0FBQ2pELFNBQUssU0FBUztBQUFBLE1BQ1osTUFBTTtBQUFBLElBQ1I7QUFDQSxRQUFJLENBQUMsUUFBUSxPQUFPO0FBQ2xCLFdBQUssT0FBTyxPQUFPLFdBQVcsUUFBUSxRQUFRLHdCQUF3QjtBQUFBLElBQ3hFO0FBQ0EsU0FBSyxRQUFRO0FBQ2IsUUFBSSxRQUFRLFNBQVMsTUFBTTtBQUN6QixXQUFLLFFBQVEsT0FBTztBQUFBLElBQ3RCO0FBQUEsRUFDRjtBQUFBO0FBQUEsRUFFQSxRQUFRO0FBQ04sZUFBVyxXQUFXLEtBQUsseUJBQXlCO0FBQ2xELGNBQVEsTUFBTTtBQUFBLElBQ2hCO0FBQ0EsU0FBSyx3QkFBd0IsU0FBUztBQUFBLEVBQ3hDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBWUEsTUFBTSx5QkFBeUIsVUFBVSxTQUFTO0FBQ2hELFlBQVEsU0FBUyxRQUFRLFVBQVU7QUFDbkMsVUFBTSxPQUFPLEdBQUcsS0FBSyxPQUFPLElBQUksUUFBUSxRQUFRO0FBQ2hELFFBQUksUUFBUSxRQUFRO0FBQ2xCLFlBQU0sa0JBQWtCLElBQUksZ0JBQWdCO0FBQzVDLFlBQU0sWUFBWSxNQUFNLEtBQUssS0FBSyxPQUFPLE1BQU0sU0FBUztBQUFBLFFBQ3RELFFBQVEsZ0JBQWdCO0FBQUEsUUFDeEIsU0FBUyxLQUFLLE9BQU87QUFBQSxNQUN2QixDQUFDO0FBQ0QsVUFBSSxDQUFDLFVBQVUsTUFBTTtBQUNuQixjQUFNLElBQUksTUFBTSxjQUFjO0FBQUEsTUFDaEM7QUFDQSxZQUFNLE1BQU0sVUFBVSxVQUFVLElBQUk7QUFDcEMsWUFBTSx5QkFBeUIsSUFBSTtBQUFBLFFBQ2pDO0FBQUEsUUFDQTtBQUFBLFFBQ0EsTUFBTTtBQUNKLGdCQUFNLElBQUksS0FBSyx3QkFBd0IsUUFBUSxzQkFBc0I7QUFDckUsY0FBSSxJQUFJLElBQUk7QUFDVixpQkFBSyx3QkFBd0IsT0FBTyxHQUFHLENBQUM7QUFBQSxVQUMxQztBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQ0EsV0FBSyx3QkFBd0IsS0FBSyxzQkFBc0I7QUFDeEQsYUFBTztBQUFBLElBQ1Q7QUFDQSxVQUFNLFdBQVcsTUFBTSxLQUFLLEtBQUssT0FBTyxNQUFNLFNBQVM7QUFBQSxNQUNyRCxTQUFTLEtBQUssT0FBTztBQUFBLElBQ3ZCLENBQUM7QUFDRCxXQUFPLE1BQU0sU0FBUyxLQUFLO0FBQUEsRUFDN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLFlBQVksT0FBTztBQUN2QixRQUFJLE9BQU8sVUFBVSxVQUFVO0FBQzdCLFlBQU0sYUFBYSxJQUFJLFdBQVcsS0FBSztBQUN2QyxVQUFJLGFBQWE7QUFDakIsWUFBTSxNQUFNLFdBQVc7QUFDdkIsZUFBUyxJQUFJLEdBQUcsSUFBSSxLQUFLLEtBQUs7QUFDNUIsc0JBQWMsT0FBTyxhQUFhLFdBQVcsQ0FBQyxDQUFDO0FBQUEsTUFDakQ7QUFDQSxhQUFPLEtBQUssVUFBVTtBQUFBLElBQ3hCO0FBQ0EsV0FBTztBQUFBLEVBQ1Q7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLE1BQU0sU0FBUyxTQUFTO0FBQ3RCLFFBQUksUUFBUSxRQUFRO0FBQ2xCLGNBQVEsU0FBUyxNQUFNLFFBQVEsSUFBSSxRQUFRLE9BQU8sSUFBSSxLQUFLLFlBQVksS0FBSyxJQUFJLENBQUMsQ0FBQztBQUFBLElBQ3BGO0FBQ0EsV0FBTyxLQUFLLHlCQUF5QixZQUFZLE9BQU87QUFBQSxFQUMxRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVNBLE1BQU0sS0FBSyxTQUFTO0FBQ2xCLFFBQUksUUFBUSxVQUFVO0FBQ3BCLGlCQUFXLFdBQVcsUUFBUSxVQUFVO0FBQ3RDLFlBQUksUUFBUSxRQUFRO0FBQ2xCLGtCQUFRLFNBQVMsTUFBTSxRQUFRO0FBQUEsWUFDN0IsUUFBUSxPQUFPLElBQUksS0FBSyxZQUFZLEtBQUssSUFBSSxDQUFDO0FBQUEsVUFDaEQ7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFDQSxXQUFPLEtBQUsseUJBQXlCLFFBQVEsT0FBTztBQUFBLEVBQ3REO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsTUFBTSxPQUFPLFNBQVM7QUFDcEIsV0FBTyxLQUFLLHlCQUF5QixVQUFVO0FBQUEsTUFDN0MsTUFBTSxRQUFRO0FBQUEsTUFDZCxRQUFRLFFBQVE7QUFBQSxNQUNoQixXQUFXLFFBQVE7QUFBQSxNQUNuQixVQUFVLFFBQVE7QUFBQSxJQUNwQixDQUFDO0FBQUEsRUFDSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFRQSxNQUFNLEtBQUssU0FBUztBQUNsQixXQUFPLEtBQUsseUJBQXlCLFFBQVE7QUFBQSxNQUMzQyxNQUFNLFFBQVE7QUFBQSxNQUNkLFFBQVEsUUFBUTtBQUFBLE1BQ2hCLFVBQVUsUUFBUTtBQUFBLElBQ3BCLENBQUM7QUFBQSxFQUNIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQVFBLE1BQU0sS0FBSyxTQUFTO0FBQ2xCLFdBQU8sS0FBSyx5QkFBeUIsUUFBUTtBQUFBLE1BQzNDLE1BQU0sUUFBUTtBQUFBLE1BQ2QsUUFBUSxRQUFRO0FBQUEsTUFDaEIsVUFBVSxRQUFRO0FBQUEsSUFDcEIsQ0FBQztBQUFBLEVBQ0g7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU9BLE1BQU0sT0FBTyxTQUFTO0FBQ3BCLFVBQU0sSUFBSSxLQUFLLE9BQU8sR0FBRyxLQUFLLE9BQU8sSUFBSSxlQUFlO0FBQUEsTUFDdEQsTUFBTSxRQUFRO0FBQUEsSUFDaEIsQ0FBQztBQUNELFdBQU8sRUFBRSxRQUFRLFVBQVU7QUFBQSxFQUM3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBT0EsTUFBTSxLQUFLLFNBQVM7QUFDbEIsVUFBTSxLQUFLLEtBQUssT0FBTyxHQUFHLEtBQUssT0FBTyxJQUFJLGFBQWEsRUFBRSxHQUFHLFFBQVEsQ0FBQztBQUNyRSxXQUFPLEVBQUUsUUFBUSxVQUFVO0FBQUEsRUFDN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLE9BQU87QUFDWCxVQUFNLFdBQVcsTUFBTSxJQUFJLEtBQUssT0FBTyxHQUFHLEtBQUssT0FBTyxJQUFJLFdBQVc7QUFDckUsV0FBTyxNQUFNLFNBQVMsS0FBSztBQUFBLEVBQzdCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLEVBTUEsTUFBTSxLQUFLLFNBQVM7QUFDbEIsVUFBTSxXQUFXLE1BQU0sS0FBSyxLQUFLLE9BQU8sR0FBRyxLQUFLLE9BQU8sSUFBSSxhQUFhO0FBQUEsTUFDdEUsR0FBRztBQUFBLElBQ0wsQ0FBQztBQUNELFdBQU8sTUFBTSxTQUFTLEtBQUs7QUFBQSxFQUM3QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxFQU1BLE1BQU0sTUFBTSxTQUFTO0FBQ25CLFVBQU0sV0FBVyxNQUFNLEtBQUssS0FBSyxPQUFPLEdBQUcsS0FBSyxPQUFPLElBQUksY0FBYztBQUFBLE1BQ3ZFLEdBQUc7QUFBQSxJQUNMLENBQUM7QUFDRCxXQUFPLE1BQU0sU0FBUyxLQUFLO0FBQUEsRUFDN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLFdBQVcsU0FBUztBQUN4QixVQUFNLFdBQVcsTUFBTSxLQUFLLEtBQUssT0FBTyxHQUFHLEtBQUssT0FBTyxJQUFJLG1CQUFtQjtBQUFBLE1BQzVFLEdBQUc7QUFBQSxJQUNMLENBQUM7QUFDRCxXQUFPLE1BQU0sU0FBUyxLQUFLO0FBQUEsRUFDN0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsRUFNQSxNQUFNLEtBQUs7QUFDVCxVQUFNLFdBQVcsTUFBTSxJQUFJLEtBQUssT0FBTyxHQUFHLEtBQUssT0FBTyxJQUFJLFNBQVM7QUFDbkUsV0FBTyxNQUFNLFNBQVMsS0FBSztBQUFBLEVBQzdCO0FBQ0Y7QUFDQSxJQUFNLFVBQVUsSUFBSSxTQUFTOzs7QUZoYTdCLFNBQVMsZ0JBQWdCLFVBQTZDO0FBQ3BFLFNBQU8sU0FBUyxJQUFJLENBQUMsUUFBUTtBQUFBLElBQzNCLE1BQU0sR0FBRztBQUFBLElBQ1QsU0FBUyxHQUFHO0FBQUEsSUFDWixRQUFRLEdBQUcsYUFBYSxJQUFJLENBQUNDLFFBQU9BLElBQUcsR0FBRztBQUFBLEVBQzVDLEVBQUU7QUFDSjtBQUVBLGVBQXNCLFdBQVc7QUFDL0IsUUFBTSxPQUFPLE1BQU0sUUFBTyxLQUFLO0FBQy9CLFFBQWUsZUFBTSxpQkFBaUI7QUFBQSxJQUNwQyxNQUFNO0FBQUEsSUFDTixRQUFRLEtBQUssT0FBTyxJQUFJLENBQUMsUUFBUSxFQUFFLElBQUksR0FBRyxNQUFNLE1BQU0sR0FBRyxLQUFLLEVBQUU7QUFBQSxJQUNoRSxNQUFNLE9BQU8sT0FBTztBQUNsQixZQUFNLElBQUksTUFBTSxRQUFPLEtBQUs7QUFBQSxRQUMxQixPQUFPLE1BQU07QUFBQSxRQUNiLFVBQVUsZ0JBQWdCLE1BQU0sUUFBUTtBQUFBLE1BQzFDLENBQUM7QUFDRCxhQUFPO0FBQUEsUUFDTCxTQUFTLEVBQUUsUUFBUTtBQUFBLE1BQ3JCO0FBQUEsSUFDRjtBQUFBLElBQ0EsT0FBTyxPQUFPLE9BQU87QUFDbkIsWUFBTSxJQUFJLE1BQU0sUUFBTyxLQUFLO0FBQUEsUUFDMUIsT0FBTyxNQUFNO0FBQUEsUUFDYixVQUFVLGdCQUFnQixNQUFNLFFBQVE7QUFBQSxRQUN4QyxRQUFRO0FBQUEsTUFDVixDQUFDO0FBQ0QsdUJBQWlCLE1BQU0sR0FBRztBQUN4QixjQUFNO0FBQUEsVUFDSixTQUFTLEdBQUcsUUFBUTtBQUFBLFFBQ3RCO0FBQUEsTUFDRjtBQUFBLElBQ0Y7QUFBQSxFQUNGLENBQUM7QUFDSDsiLAogICJuYW1lcyI6IFsiZmV0Y2giLCAiZmV0Y2giLCAiZmV0Y2giLCAiaXQiXQp9Cg==

var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// src/index.ts
import * as novachat from "@novachat/plugin";

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/error.mjs
var error_exports = {};
__export(error_exports, {
  APIConnectionError: () => APIConnectionError,
  APIConnectionTimeoutError: () => APIConnectionTimeoutError,
  APIError: () => APIError,
  APIUserAbortError: () => APIUserAbortError,
  AnthropicError: () => AnthropicError,
  AuthenticationError: () => AuthenticationError,
  BadRequestError: () => BadRequestError,
  ConflictError: () => ConflictError,
  InternalServerError: () => InternalServerError,
  NotFoundError: () => NotFoundError,
  PermissionDeniedError: () => PermissionDeniedError,
  RateLimitError: () => RateLimitError,
  UnprocessableEntityError: () => UnprocessableEntityError
});

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/version.mjs
var VERSION = "0.28.0";

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/_shims/registry.mjs
var auto = false;
var kind = void 0;
var fetch2 = void 0;
var Request2 = void 0;
var Response2 = void 0;
var Headers2 = void 0;
var FormData2 = void 0;
var Blob2 = void 0;
var File2 = void 0;
var ReadableStream2 = void 0;
var getMultipartRequestOptions = void 0;
var getDefaultAgent = void 0;
var fileFromPath = void 0;
var isFsReadStream = void 0;
function setShims(shims, options = { auto: false }) {
  if (auto) {
    throw new Error(`you must \`import '@anthropic-ai/sdk/shims/${shims.kind}'\` before importing anything else from @anthropic-ai/sdk`);
  }
  if (kind) {
    throw new Error(`can't \`import '@anthropic-ai/sdk/shims/${shims.kind}'\` after \`import '@anthropic-ai/sdk/shims/${kind}'\``);
  }
  auto = options.auto;
  kind = shims.kind;
  fetch2 = shims.fetch;
  Request2 = shims.Request;
  Response2 = shims.Response;
  Headers2 = shims.Headers;
  FormData2 = shims.FormData;
  Blob2 = shims.Blob;
  File2 = shims.File;
  ReadableStream2 = shims.ReadableStream;
  getMultipartRequestOptions = shims.getMultipartRequestOptions;
  getDefaultAgent = shims.getDefaultAgent;
  fileFromPath = shims.fileFromPath;
  isFsReadStream = shims.isFsReadStream;
}

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/_shims/MultipartBody.mjs
var MultipartBody = class {
  constructor(body) {
    this.body = body;
  }
  get [Symbol.toStringTag]() {
    return "MultipartBody";
  }
};

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/_shims/web-runtime.mjs
function getRuntime({ manuallyImported } = {}) {
  const recommendation = manuallyImported ? `You may need to use polyfills` : `Add one of these imports before your first \`import \u2026 from '@anthropic-ai/sdk'\`:
- \`import '@anthropic-ai/sdk/shims/node'\` (if you're running on Node)
- \`import '@anthropic-ai/sdk/shims/web'\` (otherwise)
`;
  let _fetch, _Request, _Response, _Headers;
  try {
    _fetch = fetch;
    _Request = Request;
    _Response = Response;
    _Headers = Headers;
  } catch (error) {
    throw new Error(`this environment is missing the following Web Fetch API type: ${error.message}. ${recommendation}`);
  }
  return {
    kind: "web",
    fetch: _fetch,
    Request: _Request,
    Response: _Response,
    Headers: _Headers,
    FormData: (
      // @ts-ignore
      typeof FormData !== "undefined" ? FormData : class FormData {
        // @ts-ignore
        constructor() {
          throw new Error(`file uploads aren't supported in this environment yet as 'FormData' is undefined. ${recommendation}`);
        }
      }
    ),
    Blob: typeof Blob !== "undefined" ? Blob : class Blob {
      constructor() {
        throw new Error(`file uploads aren't supported in this environment yet as 'Blob' is undefined. ${recommendation}`);
      }
    },
    File: (
      // @ts-ignore
      typeof File !== "undefined" ? File : class File {
        // @ts-ignore
        constructor() {
          throw new Error(`file uploads aren't supported in this environment yet as 'File' is undefined. ${recommendation}`);
        }
      }
    ),
    ReadableStream: (
      // @ts-ignore
      typeof ReadableStream !== "undefined" ? ReadableStream : class ReadableStream {
        // @ts-ignore
        constructor() {
          throw new Error(`streaming isn't supported in this environment yet as 'ReadableStream' is undefined. ${recommendation}`);
        }
      }
    ),
    getMultipartRequestOptions: async (form, opts) => ({
      ...opts,
      body: new MultipartBody(form)
    }),
    getDefaultAgent: (url) => void 0,
    fileFromPath: () => {
      throw new Error("The `fileFromPath` function is only supported in Node. See the README for more details: https://www.github.com/anthropics/anthropic-sdk-typescript#file-uploads");
    },
    isFsReadStream: (value) => false
  };
}

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/_shims/index.mjs
if (!kind) setShims(getRuntime(), { auto: true });

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/streaming.mjs
var Stream = class _Stream {
  constructor(iterator, controller) {
    this.iterator = iterator;
    this.controller = controller;
  }
  static fromSSEResponse(response, controller) {
    let consumed = false;
    async function* iterator() {
      if (consumed) {
        throw new Error("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");
      }
      consumed = true;
      let done = false;
      try {
        for await (const sse of _iterSSEMessages(response, controller)) {
          if (sse.event === "completion") {
            try {
              yield JSON.parse(sse.data);
            } catch (e) {
              console.error(`Could not parse message into JSON:`, sse.data);
              console.error(`From chunk:`, sse.raw);
              throw e;
            }
          }
          if (sse.event === "message_start" || sse.event === "message_delta" || sse.event === "message_stop" || sse.event === "content_block_start" || sse.event === "content_block_delta" || sse.event === "content_block_stop") {
            try {
              yield JSON.parse(sse.data);
            } catch (e) {
              console.error(`Could not parse message into JSON:`, sse.data);
              console.error(`From chunk:`, sse.raw);
              throw e;
            }
          }
          if (sse.event === "ping") {
            continue;
          }
          if (sse.event === "error") {
            throw APIError.generate(void 0, `SSE Error: ${sse.data}`, sse.data, createResponseHeaders(response.headers));
          }
        }
        done = true;
      } catch (e) {
        if (e instanceof Error && e.name === "AbortError")
          return;
        throw e;
      } finally {
        if (!done)
          controller.abort();
      }
    }
    return new _Stream(iterator, controller);
  }
  /**
   * Generates a Stream from a newline-separated ReadableStream
   * where each item is a JSON value.
   */
  static fromReadableStream(readableStream, controller) {
    let consumed = false;
    async function* iterLines() {
      const lineDecoder = new LineDecoder();
      const iter = readableStreamAsyncIterable(readableStream);
      for await (const chunk of iter) {
        for (const line of lineDecoder.decode(chunk)) {
          yield line;
        }
      }
      for (const line of lineDecoder.flush()) {
        yield line;
      }
    }
    async function* iterator() {
      if (consumed) {
        throw new Error("Cannot iterate over a consumed stream, use `.tee()` to split the stream.");
      }
      consumed = true;
      let done = false;
      try {
        for await (const line of iterLines()) {
          if (done)
            continue;
          if (line)
            yield JSON.parse(line);
        }
        done = true;
      } catch (e) {
        if (e instanceof Error && e.name === "AbortError")
          return;
        throw e;
      } finally {
        if (!done)
          controller.abort();
      }
    }
    return new _Stream(iterator, controller);
  }
  [Symbol.asyncIterator]() {
    return this.iterator();
  }
  /**
   * Splits the stream into two streams which can be
   * independently read from at different speeds.
   */
  tee() {
    const left = [];
    const right = [];
    const iterator = this.iterator();
    const teeIterator = (queue) => {
      return {
        next: () => {
          if (queue.length === 0) {
            const result = iterator.next();
            left.push(result);
            right.push(result);
          }
          return queue.shift();
        }
      };
    };
    return [
      new _Stream(() => teeIterator(left), this.controller),
      new _Stream(() => teeIterator(right), this.controller)
    ];
  }
  /**
   * Converts this stream to a newline-separated ReadableStream of
   * JSON stringified values in the stream
   * which can be turned back into a Stream with `Stream.fromReadableStream()`.
   */
  toReadableStream() {
    const self = this;
    let iter;
    const encoder = new TextEncoder();
    return new ReadableStream2({
      async start() {
        iter = self[Symbol.asyncIterator]();
      },
      async pull(ctrl) {
        try {
          const { value, done } = await iter.next();
          if (done)
            return ctrl.close();
          const bytes = encoder.encode(JSON.stringify(value) + "\n");
          ctrl.enqueue(bytes);
        } catch (err) {
          ctrl.error(err);
        }
      },
      async cancel() {
        await iter.return?.();
      }
    });
  }
};
async function* _iterSSEMessages(response, controller) {
  if (!response.body) {
    controller.abort();
    throw new AnthropicError(`Attempted to iterate over a response with no body`);
  }
  const sseDecoder = new SSEDecoder();
  const lineDecoder = new LineDecoder();
  const iter = readableStreamAsyncIterable(response.body);
  for await (const sseChunk of iterSSEChunks(iter)) {
    for (const line of lineDecoder.decode(sseChunk)) {
      const sse = sseDecoder.decode(line);
      if (sse)
        yield sse;
    }
  }
  for (const line of lineDecoder.flush()) {
    const sse = sseDecoder.decode(line);
    if (sse)
      yield sse;
  }
}
async function* iterSSEChunks(iterator) {
  let data = new Uint8Array();
  for await (const chunk of iterator) {
    if (chunk == null) {
      continue;
    }
    const binaryChunk = chunk instanceof ArrayBuffer ? new Uint8Array(chunk) : typeof chunk === "string" ? new TextEncoder().encode(chunk) : chunk;
    let newData = new Uint8Array(data.length + binaryChunk.length);
    newData.set(data);
    newData.set(binaryChunk, data.length);
    data = newData;
    let patternIndex;
    while ((patternIndex = findDoubleNewlineIndex(data)) !== -1) {
      yield data.slice(0, patternIndex);
      data = data.slice(patternIndex);
    }
  }
  if (data.length > 0) {
    yield data;
  }
}
function findDoubleNewlineIndex(buffer) {
  const newline = 10;
  const carriage = 13;
  for (let i = 0; i < buffer.length - 2; i++) {
    if (buffer[i] === newline && buffer[i + 1] === newline) {
      return i + 2;
    }
    if (buffer[i] === carriage && buffer[i + 1] === carriage) {
      return i + 2;
    }
    if (buffer[i] === carriage && buffer[i + 1] === newline && i + 3 < buffer.length && buffer[i + 2] === carriage && buffer[i + 3] === newline) {
      return i + 4;
    }
  }
  return -1;
}
var SSEDecoder = class {
  constructor() {
    this.event = null;
    this.data = [];
    this.chunks = [];
  }
  decode(line) {
    if (line.endsWith("\r")) {
      line = line.substring(0, line.length - 1);
    }
    if (!line) {
      if (!this.event && !this.data.length)
        return null;
      const sse = {
        event: this.event,
        data: this.data.join("\n"),
        raw: this.chunks
      };
      this.event = null;
      this.data = [];
      this.chunks = [];
      return sse;
    }
    this.chunks.push(line);
    if (line.startsWith(":")) {
      return null;
    }
    let [fieldname, _, value] = partition(line, ":");
    if (value.startsWith(" ")) {
      value = value.substring(1);
    }
    if (fieldname === "event") {
      this.event = value;
    } else if (fieldname === "data") {
      this.data.push(value);
    }
    return null;
  }
};
var LineDecoder = class _LineDecoder {
  constructor() {
    this.buffer = [];
    this.trailingCR = false;
  }
  decode(chunk) {
    let text = this.decodeText(chunk);
    if (this.trailingCR) {
      text = "\r" + text;
      this.trailingCR = false;
    }
    if (text.endsWith("\r")) {
      this.trailingCR = true;
      text = text.slice(0, -1);
    }
    if (!text) {
      return [];
    }
    const trailingNewline = _LineDecoder.NEWLINE_CHARS.has(text[text.length - 1] || "");
    let lines = text.split(_LineDecoder.NEWLINE_REGEXP);
    if (trailingNewline) {
      lines.pop();
    }
    if (lines.length === 1 && !trailingNewline) {
      this.buffer.push(lines[0]);
      return [];
    }
    if (this.buffer.length > 0) {
      lines = [this.buffer.join("") + lines[0], ...lines.slice(1)];
      this.buffer = [];
    }
    if (!trailingNewline) {
      this.buffer = [lines.pop() || ""];
    }
    return lines;
  }
  decodeText(bytes) {
    if (bytes == null)
      return "";
    if (typeof bytes === "string")
      return bytes;
    if (typeof Buffer !== "undefined") {
      if (bytes instanceof Buffer) {
        return bytes.toString();
      }
      if (bytes instanceof Uint8Array) {
        return Buffer.from(bytes).toString();
      }
      throw new AnthropicError(`Unexpected: received non-Uint8Array (${bytes.constructor.name}) stream chunk in an environment with a global "Buffer" defined, which this library assumes to be Node. Please report this error.`);
    }
    if (typeof TextDecoder !== "undefined") {
      if (bytes instanceof Uint8Array || bytes instanceof ArrayBuffer) {
        this.textDecoder ?? (this.textDecoder = new TextDecoder("utf8"));
        return this.textDecoder.decode(bytes);
      }
      throw new AnthropicError(`Unexpected: received non-Uint8Array/ArrayBuffer (${bytes.constructor.name}) in a web platform. Please report this error.`);
    }
    throw new AnthropicError(`Unexpected: neither Buffer nor TextDecoder are available as globals. Please report this error.`);
  }
  flush() {
    if (!this.buffer.length && !this.trailingCR) {
      return [];
    }
    const lines = [this.buffer.join("")];
    this.buffer = [];
    this.trailingCR = false;
    return lines;
  }
};
LineDecoder.NEWLINE_CHARS = /* @__PURE__ */ new Set(["\n", "\r"]);
LineDecoder.NEWLINE_REGEXP = /\r\n|[\n\r]/g;
function partition(str, delimiter) {
  const index = str.indexOf(delimiter);
  if (index !== -1) {
    return [str.substring(0, index), delimiter, str.substring(index + delimiter.length)];
  }
  return [str, "", ""];
}
function readableStreamAsyncIterable(stream) {
  if (stream[Symbol.asyncIterator])
    return stream;
  const reader = stream.getReader();
  return {
    async next() {
      try {
        const result = await reader.read();
        if (result?.done)
          reader.releaseLock();
        return result;
      } catch (e) {
        reader.releaseLock();
        throw e;
      }
    },
    async return() {
      const cancelPromise = reader.cancel();
      reader.releaseLock();
      await cancelPromise;
      return { done: true, value: void 0 };
    },
    [Symbol.asyncIterator]() {
      return this;
    }
  };
}

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/uploads.mjs
var isResponseLike = (value) => value != null && typeof value === "object" && typeof value.url === "string" && typeof value.blob === "function";
var isFileLike = (value) => value != null && typeof value === "object" && typeof value.name === "string" && typeof value.lastModified === "number" && isBlobLike(value);
var isBlobLike = (value) => value != null && typeof value === "object" && typeof value.size === "number" && typeof value.type === "string" && typeof value.text === "function" && typeof value.slice === "function" && typeof value.arrayBuffer === "function";
async function toFile(value, name, options) {
  value = await value;
  if (isFileLike(value)) {
    return value;
  }
  if (isResponseLike(value)) {
    const blob = await value.blob();
    name || (name = new URL(value.url).pathname.split(/[\\/]/).pop() ?? "unknown_file");
    const data = isBlobLike(blob) ? [await blob.arrayBuffer()] : [blob];
    return new File2(data, name, options);
  }
  const bits = await getBytes(value);
  name || (name = getName(value) ?? "unknown_file");
  if (!options?.type) {
    const type = bits[0]?.type;
    if (typeof type === "string") {
      options = { ...options, type };
    }
  }
  return new File2(bits, name, options);
}
async function getBytes(value) {
  let parts = [];
  if (typeof value === "string" || ArrayBuffer.isView(value) || // includes Uint8Array, Buffer, etc.
  value instanceof ArrayBuffer) {
    parts.push(value);
  } else if (isBlobLike(value)) {
    parts.push(await value.arrayBuffer());
  } else if (isAsyncIterableIterator(value)) {
    for await (const chunk of value) {
      parts.push(chunk);
    }
  } else {
    throw new Error(`Unexpected data type: ${typeof value}; constructor: ${value?.constructor?.name}; props: ${propsForError(value)}`);
  }
  return parts;
}
function propsForError(value) {
  const props = Object.getOwnPropertyNames(value);
  return `[${props.map((p) => `"${p}"`).join(", ")}]`;
}
function getName(value) {
  return getStringFromMaybeBuffer(value.name) || getStringFromMaybeBuffer(value.filename) || // For fs.ReadStream
  getStringFromMaybeBuffer(value.path)?.split(/[\\/]/).pop();
}
var getStringFromMaybeBuffer = (x) => {
  if (typeof x === "string")
    return x;
  if (typeof Buffer !== "undefined" && x instanceof Buffer)
    return String(x);
  return void 0;
};
var isAsyncIterableIterator = (value) => value != null && typeof value === "object" && typeof value[Symbol.asyncIterator] === "function";
var isMultipartBody = (body) => body && typeof body === "object" && body.body && body[Symbol.toStringTag] === "MultipartBody";

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/core.mjs
var __classPrivateFieldSet = function(receiver, state, value, kind2, f) {
  if (kind2 === "m") throw new TypeError("Private method is not writable");
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return kind2 === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
};
var __classPrivateFieldGet = function(receiver, state, kind2, f) {
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind2 === "m" ? f : kind2 === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _AbstractPage_client;
async function defaultParseResponse(props) {
  const { response } = props;
  if (props.options.stream) {
    debug("response", response.status, response.url, response.headers, response.body);
    if (props.options.__streamClass) {
      return props.options.__streamClass.fromSSEResponse(response, props.controller);
    }
    return Stream.fromSSEResponse(response, props.controller);
  }
  if (response.status === 204) {
    return null;
  }
  if (props.options.__binaryResponse) {
    return response;
  }
  const contentType = response.headers.get("content-type");
  const isJSON = contentType?.includes("application/json") || contentType?.includes("application/vnd.api+json");
  if (isJSON) {
    const json = await response.json();
    debug("response", response.status, response.url, response.headers, json);
    return json;
  }
  const text = await response.text();
  debug("response", response.status, response.url, response.headers, text);
  return text;
}
var APIPromise = class _APIPromise extends Promise {
  constructor(responsePromise, parseResponse2 = defaultParseResponse) {
    super((resolve) => {
      resolve(null);
    });
    this.responsePromise = responsePromise;
    this.parseResponse = parseResponse2;
  }
  _thenUnwrap(transform) {
    return new _APIPromise(this.responsePromise, async (props) => transform(await this.parseResponse(props)));
  }
  /**
   * Gets the raw `Response` instance instead of parsing the response
   * data.
   *
   * If you want to parse the response body but still get the `Response`
   * instance, you can use {@link withResponse()}.
   *
   * 👋 Getting the wrong TypeScript type for `Response`?
   * Try setting `"moduleResolution": "NodeNext"` if you can,
   * or add one of these imports before your first `import … from '@anthropic-ai/sdk'`:
   * - `import '@anthropic-ai/sdk/shims/node'` (if you're running on Node)
   * - `import '@anthropic-ai/sdk/shims/web'` (otherwise)
   */
  asResponse() {
    return this.responsePromise.then((p) => p.response);
  }
  /**
   * Gets the parsed response data and the raw `Response` instance.
   *
   * If you just want to get the raw `Response` instance without parsing it,
   * you can use {@link asResponse()}.
   *
   *
   * 👋 Getting the wrong TypeScript type for `Response`?
   * Try setting `"moduleResolution": "NodeNext"` if you can,
   * or add one of these imports before your first `import … from '@anthropic-ai/sdk'`:
   * - `import '@anthropic-ai/sdk/shims/node'` (if you're running on Node)
   * - `import '@anthropic-ai/sdk/shims/web'` (otherwise)
   */
  async withResponse() {
    const [data, response] = await Promise.all([this.parse(), this.asResponse()]);
    return { data, response };
  }
  parse() {
    if (!this.parsedPromise) {
      this.parsedPromise = this.responsePromise.then(this.parseResponse);
    }
    return this.parsedPromise;
  }
  then(onfulfilled, onrejected) {
    return this.parse().then(onfulfilled, onrejected);
  }
  catch(onrejected) {
    return this.parse().catch(onrejected);
  }
  finally(onfinally) {
    return this.parse().finally(onfinally);
  }
};
var APIClient = class {
  constructor({
    baseURL,
    maxRetries = 2,
    timeout = 6e5,
    // 10 minutes
    httpAgent,
    fetch: overridenFetch
  }) {
    this.baseURL = baseURL;
    this.maxRetries = validatePositiveInteger("maxRetries", maxRetries);
    this.timeout = validatePositiveInteger("timeout", timeout);
    this.httpAgent = httpAgent;
    this.fetch = overridenFetch ?? fetch2;
  }
  authHeaders(opts) {
    return {};
  }
  /**
   * Override this to add your own default headers, for example:
   *
   *  {
   *    ...super.defaultHeaders(),
   *    Authorization: 'Bearer 123',
   *  }
   */
  defaultHeaders(opts) {
    return {
      Accept: "application/json",
      "Content-Type": "application/json",
      "User-Agent": this.getUserAgent(),
      ...getPlatformHeaders(),
      ...this.authHeaders(opts)
    };
  }
  /**
   * Override this to add your own headers validation:
   */
  validateHeaders(headers, customHeaders) {
  }
  defaultIdempotencyKey() {
    return `stainless-node-retry-${uuid4()}`;
  }
  get(path, opts) {
    return this.methodRequest("get", path, opts);
  }
  post(path, opts) {
    return this.methodRequest("post", path, opts);
  }
  patch(path, opts) {
    return this.methodRequest("patch", path, opts);
  }
  put(path, opts) {
    return this.methodRequest("put", path, opts);
  }
  delete(path, opts) {
    return this.methodRequest("delete", path, opts);
  }
  methodRequest(method, path, opts) {
    return this.request(Promise.resolve(opts).then(async (opts2) => {
      const body = opts2 && isBlobLike(opts2?.body) ? new DataView(await opts2.body.arrayBuffer()) : opts2?.body instanceof DataView ? opts2.body : opts2?.body instanceof ArrayBuffer ? new DataView(opts2.body) : opts2 && ArrayBuffer.isView(opts2?.body) ? new DataView(opts2.body.buffer) : opts2?.body;
      return { method, path, ...opts2, body };
    }));
  }
  getAPIList(path, Page, opts) {
    return this.requestAPIList(Page, { method: "get", path, ...opts });
  }
  calculateContentLength(body) {
    if (typeof body === "string") {
      if (typeof Buffer !== "undefined") {
        return Buffer.byteLength(body, "utf8").toString();
      }
      if (typeof TextEncoder !== "undefined") {
        const encoder = new TextEncoder();
        const encoded = encoder.encode(body);
        return encoded.length.toString();
      }
    } else if (ArrayBuffer.isView(body)) {
      return body.byteLength.toString();
    }
    return null;
  }
  buildRequest(options, { retryCount = 0 } = {}) {
    const { method, path, query, headers = {} } = options;
    const body = ArrayBuffer.isView(options.body) || options.__binaryRequest && typeof options.body === "string" ? options.body : isMultipartBody(options.body) ? options.body.body : options.body ? JSON.stringify(options.body, null, 2) : null;
    const contentLength = this.calculateContentLength(body);
    const url = this.buildURL(path, query);
    if ("timeout" in options)
      validatePositiveInteger("timeout", options.timeout);
    const timeout = options.timeout ?? this.timeout;
    const httpAgent = options.httpAgent ?? this.httpAgent ?? getDefaultAgent(url);
    const minAgentTimeout = timeout + 1e3;
    if (typeof httpAgent?.options?.timeout === "number" && minAgentTimeout > (httpAgent.options.timeout ?? 0)) {
      httpAgent.options.timeout = minAgentTimeout;
    }
    if (this.idempotencyHeader && method !== "get") {
      if (!options.idempotencyKey)
        options.idempotencyKey = this.defaultIdempotencyKey();
      headers[this.idempotencyHeader] = options.idempotencyKey;
    }
    const reqHeaders = this.buildHeaders({ options, headers, contentLength, retryCount });
    const req = {
      method,
      ...body && { body },
      headers: reqHeaders,
      ...httpAgent && { agent: httpAgent },
      // @ts-ignore node-fetch uses a custom AbortSignal type that is
      // not compatible with standard web types
      signal: options.signal ?? null
    };
    return { req, url, timeout };
  }
  buildHeaders({ options, headers, contentLength, retryCount }) {
    const reqHeaders = {};
    if (contentLength) {
      reqHeaders["content-length"] = contentLength;
    }
    const defaultHeaders = this.defaultHeaders(options);
    applyHeadersMut(reqHeaders, defaultHeaders);
    applyHeadersMut(reqHeaders, headers);
    if (isMultipartBody(options.body) && kind !== "node") {
      delete reqHeaders["content-type"];
    }
    if (getHeader(headers, "x-stainless-retry-count") === void 0) {
      reqHeaders["x-stainless-retry-count"] = String(retryCount);
    }
    this.validateHeaders(reqHeaders, headers);
    return reqHeaders;
  }
  /**
   * Used as a callback for mutating the given `FinalRequestOptions` object.
   */
  async prepareOptions(options) {
  }
  /**
   * Used as a callback for mutating the given `RequestInit` object.
   *
   * This is useful for cases where you want to add certain headers based off of
   * the request properties, e.g. `method` or `url`.
   */
  async prepareRequest(request, { url, options }) {
  }
  parseHeaders(headers) {
    return !headers ? {} : Symbol.iterator in headers ? Object.fromEntries(Array.from(headers).map((header) => [...header])) : { ...headers };
  }
  makeStatusError(status, error, message, headers) {
    return APIError.generate(status, error, message, headers);
  }
  request(options, remainingRetries = null) {
    return new APIPromise(this.makeRequest(options, remainingRetries));
  }
  async makeRequest(optionsInput, retriesRemaining) {
    const options = await optionsInput;
    const maxRetries = options.maxRetries ?? this.maxRetries;
    if (retriesRemaining == null) {
      retriesRemaining = maxRetries;
    }
    await this.prepareOptions(options);
    const { req, url, timeout } = this.buildRequest(options, { retryCount: maxRetries - retriesRemaining });
    await this.prepareRequest(req, { url, options });
    debug("request", url, options, req.headers);
    if (options.signal?.aborted) {
      throw new APIUserAbortError();
    }
    const controller = new AbortController();
    const response = await this.fetchWithTimeout(url, req, timeout, controller).catch(castToError);
    if (response instanceof Error) {
      if (options.signal?.aborted) {
        throw new APIUserAbortError();
      }
      if (retriesRemaining) {
        return this.retryRequest(options, retriesRemaining);
      }
      if (response.name === "AbortError") {
        throw new APIConnectionTimeoutError();
      }
      throw new APIConnectionError({ cause: response });
    }
    const responseHeaders = createResponseHeaders(response.headers);
    if (!response.ok) {
      if (retriesRemaining && this.shouldRetry(response)) {
        const retryMessage2 = `retrying, ${retriesRemaining} attempts remaining`;
        debug(`response (error; ${retryMessage2})`, response.status, url, responseHeaders);
        return this.retryRequest(options, retriesRemaining, responseHeaders);
      }
      const errText = await response.text().catch((e) => castToError(e).message);
      const errJSON = safeJSON(errText);
      const errMessage = errJSON ? void 0 : errText;
      const retryMessage = retriesRemaining ? `(error; no more retries left)` : `(error; not retryable)`;
      debug(`response (error; ${retryMessage})`, response.status, url, responseHeaders, errMessage);
      const err = this.makeStatusError(response.status, errJSON, errMessage, responseHeaders);
      throw err;
    }
    return { response, options, controller };
  }
  requestAPIList(Page, options) {
    const request = this.makeRequest(options, null);
    return new PagePromise(this, request, Page);
  }
  buildURL(path, query) {
    const url = isAbsoluteURL(path) ? new URL(path) : new URL(this.baseURL + (this.baseURL.endsWith("/") && path.startsWith("/") ? path.slice(1) : path));
    const defaultQuery = this.defaultQuery();
    if (!isEmptyObj(defaultQuery)) {
      query = { ...defaultQuery, ...query };
    }
    if (typeof query === "object" && query && !Array.isArray(query)) {
      url.search = this.stringifyQuery(query);
    }
    return url.toString();
  }
  stringifyQuery(query) {
    return Object.entries(query).filter(([_, value]) => typeof value !== "undefined").map(([key, value]) => {
      if (typeof value === "string" || typeof value === "number" || typeof value === "boolean") {
        return `${encodeURIComponent(key)}=${encodeURIComponent(value)}`;
      }
      if (value === null) {
        return `${encodeURIComponent(key)}=`;
      }
      throw new AnthropicError(`Cannot stringify type ${typeof value}; Expected string, number, boolean, or null. If you need to pass nested query parameters, you can manually encode them, e.g. { query: { 'foo[key1]': value1, 'foo[key2]': value2 } }, and please open a GitHub issue requesting better support for your use case.`);
    }).join("&");
  }
  async fetchWithTimeout(url, init, ms, controller) {
    const { signal, ...options } = init || {};
    if (signal)
      signal.addEventListener("abort", () => controller.abort());
    const timeout = setTimeout(() => controller.abort(), ms);
    return this.getRequestClient().fetch.call(void 0, url, { signal: controller.signal, ...options }).finally(() => {
      clearTimeout(timeout);
    });
  }
  getRequestClient() {
    return { fetch: this.fetch };
  }
  shouldRetry(response) {
    const shouldRetryHeader = response.headers.get("x-should-retry");
    if (shouldRetryHeader === "true")
      return true;
    if (shouldRetryHeader === "false")
      return false;
    if (response.status === 408)
      return true;
    if (response.status === 409)
      return true;
    if (response.status === 429)
      return true;
    if (response.status >= 500)
      return true;
    return false;
  }
  async retryRequest(options, retriesRemaining, responseHeaders) {
    let timeoutMillis;
    const retryAfterMillisHeader = responseHeaders?.["retry-after-ms"];
    if (retryAfterMillisHeader) {
      const timeoutMs = parseFloat(retryAfterMillisHeader);
      if (!Number.isNaN(timeoutMs)) {
        timeoutMillis = timeoutMs;
      }
    }
    const retryAfterHeader = responseHeaders?.["retry-after"];
    if (retryAfterHeader && !timeoutMillis) {
      const timeoutSeconds = parseFloat(retryAfterHeader);
      if (!Number.isNaN(timeoutSeconds)) {
        timeoutMillis = timeoutSeconds * 1e3;
      } else {
        timeoutMillis = Date.parse(retryAfterHeader) - Date.now();
      }
    }
    if (!(timeoutMillis && 0 <= timeoutMillis && timeoutMillis < 60 * 1e3)) {
      const maxRetries = options.maxRetries ?? this.maxRetries;
      timeoutMillis = this.calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries);
    }
    await sleep(timeoutMillis);
    return this.makeRequest(options, retriesRemaining - 1);
  }
  calculateDefaultRetryTimeoutMillis(retriesRemaining, maxRetries) {
    const initialRetryDelay = 0.5;
    const maxRetryDelay = 8;
    const numRetries = maxRetries - retriesRemaining;
    const sleepSeconds = Math.min(initialRetryDelay * Math.pow(2, numRetries), maxRetryDelay);
    const jitter = 1 - Math.random() * 0.25;
    return sleepSeconds * jitter * 1e3;
  }
  getUserAgent() {
    return `${this.constructor.name}/JS ${VERSION}`;
  }
};
var AbstractPage = class {
  constructor(client, response, body, options) {
    _AbstractPage_client.set(this, void 0);
    __classPrivateFieldSet(this, _AbstractPage_client, client, "f");
    this.options = options;
    this.response = response;
    this.body = body;
  }
  hasNextPage() {
    const items = this.getPaginatedItems();
    if (!items.length)
      return false;
    return this.nextPageInfo() != null;
  }
  async getNextPage() {
    const nextInfo = this.nextPageInfo();
    if (!nextInfo) {
      throw new AnthropicError("No next page expected; please check `.hasNextPage()` before calling `.getNextPage()`.");
    }
    const nextOptions = { ...this.options };
    if ("params" in nextInfo && typeof nextOptions.query === "object") {
      nextOptions.query = { ...nextOptions.query, ...nextInfo.params };
    } else if ("url" in nextInfo) {
      const params = [...Object.entries(nextOptions.query || {}), ...nextInfo.url.searchParams.entries()];
      for (const [key, value] of params) {
        nextInfo.url.searchParams.set(key, value);
      }
      nextOptions.query = void 0;
      nextOptions.path = nextInfo.url.toString();
    }
    return await __classPrivateFieldGet(this, _AbstractPage_client, "f").requestAPIList(this.constructor, nextOptions);
  }
  async *iterPages() {
    let page = this;
    yield page;
    while (page.hasNextPage()) {
      page = await page.getNextPage();
      yield page;
    }
  }
  async *[(_AbstractPage_client = /* @__PURE__ */ new WeakMap(), Symbol.asyncIterator)]() {
    for await (const page of this.iterPages()) {
      for (const item of page.getPaginatedItems()) {
        yield item;
      }
    }
  }
};
var PagePromise = class extends APIPromise {
  constructor(client, request, Page) {
    super(request, async (props) => new Page(client, props.response, await defaultParseResponse(props), props.options));
  }
  /**
   * Allow auto-paginating iteration on an unawaited list call, eg:
   *
   *    for await (const item of client.items.list()) {
   *      console.log(item)
   *    }
   */
  async *[Symbol.asyncIterator]() {
    const page = await this;
    for await (const item of page) {
      yield item;
    }
  }
};
var createResponseHeaders = (headers) => {
  return new Proxy(Object.fromEntries(
    // @ts-ignore
    headers.entries()
  ), {
    get(target, name) {
      const key = name.toString();
      return target[key.toLowerCase()] || target[key];
    }
  });
};
var getPlatformProperties = () => {
  if (typeof Deno !== "undefined" && Deno.build != null) {
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": VERSION,
      "X-Stainless-OS": normalizePlatform(Deno.build.os),
      "X-Stainless-Arch": normalizeArch(Deno.build.arch),
      "X-Stainless-Runtime": "deno",
      "X-Stainless-Runtime-Version": typeof Deno.version === "string" ? Deno.version : Deno.version?.deno ?? "unknown"
    };
  }
  if (typeof EdgeRuntime !== "undefined") {
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": VERSION,
      "X-Stainless-OS": "Unknown",
      "X-Stainless-Arch": `other:${EdgeRuntime}`,
      "X-Stainless-Runtime": "edge",
      "X-Stainless-Runtime-Version": process.version
    };
  }
  if (Object.prototype.toString.call(typeof process !== "undefined" ? process : 0) === "[object process]") {
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": VERSION,
      "X-Stainless-OS": normalizePlatform(process.platform),
      "X-Stainless-Arch": normalizeArch(process.arch),
      "X-Stainless-Runtime": "node",
      "X-Stainless-Runtime-Version": process.version
    };
  }
  const browserInfo = getBrowserInfo();
  if (browserInfo) {
    return {
      "X-Stainless-Lang": "js",
      "X-Stainless-Package-Version": VERSION,
      "X-Stainless-OS": "Unknown",
      "X-Stainless-Arch": "unknown",
      "X-Stainless-Runtime": `browser:${browserInfo.browser}`,
      "X-Stainless-Runtime-Version": browserInfo.version
    };
  }
  return {
    "X-Stainless-Lang": "js",
    "X-Stainless-Package-Version": VERSION,
    "X-Stainless-OS": "Unknown",
    "X-Stainless-Arch": "unknown",
    "X-Stainless-Runtime": "unknown",
    "X-Stainless-Runtime-Version": "unknown"
  };
};
function getBrowserInfo() {
  if (typeof navigator === "undefined" || !navigator) {
    return null;
  }
  const browserPatterns = [
    { key: "edge", pattern: /Edge(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "ie", pattern: /MSIE(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "ie", pattern: /Trident(?:.*rv\:(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "chrome", pattern: /Chrome(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "firefox", pattern: /Firefox(?:\W+(\d+)\.(\d+)(?:\.(\d+))?)?/ },
    { key: "safari", pattern: /(?:Version\W+(\d+)\.(\d+)(?:\.(\d+))?)?(?:\W+Mobile\S*)?\W+Safari/ }
  ];
  for (const { key, pattern } of browserPatterns) {
    const match = pattern.exec(navigator.userAgent);
    if (match) {
      const major = match[1] || 0;
      const minor = match[2] || 0;
      const patch = match[3] || 0;
      return { browser: key, version: `${major}.${minor}.${patch}` };
    }
  }
  return null;
}
var normalizeArch = (arch) => {
  if (arch === "x32")
    return "x32";
  if (arch === "x86_64" || arch === "x64")
    return "x64";
  if (arch === "arm")
    return "arm";
  if (arch === "aarch64" || arch === "arm64")
    return "arm64";
  if (arch)
    return `other:${arch}`;
  return "unknown";
};
var normalizePlatform = (platform) => {
  platform = platform.toLowerCase();
  if (platform.includes("ios"))
    return "iOS";
  if (platform === "android")
    return "Android";
  if (platform === "darwin")
    return "MacOS";
  if (platform === "win32")
    return "Windows";
  if (platform === "freebsd")
    return "FreeBSD";
  if (platform === "openbsd")
    return "OpenBSD";
  if (platform === "linux")
    return "Linux";
  if (platform)
    return `Other:${platform}`;
  return "Unknown";
};
var _platformHeaders;
var getPlatformHeaders = () => {
  return _platformHeaders ?? (_platformHeaders = getPlatformProperties());
};
var safeJSON = (text) => {
  try {
    return JSON.parse(text);
  } catch (err) {
    return void 0;
  }
};
var startsWithSchemeRegexp = new RegExp("^(?:[a-z]+:)?//", "i");
var isAbsoluteURL = (url) => {
  return startsWithSchemeRegexp.test(url);
};
var sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));
var validatePositiveInteger = (name, n) => {
  if (typeof n !== "number" || !Number.isInteger(n)) {
    throw new AnthropicError(`${name} must be an integer`);
  }
  if (n < 0) {
    throw new AnthropicError(`${name} must be a positive integer`);
  }
  return n;
};
var castToError = (err) => {
  if (err instanceof Error)
    return err;
  if (typeof err === "object" && err !== null) {
    try {
      return new Error(JSON.stringify(err));
    } catch {
    }
  }
  return new Error(String(err));
};
var readEnv = (env) => {
  if (typeof process !== "undefined") {
    return process.env?.[env]?.trim() ?? void 0;
  }
  if (typeof Deno !== "undefined") {
    return Deno.env?.get?.(env)?.trim();
  }
  return void 0;
};
function isEmptyObj(obj) {
  if (!obj)
    return true;
  for (const _k in obj)
    return false;
  return true;
}
function hasOwn(obj, key) {
  return Object.prototype.hasOwnProperty.call(obj, key);
}
function applyHeadersMut(targetHeaders, newHeaders) {
  for (const k in newHeaders) {
    if (!hasOwn(newHeaders, k))
      continue;
    const lowerKey = k.toLowerCase();
    if (!lowerKey)
      continue;
    const val = newHeaders[k];
    if (val === null) {
      delete targetHeaders[lowerKey];
    } else if (val !== void 0) {
      targetHeaders[lowerKey] = val;
    }
  }
}
function debug(action, ...args) {
  if (typeof process !== "undefined" && process?.env?.["DEBUG"] === "true") {
    console.log(`Anthropic:DEBUG:${action}`, ...args);
  }
}
var uuid4 = () => {
  return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => {
    const r = Math.random() * 16 | 0;
    const v = c === "x" ? r : r & 3 | 8;
    return v.toString(16);
  });
};
var isRunningInBrowser = () => {
  return (
    // @ts-ignore
    typeof window !== "undefined" && // @ts-ignore
    typeof window.document !== "undefined" && // @ts-ignore
    typeof navigator !== "undefined"
  );
};
var isHeadersProtocol = (headers) => {
  return typeof headers?.get === "function";
};
var getHeader = (headers, header) => {
  const lowerCasedHeader = header.toLowerCase();
  if (isHeadersProtocol(headers)) {
    const intercapsHeader = header[0]?.toUpperCase() + header.substring(1).replace(/([^\w])(\w)/g, (_m, g1, g2) => g1 + g2.toUpperCase());
    for (const key of [header, lowerCasedHeader, header.toUpperCase(), intercapsHeader]) {
      const value = headers.get(key);
      if (value) {
        return value;
      }
    }
  }
  for (const [key, value] of Object.entries(headers)) {
    if (key.toLowerCase() === lowerCasedHeader) {
      if (Array.isArray(value)) {
        if (value.length <= 1)
          return value[0];
        console.warn(`Received ${value.length} entries for the ${header} header, using the first entry.`);
        return value[0];
      }
      return value;
    }
  }
  return void 0;
};

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/error.mjs
var AnthropicError = class extends Error {
};
var APIError = class _APIError extends AnthropicError {
  constructor(status, error, message, headers) {
    super(`${_APIError.makeMessage(status, error, message)}`);
    this.status = status;
    this.headers = headers;
    this.request_id = headers?.["request-id"];
    this.error = error;
  }
  static makeMessage(status, error, message) {
    const msg = error?.message ? typeof error.message === "string" ? error.message : JSON.stringify(error.message) : error ? JSON.stringify(error) : message;
    if (status && msg) {
      return `${status} ${msg}`;
    }
    if (status) {
      return `${status} status code (no body)`;
    }
    if (msg) {
      return msg;
    }
    return "(no status code or body)";
  }
  static generate(status, errorResponse, message, headers) {
    if (!status) {
      return new APIConnectionError({ message, cause: castToError(errorResponse) });
    }
    const error = errorResponse;
    if (status === 400) {
      return new BadRequestError(status, error, message, headers);
    }
    if (status === 401) {
      return new AuthenticationError(status, error, message, headers);
    }
    if (status === 403) {
      return new PermissionDeniedError(status, error, message, headers);
    }
    if (status === 404) {
      return new NotFoundError(status, error, message, headers);
    }
    if (status === 409) {
      return new ConflictError(status, error, message, headers);
    }
    if (status === 422) {
      return new UnprocessableEntityError(status, error, message, headers);
    }
    if (status === 429) {
      return new RateLimitError(status, error, message, headers);
    }
    if (status >= 500) {
      return new InternalServerError(status, error, message, headers);
    }
    return new _APIError(status, error, message, headers);
  }
};
var APIUserAbortError = class extends APIError {
  constructor({ message } = {}) {
    super(void 0, void 0, message || "Request was aborted.", void 0);
    this.status = void 0;
  }
};
var APIConnectionError = class extends APIError {
  constructor({ message, cause }) {
    super(void 0, void 0, message || "Connection error.", void 0);
    this.status = void 0;
    if (cause)
      this.cause = cause;
  }
};
var APIConnectionTimeoutError = class extends APIConnectionError {
  constructor({ message } = {}) {
    super({ message: message ?? "Request timed out." });
  }
};
var BadRequestError = class extends APIError {
  constructor() {
    super(...arguments);
    this.status = 400;
  }
};
var AuthenticationError = class extends APIError {
  constructor() {
    super(...arguments);
    this.status = 401;
  }
};
var PermissionDeniedError = class extends APIError {
  constructor() {
    super(...arguments);
    this.status = 403;
  }
};
var NotFoundError = class extends APIError {
  constructor() {
    super(...arguments);
    this.status = 404;
  }
};
var ConflictError = class extends APIError {
  constructor() {
    super(...arguments);
    this.status = 409;
  }
};
var UnprocessableEntityError = class extends APIError {
  constructor() {
    super(...arguments);
    this.status = 422;
  }
};
var RateLimitError = class extends APIError {
  constructor() {
    super(...arguments);
    this.status = 429;
  }
};
var InternalServerError = class extends APIError {
};

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/resource.mjs
var APIResource = class {
  constructor(client) {
    this._client = client;
  }
};

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/_vendor/partial-json-parser/parser.mjs
var tokenize = (input) => {
  let current = 0;
  let tokens = [];
  while (current < input.length) {
    let char = input[current];
    if (char === "\\") {
      current++;
      continue;
    }
    if (char === "{") {
      tokens.push({
        type: "brace",
        value: "{"
      });
      current++;
      continue;
    }
    if (char === "}") {
      tokens.push({
        type: "brace",
        value: "}"
      });
      current++;
      continue;
    }
    if (char === "[") {
      tokens.push({
        type: "paren",
        value: "["
      });
      current++;
      continue;
    }
    if (char === "]") {
      tokens.push({
        type: "paren",
        value: "]"
      });
      current++;
      continue;
    }
    if (char === ":") {
      tokens.push({
        type: "separator",
        value: ":"
      });
      current++;
      continue;
    }
    if (char === ",") {
      tokens.push({
        type: "delimiter",
        value: ","
      });
      current++;
      continue;
    }
    if (char === '"') {
      let value = "";
      let danglingQuote = false;
      char = input[++current];
      while (char !== '"') {
        if (current === input.length) {
          danglingQuote = true;
          break;
        }
        if (char === "\\") {
          current++;
          if (current === input.length) {
            danglingQuote = true;
            break;
          }
          value += char + input[current];
          char = input[++current];
        } else {
          value += char;
          char = input[++current];
        }
      }
      char = input[++current];
      if (!danglingQuote) {
        tokens.push({
          type: "string",
          value
        });
      }
      continue;
    }
    let WHITESPACE = /\s/;
    if (char && WHITESPACE.test(char)) {
      current++;
      continue;
    }
    let NUMBERS = /[0-9]/;
    if (char && NUMBERS.test(char) || char === "-" || char === ".") {
      let value = "";
      if (char === "-") {
        value += char;
        char = input[++current];
      }
      while (char && NUMBERS.test(char) || char === ".") {
        value += char;
        char = input[++current];
      }
      tokens.push({
        type: "number",
        value
      });
      continue;
    }
    let LETTERS = /[a-z]/i;
    if (char && LETTERS.test(char)) {
      let value = "";
      while (char && LETTERS.test(char)) {
        if (current === input.length) {
          break;
        }
        value += char;
        char = input[++current];
      }
      if (value == "true" || value == "false" || value === "null") {
        tokens.push({
          type: "name",
          value
        });
      } else {
        current++;
        continue;
      }
      continue;
    }
    current++;
  }
  return tokens;
};
var strip = (tokens) => {
  if (tokens.length === 0) {
    return tokens;
  }
  let lastToken = tokens[tokens.length - 1];
  switch (lastToken.type) {
    case "separator":
      tokens = tokens.slice(0, tokens.length - 1);
      return strip(tokens);
      break;
    case "number":
      let lastCharacterOfLastToken = lastToken.value[lastToken.value.length - 1];
      if (lastCharacterOfLastToken === "." || lastCharacterOfLastToken === "-") {
        tokens = tokens.slice(0, tokens.length - 1);
        return strip(tokens);
      }
    case "string":
      let tokenBeforeTheLastToken = tokens[tokens.length - 2];
      if (tokenBeforeTheLastToken?.type === "delimiter") {
        tokens = tokens.slice(0, tokens.length - 1);
        return strip(tokens);
      } else if (tokenBeforeTheLastToken?.type === "brace" && tokenBeforeTheLastToken.value === "{") {
        tokens = tokens.slice(0, tokens.length - 1);
        return strip(tokens);
      }
      break;
    case "delimiter":
      tokens = tokens.slice(0, tokens.length - 1);
      return strip(tokens);
      break;
  }
  return tokens;
};
var unstrip = (tokens) => {
  let tail = [];
  tokens.map((token) => {
    if (token.type === "brace") {
      if (token.value === "{") {
        tail.push("}");
      } else {
        tail.splice(tail.lastIndexOf("}"), 1);
      }
    }
    if (token.type === "paren") {
      if (token.value === "[") {
        tail.push("]");
      } else {
        tail.splice(tail.lastIndexOf("]"), 1);
      }
    }
  });
  if (tail.length > 0) {
    tail.reverse().map((item) => {
      if (item === "}") {
        tokens.push({
          type: "brace",
          value: "}"
        });
      } else if (item === "]") {
        tokens.push({
          type: "paren",
          value: "]"
        });
      }
    });
  }
  return tokens;
};
var generate = (tokens) => {
  let output = "";
  tokens.map((token) => {
    switch (token.type) {
      case "string":
        output += '"' + token.value + '"';
        break;
      default:
        output += token.value;
        break;
    }
  });
  return output;
};
var partialParse = (input) => JSON.parse(generate(unstrip(strip(tokenize(input)))));

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/lib/PromptCachingBetaMessageStream.mjs
var __classPrivateFieldSet2 = function(receiver, state, value, kind2, f) {
  if (kind2 === "m") throw new TypeError("Private method is not writable");
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return kind2 === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
};
var __classPrivateFieldGet2 = function(receiver, state, kind2, f) {
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind2 === "m" ? f : kind2 === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _PromptCachingBetaMessageStream_instances;
var _PromptCachingBetaMessageStream_currentMessageSnapshot;
var _PromptCachingBetaMessageStream_connectedPromise;
var _PromptCachingBetaMessageStream_resolveConnectedPromise;
var _PromptCachingBetaMessageStream_rejectConnectedPromise;
var _PromptCachingBetaMessageStream_endPromise;
var _PromptCachingBetaMessageStream_resolveEndPromise;
var _PromptCachingBetaMessageStream_rejectEndPromise;
var _PromptCachingBetaMessageStream_listeners;
var _PromptCachingBetaMessageStream_ended;
var _PromptCachingBetaMessageStream_errored;
var _PromptCachingBetaMessageStream_aborted;
var _PromptCachingBetaMessageStream_catchingPromiseCreated;
var _PromptCachingBetaMessageStream_getFinalMessage;
var _PromptCachingBetaMessageStream_getFinalText;
var _PromptCachingBetaMessageStream_handleError;
var _PromptCachingBetaMessageStream_beginRequest;
var _PromptCachingBetaMessageStream_addStreamEvent;
var _PromptCachingBetaMessageStream_endRequest;
var _PromptCachingBetaMessageStream_accumulateMessage;
var JSON_BUF_PROPERTY = "__json_buf";
var PromptCachingBetaMessageStream = class _PromptCachingBetaMessageStream {
  constructor() {
    _PromptCachingBetaMessageStream_instances.add(this);
    this.messages = [];
    this.receivedMessages = [];
    _PromptCachingBetaMessageStream_currentMessageSnapshot.set(this, void 0);
    this.controller = new AbortController();
    _PromptCachingBetaMessageStream_connectedPromise.set(this, void 0);
    _PromptCachingBetaMessageStream_resolveConnectedPromise.set(this, () => {
    });
    _PromptCachingBetaMessageStream_rejectConnectedPromise.set(this, () => {
    });
    _PromptCachingBetaMessageStream_endPromise.set(this, void 0);
    _PromptCachingBetaMessageStream_resolveEndPromise.set(this, () => {
    });
    _PromptCachingBetaMessageStream_rejectEndPromise.set(this, () => {
    });
    _PromptCachingBetaMessageStream_listeners.set(this, {});
    _PromptCachingBetaMessageStream_ended.set(this, false);
    _PromptCachingBetaMessageStream_errored.set(this, false);
    _PromptCachingBetaMessageStream_aborted.set(this, false);
    _PromptCachingBetaMessageStream_catchingPromiseCreated.set(this, false);
    _PromptCachingBetaMessageStream_handleError.set(this, (error) => {
      __classPrivateFieldSet2(this, _PromptCachingBetaMessageStream_errored, true, "f");
      if (error instanceof Error && error.name === "AbortError") {
        error = new APIUserAbortError();
      }
      if (error instanceof APIUserAbortError) {
        __classPrivateFieldSet2(this, _PromptCachingBetaMessageStream_aborted, true, "f");
        return this._emit("abort", error);
      }
      if (error instanceof AnthropicError) {
        return this._emit("error", error);
      }
      if (error instanceof Error) {
        const anthropicError = new AnthropicError(error.message);
        anthropicError.cause = error;
        return this._emit("error", anthropicError);
      }
      return this._emit("error", new AnthropicError(String(error)));
    });
    __classPrivateFieldSet2(this, _PromptCachingBetaMessageStream_connectedPromise, new Promise((resolve, reject) => {
      __classPrivateFieldSet2(this, _PromptCachingBetaMessageStream_resolveConnectedPromise, resolve, "f");
      __classPrivateFieldSet2(this, _PromptCachingBetaMessageStream_rejectConnectedPromise, reject, "f");
    }), "f");
    __classPrivateFieldSet2(this, _PromptCachingBetaMessageStream_endPromise, new Promise((resolve, reject) => {
      __classPrivateFieldSet2(this, _PromptCachingBetaMessageStream_resolveEndPromise, resolve, "f");
      __classPrivateFieldSet2(this, _PromptCachingBetaMessageStream_rejectEndPromise, reject, "f");
    }), "f");
    __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_connectedPromise, "f").catch(() => {
    });
    __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_endPromise, "f").catch(() => {
    });
  }
  /**
   * Intended for use on the frontend, consuming a stream produced with
   * `.toReadableStream()` on the backend.
   *
   * Note that messages sent to the model do not appear in `.on('message')`
   * in this context.
   */
  static fromReadableStream(stream) {
    const runner = new _PromptCachingBetaMessageStream();
    runner._run(() => runner._fromReadableStream(stream));
    return runner;
  }
  static createMessage(messages, params, options) {
    const runner = new _PromptCachingBetaMessageStream();
    for (const message of params.messages) {
      runner._addPromptCachingBetaMessageParam(message);
    }
    runner._run(() => runner._createPromptCachingBetaMessage(messages, { ...params, stream: true }, { ...options, headers: { ...options?.headers, "X-Stainless-Helper-Method": "stream" } }));
    return runner;
  }
  _run(executor) {
    executor().then(() => {
      this._emitFinal();
      this._emit("end");
    }, __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_handleError, "f"));
  }
  _addPromptCachingBetaMessageParam(message) {
    this.messages.push(message);
  }
  _addPromptCachingBetaMessage(message, emit = true) {
    this.receivedMessages.push(message);
    if (emit) {
      this._emit("message", message);
    }
  }
  async _createPromptCachingBetaMessage(messages, params, options) {
    const signal = options?.signal;
    if (signal) {
      if (signal.aborted)
        this.controller.abort();
      signal.addEventListener("abort", () => this.controller.abort());
    }
    __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_instances, "m", _PromptCachingBetaMessageStream_beginRequest).call(this);
    const stream = await messages.create({ ...params, stream: true }, { ...options, signal: this.controller.signal });
    this._connected();
    for await (const event of stream) {
      __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_instances, "m", _PromptCachingBetaMessageStream_addStreamEvent).call(this, event);
    }
    if (stream.controller.signal?.aborted) {
      throw new APIUserAbortError();
    }
    __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_instances, "m", _PromptCachingBetaMessageStream_endRequest).call(this);
  }
  _connected() {
    if (this.ended)
      return;
    __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_resolveConnectedPromise, "f").call(this);
    this._emit("connect");
  }
  get ended() {
    return __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_ended, "f");
  }
  get errored() {
    return __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_errored, "f");
  }
  get aborted() {
    return __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_aborted, "f");
  }
  abort() {
    this.controller.abort();
  }
  /**
   * Adds the listener function to the end of the listeners array for the event.
   * No checks are made to see if the listener has already been added. Multiple calls passing
   * the same combination of event and listener will result in the listener being added, and
   * called, multiple times.
   * @returns this PromptCachingBetaMessageStream, so that calls can be chained
   */
  on(event, listener) {
    const listeners = __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_listeners, "f")[event] || (__classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_listeners, "f")[event] = []);
    listeners.push({ listener });
    return this;
  }
  /**
   * Removes the specified listener from the listener array for the event.
   * off() will remove, at most, one instance of a listener from the listener array. If any single
   * listener has been added multiple times to the listener array for the specified event, then
   * off() must be called multiple times to remove each instance.
   * @returns this PromptCachingBetaMessageStream, so that calls can be chained
   */
  off(event, listener) {
    const listeners = __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_listeners, "f")[event];
    if (!listeners)
      return this;
    const index = listeners.findIndex((l) => l.listener === listener);
    if (index >= 0)
      listeners.splice(index, 1);
    return this;
  }
  /**
   * Adds a one-time listener function for the event. The next time the event is triggered,
   * this listener is removed and then invoked.
   * @returns this PromptCachingBetaMessageStream, so that calls can be chained
   */
  once(event, listener) {
    const listeners = __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_listeners, "f")[event] || (__classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_listeners, "f")[event] = []);
    listeners.push({ listener, once: true });
    return this;
  }
  /**
   * This is similar to `.once()`, but returns a Promise that resolves the next time
   * the event is triggered, instead of calling a listener callback.
   * @returns a Promise that resolves the next time given event is triggered,
   * or rejects if an error is emitted.  (If you request the 'error' event,
   * returns a promise that resolves with the error).
   *
   * Example:
   *
   *   const message = await stream.emitted('message') // rejects if the stream errors
   */
  emitted(event) {
    return new Promise((resolve, reject) => {
      __classPrivateFieldSet2(this, _PromptCachingBetaMessageStream_catchingPromiseCreated, true, "f");
      if (event !== "error")
        this.once("error", reject);
      this.once(event, resolve);
    });
  }
  async done() {
    __classPrivateFieldSet2(this, _PromptCachingBetaMessageStream_catchingPromiseCreated, true, "f");
    await __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_endPromise, "f");
  }
  get currentMessage() {
    return __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_currentMessageSnapshot, "f");
  }
  /**
   * @returns a promise that resolves with the the final assistant PromptCachingBetaMessage response,
   * or rejects if an error occurred or the stream ended prematurely without producing a PromptCachingBetaMessage.
   */
  async finalMessage() {
    await this.done();
    return __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_instances, "m", _PromptCachingBetaMessageStream_getFinalMessage).call(this);
  }
  /**
   * @returns a promise that resolves with the the final assistant PromptCachingBetaMessage's text response, concatenated
   * together if there are more than one text blocks.
   * Rejects if an error occurred or the stream ended prematurely without producing a PromptCachingBetaMessage.
   */
  async finalText() {
    await this.done();
    return __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_instances, "m", _PromptCachingBetaMessageStream_getFinalText).call(this);
  }
  _emit(event, ...args) {
    if (__classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_ended, "f"))
      return;
    if (event === "end") {
      __classPrivateFieldSet2(this, _PromptCachingBetaMessageStream_ended, true, "f");
      __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_resolveEndPromise, "f").call(this);
    }
    const listeners = __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_listeners, "f")[event];
    if (listeners) {
      __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_listeners, "f")[event] = listeners.filter((l) => !l.once);
      listeners.forEach(({ listener }) => listener(...args));
    }
    if (event === "abort") {
      const error = args[0];
      if (!__classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_catchingPromiseCreated, "f") && !listeners?.length) {
        Promise.reject(error);
      }
      __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_rejectConnectedPromise, "f").call(this, error);
      __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_rejectEndPromise, "f").call(this, error);
      this._emit("end");
      return;
    }
    if (event === "error") {
      const error = args[0];
      if (!__classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_catchingPromiseCreated, "f") && !listeners?.length) {
        Promise.reject(error);
      }
      __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_rejectConnectedPromise, "f").call(this, error);
      __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_rejectEndPromise, "f").call(this, error);
      this._emit("end");
    }
  }
  _emitFinal() {
    const finalPromptCachingBetaMessage = this.receivedMessages.at(-1);
    if (finalPromptCachingBetaMessage) {
      this._emit("finalPromptCachingBetaMessage", __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_instances, "m", _PromptCachingBetaMessageStream_getFinalMessage).call(this));
    }
  }
  async _fromReadableStream(readableStream, options) {
    const signal = options?.signal;
    if (signal) {
      if (signal.aborted)
        this.controller.abort();
      signal.addEventListener("abort", () => this.controller.abort());
    }
    __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_instances, "m", _PromptCachingBetaMessageStream_beginRequest).call(this);
    this._connected();
    const stream = Stream.fromReadableStream(readableStream, this.controller);
    for await (const event of stream) {
      __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_instances, "m", _PromptCachingBetaMessageStream_addStreamEvent).call(this, event);
    }
    if (stream.controller.signal?.aborted) {
      throw new APIUserAbortError();
    }
    __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_instances, "m", _PromptCachingBetaMessageStream_endRequest).call(this);
  }
  [(_PromptCachingBetaMessageStream_currentMessageSnapshot = /* @__PURE__ */ new WeakMap(), _PromptCachingBetaMessageStream_connectedPromise = /* @__PURE__ */ new WeakMap(), _PromptCachingBetaMessageStream_resolveConnectedPromise = /* @__PURE__ */ new WeakMap(), _PromptCachingBetaMessageStream_rejectConnectedPromise = /* @__PURE__ */ new WeakMap(), _PromptCachingBetaMessageStream_endPromise = /* @__PURE__ */ new WeakMap(), _PromptCachingBetaMessageStream_resolveEndPromise = /* @__PURE__ */ new WeakMap(), _PromptCachingBetaMessageStream_rejectEndPromise = /* @__PURE__ */ new WeakMap(), _PromptCachingBetaMessageStream_listeners = /* @__PURE__ */ new WeakMap(), _PromptCachingBetaMessageStream_ended = /* @__PURE__ */ new WeakMap(), _PromptCachingBetaMessageStream_errored = /* @__PURE__ */ new WeakMap(), _PromptCachingBetaMessageStream_aborted = /* @__PURE__ */ new WeakMap(), _PromptCachingBetaMessageStream_catchingPromiseCreated = /* @__PURE__ */ new WeakMap(), _PromptCachingBetaMessageStream_handleError = /* @__PURE__ */ new WeakMap(), _PromptCachingBetaMessageStream_instances = /* @__PURE__ */ new WeakSet(), _PromptCachingBetaMessageStream_getFinalMessage = function _PromptCachingBetaMessageStream_getFinalMessage2() {
    if (this.receivedMessages.length === 0) {
      throw new AnthropicError("stream ended without producing a PromptCachingBetaMessage with role=assistant");
    }
    return this.receivedMessages.at(-1);
  }, _PromptCachingBetaMessageStream_getFinalText = function _PromptCachingBetaMessageStream_getFinalText2() {
    if (this.receivedMessages.length === 0) {
      throw new AnthropicError("stream ended without producing a PromptCachingBetaMessage with role=assistant");
    }
    const textBlocks = this.receivedMessages.at(-1).content.filter((block) => block.type === "text").map((block) => block.text);
    if (textBlocks.length === 0) {
      throw new AnthropicError("stream ended without producing a content block with type=text");
    }
    return textBlocks.join(" ");
  }, _PromptCachingBetaMessageStream_beginRequest = function _PromptCachingBetaMessageStream_beginRequest2() {
    if (this.ended)
      return;
    __classPrivateFieldSet2(this, _PromptCachingBetaMessageStream_currentMessageSnapshot, void 0, "f");
  }, _PromptCachingBetaMessageStream_addStreamEvent = function _PromptCachingBetaMessageStream_addStreamEvent2(event) {
    if (this.ended)
      return;
    const messageSnapshot = __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_instances, "m", _PromptCachingBetaMessageStream_accumulateMessage).call(this, event);
    this._emit("streamEvent", event, messageSnapshot);
    switch (event.type) {
      case "content_block_delta": {
        const content = messageSnapshot.content.at(-1);
        if (event.delta.type === "text_delta" && content.type === "text") {
          this._emit("text", event.delta.text, content.text || "");
        } else if (event.delta.type === "input_json_delta" && content.type === "tool_use") {
          if (content.input) {
            this._emit("inputJson", event.delta.partial_json, content.input);
          }
        }
        break;
      }
      case "message_stop": {
        this._addPromptCachingBetaMessageParam(messageSnapshot);
        this._addPromptCachingBetaMessage(messageSnapshot, true);
        break;
      }
      case "content_block_stop": {
        this._emit("contentBlock", messageSnapshot.content.at(-1));
        break;
      }
      case "message_start": {
        __classPrivateFieldSet2(this, _PromptCachingBetaMessageStream_currentMessageSnapshot, messageSnapshot, "f");
        break;
      }
      case "content_block_start":
      case "message_delta":
        break;
    }
  }, _PromptCachingBetaMessageStream_endRequest = function _PromptCachingBetaMessageStream_endRequest2() {
    if (this.ended) {
      throw new AnthropicError(`stream has ended, this shouldn't happen`);
    }
    const snapshot = __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_currentMessageSnapshot, "f");
    if (!snapshot) {
      throw new AnthropicError(`request ended without sending any chunks`);
    }
    __classPrivateFieldSet2(this, _PromptCachingBetaMessageStream_currentMessageSnapshot, void 0, "f");
    return snapshot;
  }, _PromptCachingBetaMessageStream_accumulateMessage = function _PromptCachingBetaMessageStream_accumulateMessage2(event) {
    let snapshot = __classPrivateFieldGet2(this, _PromptCachingBetaMessageStream_currentMessageSnapshot, "f");
    if (event.type === "message_start") {
      if (snapshot) {
        throw new AnthropicError(`Unexpected event order, got ${event.type} before receiving "message_stop"`);
      }
      return event.message;
    }
    if (!snapshot) {
      throw new AnthropicError(`Unexpected event order, got ${event.type} before "message_start"`);
    }
    switch (event.type) {
      case "message_stop":
        return snapshot;
      case "message_delta":
        snapshot.stop_reason = event.delta.stop_reason;
        snapshot.stop_sequence = event.delta.stop_sequence;
        snapshot.usage.output_tokens = event.usage.output_tokens;
        return snapshot;
      case "content_block_start":
        snapshot.content.push(event.content_block);
        return snapshot;
      case "content_block_delta": {
        const snapshotContent = snapshot.content.at(event.index);
        if (snapshotContent?.type === "text" && event.delta.type === "text_delta") {
          snapshotContent.text += event.delta.text;
        } else if (snapshotContent?.type === "tool_use" && event.delta.type === "input_json_delta") {
          let jsonBuf = snapshotContent[JSON_BUF_PROPERTY] || "";
          jsonBuf += event.delta.partial_json;
          Object.defineProperty(snapshotContent, JSON_BUF_PROPERTY, {
            value: jsonBuf,
            enumerable: false,
            writable: true
          });
          if (jsonBuf) {
            snapshotContent.input = partialParse(jsonBuf);
          }
        }
        return snapshot;
      }
      case "content_block_stop":
        return snapshot;
    }
  }, Symbol.asyncIterator)]() {
    const pushQueue = [];
    const readQueue = [];
    let done = false;
    this.on("streamEvent", (event) => {
      const reader = readQueue.shift();
      if (reader) {
        reader.resolve(event);
      } else {
        pushQueue.push(event);
      }
    });
    this.on("end", () => {
      done = true;
      for (const reader of readQueue) {
        reader.resolve(void 0);
      }
      readQueue.length = 0;
    });
    this.on("abort", (err) => {
      done = true;
      for (const reader of readQueue) {
        reader.reject(err);
      }
      readQueue.length = 0;
    });
    this.on("error", (err) => {
      done = true;
      for (const reader of readQueue) {
        reader.reject(err);
      }
      readQueue.length = 0;
    });
    return {
      next: async () => {
        if (!pushQueue.length) {
          if (done) {
            return { value: void 0, done: true };
          }
          return new Promise((resolve, reject) => readQueue.push({ resolve, reject })).then((chunk2) => chunk2 ? { value: chunk2, done: false } : { value: void 0, done: true });
        }
        const chunk = pushQueue.shift();
        return { value: chunk, done: false };
      },
      return: async () => {
        this.abort();
        return { value: void 0, done: true };
      }
    };
  }
  toReadableStream() {
    const stream = new Stream(this[Symbol.asyncIterator].bind(this), this.controller);
    return stream.toReadableStream();
  }
};

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/resources/beta/prompt-caching/messages.mjs
var Messages = class extends APIResource {
  create(body, options) {
    return this._client.post("/v1/messages?beta=prompt_caching", {
      body,
      timeout: this._client._options.timeout ?? 6e5,
      ...options,
      headers: { "anthropic-beta": "prompt-caching-2024-07-31", ...options?.headers },
      stream: body.stream ?? false
    });
  }
  /**
   * Create a Message stream
   */
  stream(body, options) {
    return PromptCachingBetaMessageStream.createMessage(this, body, options);
  }
};
/* @__PURE__ */ (function(Messages3) {
})(Messages || (Messages = {}));

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/resources/beta/prompt-caching/prompt-caching.mjs
var PromptCaching = class extends APIResource {
  constructor() {
    super(...arguments);
    this.messages = new Messages(this._client);
  }
};
(function(PromptCaching2) {
  PromptCaching2.Messages = Messages;
})(PromptCaching || (PromptCaching = {}));

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/resources/beta/beta.mjs
var Beta = class extends APIResource {
  constructor() {
    super(...arguments);
    this.promptCaching = new PromptCaching(this._client);
  }
};
(function(Beta2) {
  Beta2.PromptCaching = PromptCaching;
})(Beta || (Beta = {}));

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/resources/completions.mjs
var Completions = class extends APIResource {
  create(body, options) {
    return this._client.post("/v1/complete", {
      body,
      timeout: this._client._options.timeout ?? 6e5,
      ...options,
      stream: body.stream ?? false
    });
  }
};
/* @__PURE__ */ (function(Completions2) {
})(Completions || (Completions = {}));

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/lib/MessageStream.mjs
var __classPrivateFieldSet3 = function(receiver, state, value, kind2, f) {
  if (kind2 === "m") throw new TypeError("Private method is not writable");
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
  return kind2 === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
};
var __classPrivateFieldGet3 = function(receiver, state, kind2, f) {
  if (kind2 === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
  if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
  return kind2 === "m" ? f : kind2 === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var _MessageStream_instances;
var _MessageStream_currentMessageSnapshot;
var _MessageStream_connectedPromise;
var _MessageStream_resolveConnectedPromise;
var _MessageStream_rejectConnectedPromise;
var _MessageStream_endPromise;
var _MessageStream_resolveEndPromise;
var _MessageStream_rejectEndPromise;
var _MessageStream_listeners;
var _MessageStream_ended;
var _MessageStream_errored;
var _MessageStream_aborted;
var _MessageStream_catchingPromiseCreated;
var _MessageStream_getFinalMessage;
var _MessageStream_getFinalText;
var _MessageStream_handleError;
var _MessageStream_beginRequest;
var _MessageStream_addStreamEvent;
var _MessageStream_endRequest;
var _MessageStream_accumulateMessage;
var JSON_BUF_PROPERTY2 = "__json_buf";
var MessageStream = class _MessageStream {
  constructor() {
    _MessageStream_instances.add(this);
    this.messages = [];
    this.receivedMessages = [];
    _MessageStream_currentMessageSnapshot.set(this, void 0);
    this.controller = new AbortController();
    _MessageStream_connectedPromise.set(this, void 0);
    _MessageStream_resolveConnectedPromise.set(this, () => {
    });
    _MessageStream_rejectConnectedPromise.set(this, () => {
    });
    _MessageStream_endPromise.set(this, void 0);
    _MessageStream_resolveEndPromise.set(this, () => {
    });
    _MessageStream_rejectEndPromise.set(this, () => {
    });
    _MessageStream_listeners.set(this, {});
    _MessageStream_ended.set(this, false);
    _MessageStream_errored.set(this, false);
    _MessageStream_aborted.set(this, false);
    _MessageStream_catchingPromiseCreated.set(this, false);
    _MessageStream_handleError.set(this, (error) => {
      __classPrivateFieldSet3(this, _MessageStream_errored, true, "f");
      if (error instanceof Error && error.name === "AbortError") {
        error = new APIUserAbortError();
      }
      if (error instanceof APIUserAbortError) {
        __classPrivateFieldSet3(this, _MessageStream_aborted, true, "f");
        return this._emit("abort", error);
      }
      if (error instanceof AnthropicError) {
        return this._emit("error", error);
      }
      if (error instanceof Error) {
        const anthropicError = new AnthropicError(error.message);
        anthropicError.cause = error;
        return this._emit("error", anthropicError);
      }
      return this._emit("error", new AnthropicError(String(error)));
    });
    __classPrivateFieldSet3(this, _MessageStream_connectedPromise, new Promise((resolve, reject) => {
      __classPrivateFieldSet3(this, _MessageStream_resolveConnectedPromise, resolve, "f");
      __classPrivateFieldSet3(this, _MessageStream_rejectConnectedPromise, reject, "f");
    }), "f");
    __classPrivateFieldSet3(this, _MessageStream_endPromise, new Promise((resolve, reject) => {
      __classPrivateFieldSet3(this, _MessageStream_resolveEndPromise, resolve, "f");
      __classPrivateFieldSet3(this, _MessageStream_rejectEndPromise, reject, "f");
    }), "f");
    __classPrivateFieldGet3(this, _MessageStream_connectedPromise, "f").catch(() => {
    });
    __classPrivateFieldGet3(this, _MessageStream_endPromise, "f").catch(() => {
    });
  }
  /**
   * Intended for use on the frontend, consuming a stream produced with
   * `.toReadableStream()` on the backend.
   *
   * Note that messages sent to the model do not appear in `.on('message')`
   * in this context.
   */
  static fromReadableStream(stream) {
    const runner = new _MessageStream();
    runner._run(() => runner._fromReadableStream(stream));
    return runner;
  }
  static createMessage(messages, params, options) {
    const runner = new _MessageStream();
    for (const message of params.messages) {
      runner._addMessageParam(message);
    }
    runner._run(() => runner._createMessage(messages, { ...params, stream: true }, { ...options, headers: { ...options?.headers, "X-Stainless-Helper-Method": "stream" } }));
    return runner;
  }
  _run(executor) {
    executor().then(() => {
      this._emitFinal();
      this._emit("end");
    }, __classPrivateFieldGet3(this, _MessageStream_handleError, "f"));
  }
  _addMessageParam(message) {
    this.messages.push(message);
  }
  _addMessage(message, emit = true) {
    this.receivedMessages.push(message);
    if (emit) {
      this._emit("message", message);
    }
  }
  async _createMessage(messages, params, options) {
    const signal = options?.signal;
    if (signal) {
      if (signal.aborted)
        this.controller.abort();
      signal.addEventListener("abort", () => this.controller.abort());
    }
    __classPrivateFieldGet3(this, _MessageStream_instances, "m", _MessageStream_beginRequest).call(this);
    const stream = await messages.create({ ...params, stream: true }, { ...options, signal: this.controller.signal });
    this._connected();
    for await (const event of stream) {
      __classPrivateFieldGet3(this, _MessageStream_instances, "m", _MessageStream_addStreamEvent).call(this, event);
    }
    if (stream.controller.signal?.aborted) {
      throw new APIUserAbortError();
    }
    __classPrivateFieldGet3(this, _MessageStream_instances, "m", _MessageStream_endRequest).call(this);
  }
  _connected() {
    if (this.ended)
      return;
    __classPrivateFieldGet3(this, _MessageStream_resolveConnectedPromise, "f").call(this);
    this._emit("connect");
  }
  get ended() {
    return __classPrivateFieldGet3(this, _MessageStream_ended, "f");
  }
  get errored() {
    return __classPrivateFieldGet3(this, _MessageStream_errored, "f");
  }
  get aborted() {
    return __classPrivateFieldGet3(this, _MessageStream_aborted, "f");
  }
  abort() {
    this.controller.abort();
  }
  /**
   * Adds the listener function to the end of the listeners array for the event.
   * No checks are made to see if the listener has already been added. Multiple calls passing
   * the same combination of event and listener will result in the listener being added, and
   * called, multiple times.
   * @returns this MessageStream, so that calls can be chained
   */
  on(event, listener) {
    const listeners = __classPrivateFieldGet3(this, _MessageStream_listeners, "f")[event] || (__classPrivateFieldGet3(this, _MessageStream_listeners, "f")[event] = []);
    listeners.push({ listener });
    return this;
  }
  /**
   * Removes the specified listener from the listener array for the event.
   * off() will remove, at most, one instance of a listener from the listener array. If any single
   * listener has been added multiple times to the listener array for the specified event, then
   * off() must be called multiple times to remove each instance.
   * @returns this MessageStream, so that calls can be chained
   */
  off(event, listener) {
    const listeners = __classPrivateFieldGet3(this, _MessageStream_listeners, "f")[event];
    if (!listeners)
      return this;
    const index = listeners.findIndex((l) => l.listener === listener);
    if (index >= 0)
      listeners.splice(index, 1);
    return this;
  }
  /**
   * Adds a one-time listener function for the event. The next time the event is triggered,
   * this listener is removed and then invoked.
   * @returns this MessageStream, so that calls can be chained
   */
  once(event, listener) {
    const listeners = __classPrivateFieldGet3(this, _MessageStream_listeners, "f")[event] || (__classPrivateFieldGet3(this, _MessageStream_listeners, "f")[event] = []);
    listeners.push({ listener, once: true });
    return this;
  }
  /**
   * This is similar to `.once()`, but returns a Promise that resolves the next time
   * the event is triggered, instead of calling a listener callback.
   * @returns a Promise that resolves the next time given event is triggered,
   * or rejects if an error is emitted.  (If you request the 'error' event,
   * returns a promise that resolves with the error).
   *
   * Example:
   *
   *   const message = await stream.emitted('message') // rejects if the stream errors
   */
  emitted(event) {
    return new Promise((resolve, reject) => {
      __classPrivateFieldSet3(this, _MessageStream_catchingPromiseCreated, true, "f");
      if (event !== "error")
        this.once("error", reject);
      this.once(event, resolve);
    });
  }
  async done() {
    __classPrivateFieldSet3(this, _MessageStream_catchingPromiseCreated, true, "f");
    await __classPrivateFieldGet3(this, _MessageStream_endPromise, "f");
  }
  get currentMessage() {
    return __classPrivateFieldGet3(this, _MessageStream_currentMessageSnapshot, "f");
  }
  /**
   * @returns a promise that resolves with the the final assistant Message response,
   * or rejects if an error occurred or the stream ended prematurely without producing a Message.
   */
  async finalMessage() {
    await this.done();
    return __classPrivateFieldGet3(this, _MessageStream_instances, "m", _MessageStream_getFinalMessage).call(this);
  }
  /**
   * @returns a promise that resolves with the the final assistant Message's text response, concatenated
   * together if there are more than one text blocks.
   * Rejects if an error occurred or the stream ended prematurely without producing a Message.
   */
  async finalText() {
    await this.done();
    return __classPrivateFieldGet3(this, _MessageStream_instances, "m", _MessageStream_getFinalText).call(this);
  }
  _emit(event, ...args) {
    if (__classPrivateFieldGet3(this, _MessageStream_ended, "f"))
      return;
    if (event === "end") {
      __classPrivateFieldSet3(this, _MessageStream_ended, true, "f");
      __classPrivateFieldGet3(this, _MessageStream_resolveEndPromise, "f").call(this);
    }
    const listeners = __classPrivateFieldGet3(this, _MessageStream_listeners, "f")[event];
    if (listeners) {
      __classPrivateFieldGet3(this, _MessageStream_listeners, "f")[event] = listeners.filter((l) => !l.once);
      listeners.forEach(({ listener }) => listener(...args));
    }
    if (event === "abort") {
      const error = args[0];
      if (!__classPrivateFieldGet3(this, _MessageStream_catchingPromiseCreated, "f") && !listeners?.length) {
        Promise.reject(error);
      }
      __classPrivateFieldGet3(this, _MessageStream_rejectConnectedPromise, "f").call(this, error);
      __classPrivateFieldGet3(this, _MessageStream_rejectEndPromise, "f").call(this, error);
      this._emit("end");
      return;
    }
    if (event === "error") {
      const error = args[0];
      if (!__classPrivateFieldGet3(this, _MessageStream_catchingPromiseCreated, "f") && !listeners?.length) {
        Promise.reject(error);
      }
      __classPrivateFieldGet3(this, _MessageStream_rejectConnectedPromise, "f").call(this, error);
      __classPrivateFieldGet3(this, _MessageStream_rejectEndPromise, "f").call(this, error);
      this._emit("end");
    }
  }
  _emitFinal() {
    const finalMessage = this.receivedMessages.at(-1);
    if (finalMessage) {
      this._emit("finalMessage", __classPrivateFieldGet3(this, _MessageStream_instances, "m", _MessageStream_getFinalMessage).call(this));
    }
  }
  async _fromReadableStream(readableStream, options) {
    const signal = options?.signal;
    if (signal) {
      if (signal.aborted)
        this.controller.abort();
      signal.addEventListener("abort", () => this.controller.abort());
    }
    __classPrivateFieldGet3(this, _MessageStream_instances, "m", _MessageStream_beginRequest).call(this);
    this._connected();
    const stream = Stream.fromReadableStream(readableStream, this.controller);
    for await (const event of stream) {
      __classPrivateFieldGet3(this, _MessageStream_instances, "m", _MessageStream_addStreamEvent).call(this, event);
    }
    if (stream.controller.signal?.aborted) {
      throw new APIUserAbortError();
    }
    __classPrivateFieldGet3(this, _MessageStream_instances, "m", _MessageStream_endRequest).call(this);
  }
  [(_MessageStream_currentMessageSnapshot = /* @__PURE__ */ new WeakMap(), _MessageStream_connectedPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_resolveConnectedPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_rejectConnectedPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_endPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_resolveEndPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_rejectEndPromise = /* @__PURE__ */ new WeakMap(), _MessageStream_listeners = /* @__PURE__ */ new WeakMap(), _MessageStream_ended = /* @__PURE__ */ new WeakMap(), _MessageStream_errored = /* @__PURE__ */ new WeakMap(), _MessageStream_aborted = /* @__PURE__ */ new WeakMap(), _MessageStream_catchingPromiseCreated = /* @__PURE__ */ new WeakMap(), _MessageStream_handleError = /* @__PURE__ */ new WeakMap(), _MessageStream_instances = /* @__PURE__ */ new WeakSet(), _MessageStream_getFinalMessage = function _MessageStream_getFinalMessage2() {
    if (this.receivedMessages.length === 0) {
      throw new AnthropicError("stream ended without producing a Message with role=assistant");
    }
    return this.receivedMessages.at(-1);
  }, _MessageStream_getFinalText = function _MessageStream_getFinalText2() {
    if (this.receivedMessages.length === 0) {
      throw new AnthropicError("stream ended without producing a Message with role=assistant");
    }
    const textBlocks = this.receivedMessages.at(-1).content.filter((block) => block.type === "text").map((block) => block.text);
    if (textBlocks.length === 0) {
      throw new AnthropicError("stream ended without producing a content block with type=text");
    }
    return textBlocks.join(" ");
  }, _MessageStream_beginRequest = function _MessageStream_beginRequest2() {
    if (this.ended)
      return;
    __classPrivateFieldSet3(this, _MessageStream_currentMessageSnapshot, void 0, "f");
  }, _MessageStream_addStreamEvent = function _MessageStream_addStreamEvent2(event) {
    if (this.ended)
      return;
    const messageSnapshot = __classPrivateFieldGet3(this, _MessageStream_instances, "m", _MessageStream_accumulateMessage).call(this, event);
    this._emit("streamEvent", event, messageSnapshot);
    switch (event.type) {
      case "content_block_delta": {
        const content = messageSnapshot.content.at(-1);
        if (event.delta.type === "text_delta" && content.type === "text") {
          this._emit("text", event.delta.text, content.text || "");
        } else if (event.delta.type === "input_json_delta" && content.type === "tool_use") {
          if (content.input) {
            this._emit("inputJson", event.delta.partial_json, content.input);
          }
        }
        break;
      }
      case "message_stop": {
        this._addMessageParam(messageSnapshot);
        this._addMessage(messageSnapshot, true);
        break;
      }
      case "content_block_stop": {
        this._emit("contentBlock", messageSnapshot.content.at(-1));
        break;
      }
      case "message_start": {
        __classPrivateFieldSet3(this, _MessageStream_currentMessageSnapshot, messageSnapshot, "f");
        break;
      }
      case "content_block_start":
      case "message_delta":
        break;
    }
  }, _MessageStream_endRequest = function _MessageStream_endRequest2() {
    if (this.ended) {
      throw new AnthropicError(`stream has ended, this shouldn't happen`);
    }
    const snapshot = __classPrivateFieldGet3(this, _MessageStream_currentMessageSnapshot, "f");
    if (!snapshot) {
      throw new AnthropicError(`request ended without sending any chunks`);
    }
    __classPrivateFieldSet3(this, _MessageStream_currentMessageSnapshot, void 0, "f");
    return snapshot;
  }, _MessageStream_accumulateMessage = function _MessageStream_accumulateMessage2(event) {
    let snapshot = __classPrivateFieldGet3(this, _MessageStream_currentMessageSnapshot, "f");
    if (event.type === "message_start") {
      if (snapshot) {
        throw new AnthropicError(`Unexpected event order, got ${event.type} before receiving "message_stop"`);
      }
      return event.message;
    }
    if (!snapshot) {
      throw new AnthropicError(`Unexpected event order, got ${event.type} before "message_start"`);
    }
    switch (event.type) {
      case "message_stop":
        return snapshot;
      case "message_delta":
        snapshot.stop_reason = event.delta.stop_reason;
        snapshot.stop_sequence = event.delta.stop_sequence;
        snapshot.usage.output_tokens = event.usage.output_tokens;
        return snapshot;
      case "content_block_start":
        snapshot.content.push(event.content_block);
        return snapshot;
      case "content_block_delta": {
        const snapshotContent = snapshot.content.at(event.index);
        if (snapshotContent?.type === "text" && event.delta.type === "text_delta") {
          snapshotContent.text += event.delta.text;
        } else if (snapshotContent?.type === "tool_use" && event.delta.type === "input_json_delta") {
          let jsonBuf = snapshotContent[JSON_BUF_PROPERTY2] || "";
          jsonBuf += event.delta.partial_json;
          Object.defineProperty(snapshotContent, JSON_BUF_PROPERTY2, {
            value: jsonBuf,
            enumerable: false,
            writable: true
          });
          if (jsonBuf) {
            snapshotContent.input = partialParse(jsonBuf);
          }
        }
        return snapshot;
      }
      case "content_block_stop":
        return snapshot;
    }
  }, Symbol.asyncIterator)]() {
    const pushQueue = [];
    const readQueue = [];
    let done = false;
    this.on("streamEvent", (event) => {
      const reader = readQueue.shift();
      if (reader) {
        reader.resolve(event);
      } else {
        pushQueue.push(event);
      }
    });
    this.on("end", () => {
      done = true;
      for (const reader of readQueue) {
        reader.resolve(void 0);
      }
      readQueue.length = 0;
    });
    this.on("abort", (err) => {
      done = true;
      for (const reader of readQueue) {
        reader.reject(err);
      }
      readQueue.length = 0;
    });
    this.on("error", (err) => {
      done = true;
      for (const reader of readQueue) {
        reader.reject(err);
      }
      readQueue.length = 0;
    });
    return {
      next: async () => {
        if (!pushQueue.length) {
          if (done) {
            return { value: void 0, done: true };
          }
          return new Promise((resolve, reject) => readQueue.push({ resolve, reject })).then((chunk2) => chunk2 ? { value: chunk2, done: false } : { value: void 0, done: true });
        }
        const chunk = pushQueue.shift();
        return { value: chunk, done: false };
      },
      return: async () => {
        this.abort();
        return { value: void 0, done: true };
      }
    };
  }
  toReadableStream() {
    const stream = new Stream(this[Symbol.asyncIterator].bind(this), this.controller);
    return stream.toReadableStream();
  }
};

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/resources/messages.mjs
var Messages2 = class extends APIResource {
  create(body, options) {
    if (body.model in DEPRECATED_MODELS) {
      console.warn(`The model '${body.model}' is deprecated and will reach end-of-life on ${DEPRECATED_MODELS[body.model]}
Please migrate to a newer model. Visit https://docs.anthropic.com/en/docs/resources/model-deprecations for more information.`);
    }
    return this._client.post("/v1/messages", {
      body,
      timeout: this._client._options.timeout ?? 6e5,
      ...options,
      stream: body.stream ?? false
    });
  }
  /**
   * Create a Message stream
   */
  stream(body, options) {
    return MessageStream.createMessage(this, body, options);
  }
};
var DEPRECATED_MODELS = {
  "claude-1.3": "November 6th, 2024",
  "claude-1.3-100k": "November 6th, 2024",
  "claude-instant-1.1": "November 6th, 2024",
  "claude-instant-1.1-100k": "November 6th, 2024",
  "claude-instant-1.2": "November 6th, 2024"
};
/* @__PURE__ */ (function(Messages3) {
})(Messages2 || (Messages2 = {}));

// ../../node_modules/.pnpm/@anthropic-ai+sdk@0.28.0/node_modules/@anthropic-ai/sdk/index.mjs
var _a;
var Anthropic = class extends APIClient {
  /**
   * API Client for interfacing with the Anthropic API.
   *
   * @param {string | null | undefined} [opts.apiKey=process.env['ANTHROPIC_API_KEY'] ?? null]
   * @param {string | null | undefined} [opts.authToken=process.env['ANTHROPIC_AUTH_TOKEN'] ?? null]
   * @param {string} [opts.baseURL=process.env['ANTHROPIC_BASE_URL'] ?? https://api.anthropic.com] - Override the default base URL for the API.
   * @param {number} [opts.timeout=10 minutes] - The maximum amount of time (in milliseconds) the client will wait for a response before timing out.
   * @param {number} [opts.httpAgent] - An HTTP agent used to manage HTTP(s) connections.
   * @param {Core.Fetch} [opts.fetch] - Specify a custom `fetch` function implementation.
   * @param {number} [opts.maxRetries=2] - The maximum number of times the client will retry a request.
   * @param {Core.Headers} opts.defaultHeaders - Default headers to include with every request to the API.
   * @param {Core.DefaultQuery} opts.defaultQuery - Default query parameters to include with every request to the API.
   * @param {boolean} [opts.dangerouslyAllowBrowser=false] - By default, client-side use of this library is not allowed, as it risks exposing your secret API credentials to attackers.
   */
  constructor({ baseURL = readEnv("ANTHROPIC_BASE_URL"), apiKey = readEnv("ANTHROPIC_API_KEY") ?? null, authToken = readEnv("ANTHROPIC_AUTH_TOKEN") ?? null, ...opts } = {}) {
    const options = {
      apiKey,
      authToken,
      ...opts,
      baseURL: baseURL || `https://api.anthropic.com`
    };
    if (!options.dangerouslyAllowBrowser && isRunningInBrowser()) {
      throw new AnthropicError("It looks like you're running in a browser-like environment.\n\nThis is disabled by default, as it risks exposing your secret API credentials to attackers.\nIf you understand the risks and have appropriate mitigations in place,\nyou can set the `dangerouslyAllowBrowser` option to `true`, e.g.,\n\nnew Anthropic({ apiKey, dangerouslyAllowBrowser: true });\n\nTODO: link!\n");
    }
    super({
      baseURL: options.baseURL,
      timeout: options.timeout ?? 6e5,
      httpAgent: options.httpAgent,
      maxRetries: options.maxRetries,
      fetch: options.fetch
    });
    this.completions = new Completions(this);
    this.messages = new Messages2(this);
    this.beta = new Beta(this);
    this._options = options;
    this.apiKey = apiKey;
    this.authToken = authToken;
  }
  defaultQuery() {
    return this._options.defaultQuery;
  }
  defaultHeaders(opts) {
    return {
      ...super.defaultHeaders(opts),
      ...this._options.dangerouslyAllowBrowser ? { "anthropic-dangerous-direct-browser-access": "true" } : void 0,
      "anthropic-version": "2023-06-01",
      ...this._options.defaultHeaders
    };
  }
  validateHeaders(headers, customHeaders) {
    if (this.apiKey && headers["x-api-key"]) {
      return;
    }
    if (customHeaders["x-api-key"] === null) {
      return;
    }
    if (this.authToken && headers["authorization"]) {
      return;
    }
    if (customHeaders["authorization"] === null) {
      return;
    }
    throw new Error('Could not resolve authentication method. Expected either apiKey or authToken to be set. Or for one of the "X-Api-Key" or "Authorization" headers to be explicitly omitted');
  }
  authHeaders(opts) {
    const apiKeyAuth = this.apiKeyAuth(opts);
    const bearerAuth = this.bearerAuth(opts);
    if (apiKeyAuth != null && !isEmptyObj(apiKeyAuth)) {
      return apiKeyAuth;
    }
    if (bearerAuth != null && !isEmptyObj(bearerAuth)) {
      return bearerAuth;
    }
    return {};
  }
  apiKeyAuth(opts) {
    if (this.apiKey == null) {
      return {};
    }
    return { "X-Api-Key": this.apiKey };
  }
  bearerAuth(opts) {
    if (this.authToken == null) {
      return {};
    }
    return { Authorization: `Bearer ${this.authToken}` };
  }
};
_a = Anthropic;
Anthropic.Anthropic = _a;
Anthropic.HUMAN_PROMPT = "\n\nHuman:";
Anthropic.AI_PROMPT = "\n\nAssistant:";
Anthropic.DEFAULT_TIMEOUT = 6e5;
Anthropic.AnthropicError = AnthropicError;
Anthropic.APIError = APIError;
Anthropic.APIConnectionError = APIConnectionError;
Anthropic.APIConnectionTimeoutError = APIConnectionTimeoutError;
Anthropic.APIUserAbortError = APIUserAbortError;
Anthropic.NotFoundError = NotFoundError;
Anthropic.ConflictError = ConflictError;
Anthropic.RateLimitError = RateLimitError;
Anthropic.BadRequestError = BadRequestError;
Anthropic.AuthenticationError = AuthenticationError;
Anthropic.InternalServerError = InternalServerError;
Anthropic.PermissionDeniedError = PermissionDeniedError;
Anthropic.UnprocessableEntityError = UnprocessableEntityError;
Anthropic.toFile = toFile;
Anthropic.fileFromPath = fileFromPath;
var { HUMAN_PROMPT, AI_PROMPT } = Anthropic;
var { AnthropicError: AnthropicError2, APIError: APIError2, APIConnectionError: APIConnectionError2, APIConnectionTimeoutError: APIConnectionTimeoutError2, APIUserAbortError: APIUserAbortError2, NotFoundError: NotFoundError2, ConflictError: ConflictError2, RateLimitError: RateLimitError2, BadRequestError: BadRequestError2, AuthenticationError: AuthenticationError2, InternalServerError: InternalServerError2, PermissionDeniedError: PermissionDeniedError2, UnprocessableEntityError: UnprocessableEntityError2 } = error_exports;
(function(Anthropic2) {
  Anthropic2.Completions = Completions;
  Anthropic2.Messages = Messages2;
  Anthropic2.Beta = Beta;
})(Anthropic || (Anthropic = {}));

// src/utils/base64.ts
function arrayBufferToBase64(buffer) {
  let binary = "";
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < bytes.byteLength; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}
async function getImageAsBase64(imageUrl) {
  if (imageUrl.startsWith("data:")) {
    const [header, data] = imageUrl.split(",");
    const media_type = header.split(":")[1].split(";")[0];
    return { media_type, data };
  }
  const response = await fetch(imageUrl);
  const arrayBuffer = await response.arrayBuffer();
  const base64 = arrayBufferToBase64(arrayBuffer);
  return {
    media_type: response.headers.get("content-type") || "image/jpeg",
    data: base64
  };
}

// src/index.ts
async function convertMessages(messages) {
  return Promise.all(
    messages.map(async (it) => {
      if (!it.content) {
        throw new Error("content is required");
      }
      if (!it.attachments) {
        return {
          role: it.role,
          content: it.content
        };
      }
      return {
        role: it.role,
        content: [
          {
            type: "text",
            text: it.content
          },
          ...await Promise.all(
            it.attachments.map(async (it2) => {
              return {
                type: "image",
                source: {
                  type: "base64",
                  ...await getImageAsBase64(it2.url)
                }
              };
            })
          )
        ]
      };
    })
  );
}
function getModelMaxTokens(model2) {
  if (model2.startsWith("claude-3-5")) {
    return 4096;
  }
  return 8192;
}
async function parseReq(req, stream) {
  return {
    messages: await convertMessages(
      req.messages.filter(
        (it) => [
          "user",
          "assistant"
        ].includes(it.role)
      )
    ),
    max_tokens: getModelMaxTokens(req.model),
    stream,
    model: req.model,
    system: req.messages.find((it) => it.role === "system")?.content
  };
}
function parseResponse(resp) {
  if (resp.content.length !== 1) {
    console.error("Unsupported response", resp.content);
    throw new Error("Unsupported response");
  }
  return {
    content: resp.content[0].text
  };
}
async function activate(context) {
  const createClient = async () => {
    return new Anthropic({
      apiKey: await novachat.setting.get("anthropic.apiKey"),
      defaultHeaders: {
        "anthropic-dangerous-direct-browser-access": "true"
      }
    });
  };
  await novachat.model.registerProvider({
    name: "Anthropic",
    models: [
      { id: "claude-3-5-sonnet-20241022", name: "Claude 3.5 Sonnet v2" },
      { id: "claude-3-5-sonnet-20240620", name: "Claude 3.5 Sonnet" },
      { id: "claude-3-opus-20240229", name: "Claude 3 Opus" },
      { id: "claude-3-sonnet-20240229", name: "Claude 3 Sonnet" },
      { id: "claude-3-haiku-20240307", name: "Claude 3 Haiku" }
    ],
    async invoke(query) {
      const client = await createClient();
      return parseResponse(
        await client.messages.create(
          await parseReq(
            query,
            false
          )
        )
      );
    },
    async *stream(query) {
      const client = await createClient();
      const stream = await client.messages.create(
        await parseReq(
          query,
          true
        )
      );
      for await (const it of stream) {
        if (it.type === "content_block_delta") {
          if (it.delta.type !== "text_delta") {
            throw new Error("Unsupported delta type");
          }
          yield {
            content: it.delta.text
          };
        }
      }
    }
  });
}
export {
  activate
};
//# sourceMappingURL=data:application/json;base64,ewogICJ2ZXJzaW9uIjogMywKICAic291cmNlcyI6IFsiLi4vc3JjL2luZGV4LnRzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AYW50aHJvcGljLWFpK3Nka0AwLjI4LjAvbm9kZV9tb2R1bGVzL0BhbnRocm9waWMtYWkvc2RrL3NyYy9lcnJvci50cyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGFudGhyb3BpYy1haStzZGtAMC4yOC4wL25vZGVfbW9kdWxlcy9AYW50aHJvcGljLWFpL3Nkay9zcmMvdmVyc2lvbi50cyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGFudGhyb3BpYy1haStzZGtAMC4yOC4wL25vZGVfbW9kdWxlcy9AYW50aHJvcGljLWFpL3Nkay9zcmMvX3NoaW1zL3JlZ2lzdHJ5LnRzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AYW50aHJvcGljLWFpK3Nka0AwLjI4LjAvbm9kZV9tb2R1bGVzL0BhbnRocm9waWMtYWkvc2RrL3NyYy9fc2hpbXMvTXVsdGlwYXJ0Qm9keS50cyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGFudGhyb3BpYy1haStzZGtAMC4yOC4wL25vZGVfbW9kdWxlcy9AYW50aHJvcGljLWFpL3Nkay9zcmMvX3NoaW1zL3dlYi1ydW50aW1lLnRzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AYW50aHJvcGljLWFpK3Nka0AwLjI4LjAvbm9kZV9tb2R1bGVzL0BhbnRocm9waWMtYWkvc2RrL19zaGltcy9pbmRleC5tanMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BhbnRocm9waWMtYWkrc2RrQDAuMjguMC9ub2RlX21vZHVsZXMvQGFudGhyb3BpYy1haS9zZGsvc3JjL3N0cmVhbWluZy50cyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGFudGhyb3BpYy1haStzZGtAMC4yOC4wL25vZGVfbW9kdWxlcy9AYW50aHJvcGljLWFpL3Nkay9zcmMvdXBsb2Fkcy50cyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGFudGhyb3BpYy1haStzZGtAMC4yOC4wL25vZGVfbW9kdWxlcy9AYW50aHJvcGljLWFpL3Nkay9zcmMvY29yZS50cyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGFudGhyb3BpYy1haStzZGtAMC4yOC4wL25vZGVfbW9kdWxlcy9AYW50aHJvcGljLWFpL3Nkay9zcmMvcmVzb3VyY2UudHMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BhbnRocm9waWMtYWkrc2RrQDAuMjguMC9ub2RlX21vZHVsZXMvQGFudGhyb3BpYy1haS9zZGsvc3JjL192ZW5kb3IvcGFydGlhbC1qc29uLXBhcnNlci9wYXJzZXIudHMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BhbnRocm9waWMtYWkrc2RrQDAuMjguMC9ub2RlX21vZHVsZXMvQGFudGhyb3BpYy1haS9zZGsvc3JjL2xpYi9Qcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW0udHMiLCAiLi4vLi4vLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BhbnRocm9waWMtYWkrc2RrQDAuMjguMC9ub2RlX21vZHVsZXMvQGFudGhyb3BpYy1haS9zZGsvc3JjL3Jlc291cmNlcy9iZXRhL3Byb21wdC1jYWNoaW5nL21lc3NhZ2VzLnRzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AYW50aHJvcGljLWFpK3Nka0AwLjI4LjAvbm9kZV9tb2R1bGVzL0BhbnRocm9waWMtYWkvc2RrL3NyYy9yZXNvdXJjZXMvYmV0YS9wcm9tcHQtY2FjaGluZy9wcm9tcHQtY2FjaGluZy50cyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGFudGhyb3BpYy1haStzZGtAMC4yOC4wL25vZGVfbW9kdWxlcy9AYW50aHJvcGljLWFpL3Nkay9zcmMvcmVzb3VyY2VzL2JldGEvYmV0YS50cyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGFudGhyb3BpYy1haStzZGtAMC4yOC4wL25vZGVfbW9kdWxlcy9AYW50aHJvcGljLWFpL3Nkay9zcmMvcmVzb3VyY2VzL2NvbXBsZXRpb25zLnRzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AYW50aHJvcGljLWFpK3Nka0AwLjI4LjAvbm9kZV9tb2R1bGVzL0BhbnRocm9waWMtYWkvc2RrL3NyYy9saWIvTWVzc2FnZVN0cmVhbS50cyIsICIuLi8uLi8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGFudGhyb3BpYy1haStzZGtAMC4yOC4wL25vZGVfbW9kdWxlcy9AYW50aHJvcGljLWFpL3Nkay9zcmMvcmVzb3VyY2VzL21lc3NhZ2VzLnRzIiwgIi4uLy4uLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AYW50aHJvcGljLWFpK3Nka0AwLjI4LjAvbm9kZV9tb2R1bGVzL0BhbnRocm9waWMtYWkvc2RrL3NyYy9pbmRleC50cyIsICIuLi9zcmMvdXRpbHMvYmFzZTY0LnRzIl0sCiAgInNvdXJjZXNDb250ZW50IjogWyJpbXBvcnQgKiBhcyBub3ZhY2hhdCBmcm9tICdAbm92YWNoYXQvcGx1Z2luJ1xuaW1wb3J0IHR5cGUgQW50aHJvcGljVHlwZXMgZnJvbSAnQGFudGhyb3BpYy1haS9zZGsnXG5pbXBvcnQgeyBBbnRocm9waWMgfSBmcm9tICdAYW50aHJvcGljLWFpL3NkaydcbmltcG9ydCB7IGdldEltYWdlQXNCYXNlNjQgfSBmcm9tICcuL3V0aWxzL2Jhc2U2NCdcblxuYXN5bmMgZnVuY3Rpb24gY29udmVydE1lc3NhZ2VzKFxuICBtZXNzYWdlczogbm92YWNoYXQuUXVlcnlSZXF1ZXN0WydtZXNzYWdlcyddLFxuKTogUHJvbWlzZTxBbnRocm9waWNUeXBlcy5NZXNzYWdlQ3JlYXRlUGFyYW1zTm9uU3RyZWFtaW5nWydtZXNzYWdlcyddPiB7XG4gIHJldHVybiBQcm9taXNlLmFsbChcbiAgICBtZXNzYWdlcy5tYXAoYXN5bmMgKGl0KSA9PiB7XG4gICAgICBpZiAoIWl0LmNvbnRlbnQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdjb250ZW50IGlzIHJlcXVpcmVkJylcbiAgICAgIH1cbiAgICAgIGlmICghaXQuYXR0YWNobWVudHMpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICByb2xlOiBpdC5yb2xlLFxuICAgICAgICAgIGNvbnRlbnQ6IGl0LmNvbnRlbnQsXG4gICAgICAgIH0gYXMgQW50aHJvcGljVHlwZXMuTWVzc2FnZVBhcmFtXG4gICAgICB9XG4gICAgICByZXR1cm4ge1xuICAgICAgICByb2xlOiBpdC5yb2xlLFxuICAgICAgICBjb250ZW50OiBbXG4gICAgICAgICAge1xuICAgICAgICAgICAgdHlwZTogJ3RleHQnLFxuICAgICAgICAgICAgdGV4dDogaXQuY29udGVudCxcbiAgICAgICAgICB9LFxuICAgICAgICAgIC4uLihhd2FpdCBQcm9taXNlLmFsbChcbiAgICAgICAgICAgIGl0LmF0dGFjaG1lbnRzLm1hcChhc3luYyAoaXQpID0+IHtcbiAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICB0eXBlOiAnaW1hZ2UnLFxuICAgICAgICAgICAgICAgIHNvdXJjZToge1xuICAgICAgICAgICAgICAgICAgdHlwZTogJ2Jhc2U2NCcsXG4gICAgICAgICAgICAgICAgICAuLi4oYXdhaXQgZ2V0SW1hZ2VBc0Jhc2U2NChpdC51cmwpKSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICB9IGFzIEFudGhyb3BpY1R5cGVzLkltYWdlQmxvY2tQYXJhbVxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgKSksXG4gICAgICAgIF0sXG4gICAgICB9IGFzIEFudGhyb3BpY1R5cGVzLk1lc3NhZ2VQYXJhbVxuICAgIH0pLFxuICApXG59XG5cbmZ1bmN0aW9uIGdldE1vZGVsTWF4VG9rZW5zKG1vZGVsOiBzdHJpbmcpOiBudW1iZXIge1xuICBpZiAobW9kZWwuc3RhcnRzV2l0aCgnY2xhdWRlLTMtNScpKSB7XG4gICAgcmV0dXJuIDQwOTZcbiAgfVxuICByZXR1cm4gODE5MlxufVxuXG5hc3luYyBmdW5jdGlvbiBwYXJzZVJlcShcbiAgcmVxOiBub3ZhY2hhdC5RdWVyeVJlcXVlc3QsXG4gIHN0cmVhbTogYm9vbGVhbixcbik6IFByb21pc2U8QW50aHJvcGljVHlwZXMuTWVzc2FnZUNyZWF0ZVBhcmFtcz4ge1xuICByZXR1cm4ge1xuICAgIG1lc3NhZ2VzOiBhd2FpdCBjb252ZXJ0TWVzc2FnZXMoXG4gICAgICByZXEubWVzc2FnZXMuZmlsdGVyKChpdCkgPT5cbiAgICAgICAgKFxuICAgICAgICAgIFtcbiAgICAgICAgICAgICd1c2VyJyxcbiAgICAgICAgICAgICdhc3Npc3RhbnQnLFxuICAgICAgICAgIF0gYXMgbm92YWNoYXQuUXVlcnlSZXF1ZXN0WydtZXNzYWdlcyddW251bWJlcl1bJ3JvbGUnXVtdXG4gICAgICAgICkuaW5jbHVkZXMoaXQucm9sZSksXG4gICAgICApLFxuICAgICksXG4gICAgbWF4X3Rva2VuczogZ2V0TW9kZWxNYXhUb2tlbnMocmVxLm1vZGVsKSxcbiAgICBzdHJlYW0sXG4gICAgbW9kZWw6IHJlcS5tb2RlbCxcbiAgICBzeXN0ZW06IHJlcS5tZXNzYWdlcy5maW5kKChpdCkgPT4gaXQucm9sZSA9PT0gJ3N5c3RlbScpPy5jb250ZW50LFxuICB9IGFzIEFudGhyb3BpY1R5cGVzLk1lc3NhZ2VDcmVhdGVQYXJhbXNOb25TdHJlYW1pbmdcbn1cblxuZnVuY3Rpb24gcGFyc2VSZXNwb25zZShcbiAgcmVzcDogQW50aHJvcGljVHlwZXMuTWVzc2FnZXMuTWVzc2FnZSxcbik6IG5vdmFjaGF0LlF1ZXJ5UmVzcG9uc2Uge1xuICBpZiAocmVzcC5jb250ZW50Lmxlbmd0aCAhPT0gMSkge1xuICAgIGNvbnNvbGUuZXJyb3IoJ1Vuc3VwcG9ydGVkIHJlc3BvbnNlJywgcmVzcC5jb250ZW50KVxuICAgIHRocm93IG5ldyBFcnJvcignVW5zdXBwb3J0ZWQgcmVzcG9uc2UnKVxuICB9XG4gIHJldHVybiB7XG4gICAgY29udGVudDogKHJlc3AuY29udGVudFswXSBhcyBBbnRocm9waWNUeXBlcy5UZXh0QmxvY2spLnRleHQsXG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uIGFjdGl2YXRlKGNvbnRleHQ6IG5vdmFjaGF0LlBsdWdpbkNvbnRleHQpIHtcbiAgY29uc3QgY3JlYXRlQ2xpZW50ID0gYXN5bmMgKCkgPT4ge1xuICAgIHJldHVybiBuZXcgQW50aHJvcGljKHtcbiAgICAgIGFwaUtleTogYXdhaXQgbm92YWNoYXQuc2V0dGluZy5nZXQoJ2FudGhyb3BpYy5hcGlLZXknKSxcbiAgICAgIGRlZmF1bHRIZWFkZXJzOiB7XG4gICAgICAgICdhbnRocm9waWMtZGFuZ2Vyb3VzLWRpcmVjdC1icm93c2VyLWFjY2Vzcyc6ICd0cnVlJyxcbiAgICAgIH0sXG4gICAgfSlcbiAgfVxuICBhd2FpdCBub3ZhY2hhdC5tb2RlbC5yZWdpc3RlclByb3ZpZGVyKHtcbiAgICBuYW1lOiAnQW50aHJvcGljJyxcbiAgICBtb2RlbHM6IFtcbiAgICAgIHsgaWQ6ICdjbGF1ZGUtMy01LXNvbm5ldC0yMDI0MTAyMicsIG5hbWU6ICdDbGF1ZGUgMy41IFNvbm5ldCB2MicgfSxcbiAgICAgIHsgaWQ6ICdjbGF1ZGUtMy01LXNvbm5ldC0yMDI0MDYyMCcsIG5hbWU6ICdDbGF1ZGUgMy41IFNvbm5ldCcgfSxcbiAgICAgIHsgaWQ6ICdjbGF1ZGUtMy1vcHVzLTIwMjQwMjI5JywgbmFtZTogJ0NsYXVkZSAzIE9wdXMnIH0sXG4gICAgICB7IGlkOiAnY2xhdWRlLTMtc29ubmV0LTIwMjQwMjI5JywgbmFtZTogJ0NsYXVkZSAzIFNvbm5ldCcgfSxcbiAgICAgIHsgaWQ6ICdjbGF1ZGUtMy1oYWlrdS0yMDI0MDMwNycsIG5hbWU6ICdDbGF1ZGUgMyBIYWlrdScgfSxcbiAgICBdLFxuICAgIGFzeW5jIGludm9rZShxdWVyeSkge1xuICAgICAgY29uc3QgY2xpZW50ID0gYXdhaXQgY3JlYXRlQ2xpZW50KClcbiAgICAgIHJldHVybiBwYXJzZVJlc3BvbnNlKFxuICAgICAgICBhd2FpdCBjbGllbnQubWVzc2FnZXMuY3JlYXRlKFxuICAgICAgICAgIChhd2FpdCBwYXJzZVJlcShcbiAgICAgICAgICAgIHF1ZXJ5LFxuICAgICAgICAgICAgZmFsc2UsXG4gICAgICAgICAgKSkgYXMgQW50aHJvcGljVHlwZXMuTWVzc2FnZUNyZWF0ZVBhcmFtc05vblN0cmVhbWluZyxcbiAgICAgICAgKSxcbiAgICAgIClcbiAgICB9LFxuICAgIGFzeW5jICpzdHJlYW0ocXVlcnkpIHtcbiAgICAgIGNvbnN0IGNsaWVudCA9IGF3YWl0IGNyZWF0ZUNsaWVudCgpXG4gICAgICBjb25zdCBzdHJlYW0gPSBhd2FpdCBjbGllbnQubWVzc2FnZXMuY3JlYXRlKFxuICAgICAgICAoYXdhaXQgcGFyc2VSZXEoXG4gICAgICAgICAgcXVlcnksXG4gICAgICAgICAgdHJ1ZSxcbiAgICAgICAgKSkgYXMgQW50aHJvcGljVHlwZXMuTWVzc2FnZUNyZWF0ZVBhcmFtc1N0cmVhbWluZyxcbiAgICAgIClcbiAgICAgIGZvciBhd2FpdCAoY29uc3QgaXQgb2Ygc3RyZWFtKSB7XG4gICAgICAgIGlmIChpdC50eXBlID09PSAnY29udGVudF9ibG9ja19kZWx0YScpIHtcbiAgICAgICAgICBpZiAoaXQuZGVsdGEudHlwZSAhPT0gJ3RleHRfZGVsdGEnKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1Vuc3VwcG9ydGVkIGRlbHRhIHR5cGUnKVxuICAgICAgICAgIH1cbiAgICAgICAgICB5aWVsZCB7XG4gICAgICAgICAgICBjb250ZW50OiBpdC5kZWx0YS50ZXh0LFxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuICAgIH0sXG4gIH0pXG59XG4iLCAiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cblxuaW1wb3J0IHsgY2FzdFRvRXJyb3IsIEhlYWRlcnMgfSBmcm9tIFwiLi9jb3JlLmpzXCI7XG5cbmV4cG9ydCBjbGFzcyBBbnRocm9waWNFcnJvciBleHRlbmRzIEVycm9yIHt9XG5cbmV4cG9ydCBjbGFzcyBBUElFcnJvciBleHRlbmRzIEFudGhyb3BpY0Vycm9yIHtcbiAgcmVhZG9ubHkgc3RhdHVzOiBudW1iZXIgfCB1bmRlZmluZWQ7XG4gIHJlYWRvbmx5IGhlYWRlcnM6IEhlYWRlcnMgfCB1bmRlZmluZWQ7XG4gIHJlYWRvbmx5IGVycm9yOiBPYmplY3QgfCB1bmRlZmluZWQ7XG5cbiAgcmVhZG9ubHkgcmVxdWVzdF9pZDogc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZDtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBzdGF0dXM6IG51bWJlciB8IHVuZGVmaW5lZCxcbiAgICBlcnJvcjogT2JqZWN0IHwgdW5kZWZpbmVkLFxuICAgIG1lc3NhZ2U6IHN0cmluZyB8IHVuZGVmaW5lZCxcbiAgICBoZWFkZXJzOiBIZWFkZXJzIHwgdW5kZWZpbmVkLFxuICApIHtcbiAgICBzdXBlcihgJHtBUElFcnJvci5tYWtlTWVzc2FnZShzdGF0dXMsIGVycm9yLCBtZXNzYWdlKX1gKTtcbiAgICB0aGlzLnN0YXR1cyA9IHN0YXR1cztcbiAgICB0aGlzLmhlYWRlcnMgPSBoZWFkZXJzO1xuICAgIHRoaXMucmVxdWVzdF9pZCA9IGhlYWRlcnM/LlsncmVxdWVzdC1pZCddO1xuICAgIHRoaXMuZXJyb3IgPSBlcnJvcjtcbiAgfVxuXG4gIHByaXZhdGUgc3RhdGljIG1ha2VNZXNzYWdlKHN0YXR1czogbnVtYmVyIHwgdW5kZWZpbmVkLCBlcnJvcjogYW55LCBtZXNzYWdlOiBzdHJpbmcgfCB1bmRlZmluZWQpIHtcbiAgICBjb25zdCBtc2cgPVxuICAgICAgZXJyb3I/Lm1lc3NhZ2UgP1xuICAgICAgICB0eXBlb2YgZXJyb3IubWVzc2FnZSA9PT0gJ3N0cmluZycgP1xuICAgICAgICAgIGVycm9yLm1lc3NhZ2VcbiAgICAgICAgOiBKU09OLnN0cmluZ2lmeShlcnJvci5tZXNzYWdlKVxuICAgICAgOiBlcnJvciA/IEpTT04uc3RyaW5naWZ5KGVycm9yKVxuICAgICAgOiBtZXNzYWdlO1xuXG4gICAgaWYgKHN0YXR1cyAmJiBtc2cpIHtcbiAgICAgIHJldHVybiBgJHtzdGF0dXN9ICR7bXNnfWA7XG4gICAgfVxuICAgIGlmIChzdGF0dXMpIHtcbiAgICAgIHJldHVybiBgJHtzdGF0dXN9IHN0YXR1cyBjb2RlIChubyBib2R5KWA7XG4gICAgfVxuICAgIGlmIChtc2cpIHtcbiAgICAgIHJldHVybiBtc2c7XG4gICAgfVxuICAgIHJldHVybiAnKG5vIHN0YXR1cyBjb2RlIG9yIGJvZHkpJztcbiAgfVxuXG4gIHN0YXRpYyBnZW5lcmF0ZShcbiAgICBzdGF0dXM6IG51bWJlciB8IHVuZGVmaW5lZCxcbiAgICBlcnJvclJlc3BvbnNlOiBPYmplY3QgfCB1bmRlZmluZWQsXG4gICAgbWVzc2FnZTogc3RyaW5nIHwgdW5kZWZpbmVkLFxuICAgIGhlYWRlcnM6IEhlYWRlcnMgfCB1bmRlZmluZWQsXG4gICkge1xuICAgIGlmICghc3RhdHVzKSB7XG4gICAgICByZXR1cm4gbmV3IEFQSUNvbm5lY3Rpb25FcnJvcih7IG1lc3NhZ2UsIGNhdXNlOiBjYXN0VG9FcnJvcihlcnJvclJlc3BvbnNlKSB9KTtcbiAgICB9XG5cbiAgICBjb25zdCBlcnJvciA9IGVycm9yUmVzcG9uc2UgYXMgUmVjb3JkPHN0cmluZywgYW55PjtcblxuICAgIGlmIChzdGF0dXMgPT09IDQwMCkge1xuICAgICAgcmV0dXJuIG5ldyBCYWRSZXF1ZXN0RXJyb3Ioc3RhdHVzLCBlcnJvciwgbWVzc2FnZSwgaGVhZGVycyk7XG4gICAgfVxuXG4gICAgaWYgKHN0YXR1cyA9PT0gNDAxKSB7XG4gICAgICByZXR1cm4gbmV3IEF1dGhlbnRpY2F0aW9uRXJyb3Ioc3RhdHVzLCBlcnJvciwgbWVzc2FnZSwgaGVhZGVycyk7XG4gICAgfVxuXG4gICAgaWYgKHN0YXR1cyA9PT0gNDAzKSB7XG4gICAgICByZXR1cm4gbmV3IFBlcm1pc3Npb25EZW5pZWRFcnJvcihzdGF0dXMsIGVycm9yLCBtZXNzYWdlLCBoZWFkZXJzKTtcbiAgICB9XG5cbiAgICBpZiAoc3RhdHVzID09PSA0MDQpIHtcbiAgICAgIHJldHVybiBuZXcgTm90Rm91bmRFcnJvcihzdGF0dXMsIGVycm9yLCBtZXNzYWdlLCBoZWFkZXJzKTtcbiAgICB9XG5cbiAgICBpZiAoc3RhdHVzID09PSA0MDkpIHtcbiAgICAgIHJldHVybiBuZXcgQ29uZmxpY3RFcnJvcihzdGF0dXMsIGVycm9yLCBtZXNzYWdlLCBoZWFkZXJzKTtcbiAgICB9XG5cbiAgICBpZiAoc3RhdHVzID09PSA0MjIpIHtcbiAgICAgIHJldHVybiBuZXcgVW5wcm9jZXNzYWJsZUVudGl0eUVycm9yKHN0YXR1cywgZXJyb3IsIG1lc3NhZ2UsIGhlYWRlcnMpO1xuICAgIH1cblxuICAgIGlmIChzdGF0dXMgPT09IDQyOSkge1xuICAgICAgcmV0dXJuIG5ldyBSYXRlTGltaXRFcnJvcihzdGF0dXMsIGVycm9yLCBtZXNzYWdlLCBoZWFkZXJzKTtcbiAgICB9XG5cbiAgICBpZiAoc3RhdHVzID49IDUwMCkge1xuICAgICAgcmV0dXJuIG5ldyBJbnRlcm5hbFNlcnZlckVycm9yKHN0YXR1cywgZXJyb3IsIG1lc3NhZ2UsIGhlYWRlcnMpO1xuICAgIH1cblxuICAgIHJldHVybiBuZXcgQVBJRXJyb3Ioc3RhdHVzLCBlcnJvciwgbWVzc2FnZSwgaGVhZGVycyk7XG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIEFQSVVzZXJBYm9ydEVycm9yIGV4dGVuZHMgQVBJRXJyb3Ige1xuICBvdmVycmlkZSByZWFkb25seSBzdGF0dXM6IHVuZGVmaW5lZCA9IHVuZGVmaW5lZDtcblxuICBjb25zdHJ1Y3Rvcih7IG1lc3NhZ2UgfTogeyBtZXNzYWdlPzogc3RyaW5nIH0gPSB7fSkge1xuICAgIHN1cGVyKHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBtZXNzYWdlIHx8ICdSZXF1ZXN0IHdhcyBhYm9ydGVkLicsIHVuZGVmaW5lZCk7XG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIEFQSUNvbm5lY3Rpb25FcnJvciBleHRlbmRzIEFQSUVycm9yIHtcbiAgb3ZlcnJpZGUgcmVhZG9ubHkgc3RhdHVzOiB1bmRlZmluZWQgPSB1bmRlZmluZWQ7XG5cbiAgY29uc3RydWN0b3IoeyBtZXNzYWdlLCBjYXVzZSB9OiB7IG1lc3NhZ2U/OiBzdHJpbmcgfCB1bmRlZmluZWQ7IGNhdXNlPzogRXJyb3IgfCB1bmRlZmluZWQgfSkge1xuICAgIHN1cGVyKHVuZGVmaW5lZCwgdW5kZWZpbmVkLCBtZXNzYWdlIHx8ICdDb25uZWN0aW9uIGVycm9yLicsIHVuZGVmaW5lZCk7XG4gICAgLy8gaW4gc29tZSBlbnZpcm9ubWVudHMgdGhlICdjYXVzZScgcHJvcGVydHkgaXMgYWxyZWFkeSBkZWNsYXJlZFxuICAgIC8vIEB0cy1pZ25vcmVcbiAgICBpZiAoY2F1c2UpIHRoaXMuY2F1c2UgPSBjYXVzZTtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgQVBJQ29ubmVjdGlvblRpbWVvdXRFcnJvciBleHRlbmRzIEFQSUNvbm5lY3Rpb25FcnJvciB7XG4gIGNvbnN0cnVjdG9yKHsgbWVzc2FnZSB9OiB7IG1lc3NhZ2U/OiBzdHJpbmcgfSA9IHt9KSB7XG4gICAgc3VwZXIoeyBtZXNzYWdlOiBtZXNzYWdlID8/ICdSZXF1ZXN0IHRpbWVkIG91dC4nIH0pO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBCYWRSZXF1ZXN0RXJyb3IgZXh0ZW5kcyBBUElFcnJvciB7XG4gIG92ZXJyaWRlIHJlYWRvbmx5IHN0YXR1czogNDAwID0gNDAwO1xufVxuXG5leHBvcnQgY2xhc3MgQXV0aGVudGljYXRpb25FcnJvciBleHRlbmRzIEFQSUVycm9yIHtcbiAgb3ZlcnJpZGUgcmVhZG9ubHkgc3RhdHVzOiA0MDEgPSA0MDE7XG59XG5cbmV4cG9ydCBjbGFzcyBQZXJtaXNzaW9uRGVuaWVkRXJyb3IgZXh0ZW5kcyBBUElFcnJvciB7XG4gIG92ZXJyaWRlIHJlYWRvbmx5IHN0YXR1czogNDAzID0gNDAzO1xufVxuXG5leHBvcnQgY2xhc3MgTm90Rm91bmRFcnJvciBleHRlbmRzIEFQSUVycm9yIHtcbiAgb3ZlcnJpZGUgcmVhZG9ubHkgc3RhdHVzOiA0MDQgPSA0MDQ7XG59XG5cbmV4cG9ydCBjbGFzcyBDb25mbGljdEVycm9yIGV4dGVuZHMgQVBJRXJyb3Ige1xuICBvdmVycmlkZSByZWFkb25seSBzdGF0dXM6IDQwOSA9IDQwOTtcbn1cblxuZXhwb3J0IGNsYXNzIFVucHJvY2Vzc2FibGVFbnRpdHlFcnJvciBleHRlbmRzIEFQSUVycm9yIHtcbiAgb3ZlcnJpZGUgcmVhZG9ubHkgc3RhdHVzOiA0MjIgPSA0MjI7XG59XG5cbmV4cG9ydCBjbGFzcyBSYXRlTGltaXRFcnJvciBleHRlbmRzIEFQSUVycm9yIHtcbiAgb3ZlcnJpZGUgcmVhZG9ubHkgc3RhdHVzOiA0MjkgPSA0Mjk7XG59XG5cbmV4cG9ydCBjbGFzcyBJbnRlcm5hbFNlcnZlckVycm9yIGV4dGVuZHMgQVBJRXJyb3Ige31cbiIsICJleHBvcnQgY29uc3QgVkVSU0lPTiA9ICcwLjI4LjAnOyAvLyB4LXJlbGVhc2UtcGxlYXNlLXZlcnNpb25cbiIsICIvKipcbiAqIERpc2NsYWltZXI6IG1vZHVsZXMgaW4gX3NoaW1zIGFyZW4ndCBpbnRlbmRlZCB0byBiZSBpbXBvcnRlZCBieSBTREsgdXNlcnMuXG4gKi9cbmltcG9ydCB7IHR5cGUgUmVxdWVzdE9wdGlvbnMgfSBmcm9tIFwiLi4vY29yZS5qc1wiO1xuXG5leHBvcnQgaW50ZXJmYWNlIFNoaW1zIHtcbiAga2luZDogc3RyaW5nO1xuICBmZXRjaDogYW55O1xuICBSZXF1ZXN0OiBhbnk7XG4gIFJlc3BvbnNlOiBhbnk7XG4gIEhlYWRlcnM6IGFueTtcbiAgRm9ybURhdGE6IGFueTtcbiAgQmxvYjogYW55O1xuICBGaWxlOiBhbnk7XG4gIFJlYWRhYmxlU3RyZWFtOiBhbnk7XG4gIGdldE11bHRpcGFydFJlcXVlc3RPcHRpb25zOiA8VCA9IFJlY29yZDxzdHJpbmcsIHVua25vd24+PihcbiAgICBmb3JtOiBTaGltc1snRm9ybURhdGEnXSxcbiAgICBvcHRzOiBSZXF1ZXN0T3B0aW9uczxUPixcbiAgKSA9PiBQcm9taXNlPFJlcXVlc3RPcHRpb25zPFQ+PjtcbiAgZ2V0RGVmYXVsdEFnZW50OiAodXJsOiBzdHJpbmcpID0+IGFueTtcbiAgZmlsZUZyb21QYXRoOlxuICAgIHwgKChwYXRoOiBzdHJpbmcsIGZpbGVuYW1lPzogc3RyaW5nLCBvcHRpb25zPzoge30pID0+IFByb21pc2U8U2hpbXNbJ0ZpbGUnXT4pXG4gICAgfCAoKHBhdGg6IHN0cmluZywgb3B0aW9ucz86IHt9KSA9PiBQcm9taXNlPFNoaW1zWydGaWxlJ10+KTtcbiAgaXNGc1JlYWRTdHJlYW06ICh2YWx1ZTogYW55KSA9PiBib29sZWFuO1xufVxuXG5leHBvcnQgbGV0IGF1dG8gPSBmYWxzZTtcbmV4cG9ydCBsZXQga2luZDogU2hpbXNbJ2tpbmQnXSB8IHVuZGVmaW5lZCA9IHVuZGVmaW5lZDtcbmV4cG9ydCBsZXQgZmV0Y2g6IFNoaW1zWydmZXRjaCddIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuZXhwb3J0IGxldCBSZXF1ZXN0OiBTaGltc1snUmVxdWVzdCddIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuZXhwb3J0IGxldCBSZXNwb25zZTogU2hpbXNbJ1Jlc3BvbnNlJ10gfCB1bmRlZmluZWQgPSB1bmRlZmluZWQ7XG5leHBvcnQgbGV0IEhlYWRlcnM6IFNoaW1zWydIZWFkZXJzJ10gfCB1bmRlZmluZWQgPSB1bmRlZmluZWQ7XG5leHBvcnQgbGV0IEZvcm1EYXRhOiBTaGltc1snRm9ybURhdGEnXSB8IHVuZGVmaW5lZCA9IHVuZGVmaW5lZDtcbmV4cG9ydCBsZXQgQmxvYjogU2hpbXNbJ0Jsb2InXSB8IHVuZGVmaW5lZCA9IHVuZGVmaW5lZDtcbmV4cG9ydCBsZXQgRmlsZTogU2hpbXNbJ0ZpbGUnXSB8IHVuZGVmaW5lZCA9IHVuZGVmaW5lZDtcbmV4cG9ydCBsZXQgUmVhZGFibGVTdHJlYW06IFNoaW1zWydSZWFkYWJsZVN0cmVhbSddIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuZXhwb3J0IGxldCBnZXRNdWx0aXBhcnRSZXF1ZXN0T3B0aW9uczogU2hpbXNbJ2dldE11bHRpcGFydFJlcXVlc3RPcHRpb25zJ10gfCB1bmRlZmluZWQgPSB1bmRlZmluZWQ7XG5leHBvcnQgbGV0IGdldERlZmF1bHRBZ2VudDogU2hpbXNbJ2dldERlZmF1bHRBZ2VudCddIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuZXhwb3J0IGxldCBmaWxlRnJvbVBhdGg6IFNoaW1zWydmaWxlRnJvbVBhdGgnXSB8IHVuZGVmaW5lZCA9IHVuZGVmaW5lZDtcbmV4cG9ydCBsZXQgaXNGc1JlYWRTdHJlYW06IFNoaW1zWydpc0ZzUmVhZFN0cmVhbSddIHwgdW5kZWZpbmVkID0gdW5kZWZpbmVkO1xuXG5leHBvcnQgZnVuY3Rpb24gc2V0U2hpbXMoc2hpbXM6IFNoaW1zLCBvcHRpb25zOiB7IGF1dG86IGJvb2xlYW4gfSA9IHsgYXV0bzogZmFsc2UgfSkge1xuICBpZiAoYXV0bykge1xuICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgIGB5b3UgbXVzdCBcXGBpbXBvcnQgJ0BhbnRocm9waWMtYWkvc2RrL3NoaW1zLyR7c2hpbXMua2luZH0nXFxgIGJlZm9yZSBpbXBvcnRpbmcgYW55dGhpbmcgZWxzZSBmcm9tIEBhbnRocm9waWMtYWkvc2RrYCxcbiAgICApO1xuICB9XG4gIGlmIChraW5kKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgYGNhbid0IFxcYGltcG9ydCAnQGFudGhyb3BpYy1haS9zZGsvc2hpbXMvJHtzaGltcy5raW5kfSdcXGAgYWZ0ZXIgXFxgaW1wb3J0ICdAYW50aHJvcGljLWFpL3Nkay9zaGltcy8ke2tpbmR9J1xcYGAsXG4gICAgKTtcbiAgfVxuICBhdXRvID0gb3B0aW9ucy5hdXRvO1xuICBraW5kID0gc2hpbXMua2luZDtcbiAgZmV0Y2ggPSBzaGltcy5mZXRjaDtcbiAgUmVxdWVzdCA9IHNoaW1zLlJlcXVlc3Q7XG4gIFJlc3BvbnNlID0gc2hpbXMuUmVzcG9uc2U7XG4gIEhlYWRlcnMgPSBzaGltcy5IZWFkZXJzO1xuICBGb3JtRGF0YSA9IHNoaW1zLkZvcm1EYXRhO1xuICBCbG9iID0gc2hpbXMuQmxvYjtcbiAgRmlsZSA9IHNoaW1zLkZpbGU7XG4gIFJlYWRhYmxlU3RyZWFtID0gc2hpbXMuUmVhZGFibGVTdHJlYW07XG4gIGdldE11bHRpcGFydFJlcXVlc3RPcHRpb25zID0gc2hpbXMuZ2V0TXVsdGlwYXJ0UmVxdWVzdE9wdGlvbnM7XG4gIGdldERlZmF1bHRBZ2VudCA9IHNoaW1zLmdldERlZmF1bHRBZ2VudDtcbiAgZmlsZUZyb21QYXRoID0gc2hpbXMuZmlsZUZyb21QYXRoO1xuICBpc0ZzUmVhZFN0cmVhbSA9IHNoaW1zLmlzRnNSZWFkU3RyZWFtO1xufVxuIiwgIi8qKlxuICogRGlzY2xhaW1lcjogbW9kdWxlcyBpbiBfc2hpbXMgYXJlbid0IGludGVuZGVkIHRvIGJlIGltcG9ydGVkIGJ5IFNESyB1c2Vycy5cbiAqL1xuZXhwb3J0IGNsYXNzIE11bHRpcGFydEJvZHkge1xuICBjb25zdHJ1Y3RvcihwdWJsaWMgYm9keTogYW55KSB7fVxuICBnZXQgW1N5bWJvbC50b1N0cmluZ1RhZ10oKTogc3RyaW5nIHtcbiAgICByZXR1cm4gJ011bHRpcGFydEJvZHknO1xuICB9XG59XG4iLCAiLyoqXG4gKiBEaXNjbGFpbWVyOiBtb2R1bGVzIGluIF9zaGltcyBhcmVuJ3QgaW50ZW5kZWQgdG8gYmUgaW1wb3J0ZWQgYnkgU0RLIHVzZXJzLlxuICovXG5pbXBvcnQgeyBNdWx0aXBhcnRCb2R5IH0gZnJvbSBcIi4vTXVsdGlwYXJ0Qm9keS5qc1wiO1xuaW1wb3J0IHsgdHlwZSBSZXF1ZXN0T3B0aW9ucyB9IGZyb20gXCIuLi9jb3JlLmpzXCI7XG5pbXBvcnQgeyB0eXBlIFNoaW1zIH0gZnJvbSBcIi4vcmVnaXN0cnkuanNcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIGdldFJ1bnRpbWUoeyBtYW51YWxseUltcG9ydGVkIH06IHsgbWFudWFsbHlJbXBvcnRlZD86IGJvb2xlYW4gfSA9IHt9KTogU2hpbXMge1xuICBjb25zdCByZWNvbW1lbmRhdGlvbiA9XG4gICAgbWFudWFsbHlJbXBvcnRlZCA/XG4gICAgICBgWW91IG1heSBuZWVkIHRvIHVzZSBwb2x5ZmlsbHNgXG4gICAgOiBgQWRkIG9uZSBvZiB0aGVzZSBpbXBvcnRzIGJlZm9yZSB5b3VyIGZpcnN0IFxcYGltcG9ydCBcdTIwMjYgZnJvbSAnQGFudGhyb3BpYy1haS9zZGsnXFxgOlxuLSBcXGBpbXBvcnQgJ0BhbnRocm9waWMtYWkvc2RrL3NoaW1zL25vZGUnXFxgIChpZiB5b3UncmUgcnVubmluZyBvbiBOb2RlKVxuLSBcXGBpbXBvcnQgJ0BhbnRocm9waWMtYWkvc2RrL3NoaW1zL3dlYidcXGAgKG90aGVyd2lzZSlcbmA7XG5cbiAgbGV0IF9mZXRjaCwgX1JlcXVlc3QsIF9SZXNwb25zZSwgX0hlYWRlcnM7XG4gIHRyeSB7XG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIF9mZXRjaCA9IGZldGNoO1xuICAgIC8vIEB0cy1pZ25vcmVcbiAgICBfUmVxdWVzdCA9IFJlcXVlc3Q7XG4gICAgLy8gQHRzLWlnbm9yZVxuICAgIF9SZXNwb25zZSA9IFJlc3BvbnNlO1xuICAgIC8vIEB0cy1pZ25vcmVcbiAgICBfSGVhZGVycyA9IEhlYWRlcnM7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgYHRoaXMgZW52aXJvbm1lbnQgaXMgbWlzc2luZyB0aGUgZm9sbG93aW5nIFdlYiBGZXRjaCBBUEkgdHlwZTogJHtcbiAgICAgICAgKGVycm9yIGFzIGFueSkubWVzc2FnZVxuICAgICAgfS4gJHtyZWNvbW1lbmRhdGlvbn1gLFxuICAgICk7XG4gIH1cblxuICByZXR1cm4ge1xuICAgIGtpbmQ6ICd3ZWInLFxuICAgIGZldGNoOiBfZmV0Y2gsXG4gICAgUmVxdWVzdDogX1JlcXVlc3QsXG4gICAgUmVzcG9uc2U6IF9SZXNwb25zZSxcbiAgICBIZWFkZXJzOiBfSGVhZGVycyxcbiAgICBGb3JtRGF0YTpcbiAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgIHR5cGVvZiBGb3JtRGF0YSAhPT0gJ3VuZGVmaW5lZCcgPyBGb3JtRGF0YSA6IChcbiAgICAgICAgY2xhc3MgRm9ybURhdGEge1xuICAgICAgICAgIC8vIEB0cy1pZ25vcmVcbiAgICAgICAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgICAgICAgYGZpbGUgdXBsb2FkcyBhcmVuJ3Qgc3VwcG9ydGVkIGluIHRoaXMgZW52aXJvbm1lbnQgeWV0IGFzICdGb3JtRGF0YScgaXMgdW5kZWZpbmVkLiAke3JlY29tbWVuZGF0aW9ufWAsXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgKSxcbiAgICBCbG9iOlxuICAgICAgdHlwZW9mIEJsb2IgIT09ICd1bmRlZmluZWQnID8gQmxvYiA6IChcbiAgICAgICAgY2xhc3MgQmxvYiB7XG4gICAgICAgICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgICAgIGBmaWxlIHVwbG9hZHMgYXJlbid0IHN1cHBvcnRlZCBpbiB0aGlzIGVudmlyb25tZW50IHlldCBhcyAnQmxvYicgaXMgdW5kZWZpbmVkLiAke3JlY29tbWVuZGF0aW9ufWAsXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgKSxcbiAgICBGaWxlOlxuICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgdHlwZW9mIEZpbGUgIT09ICd1bmRlZmluZWQnID8gRmlsZSA6IChcbiAgICAgICAgY2xhc3MgRmlsZSB7XG4gICAgICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgICAgIGNvbnN0cnVjdG9yKCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgICAgICBgZmlsZSB1cGxvYWRzIGFyZW4ndCBzdXBwb3J0ZWQgaW4gdGhpcyBlbnZpcm9ubWVudCB5ZXQgYXMgJ0ZpbGUnIGlzIHVuZGVmaW5lZC4gJHtyZWNvbW1lbmRhdGlvbn1gLFxuICAgICAgICAgICAgKTtcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICksXG4gICAgUmVhZGFibGVTdHJlYW06XG4gICAgICAvLyBAdHMtaWdub3JlXG4gICAgICB0eXBlb2YgUmVhZGFibGVTdHJlYW0gIT09ICd1bmRlZmluZWQnID8gUmVhZGFibGVTdHJlYW0gOiAoXG4gICAgICAgIGNsYXNzIFJlYWRhYmxlU3RyZWFtIHtcbiAgICAgICAgICAvLyBAdHMtaWdub3JlXG4gICAgICAgICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgICAgIGBzdHJlYW1pbmcgaXNuJ3Qgc3VwcG9ydGVkIGluIHRoaXMgZW52aXJvbm1lbnQgeWV0IGFzICdSZWFkYWJsZVN0cmVhbScgaXMgdW5kZWZpbmVkLiAke3JlY29tbWVuZGF0aW9ufWAsXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgKSxcbiAgICBnZXRNdWx0aXBhcnRSZXF1ZXN0T3B0aW9uczogYXN5bmMgPFQgPSBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPj4oXG4gICAgICAvLyBAdHMtaWdub3JlXG4gICAgICBmb3JtOiBGb3JtRGF0YSxcbiAgICAgIG9wdHM6IFJlcXVlc3RPcHRpb25zPFQ+LFxuICAgICk6IFByb21pc2U8UmVxdWVzdE9wdGlvbnM8VD4+ID0+ICh7XG4gICAgICAuLi5vcHRzLFxuICAgICAgYm9keTogbmV3IE11bHRpcGFydEJvZHkoZm9ybSkgYXMgYW55LFxuICAgIH0pLFxuICAgIGdldERlZmF1bHRBZ2VudDogKHVybDogc3RyaW5nKSA9PiB1bmRlZmluZWQsXG4gICAgZmlsZUZyb21QYXRoOiAoKSA9PiB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICdUaGUgYGZpbGVGcm9tUGF0aGAgZnVuY3Rpb24gaXMgb25seSBzdXBwb3J0ZWQgaW4gTm9kZS4gU2VlIHRoZSBSRUFETUUgZm9yIG1vcmUgZGV0YWlsczogaHR0cHM6Ly93d3cuZ2l0aHViLmNvbS9hbnRocm9waWNzL2FudGhyb3BpYy1zZGstdHlwZXNjcmlwdCNmaWxlLXVwbG9hZHMnLFxuICAgICAgKTtcbiAgICB9LFxuICAgIGlzRnNSZWFkU3RyZWFtOiAodmFsdWU6IGFueSkgPT4gZmFsc2UsXG4gIH07XG59XG4iLCAiLyoqXG4gKiBEaXNjbGFpbWVyOiBtb2R1bGVzIGluIF9zaGltcyBhcmVuJ3QgaW50ZW5kZWQgdG8gYmUgaW1wb3J0ZWQgYnkgU0RLIHVzZXJzLlxuICovXG5pbXBvcnQgKiBhcyBzaGltcyBmcm9tICcuL3JlZ2lzdHJ5Lm1qcyc7XG5pbXBvcnQgKiBhcyBhdXRvIGZyb20gJ0BhbnRocm9waWMtYWkvc2RrL19zaGltcy9hdXRvL3J1bnRpbWUnO1xuaWYgKCFzaGltcy5raW5kKSBzaGltcy5zZXRTaGltcyhhdXRvLmdldFJ1bnRpbWUoKSwgeyBhdXRvOiB0cnVlIH0pO1xuZXhwb3J0ICogZnJvbSAnLi9yZWdpc3RyeS5tanMnO1xuIiwgImltcG9ydCB7IFJlYWRhYmxlU3RyZWFtLCB0eXBlIFJlc3BvbnNlIH0gZnJvbSBcIi4vX3NoaW1zL2luZGV4LmpzXCI7XG5pbXBvcnQgeyBBbnRocm9waWNFcnJvciB9IGZyb20gXCIuL2Vycm9yLmpzXCI7XG5cbmltcG9ydCB7IGNyZWF0ZVJlc3BvbnNlSGVhZGVycyB9IGZyb20gXCIuL2NvcmUuanNcIjtcbmltcG9ydCB7IEFQSUVycm9yIH0gZnJvbSBcIi4vZXJyb3IuanNcIjtcblxudHlwZSBCeXRlcyA9IHN0cmluZyB8IEFycmF5QnVmZmVyIHwgVWludDhBcnJheSB8IEJ1ZmZlciB8IG51bGwgfCB1bmRlZmluZWQ7XG5cbmV4cG9ydCB0eXBlIFNlcnZlclNlbnRFdmVudCA9IHtcbiAgZXZlbnQ6IHN0cmluZyB8IG51bGw7XG4gIGRhdGE6IHN0cmluZztcbiAgcmF3OiBzdHJpbmdbXTtcbn07XG5cbmV4cG9ydCBjbGFzcyBTdHJlYW08SXRlbT4gaW1wbGVtZW50cyBBc3luY0l0ZXJhYmxlPEl0ZW0+IHtcbiAgY29udHJvbGxlcjogQWJvcnRDb250cm9sbGVyO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHByaXZhdGUgaXRlcmF0b3I6ICgpID0+IEFzeW5jSXRlcmF0b3I8SXRlbT4sXG4gICAgY29udHJvbGxlcjogQWJvcnRDb250cm9sbGVyLFxuICApIHtcbiAgICB0aGlzLmNvbnRyb2xsZXIgPSBjb250cm9sbGVyO1xuICB9XG5cbiAgc3RhdGljIGZyb21TU0VSZXNwb25zZTxJdGVtPihyZXNwb25zZTogUmVzcG9uc2UsIGNvbnRyb2xsZXI6IEFib3J0Q29udHJvbGxlcikge1xuICAgIGxldCBjb25zdW1lZCA9IGZhbHNlO1xuXG4gICAgYXN5bmMgZnVuY3Rpb24qIGl0ZXJhdG9yKCk6IEFzeW5jSXRlcmF0b3I8SXRlbSwgYW55LCB1bmRlZmluZWQ+IHtcbiAgICAgIGlmIChjb25zdW1lZCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBpdGVyYXRlIG92ZXIgYSBjb25zdW1lZCBzdHJlYW0sIHVzZSBgLnRlZSgpYCB0byBzcGxpdCB0aGUgc3RyZWFtLicpO1xuICAgICAgfVxuICAgICAgY29uc3VtZWQgPSB0cnVlO1xuICAgICAgbGV0IGRvbmUgPSBmYWxzZTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGZvciBhd2FpdCAoY29uc3Qgc3NlIG9mIF9pdGVyU1NFTWVzc2FnZXMocmVzcG9uc2UsIGNvbnRyb2xsZXIpKSB7XG4gICAgICAgICAgaWYgKHNzZS5ldmVudCA9PT0gJ2NvbXBsZXRpb24nKSB7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICB5aWVsZCBKU09OLnBhcnNlKHNzZS5kYXRhKTtcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgQ291bGQgbm90IHBhcnNlIG1lc3NhZ2UgaW50byBKU09OOmAsIHNzZS5kYXRhKTtcbiAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihgRnJvbSBjaHVuazpgLCBzc2UucmF3KTtcbiAgICAgICAgICAgICAgdGhyb3cgZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoXG4gICAgICAgICAgICBzc2UuZXZlbnQgPT09ICdtZXNzYWdlX3N0YXJ0JyB8fFxuICAgICAgICAgICAgc3NlLmV2ZW50ID09PSAnbWVzc2FnZV9kZWx0YScgfHxcbiAgICAgICAgICAgIHNzZS5ldmVudCA9PT0gJ21lc3NhZ2Vfc3RvcCcgfHxcbiAgICAgICAgICAgIHNzZS5ldmVudCA9PT0gJ2NvbnRlbnRfYmxvY2tfc3RhcnQnIHx8XG4gICAgICAgICAgICBzc2UuZXZlbnQgPT09ICdjb250ZW50X2Jsb2NrX2RlbHRhJyB8fFxuICAgICAgICAgICAgc3NlLmV2ZW50ID09PSAnY29udGVudF9ibG9ja19zdG9wJ1xuICAgICAgICAgICkge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgeWllbGQgSlNPTi5wYXJzZShzc2UuZGF0YSk7XG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYENvdWxkIG5vdCBwYXJzZSBtZXNzYWdlIGludG8gSlNPTjpgLCBzc2UuZGF0YSk7XG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoYEZyb20gY2h1bms6YCwgc3NlLnJhdyk7XG4gICAgICAgICAgICAgIHRocm93IGU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKHNzZS5ldmVudCA9PT0gJ3BpbmcnKSB7XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoc3NlLmV2ZW50ID09PSAnZXJyb3InKSB7XG4gICAgICAgICAgICB0aHJvdyBBUElFcnJvci5nZW5lcmF0ZShcbiAgICAgICAgICAgICAgdW5kZWZpbmVkLFxuICAgICAgICAgICAgICBgU1NFIEVycm9yOiAke3NzZS5kYXRhfWAsXG4gICAgICAgICAgICAgIHNzZS5kYXRhLFxuICAgICAgICAgICAgICBjcmVhdGVSZXNwb25zZUhlYWRlcnMocmVzcG9uc2UuaGVhZGVycyksXG4gICAgICAgICAgICApO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBkb25lID0gdHJ1ZTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgLy8gSWYgdGhlIHVzZXIgY2FsbHMgYHN0cmVhbS5jb250cm9sbGVyLmFib3J0KClgLCB3ZSBzaG91bGQgZXhpdCB3aXRob3V0IHRocm93aW5nLlxuICAgICAgICBpZiAoZSBpbnN0YW5jZW9mIEVycm9yICYmIGUubmFtZSA9PT0gJ0Fib3J0RXJyb3InKSByZXR1cm47XG4gICAgICAgIHRocm93IGU7XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICAvLyBJZiB0aGUgdXNlciBgYnJlYWtgcywgYWJvcnQgdGhlIG9uZ29pbmcgcmVxdWVzdC5cbiAgICAgICAgaWYgKCFkb25lKSBjb250cm9sbGVyLmFib3J0KCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBTdHJlYW0oaXRlcmF0b3IsIGNvbnRyb2xsZXIpO1xuICB9XG5cbiAgLyoqXG4gICAqIEdlbmVyYXRlcyBhIFN0cmVhbSBmcm9tIGEgbmV3bGluZS1zZXBhcmF0ZWQgUmVhZGFibGVTdHJlYW1cbiAgICogd2hlcmUgZWFjaCBpdGVtIGlzIGEgSlNPTiB2YWx1ZS5cbiAgICovXG4gIHN0YXRpYyBmcm9tUmVhZGFibGVTdHJlYW08SXRlbT4ocmVhZGFibGVTdHJlYW06IFJlYWRhYmxlU3RyZWFtLCBjb250cm9sbGVyOiBBYm9ydENvbnRyb2xsZXIpIHtcbiAgICBsZXQgY29uc3VtZWQgPSBmYWxzZTtcblxuICAgIGFzeW5jIGZ1bmN0aW9uKiBpdGVyTGluZXMoKTogQXN5bmNHZW5lcmF0b3I8c3RyaW5nLCB2b2lkLCB1bmtub3duPiB7XG4gICAgICBjb25zdCBsaW5lRGVjb2RlciA9IG5ldyBMaW5lRGVjb2RlcigpO1xuXG4gICAgICBjb25zdCBpdGVyID0gcmVhZGFibGVTdHJlYW1Bc3luY0l0ZXJhYmxlPEJ5dGVzPihyZWFkYWJsZVN0cmVhbSk7XG4gICAgICBmb3IgYXdhaXQgKGNvbnN0IGNodW5rIG9mIGl0ZXIpIHtcbiAgICAgICAgZm9yIChjb25zdCBsaW5lIG9mIGxpbmVEZWNvZGVyLmRlY29kZShjaHVuaykpIHtcbiAgICAgICAgICB5aWVsZCBsaW5lO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIGZvciAoY29uc3QgbGluZSBvZiBsaW5lRGVjb2Rlci5mbHVzaCgpKSB7XG4gICAgICAgIHlpZWxkIGxpbmU7XG4gICAgICB9XG4gICAgfVxuXG4gICAgYXN5bmMgZnVuY3Rpb24qIGl0ZXJhdG9yKCk6IEFzeW5jSXRlcmF0b3I8SXRlbSwgYW55LCB1bmRlZmluZWQ+IHtcbiAgICAgIGlmIChjb25zdW1lZCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBpdGVyYXRlIG92ZXIgYSBjb25zdW1lZCBzdHJlYW0sIHVzZSBgLnRlZSgpYCB0byBzcGxpdCB0aGUgc3RyZWFtLicpO1xuICAgICAgfVxuICAgICAgY29uc3VtZWQgPSB0cnVlO1xuICAgICAgbGV0IGRvbmUgPSBmYWxzZTtcbiAgICAgIHRyeSB7XG4gICAgICAgIGZvciBhd2FpdCAoY29uc3QgbGluZSBvZiBpdGVyTGluZXMoKSkge1xuICAgICAgICAgIGlmIChkb25lKSBjb250aW51ZTtcbiAgICAgICAgICBpZiAobGluZSkgeWllbGQgSlNPTi5wYXJzZShsaW5lKTtcbiAgICAgICAgfVxuICAgICAgICBkb25lID0gdHJ1ZTtcbiAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgLy8gSWYgdGhlIHVzZXIgY2FsbHMgYHN0cmVhbS5jb250cm9sbGVyLmFib3J0KClgLCB3ZSBzaG91bGQgZXhpdCB3aXRob3V0IHRocm93aW5nLlxuICAgICAgICBpZiAoZSBpbnN0YW5jZW9mIEVycm9yICYmIGUubmFtZSA9PT0gJ0Fib3J0RXJyb3InKSByZXR1cm47XG4gICAgICAgIHRocm93IGU7XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICAvLyBJZiB0aGUgdXNlciBgYnJlYWtgcywgYWJvcnQgdGhlIG9uZ29pbmcgcmVxdWVzdC5cbiAgICAgICAgaWYgKCFkb25lKSBjb250cm9sbGVyLmFib3J0KCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIG5ldyBTdHJlYW0oaXRlcmF0b3IsIGNvbnRyb2xsZXIpO1xuICB9XG5cbiAgW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSgpOiBBc3luY0l0ZXJhdG9yPEl0ZW0+IHtcbiAgICByZXR1cm4gdGhpcy5pdGVyYXRvcigpO1xuICB9XG5cbiAgLyoqXG4gICAqIFNwbGl0cyB0aGUgc3RyZWFtIGludG8gdHdvIHN0cmVhbXMgd2hpY2ggY2FuIGJlXG4gICAqIGluZGVwZW5kZW50bHkgcmVhZCBmcm9tIGF0IGRpZmZlcmVudCBzcGVlZHMuXG4gICAqL1xuICB0ZWUoKTogW1N0cmVhbTxJdGVtPiwgU3RyZWFtPEl0ZW0+XSB7XG4gICAgY29uc3QgbGVmdDogQXJyYXk8UHJvbWlzZTxJdGVyYXRvclJlc3VsdDxJdGVtPj4+ID0gW107XG4gICAgY29uc3QgcmlnaHQ6IEFycmF5PFByb21pc2U8SXRlcmF0b3JSZXN1bHQ8SXRlbT4+PiA9IFtdO1xuICAgIGNvbnN0IGl0ZXJhdG9yID0gdGhpcy5pdGVyYXRvcigpO1xuXG4gICAgY29uc3QgdGVlSXRlcmF0b3IgPSAocXVldWU6IEFycmF5PFByb21pc2U8SXRlcmF0b3JSZXN1bHQ8SXRlbT4+Pik6IEFzeW5jSXRlcmF0b3I8SXRlbT4gPT4ge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbmV4dDogKCkgPT4ge1xuICAgICAgICAgIGlmIChxdWV1ZS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGl0ZXJhdG9yLm5leHQoKTtcbiAgICAgICAgICAgIGxlZnQucHVzaChyZXN1bHQpO1xuICAgICAgICAgICAgcmlnaHQucHVzaChyZXN1bHQpO1xuICAgICAgICAgIH1cbiAgICAgICAgICByZXR1cm4gcXVldWUuc2hpZnQoKSE7XG4gICAgICAgIH0sXG4gICAgICB9O1xuICAgIH07XG5cbiAgICByZXR1cm4gW1xuICAgICAgbmV3IFN0cmVhbSgoKSA9PiB0ZWVJdGVyYXRvcihsZWZ0KSwgdGhpcy5jb250cm9sbGVyKSxcbiAgICAgIG5ldyBTdHJlYW0oKCkgPT4gdGVlSXRlcmF0b3IocmlnaHQpLCB0aGlzLmNvbnRyb2xsZXIpLFxuICAgIF07XG4gIH1cblxuICAvKipcbiAgICogQ29udmVydHMgdGhpcyBzdHJlYW0gdG8gYSBuZXdsaW5lLXNlcGFyYXRlZCBSZWFkYWJsZVN0cmVhbSBvZlxuICAgKiBKU09OIHN0cmluZ2lmaWVkIHZhbHVlcyBpbiB0aGUgc3RyZWFtXG4gICAqIHdoaWNoIGNhbiBiZSB0dXJuZWQgYmFjayBpbnRvIGEgU3RyZWFtIHdpdGggYFN0cmVhbS5mcm9tUmVhZGFibGVTdHJlYW0oKWAuXG4gICAqL1xuICB0b1JlYWRhYmxlU3RyZWFtKCk6IFJlYWRhYmxlU3RyZWFtIHtcbiAgICBjb25zdCBzZWxmID0gdGhpcztcbiAgICBsZXQgaXRlcjogQXN5bmNJdGVyYXRvcjxJdGVtPjtcbiAgICBjb25zdCBlbmNvZGVyID0gbmV3IFRleHRFbmNvZGVyKCk7XG5cbiAgICByZXR1cm4gbmV3IFJlYWRhYmxlU3RyZWFtKHtcbiAgICAgIGFzeW5jIHN0YXJ0KCkge1xuICAgICAgICBpdGVyID0gc2VsZltTeW1ib2wuYXN5bmNJdGVyYXRvcl0oKTtcbiAgICAgIH0sXG4gICAgICBhc3luYyBwdWxsKGN0cmw6IGFueSkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGNvbnN0IHsgdmFsdWUsIGRvbmUgfSA9IGF3YWl0IGl0ZXIubmV4dCgpO1xuICAgICAgICAgIGlmIChkb25lKSByZXR1cm4gY3RybC5jbG9zZSgpO1xuXG4gICAgICAgICAgY29uc3QgYnl0ZXMgPSBlbmNvZGVyLmVuY29kZShKU09OLnN0cmluZ2lmeSh2YWx1ZSkgKyAnXFxuJyk7XG5cbiAgICAgICAgICBjdHJsLmVucXVldWUoYnl0ZXMpO1xuICAgICAgICB9IGNhdGNoIChlcnIpIHtcbiAgICAgICAgICBjdHJsLmVycm9yKGVycik7XG4gICAgICAgIH1cbiAgICAgIH0sXG4gICAgICBhc3luYyBjYW5jZWwoKSB7XG4gICAgICAgIGF3YWl0IGl0ZXIucmV0dXJuPy4oKTtcbiAgICAgIH0sXG4gICAgfSk7XG4gIH1cbn1cblxuZXhwb3J0IGFzeW5jIGZ1bmN0aW9uKiBfaXRlclNTRU1lc3NhZ2VzKFxuICByZXNwb25zZTogUmVzcG9uc2UsXG4gIGNvbnRyb2xsZXI6IEFib3J0Q29udHJvbGxlcixcbik6IEFzeW5jR2VuZXJhdG9yPFNlcnZlclNlbnRFdmVudCwgdm9pZCwgdW5rbm93bj4ge1xuICBpZiAoIXJlc3BvbnNlLmJvZHkpIHtcbiAgICBjb250cm9sbGVyLmFib3J0KCk7XG4gICAgdGhyb3cgbmV3IEFudGhyb3BpY0Vycm9yKGBBdHRlbXB0ZWQgdG8gaXRlcmF0ZSBvdmVyIGEgcmVzcG9uc2Ugd2l0aCBubyBib2R5YCk7XG4gIH1cblxuICBjb25zdCBzc2VEZWNvZGVyID0gbmV3IFNTRURlY29kZXIoKTtcbiAgY29uc3QgbGluZURlY29kZXIgPSBuZXcgTGluZURlY29kZXIoKTtcblxuICBjb25zdCBpdGVyID0gcmVhZGFibGVTdHJlYW1Bc3luY0l0ZXJhYmxlPEJ5dGVzPihyZXNwb25zZS5ib2R5KTtcbiAgZm9yIGF3YWl0IChjb25zdCBzc2VDaHVuayBvZiBpdGVyU1NFQ2h1bmtzKGl0ZXIpKSB7XG4gICAgZm9yIChjb25zdCBsaW5lIG9mIGxpbmVEZWNvZGVyLmRlY29kZShzc2VDaHVuaykpIHtcbiAgICAgIGNvbnN0IHNzZSA9IHNzZURlY29kZXIuZGVjb2RlKGxpbmUpO1xuICAgICAgaWYgKHNzZSkgeWllbGQgc3NlO1xuICAgIH1cbiAgfVxuXG4gIGZvciAoY29uc3QgbGluZSBvZiBsaW5lRGVjb2Rlci5mbHVzaCgpKSB7XG4gICAgY29uc3Qgc3NlID0gc3NlRGVjb2Rlci5kZWNvZGUobGluZSk7XG4gICAgaWYgKHNzZSkgeWllbGQgc3NlO1xuICB9XG59XG5cbi8qKlxuICogR2l2ZW4gYW4gYXN5bmMgaXRlcmFibGUgaXRlcmF0b3IsIGl0ZXJhdGVzIG92ZXIgaXQgYW5kIHlpZWxkcyBmdWxsXG4gKiBTU0UgY2h1bmtzLCBpLmUuIHlpZWxkcyB3aGVuIGEgZG91YmxlIG5ldy1saW5lIGlzIGVuY291bnRlcmVkLlxuICovXG5hc3luYyBmdW5jdGlvbiogaXRlclNTRUNodW5rcyhpdGVyYXRvcjogQXN5bmNJdGVyYWJsZUl0ZXJhdG9yPEJ5dGVzPik6IEFzeW5jR2VuZXJhdG9yPFVpbnQ4QXJyYXk+IHtcbiAgbGV0IGRhdGEgPSBuZXcgVWludDhBcnJheSgpO1xuXG4gIGZvciBhd2FpdCAoY29uc3QgY2h1bmsgb2YgaXRlcmF0b3IpIHtcbiAgICBpZiAoY2h1bmsgPT0gbnVsbCkge1xuICAgICAgY29udGludWU7XG4gICAgfVxuXG4gICAgY29uc3QgYmluYXJ5Q2h1bmsgPVxuICAgICAgY2h1bmsgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlciA/IG5ldyBVaW50OEFycmF5KGNodW5rKVxuICAgICAgOiB0eXBlb2YgY2h1bmsgPT09ICdzdHJpbmcnID8gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKGNodW5rKVxuICAgICAgOiBjaHVuaztcblxuICAgIGxldCBuZXdEYXRhID0gbmV3IFVpbnQ4QXJyYXkoZGF0YS5sZW5ndGggKyBiaW5hcnlDaHVuay5sZW5ndGgpO1xuICAgIG5ld0RhdGEuc2V0KGRhdGEpO1xuICAgIG5ld0RhdGEuc2V0KGJpbmFyeUNodW5rLCBkYXRhLmxlbmd0aCk7XG4gICAgZGF0YSA9IG5ld0RhdGE7XG5cbiAgICBsZXQgcGF0dGVybkluZGV4O1xuICAgIHdoaWxlICgocGF0dGVybkluZGV4ID0gZmluZERvdWJsZU5ld2xpbmVJbmRleChkYXRhKSkgIT09IC0xKSB7XG4gICAgICB5aWVsZCBkYXRhLnNsaWNlKDAsIHBhdHRlcm5JbmRleCk7XG4gICAgICBkYXRhID0gZGF0YS5zbGljZShwYXR0ZXJuSW5kZXgpO1xuICAgIH1cbiAgfVxuXG4gIGlmIChkYXRhLmxlbmd0aCA+IDApIHtcbiAgICB5aWVsZCBkYXRhO1xuICB9XG59XG5cbmZ1bmN0aW9uIGZpbmREb3VibGVOZXdsaW5lSW5kZXgoYnVmZmVyOiBVaW50OEFycmF5KTogbnVtYmVyIHtcbiAgLy8gVGhpcyBmdW5jdGlvbiBzZWFyY2hlcyB0aGUgYnVmZmVyIGZvciB0aGUgZW5kIHBhdHRlcm5zIChcXHJcXHIsIFxcblxcbiwgXFxyXFxuXFxyXFxuKVxuICAvLyBhbmQgcmV0dXJucyB0aGUgaW5kZXggcmlnaHQgYWZ0ZXIgdGhlIGZpcnN0IG9jY3VycmVuY2Ugb2YgYW55IHBhdHRlcm4sXG4gIC8vIG9yIC0xIGlmIG5vbmUgb2YgdGhlIHBhdHRlcm5zIGFyZSBmb3VuZC5cbiAgY29uc3QgbmV3bGluZSA9IDB4MGE7IC8vIFxcblxuICBjb25zdCBjYXJyaWFnZSA9IDB4MGQ7IC8vIFxcclxuXG4gIGZvciAobGV0IGkgPSAwOyBpIDwgYnVmZmVyLmxlbmd0aCAtIDI7IGkrKykge1xuICAgIGlmIChidWZmZXJbaV0gPT09IG5ld2xpbmUgJiYgYnVmZmVyW2kgKyAxXSA9PT0gbmV3bGluZSkge1xuICAgICAgLy8gXFxuXFxuXG4gICAgICByZXR1cm4gaSArIDI7XG4gICAgfVxuICAgIGlmIChidWZmZXJbaV0gPT09IGNhcnJpYWdlICYmIGJ1ZmZlcltpICsgMV0gPT09IGNhcnJpYWdlKSB7XG4gICAgICAvLyBcXHJcXHJcbiAgICAgIHJldHVybiBpICsgMjtcbiAgICB9XG4gICAgaWYgKFxuICAgICAgYnVmZmVyW2ldID09PSBjYXJyaWFnZSAmJlxuICAgICAgYnVmZmVyW2kgKyAxXSA9PT0gbmV3bGluZSAmJlxuICAgICAgaSArIDMgPCBidWZmZXIubGVuZ3RoICYmXG4gICAgICBidWZmZXJbaSArIDJdID09PSBjYXJyaWFnZSAmJlxuICAgICAgYnVmZmVyW2kgKyAzXSA9PT0gbmV3bGluZVxuICAgICkge1xuICAgICAgLy8gXFxyXFxuXFxyXFxuXG4gICAgICByZXR1cm4gaSArIDQ7XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIC0xO1xufVxuXG5jbGFzcyBTU0VEZWNvZGVyIHtcbiAgcHJpdmF0ZSBkYXRhOiBzdHJpbmdbXTtcbiAgcHJpdmF0ZSBldmVudDogc3RyaW5nIHwgbnVsbDtcbiAgcHJpdmF0ZSBjaHVua3M6IHN0cmluZ1tdO1xuXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMuZXZlbnQgPSBudWxsO1xuICAgIHRoaXMuZGF0YSA9IFtdO1xuICAgIHRoaXMuY2h1bmtzID0gW107XG4gIH1cblxuICBkZWNvZGUobGluZTogc3RyaW5nKSB7XG4gICAgaWYgKGxpbmUuZW5kc1dpdGgoJ1xccicpKSB7XG4gICAgICBsaW5lID0gbGluZS5zdWJzdHJpbmcoMCwgbGluZS5sZW5ndGggLSAxKTtcbiAgICB9XG5cbiAgICBpZiAoIWxpbmUpIHtcbiAgICAgIC8vIGVtcHR5IGxpbmUgYW5kIHdlIGRpZG4ndCBwcmV2aW91c2x5IGVuY291bnRlciBhbnkgbWVzc2FnZXNcbiAgICAgIGlmICghdGhpcy5ldmVudCAmJiAhdGhpcy5kYXRhLmxlbmd0aCkgcmV0dXJuIG51bGw7XG5cbiAgICAgIGNvbnN0IHNzZTogU2VydmVyU2VudEV2ZW50ID0ge1xuICAgICAgICBldmVudDogdGhpcy5ldmVudCxcbiAgICAgICAgZGF0YTogdGhpcy5kYXRhLmpvaW4oJ1xcbicpLFxuICAgICAgICByYXc6IHRoaXMuY2h1bmtzLFxuICAgICAgfTtcblxuICAgICAgdGhpcy5ldmVudCA9IG51bGw7XG4gICAgICB0aGlzLmRhdGEgPSBbXTtcbiAgICAgIHRoaXMuY2h1bmtzID0gW107XG5cbiAgICAgIHJldHVybiBzc2U7XG4gICAgfVxuXG4gICAgdGhpcy5jaHVua3MucHVzaChsaW5lKTtcblxuICAgIGlmIChsaW5lLnN0YXJ0c1dpdGgoJzonKSkge1xuICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuXG4gICAgbGV0IFtmaWVsZG5hbWUsIF8sIHZhbHVlXSA9IHBhcnRpdGlvbihsaW5lLCAnOicpO1xuXG4gICAgaWYgKHZhbHVlLnN0YXJ0c1dpdGgoJyAnKSkge1xuICAgICAgdmFsdWUgPSB2YWx1ZS5zdWJzdHJpbmcoMSk7XG4gICAgfVxuXG4gICAgaWYgKGZpZWxkbmFtZSA9PT0gJ2V2ZW50Jykge1xuICAgICAgdGhpcy5ldmVudCA9IHZhbHVlO1xuICAgIH0gZWxzZSBpZiAoZmllbGRuYW1lID09PSAnZGF0YScpIHtcbiAgICAgIHRoaXMuZGF0YS5wdXNoKHZhbHVlKTtcbiAgICB9XG5cbiAgICByZXR1cm4gbnVsbDtcbiAgfVxufVxuXG4vKipcbiAqIEEgcmUtaW1wbGVtZW50YXRpb24gb2YgaHR0cHgncyBgTGluZURlY29kZXJgIGluIFB5dGhvbiB0aGF0IGhhbmRsZXMgaW5jcmVtZW50YWxseVxuICogcmVhZGluZyBsaW5lcyBmcm9tIHRleHQuXG4gKlxuICogaHR0cHM6Ly9naXRodWIuY29tL2VuY29kZS9odHRweC9ibG9iLzkyMDMzM2VhOTgxMThlOWNmNjE3ZjI0NjkwNWQ3YjIwMjUxMDk0MWMvaHR0cHgvX2RlY29kZXJzLnB5I0wyNThcbiAqL1xuY2xhc3MgTGluZURlY29kZXIge1xuICAvLyBwcmV0dGllci1pZ25vcmVcbiAgc3RhdGljIE5FV0xJTkVfQ0hBUlMgPSBuZXcgU2V0KFsnXFxuJywgJ1xcciddKTtcbiAgc3RhdGljIE5FV0xJTkVfUkVHRVhQID0gL1xcclxcbnxbXFxuXFxyXS9nO1xuXG4gIGJ1ZmZlcjogc3RyaW5nW107XG4gIHRyYWlsaW5nQ1I6IGJvb2xlYW47XG4gIHRleHREZWNvZGVyOiBhbnk7IC8vIFRleHREZWNvZGVyIGZvdW5kIGluIGJyb3dzZXJzOyBub3QgdHlwZWQgdG8gYXZvaWQgcHVsbGluZyBpbiBlaXRoZXIgXCJkb21cIiBvciBcIm5vZGVcIiB0eXBlcy5cblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLmJ1ZmZlciA9IFtdO1xuICAgIHRoaXMudHJhaWxpbmdDUiA9IGZhbHNlO1xuICB9XG5cbiAgZGVjb2RlKGNodW5rOiBCeXRlcyk6IHN0cmluZ1tdIHtcbiAgICBsZXQgdGV4dCA9IHRoaXMuZGVjb2RlVGV4dChjaHVuayk7XG5cbiAgICBpZiAodGhpcy50cmFpbGluZ0NSKSB7XG4gICAgICB0ZXh0ID0gJ1xccicgKyB0ZXh0O1xuICAgICAgdGhpcy50cmFpbGluZ0NSID0gZmFsc2U7XG4gICAgfVxuICAgIGlmICh0ZXh0LmVuZHNXaXRoKCdcXHInKSkge1xuICAgICAgdGhpcy50cmFpbGluZ0NSID0gdHJ1ZTtcbiAgICAgIHRleHQgPSB0ZXh0LnNsaWNlKDAsIC0xKTtcbiAgICB9XG5cbiAgICBpZiAoIXRleHQpIHtcbiAgICAgIHJldHVybiBbXTtcbiAgICB9XG5cbiAgICBjb25zdCB0cmFpbGluZ05ld2xpbmUgPSBMaW5lRGVjb2Rlci5ORVdMSU5FX0NIQVJTLmhhcyh0ZXh0W3RleHQubGVuZ3RoIC0gMV0gfHwgJycpO1xuICAgIGxldCBsaW5lcyA9IHRleHQuc3BsaXQoTGluZURlY29kZXIuTkVXTElORV9SRUdFWFApO1xuXG4gICAgLy8gaWYgdGhlcmUgaXMgYSB0cmFpbGluZyBuZXcgbGluZSB0aGVuIHRoZSBsYXN0IGVudHJ5IHdpbGwgYmUgYW4gZW1wdHlcbiAgICAvLyBzdHJpbmcgd2hpY2ggd2UgZG9uJ3QgY2FyZSBhYm91dFxuICAgIGlmICh0cmFpbGluZ05ld2xpbmUpIHtcbiAgICAgIGxpbmVzLnBvcCgpO1xuICAgIH1cblxuICAgIGlmIChsaW5lcy5sZW5ndGggPT09IDEgJiYgIXRyYWlsaW5nTmV3bGluZSkge1xuICAgICAgdGhpcy5idWZmZXIucHVzaChsaW5lc1swXSEpO1xuICAgICAgcmV0dXJuIFtdO1xuICAgIH1cblxuICAgIGlmICh0aGlzLmJ1ZmZlci5sZW5ndGggPiAwKSB7XG4gICAgICBsaW5lcyA9IFt0aGlzLmJ1ZmZlci5qb2luKCcnKSArIGxpbmVzWzBdLCAuLi5saW5lcy5zbGljZSgxKV07XG4gICAgICB0aGlzLmJ1ZmZlciA9IFtdO1xuICAgIH1cblxuICAgIGlmICghdHJhaWxpbmdOZXdsaW5lKSB7XG4gICAgICB0aGlzLmJ1ZmZlciA9IFtsaW5lcy5wb3AoKSB8fCAnJ107XG4gICAgfVxuXG4gICAgcmV0dXJuIGxpbmVzO1xuICB9XG5cbiAgZGVjb2RlVGV4dChieXRlczogQnl0ZXMpOiBzdHJpbmcge1xuICAgIGlmIChieXRlcyA9PSBudWxsKSByZXR1cm4gJyc7XG4gICAgaWYgKHR5cGVvZiBieXRlcyA9PT0gJ3N0cmluZycpIHJldHVybiBieXRlcztcblxuICAgIC8vIE5vZGU6XG4gICAgaWYgKHR5cGVvZiBCdWZmZXIgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICBpZiAoYnl0ZXMgaW5zdGFuY2VvZiBCdWZmZXIpIHtcbiAgICAgICAgcmV0dXJuIGJ5dGVzLnRvU3RyaW5nKCk7XG4gICAgICB9XG4gICAgICBpZiAoYnl0ZXMgaW5zdGFuY2VvZiBVaW50OEFycmF5KSB7XG4gICAgICAgIHJldHVybiBCdWZmZXIuZnJvbShieXRlcykudG9TdHJpbmcoKTtcbiAgICAgIH1cblxuICAgICAgdGhyb3cgbmV3IEFudGhyb3BpY0Vycm9yKFxuICAgICAgICBgVW5leHBlY3RlZDogcmVjZWl2ZWQgbm9uLVVpbnQ4QXJyYXkgKCR7Ynl0ZXMuY29uc3RydWN0b3IubmFtZX0pIHN0cmVhbSBjaHVuayBpbiBhbiBlbnZpcm9ubWVudCB3aXRoIGEgZ2xvYmFsIFwiQnVmZmVyXCIgZGVmaW5lZCwgd2hpY2ggdGhpcyBsaWJyYXJ5IGFzc3VtZXMgdG8gYmUgTm9kZS4gUGxlYXNlIHJlcG9ydCB0aGlzIGVycm9yLmAsXG4gICAgICApO1xuICAgIH1cblxuICAgIC8vIEJyb3dzZXJcbiAgICBpZiAodHlwZW9mIFRleHREZWNvZGVyICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgaWYgKGJ5dGVzIGluc3RhbmNlb2YgVWludDhBcnJheSB8fCBieXRlcyBpbnN0YW5jZW9mIEFycmF5QnVmZmVyKSB7XG4gICAgICAgIHRoaXMudGV4dERlY29kZXIgPz89IG5ldyBUZXh0RGVjb2RlcigndXRmOCcpO1xuICAgICAgICByZXR1cm4gdGhpcy50ZXh0RGVjb2Rlci5kZWNvZGUoYnl0ZXMpO1xuICAgICAgfVxuXG4gICAgICB0aHJvdyBuZXcgQW50aHJvcGljRXJyb3IoXG4gICAgICAgIGBVbmV4cGVjdGVkOiByZWNlaXZlZCBub24tVWludDhBcnJheS9BcnJheUJ1ZmZlciAoJHtcbiAgICAgICAgICAoYnl0ZXMgYXMgYW55KS5jb25zdHJ1Y3Rvci5uYW1lXG4gICAgICAgIH0pIGluIGEgd2ViIHBsYXRmb3JtLiBQbGVhc2UgcmVwb3J0IHRoaXMgZXJyb3IuYCxcbiAgICAgICk7XG4gICAgfVxuXG4gICAgdGhyb3cgbmV3IEFudGhyb3BpY0Vycm9yKFxuICAgICAgYFVuZXhwZWN0ZWQ6IG5laXRoZXIgQnVmZmVyIG5vciBUZXh0RGVjb2RlciBhcmUgYXZhaWxhYmxlIGFzIGdsb2JhbHMuIFBsZWFzZSByZXBvcnQgdGhpcyBlcnJvci5gLFxuICAgICk7XG4gIH1cblxuICBmbHVzaCgpOiBzdHJpbmdbXSB7XG4gICAgaWYgKCF0aGlzLmJ1ZmZlci5sZW5ndGggJiYgIXRoaXMudHJhaWxpbmdDUikge1xuICAgICAgcmV0dXJuIFtdO1xuICAgIH1cblxuICAgIGNvbnN0IGxpbmVzID0gW3RoaXMuYnVmZmVyLmpvaW4oJycpXTtcbiAgICB0aGlzLmJ1ZmZlciA9IFtdO1xuICAgIHRoaXMudHJhaWxpbmdDUiA9IGZhbHNlO1xuICAgIHJldHVybiBsaW5lcztcbiAgfVxufVxuXG4vKiogVGhpcyBpcyBhbiBpbnRlcm5hbCBoZWxwZXIgZnVuY3Rpb24gdGhhdCdzIGp1c3QgdXNlZCBmb3IgdGVzdGluZyAqL1xuZXhwb3J0IGZ1bmN0aW9uIF9kZWNvZGVDaHVua3MoY2h1bmtzOiBzdHJpbmdbXSk6IHN0cmluZ1tdIHtcbiAgY29uc3QgZGVjb2RlciA9IG5ldyBMaW5lRGVjb2RlcigpO1xuICBjb25zdCBsaW5lczogc3RyaW5nW10gPSBbXTtcbiAgZm9yIChjb25zdCBjaHVuayBvZiBjaHVua3MpIHtcbiAgICBsaW5lcy5wdXNoKC4uLmRlY29kZXIuZGVjb2RlKGNodW5rKSk7XG4gIH1cblxuICByZXR1cm4gbGluZXM7XG59XG5cbmZ1bmN0aW9uIHBhcnRpdGlvbihzdHI6IHN0cmluZywgZGVsaW1pdGVyOiBzdHJpbmcpOiBbc3RyaW5nLCBzdHJpbmcsIHN0cmluZ10ge1xuICBjb25zdCBpbmRleCA9IHN0ci5pbmRleE9mKGRlbGltaXRlcik7XG4gIGlmIChpbmRleCAhPT0gLTEpIHtcbiAgICByZXR1cm4gW3N0ci5zdWJzdHJpbmcoMCwgaW5kZXgpLCBkZWxpbWl0ZXIsIHN0ci5zdWJzdHJpbmcoaW5kZXggKyBkZWxpbWl0ZXIubGVuZ3RoKV07XG4gIH1cblxuICByZXR1cm4gW3N0ciwgJycsICcnXTtcbn1cblxuLyoqXG4gKiBNb3N0IGJyb3dzZXJzIGRvbid0IHlldCBoYXZlIGFzeW5jIGl0ZXJhYmxlIHN1cHBvcnQgZm9yIFJlYWRhYmxlU3RyZWFtLFxuICogYW5kIE5vZGUgaGFzIGEgdmVyeSBkaWZmZXJlbnQgd2F5IG9mIHJlYWRpbmcgYnl0ZXMgZnJvbSBpdHMgXCJSZWFkYWJsZVN0cmVhbVwiLlxuICpcbiAqIFRoaXMgcG9seWZpbGwgd2FzIHB1bGxlZCBmcm9tIGh0dHBzOi8vZ2l0aHViLmNvbS9NYXR0aWFzQnVlbGVucy93ZWItc3RyZWFtcy1wb2x5ZmlsbC9wdWxsLzEyMiNpc3N1ZWNvbW1lbnQtMTYyNzM1NDQ5MFxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVhZGFibGVTdHJlYW1Bc3luY0l0ZXJhYmxlPFQ+KHN0cmVhbTogYW55KTogQXN5bmNJdGVyYWJsZUl0ZXJhdG9yPFQ+IHtcbiAgaWYgKHN0cmVhbVtTeW1ib2wuYXN5bmNJdGVyYXRvcl0pIHJldHVybiBzdHJlYW07XG5cbiAgY29uc3QgcmVhZGVyID0gc3RyZWFtLmdldFJlYWRlcigpO1xuICByZXR1cm4ge1xuICAgIGFzeW5jIG5leHQoKSB7XG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCByZWFkZXIucmVhZCgpO1xuICAgICAgICBpZiAocmVzdWx0Py5kb25lKSByZWFkZXIucmVsZWFzZUxvY2soKTsgLy8gcmVsZWFzZSBsb2NrIHdoZW4gc3RyZWFtIGJlY29tZXMgY2xvc2VkXG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgIHJlYWRlci5yZWxlYXNlTG9jaygpOyAvLyByZWxlYXNlIGxvY2sgd2hlbiBzdHJlYW0gYmVjb21lcyBlcnJvcmVkXG4gICAgICAgIHRocm93IGU7XG4gICAgICB9XG4gICAgfSxcbiAgICBhc3luYyByZXR1cm4oKSB7XG4gICAgICBjb25zdCBjYW5jZWxQcm9taXNlID0gcmVhZGVyLmNhbmNlbCgpO1xuICAgICAgcmVhZGVyLnJlbGVhc2VMb2NrKCk7XG4gICAgICBhd2FpdCBjYW5jZWxQcm9taXNlO1xuICAgICAgcmV0dXJuIHsgZG9uZTogdHJ1ZSwgdmFsdWU6IHVuZGVmaW5lZCB9O1xuICAgIH0sXG4gICAgW1N5bWJvbC5hc3luY0l0ZXJhdG9yXSgpIHtcbiAgICAgIHJldHVybiB0aGlzO1xuICAgIH0sXG4gIH07XG59XG4iLCAiaW1wb3J0IHsgdHlwZSBSZXF1ZXN0T3B0aW9ucyB9IGZyb20gXCIuL2NvcmUuanNcIjtcbmltcG9ydCB7XG4gIEZvcm1EYXRhLFxuICBGaWxlLFxuICB0eXBlIEJsb2IsXG4gIHR5cGUgRmlsZVByb3BlcnR5QmFnLFxuICBnZXRNdWx0aXBhcnRSZXF1ZXN0T3B0aW9ucyxcbiAgdHlwZSBGc1JlYWRTdHJlYW0sXG4gIGlzRnNSZWFkU3RyZWFtLFxufSBmcm9tIFwiLi9fc2hpbXMvaW5kZXguanNcIjtcbmltcG9ydCB7IE11bHRpcGFydEJvZHkgfSBmcm9tIFwiLi9fc2hpbXMvTXVsdGlwYXJ0Qm9keS5qc1wiO1xuZXhwb3J0IHsgZmlsZUZyb21QYXRoIH0gZnJvbSBcIi4vX3NoaW1zL2luZGV4LmpzXCI7XG5cbnR5cGUgQmxvYkxpa2VQYXJ0ID0gc3RyaW5nIHwgQXJyYXlCdWZmZXIgfCBBcnJheUJ1ZmZlclZpZXcgfCBCbG9iTGlrZSB8IFVpbnQ4QXJyYXkgfCBEYXRhVmlldztcbmV4cG9ydCB0eXBlIEJsb2JQYXJ0ID0gc3RyaW5nIHwgQXJyYXlCdWZmZXIgfCBBcnJheUJ1ZmZlclZpZXcgfCBCbG9iIHwgVWludDhBcnJheSB8IERhdGFWaWV3O1xuXG4vKipcbiAqIFR5cGljYWxseSwgdGhpcyBpcyBhIG5hdGl2ZSBcIkZpbGVcIiBjbGFzcy5cbiAqXG4gKiBXZSBwcm92aWRlIHRoZSB7QGxpbmsgdG9GaWxlfSB1dGlsaXR5IHRvIGNvbnZlcnQgYSB2YXJpZXR5IG9mIG9iamVjdHNcbiAqIGludG8gdGhlIEZpbGUgY2xhc3MuXG4gKlxuICogRm9yIGNvbnZlbmllbmNlLCB5b3UgY2FuIGFsc28gcGFzcyBhIGZldGNoIFJlc3BvbnNlLCBvciBpbiBOb2RlLFxuICogdGhlIHJlc3VsdCBvZiBmcy5jcmVhdGVSZWFkU3RyZWFtKCkuXG4gKi9cbmV4cG9ydCB0eXBlIFVwbG9hZGFibGUgPSBGaWxlTGlrZSB8IFJlc3BvbnNlTGlrZSB8IEZzUmVhZFN0cmVhbTtcblxuLyoqXG4gKiBJbnRlbmRlZCB0byBtYXRjaCB3ZWIuQmxvYiwgbm9kZS5CbG9iLCBub2RlLWZldGNoLkJsb2IsIGV0Yy5cbiAqL1xuZXhwb3J0IGludGVyZmFjZSBCbG9iTGlrZSB7XG4gIC8qKiBbTUROIFJlZmVyZW5jZV0oaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZG9jcy9XZWIvQVBJL0Jsb2Ivc2l6ZSkgKi9cbiAgcmVhZG9ubHkgc2l6ZTogbnVtYmVyO1xuICAvKiogW01ETiBSZWZlcmVuY2VdKGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2RvY3MvV2ViL0FQSS9CbG9iL3R5cGUpICovXG4gIHJlYWRvbmx5IHR5cGU6IHN0cmluZztcbiAgLyoqIFtNRE4gUmVmZXJlbmNlXShodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9kb2NzL1dlYi9BUEkvQmxvYi90ZXh0KSAqL1xuICB0ZXh0KCk6IFByb21pc2U8c3RyaW5nPjtcbiAgLyoqIFtNRE4gUmVmZXJlbmNlXShodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9kb2NzL1dlYi9BUEkvQmxvYi9zbGljZSkgKi9cbiAgc2xpY2Uoc3RhcnQ/OiBudW1iZXIsIGVuZD86IG51bWJlcik6IEJsb2JMaWtlO1xuICAvLyB1bmZvcnR1bmF0ZWx5IEB0eXBlcy9ub2RlLWZldGNoQF4yLjYuNCBkb2Vzbid0IHR5cGUgdGhlIGFycmF5QnVmZmVyIG1ldGhvZFxufVxuXG4vKipcbiAqIEludGVuZGVkIHRvIG1hdGNoIHdlYi5GaWxlLCBub2RlLkZpbGUsIG5vZGUtZmV0Y2guRmlsZSwgZXRjLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIEZpbGVMaWtlIGV4dGVuZHMgQmxvYkxpa2Uge1xuICAvKiogW01ETiBSZWZlcmVuY2VdKGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2RvY3MvV2ViL0FQSS9GaWxlL2xhc3RNb2RpZmllZCkgKi9cbiAgcmVhZG9ubHkgbGFzdE1vZGlmaWVkOiBudW1iZXI7XG4gIC8qKiBbTUROIFJlZmVyZW5jZV0oaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZG9jcy9XZWIvQVBJL0ZpbGUvbmFtZSkgKi9cbiAgcmVhZG9ubHkgbmFtZTogc3RyaW5nO1xufVxuXG4vKipcbiAqIEludGVuZGVkIHRvIG1hdGNoIHdlYi5SZXNwb25zZSwgbm9kZS5SZXNwb25zZSwgbm9kZS1mZXRjaC5SZXNwb25zZSwgZXRjLlxuICovXG5leHBvcnQgaW50ZXJmYWNlIFJlc3BvbnNlTGlrZSB7XG4gIHVybDogc3RyaW5nO1xuICBibG9iKCk6IFByb21pc2U8QmxvYkxpa2U+O1xufVxuXG5leHBvcnQgY29uc3QgaXNSZXNwb25zZUxpa2UgPSAodmFsdWU6IGFueSk6IHZhbHVlIGlzIFJlc3BvbnNlTGlrZSA9PlxuICB2YWx1ZSAhPSBudWxsICYmXG4gIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiZcbiAgdHlwZW9mIHZhbHVlLnVybCA9PT0gJ3N0cmluZycgJiZcbiAgdHlwZW9mIHZhbHVlLmJsb2IgPT09ICdmdW5jdGlvbic7XG5cbmV4cG9ydCBjb25zdCBpc0ZpbGVMaWtlID0gKHZhbHVlOiBhbnkpOiB2YWx1ZSBpcyBGaWxlTGlrZSA9PlxuICB2YWx1ZSAhPSBudWxsICYmXG4gIHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiZcbiAgdHlwZW9mIHZhbHVlLm5hbWUgPT09ICdzdHJpbmcnICYmXG4gIHR5cGVvZiB2YWx1ZS5sYXN0TW9kaWZpZWQgPT09ICdudW1iZXInICYmXG4gIGlzQmxvYkxpa2UodmFsdWUpO1xuXG4vKipcbiAqIFRoZSBCbG9iTGlrZSB0eXBlIG9taXRzIGFycmF5QnVmZmVyKCkgYmVjYXVzZSBAdHlwZXMvbm9kZS1mZXRjaEBeMi42LjQgbGFja3MgaXQ7IGJ1dCB0aGlzIGNoZWNrXG4gKiBhZGRzIHRoZSBhcnJheUJ1ZmZlcigpIG1ldGhvZCB0eXBlIGJlY2F1c2UgaXQgaXMgYXZhaWxhYmxlIGFuZCB1c2VkIGF0IHJ1bnRpbWVcbiAqL1xuZXhwb3J0IGNvbnN0IGlzQmxvYkxpa2UgPSAodmFsdWU6IGFueSk6IHZhbHVlIGlzIEJsb2JMaWtlICYgeyBhcnJheUJ1ZmZlcigpOiBQcm9taXNlPEFycmF5QnVmZmVyPiB9ID0+XG4gIHZhbHVlICE9IG51bGwgJiZcbiAgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJlxuICB0eXBlb2YgdmFsdWUuc2l6ZSA9PT0gJ251bWJlcicgJiZcbiAgdHlwZW9mIHZhbHVlLnR5cGUgPT09ICdzdHJpbmcnICYmXG4gIHR5cGVvZiB2YWx1ZS50ZXh0ID09PSAnZnVuY3Rpb24nICYmXG4gIHR5cGVvZiB2YWx1ZS5zbGljZSA9PT0gJ2Z1bmN0aW9uJyAmJlxuICB0eXBlb2YgdmFsdWUuYXJyYXlCdWZmZXIgPT09ICdmdW5jdGlvbic7XG5cbmV4cG9ydCBjb25zdCBpc1VwbG9hZGFibGUgPSAodmFsdWU6IGFueSk6IHZhbHVlIGlzIFVwbG9hZGFibGUgPT4ge1xuICByZXR1cm4gaXNGaWxlTGlrZSh2YWx1ZSkgfHwgaXNSZXNwb25zZUxpa2UodmFsdWUpIHx8IGlzRnNSZWFkU3RyZWFtKHZhbHVlKTtcbn07XG5cbmV4cG9ydCB0eXBlIFRvRmlsZUlucHV0ID0gVXBsb2FkYWJsZSB8IEV4Y2x1ZGU8QmxvYkxpa2VQYXJ0LCBzdHJpbmc+IHwgQXN5bmNJdGVyYWJsZTxCbG9iTGlrZVBhcnQ+O1xuXG4vKipcbiAqIEhlbHBlciBmb3IgY3JlYXRpbmcgYSB7QGxpbmsgRmlsZX0gdG8gcGFzcyB0byBhbiBTREsgdXBsb2FkIG1ldGhvZCBmcm9tIGEgdmFyaWV0eSBvZiBkaWZmZXJlbnQgZGF0YSBmb3JtYXRzXG4gKiBAcGFyYW0gdmFsdWUgdGhlIHJhdyBjb250ZW50IG9mIHRoZSBmaWxlLiAgQ2FuIGJlIGFuIHtAbGluayBVcGxvYWRhYmxlfSwge0BsaW5rIEJsb2JMaWtlUGFydH0sIG9yIHtAbGluayBBc3luY0l0ZXJhYmxlfSBvZiB7QGxpbmsgQmxvYkxpa2VQYXJ0fXNcbiAqIEBwYXJhbSB7c3RyaW5nPX0gbmFtZSB0aGUgbmFtZSBvZiB0aGUgZmlsZS4gSWYgb21pdHRlZCwgdG9GaWxlIHdpbGwgdHJ5IHRvIGRldGVybWluZSBhIGZpbGUgbmFtZSBmcm9tIGJpdHMgaWYgcG9zc2libGVcbiAqIEBwYXJhbSB7T2JqZWN0PX0gb3B0aW9ucyBhZGRpdGlvbmFsIHByb3BlcnRpZXNcbiAqIEBwYXJhbSB7c3RyaW5nPX0gb3B0aW9ucy50eXBlIHRoZSBNSU1FIHR5cGUgb2YgdGhlIGNvbnRlbnRcbiAqIEBwYXJhbSB7bnVtYmVyPX0gb3B0aW9ucy5sYXN0TW9kaWZpZWQgdGhlIGxhc3QgbW9kaWZpZWQgdGltZXN0YW1wXG4gKiBAcmV0dXJucyBhIHtAbGluayBGaWxlfSB3aXRoIHRoZSBnaXZlbiBwcm9wZXJ0aWVzXG4gKi9cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiB0b0ZpbGUoXG4gIHZhbHVlOiBUb0ZpbGVJbnB1dCB8IFByb21pc2VMaWtlPFRvRmlsZUlucHV0PixcbiAgbmFtZT86IHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQsXG4gIG9wdGlvbnM/OiBGaWxlUHJvcGVydHlCYWcgfCB1bmRlZmluZWQsXG4pOiBQcm9taXNlPEZpbGVMaWtlPiB7XG4gIC8vIElmIGl0J3MgYSBwcm9taXNlLCByZXNvbHZlIGl0LlxuICB2YWx1ZSA9IGF3YWl0IHZhbHVlO1xuXG4gIC8vIElmIHdlJ3ZlIGJlZW4gZ2l2ZW4gYSBgRmlsZWAgd2UgZG9uJ3QgbmVlZCB0byBkbyBhbnl0aGluZ1xuICBpZiAoaXNGaWxlTGlrZSh2YWx1ZSkpIHtcbiAgICByZXR1cm4gdmFsdWU7XG4gIH1cblxuICBpZiAoaXNSZXNwb25zZUxpa2UodmFsdWUpKSB7XG4gICAgY29uc3QgYmxvYiA9IGF3YWl0IHZhbHVlLmJsb2IoKTtcbiAgICBuYW1lIHx8PSBuZXcgVVJMKHZhbHVlLnVybCkucGF0aG5hbWUuc3BsaXQoL1tcXFxcL10vKS5wb3AoKSA/PyAndW5rbm93bl9maWxlJztcblxuICAgIC8vIHdlIG5lZWQgdG8gY29udmVydCB0aGUgYEJsb2JgIGludG8gYW4gYXJyYXkgYnVmZmVyIGJlY2F1c2UgdGhlIGBCbG9iYCBjbGFzc1xuICAgIC8vIHRoYXQgYG5vZGUtZmV0Y2hgIGRlZmluZXMgaXMgaW5jb21wYXRpYmxlIHdpdGggdGhlIHdlYiBzdGFuZGFyZCB3aGljaCByZXN1bHRzXG4gICAgLy8gaW4gYG5ldyBGaWxlYCBpbnRlcnByZXRpbmcgaXQgYXMgYSBzdHJpbmcgaW5zdGVhZCBvZiBiaW5hcnkgZGF0YS5cbiAgICBjb25zdCBkYXRhID0gaXNCbG9iTGlrZShibG9iKSA/IFsoYXdhaXQgYmxvYi5hcnJheUJ1ZmZlcigpKSBhcyBhbnldIDogW2Jsb2JdO1xuXG4gICAgcmV0dXJuIG5ldyBGaWxlKGRhdGEsIG5hbWUsIG9wdGlvbnMpO1xuICB9XG5cbiAgY29uc3QgYml0cyA9IGF3YWl0IGdldEJ5dGVzKHZhbHVlKTtcblxuICBuYW1lIHx8PSBnZXROYW1lKHZhbHVlKSA/PyAndW5rbm93bl9maWxlJztcblxuICBpZiAoIW9wdGlvbnM/LnR5cGUpIHtcbiAgICBjb25zdCB0eXBlID0gKGJpdHNbMF0gYXMgYW55KT8udHlwZTtcbiAgICBpZiAodHlwZW9mIHR5cGUgPT09ICdzdHJpbmcnKSB7XG4gICAgICBvcHRpb25zID0geyAuLi5vcHRpb25zLCB0eXBlIH07XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIG5ldyBGaWxlKGJpdHMsIG5hbWUsIG9wdGlvbnMpO1xufVxuXG5hc3luYyBmdW5jdGlvbiBnZXRCeXRlcyh2YWx1ZTogVG9GaWxlSW5wdXQpOiBQcm9taXNlPEFycmF5PEJsb2JQYXJ0Pj4ge1xuICBsZXQgcGFydHM6IEFycmF5PEJsb2JQYXJ0PiA9IFtdO1xuICBpZiAoXG4gICAgdHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyB8fFxuICAgIEFycmF5QnVmZmVyLmlzVmlldyh2YWx1ZSkgfHwgLy8gaW5jbHVkZXMgVWludDhBcnJheSwgQnVmZmVyLCBldGMuXG4gICAgdmFsdWUgaW5zdGFuY2VvZiBBcnJheUJ1ZmZlclxuICApIHtcbiAgICBwYXJ0cy5wdXNoKHZhbHVlKTtcbiAgfSBlbHNlIGlmIChpc0Jsb2JMaWtlKHZhbHVlKSkge1xuICAgIHBhcnRzLnB1c2goYXdhaXQgdmFsdWUuYXJyYXlCdWZmZXIoKSk7XG4gIH0gZWxzZSBpZiAoXG4gICAgaXNBc3luY0l0ZXJhYmxlSXRlcmF0b3IodmFsdWUpIC8vIGluY2x1ZGVzIFJlYWRhYmxlLCBSZWFkYWJsZVN0cmVhbSwgZXRjLlxuICApIHtcbiAgICBmb3IgYXdhaXQgKGNvbnN0IGNodW5rIG9mIHZhbHVlKSB7XG4gICAgICBwYXJ0cy5wdXNoKGNodW5rIGFzIEJsb2JQYXJ0KTsgLy8gVE9ETywgY29uc2lkZXIgdmFsaWRhdGluZz9cbiAgICB9XG4gIH0gZWxzZSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgYFVuZXhwZWN0ZWQgZGF0YSB0eXBlOiAke3R5cGVvZiB2YWx1ZX07IGNvbnN0cnVjdG9yOiAke3ZhbHVlPy5jb25zdHJ1Y3RvclxuICAgICAgICA/Lm5hbWV9OyBwcm9wczogJHtwcm9wc0ZvckVycm9yKHZhbHVlKX1gLFxuICAgICk7XG4gIH1cblxuICByZXR1cm4gcGFydHM7XG59XG5cbmZ1bmN0aW9uIHByb3BzRm9yRXJyb3IodmFsdWU6IGFueSk6IHN0cmluZyB7XG4gIGNvbnN0IHByb3BzID0gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModmFsdWUpO1xuICByZXR1cm4gYFske3Byb3BzLm1hcCgocCkgPT4gYFwiJHtwfVwiYCkuam9pbignLCAnKX1dYDtcbn1cblxuZnVuY3Rpb24gZ2V0TmFtZSh2YWx1ZTogYW55KTogc3RyaW5nIHwgdW5kZWZpbmVkIHtcbiAgcmV0dXJuIChcbiAgICBnZXRTdHJpbmdGcm9tTWF5YmVCdWZmZXIodmFsdWUubmFtZSkgfHxcbiAgICBnZXRTdHJpbmdGcm9tTWF5YmVCdWZmZXIodmFsdWUuZmlsZW5hbWUpIHx8XG4gICAgLy8gRm9yIGZzLlJlYWRTdHJlYW1cbiAgICBnZXRTdHJpbmdGcm9tTWF5YmVCdWZmZXIodmFsdWUucGF0aCk/LnNwbGl0KC9bXFxcXC9dLykucG9wKClcbiAgKTtcbn1cblxuY29uc3QgZ2V0U3RyaW5nRnJvbU1heWJlQnVmZmVyID0gKHg6IHN0cmluZyB8IEJ1ZmZlciB8IHVua25vd24pOiBzdHJpbmcgfCB1bmRlZmluZWQgPT4ge1xuICBpZiAodHlwZW9mIHggPT09ICdzdHJpbmcnKSByZXR1cm4geDtcbiAgaWYgKHR5cGVvZiBCdWZmZXIgIT09ICd1bmRlZmluZWQnICYmIHggaW5zdGFuY2VvZiBCdWZmZXIpIHJldHVybiBTdHJpbmcoeCk7XG4gIHJldHVybiB1bmRlZmluZWQ7XG59O1xuXG5jb25zdCBpc0FzeW5jSXRlcmFibGVJdGVyYXRvciA9ICh2YWx1ZTogYW55KTogdmFsdWUgaXMgQXN5bmNJdGVyYWJsZUl0ZXJhdG9yPHVua25vd24+ID0+XG4gIHZhbHVlICE9IG51bGwgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB0eXBlb2YgdmFsdWVbU3ltYm9sLmFzeW5jSXRlcmF0b3JdID09PSAnZnVuY3Rpb24nO1xuXG5leHBvcnQgY29uc3QgaXNNdWx0aXBhcnRCb2R5ID0gKGJvZHk6IGFueSk6IGJvZHkgaXMgTXVsdGlwYXJ0Qm9keSA9PlxuICBib2R5ICYmIHR5cGVvZiBib2R5ID09PSAnb2JqZWN0JyAmJiBib2R5LmJvZHkgJiYgYm9keVtTeW1ib2wudG9TdHJpbmdUYWddID09PSAnTXVsdGlwYXJ0Qm9keSc7XG5cbi8qKlxuICogUmV0dXJucyBhIG11bHRpcGFydC9mb3JtLWRhdGEgcmVxdWVzdCBpZiBhbnkgcGFydCBvZiB0aGUgZ2l2ZW4gcmVxdWVzdCBib2R5IGNvbnRhaW5zIGEgRmlsZSAvIEJsb2IgdmFsdWUuXG4gKiBPdGhlcndpc2UgcmV0dXJucyB0aGUgcmVxdWVzdCBhcyBpcy5cbiAqL1xuZXhwb3J0IGNvbnN0IG1heWJlTXVsdGlwYXJ0Rm9ybVJlcXVlc3RPcHRpb25zID0gYXN5bmMgPFQgPSBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPj4oXG4gIG9wdHM6IFJlcXVlc3RPcHRpb25zPFQ+LFxuKTogUHJvbWlzZTxSZXF1ZXN0T3B0aW9uczxUIHwgTXVsdGlwYXJ0Qm9keT4+ID0+IHtcbiAgaWYgKCFoYXNVcGxvYWRhYmxlVmFsdWUob3B0cy5ib2R5KSkgcmV0dXJuIG9wdHM7XG5cbiAgY29uc3QgZm9ybSA9IGF3YWl0IGNyZWF0ZUZvcm0ob3B0cy5ib2R5KTtcbiAgcmV0dXJuIGdldE11bHRpcGFydFJlcXVlc3RPcHRpb25zKGZvcm0sIG9wdHMpO1xufTtcblxuZXhwb3J0IGNvbnN0IG11bHRpcGFydEZvcm1SZXF1ZXN0T3B0aW9ucyA9IGFzeW5jIDxUID0gUmVjb3JkPHN0cmluZywgdW5rbm93bj4+KFxuICBvcHRzOiBSZXF1ZXN0T3B0aW9uczxUPixcbik6IFByb21pc2U8UmVxdWVzdE9wdGlvbnM8VCB8IE11bHRpcGFydEJvZHk+PiA9PiB7XG4gIGNvbnN0IGZvcm0gPSBhd2FpdCBjcmVhdGVGb3JtKG9wdHMuYm9keSk7XG4gIHJldHVybiBnZXRNdWx0aXBhcnRSZXF1ZXN0T3B0aW9ucyhmb3JtLCBvcHRzKTtcbn07XG5cbmV4cG9ydCBjb25zdCBjcmVhdGVGb3JtID0gYXN5bmMgPFQgPSBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPj4oYm9keTogVCB8IHVuZGVmaW5lZCk6IFByb21pc2U8Rm9ybURhdGE+ID0+IHtcbiAgY29uc3QgZm9ybSA9IG5ldyBGb3JtRGF0YSgpO1xuICBhd2FpdCBQcm9taXNlLmFsbChPYmplY3QuZW50cmllcyhib2R5IHx8IHt9KS5tYXAoKFtrZXksIHZhbHVlXSkgPT4gYWRkRm9ybVZhbHVlKGZvcm0sIGtleSwgdmFsdWUpKSk7XG4gIHJldHVybiBmb3JtO1xufTtcblxuY29uc3QgaGFzVXBsb2FkYWJsZVZhbHVlID0gKHZhbHVlOiB1bmtub3duKTogYm9vbGVhbiA9PiB7XG4gIGlmIChpc1VwbG9hZGFibGUodmFsdWUpKSByZXR1cm4gdHJ1ZTtcbiAgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSByZXR1cm4gdmFsdWUuc29tZShoYXNVcGxvYWRhYmxlVmFsdWUpO1xuICBpZiAodmFsdWUgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0Jykge1xuICAgIGZvciAoY29uc3QgayBpbiB2YWx1ZSkge1xuICAgICAgaWYgKGhhc1VwbG9hZGFibGVWYWx1ZSgodmFsdWUgYXMgYW55KVtrXSkpIHJldHVybiB0cnVlO1xuICAgIH1cbiAgfVxuICByZXR1cm4gZmFsc2U7XG59O1xuXG5jb25zdCBhZGRGb3JtVmFsdWUgPSBhc3luYyAoZm9ybTogRm9ybURhdGEsIGtleTogc3RyaW5nLCB2YWx1ZTogdW5rbm93bik6IFByb21pc2U8dm9pZD4gPT4ge1xuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkgcmV0dXJuO1xuICBpZiAodmFsdWUgPT0gbnVsbCkge1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXG4gICAgICBgUmVjZWl2ZWQgbnVsbCBmb3IgXCIke2tleX1cIjsgdG8gcGFzcyBudWxsIGluIEZvcm1EYXRhLCB5b3UgbXVzdCB1c2UgdGhlIHN0cmluZyAnbnVsbCdgLFxuICAgICk7XG4gIH1cblxuICAvLyBUT0RPOiBtYWtlIG5lc3RlZCBmb3JtYXRzIGNvbmZpZ3VyYWJsZVxuICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJyB8fCB0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInIHx8IHR5cGVvZiB2YWx1ZSA9PT0gJ2Jvb2xlYW4nKSB7XG4gICAgZm9ybS5hcHBlbmQoa2V5LCBTdHJpbmcodmFsdWUpKTtcbiAgfSBlbHNlIGlmIChpc1VwbG9hZGFibGUodmFsdWUpKSB7XG4gICAgY29uc3QgZmlsZSA9IGF3YWl0IHRvRmlsZSh2YWx1ZSk7XG4gICAgZm9ybS5hcHBlbmQoa2V5LCBmaWxlIGFzIEZpbGUpO1xuICB9IGVsc2UgaWYgKEFycmF5LmlzQXJyYXkodmFsdWUpKSB7XG4gICAgYXdhaXQgUHJvbWlzZS5hbGwodmFsdWUubWFwKChlbnRyeSkgPT4gYWRkRm9ybVZhbHVlKGZvcm0sIGtleSArICdbXScsIGVudHJ5KSkpO1xuICB9IGVsc2UgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcpIHtcbiAgICBhd2FpdCBQcm9taXNlLmFsbChcbiAgICAgIE9iamVjdC5lbnRyaWVzKHZhbHVlKS5tYXAoKFtuYW1lLCBwcm9wXSkgPT4gYWRkRm9ybVZhbHVlKGZvcm0sIGAke2tleX1bJHtuYW1lfV1gLCBwcm9wKSksXG4gICAgKTtcbiAgfSBlbHNlIHtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFxuICAgICAgYEludmFsaWQgdmFsdWUgZ2l2ZW4gdG8gZm9ybSwgZXhwZWN0ZWQgYSBzdHJpbmcsIG51bWJlciwgYm9vbGVhbiwgb2JqZWN0LCBBcnJheSwgRmlsZSBvciBCbG9iIGJ1dCBnb3QgJHt2YWx1ZX0gaW5zdGVhZGAsXG4gICAgKTtcbiAgfVxufTtcbiIsICJpbXBvcnQgeyBWRVJTSU9OIH0gZnJvbSBcIi4vdmVyc2lvbi5qc1wiO1xuaW1wb3J0IHsgU3RyZWFtIH0gZnJvbSBcIi4vc3RyZWFtaW5nLmpzXCI7XG5pbXBvcnQge1xuICBBbnRocm9waWNFcnJvcixcbiAgQVBJRXJyb3IsXG4gIEFQSUNvbm5lY3Rpb25FcnJvcixcbiAgQVBJQ29ubmVjdGlvblRpbWVvdXRFcnJvcixcbiAgQVBJVXNlckFib3J0RXJyb3IsXG59IGZyb20gXCIuL2Vycm9yLmpzXCI7XG5pbXBvcnQge1xuICBraW5kIGFzIHNoaW1zS2luZCxcbiAgdHlwZSBSZWFkYWJsZSxcbiAgZ2V0RGVmYXVsdEFnZW50LFxuICB0eXBlIEFnZW50LFxuICBmZXRjaCxcbiAgdHlwZSBSZXF1ZXN0SW5mbyxcbiAgdHlwZSBSZXF1ZXN0SW5pdCxcbiAgdHlwZSBSZXNwb25zZSxcbiAgdHlwZSBIZWFkZXJzSW5pdCxcbn0gZnJvbSBcIi4vX3NoaW1zL2luZGV4LmpzXCI7XG5leHBvcnQgeyB0eXBlIFJlc3BvbnNlIH07XG5pbXBvcnQgeyBCbG9iTGlrZSwgaXNCbG9iTGlrZSwgaXNNdWx0aXBhcnRCb2R5IH0gZnJvbSBcIi4vdXBsb2Fkcy5qc1wiO1xuZXhwb3J0IHtcbiAgbWF5YmVNdWx0aXBhcnRGb3JtUmVxdWVzdE9wdGlvbnMsXG4gIG11bHRpcGFydEZvcm1SZXF1ZXN0T3B0aW9ucyxcbiAgY3JlYXRlRm9ybSxcbiAgdHlwZSBVcGxvYWRhYmxlLFxufSBmcm9tIFwiLi91cGxvYWRzLmpzXCI7XG5cbmV4cG9ydCB0eXBlIEZldGNoID0gKHVybDogUmVxdWVzdEluZm8sIGluaXQ/OiBSZXF1ZXN0SW5pdCkgPT4gUHJvbWlzZTxSZXNwb25zZT47XG5cbnR5cGUgUHJvbWlzZU9yVmFsdWU8VD4gPSBUIHwgUHJvbWlzZTxUPjtcblxudHlwZSBBUElSZXNwb25zZVByb3BzID0ge1xuICByZXNwb25zZTogUmVzcG9uc2U7XG4gIG9wdGlvbnM6IEZpbmFsUmVxdWVzdE9wdGlvbnM7XG4gIGNvbnRyb2xsZXI6IEFib3J0Q29udHJvbGxlcjtcbn07XG5cbmFzeW5jIGZ1bmN0aW9uIGRlZmF1bHRQYXJzZVJlc3BvbnNlPFQ+KHByb3BzOiBBUElSZXNwb25zZVByb3BzKTogUHJvbWlzZTxUPiB7XG4gIGNvbnN0IHsgcmVzcG9uc2UgfSA9IHByb3BzO1xuICBpZiAocHJvcHMub3B0aW9ucy5zdHJlYW0pIHtcbiAgICBkZWJ1ZygncmVzcG9uc2UnLCByZXNwb25zZS5zdGF0dXMsIHJlc3BvbnNlLnVybCwgcmVzcG9uc2UuaGVhZGVycywgcmVzcG9uc2UuYm9keSk7XG5cbiAgICAvLyBOb3RlOiB0aGVyZSBpcyBhbiBpbnZhcmlhbnQgaGVyZSB0aGF0IGlzbid0IHJlcHJlc2VudGVkIGluIHRoZSB0eXBlIHN5c3RlbVxuICAgIC8vIHRoYXQgaWYgeW91IHNldCBgc3RyZWFtOiB0cnVlYCB0aGUgcmVzcG9uc2UgdHlwZSBtdXN0IGFsc28gYmUgYFN0cmVhbTxUPmBcblxuICAgIGlmIChwcm9wcy5vcHRpb25zLl9fc3RyZWFtQ2xhc3MpIHtcbiAgICAgIHJldHVybiBwcm9wcy5vcHRpb25zLl9fc3RyZWFtQ2xhc3MuZnJvbVNTRVJlc3BvbnNlKHJlc3BvbnNlLCBwcm9wcy5jb250cm9sbGVyKSBhcyBhbnk7XG4gICAgfVxuXG4gICAgcmV0dXJuIFN0cmVhbS5mcm9tU1NFUmVzcG9uc2UocmVzcG9uc2UsIHByb3BzLmNvbnRyb2xsZXIpIGFzIGFueTtcbiAgfVxuXG4gIC8vIGZldGNoIHJlZnVzZXMgdG8gcmVhZCB0aGUgYm9keSB3aGVuIHRoZSBzdGF0dXMgY29kZSBpcyAyMDQuXG4gIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDIwNCkge1xuICAgIHJldHVybiBudWxsIGFzIFQ7XG4gIH1cblxuICBpZiAocHJvcHMub3B0aW9ucy5fX2JpbmFyeVJlc3BvbnNlKSB7XG4gICAgcmV0dXJuIHJlc3BvbnNlIGFzIHVua25vd24gYXMgVDtcbiAgfVxuXG4gIGNvbnN0IGNvbnRlbnRUeXBlID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoJ2NvbnRlbnQtdHlwZScpO1xuICBjb25zdCBpc0pTT04gPVxuICAgIGNvbnRlbnRUeXBlPy5pbmNsdWRlcygnYXBwbGljYXRpb24vanNvbicpIHx8IGNvbnRlbnRUeXBlPy5pbmNsdWRlcygnYXBwbGljYXRpb24vdm5kLmFwaStqc29uJyk7XG4gIGlmIChpc0pTT04pIHtcbiAgICBjb25zdCBqc29uID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuXG4gICAgZGVidWcoJ3Jlc3BvbnNlJywgcmVzcG9uc2Uuc3RhdHVzLCByZXNwb25zZS51cmwsIHJlc3BvbnNlLmhlYWRlcnMsIGpzb24pO1xuXG4gICAgcmV0dXJuIGpzb24gYXMgVDtcbiAgfVxuXG4gIGNvbnN0IHRleHQgPSBhd2FpdCByZXNwb25zZS50ZXh0KCk7XG4gIGRlYnVnKCdyZXNwb25zZScsIHJlc3BvbnNlLnN0YXR1cywgcmVzcG9uc2UudXJsLCByZXNwb25zZS5oZWFkZXJzLCB0ZXh0KTtcblxuICAvLyBUT0RPIGhhbmRsZSBibG9iLCBhcnJheWJ1ZmZlciwgb3RoZXIgY29udGVudCB0eXBlcywgZXRjLlxuICByZXR1cm4gdGV4dCBhcyB1bmtub3duIGFzIFQ7XG59XG5cbi8qKlxuICogQSBzdWJjbGFzcyBvZiBgUHJvbWlzZWAgcHJvdmlkaW5nIGFkZGl0aW9uYWwgaGVscGVyIG1ldGhvZHNcbiAqIGZvciBpbnRlcmFjdGluZyB3aXRoIHRoZSBTREsuXG4gKi9cbmV4cG9ydCBjbGFzcyBBUElQcm9taXNlPFQ+IGV4dGVuZHMgUHJvbWlzZTxUPiB7XG4gIHByaXZhdGUgcGFyc2VkUHJvbWlzZTogUHJvbWlzZTxUPiB8IHVuZGVmaW5lZDtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBwcml2YXRlIHJlc3BvbnNlUHJvbWlzZTogUHJvbWlzZTxBUElSZXNwb25zZVByb3BzPixcbiAgICBwcml2YXRlIHBhcnNlUmVzcG9uc2U6IChwcm9wczogQVBJUmVzcG9uc2VQcm9wcykgPT4gUHJvbWlzZU9yVmFsdWU8VD4gPSBkZWZhdWx0UGFyc2VSZXNwb25zZSxcbiAgKSB7XG4gICAgc3VwZXIoKHJlc29sdmUpID0+IHtcbiAgICAgIC8vIHRoaXMgaXMgbWF5YmUgYSBiaXQgd2VpcmQgYnV0IHRoaXMgaGFzIHRvIGJlIGEgbm8tb3AgdG8gbm90IGltcGxpY2l0bHlcbiAgICAgIC8vIHBhcnNlIHRoZSByZXNwb25zZSBib2R5OyBpbnN0ZWFkIC50aGVuLCAuY2F0Y2gsIC5maW5hbGx5IGFyZSBvdmVycmlkZGVuXG4gICAgICAvLyB0byBwYXJzZSB0aGUgcmVzcG9uc2VcbiAgICAgIHJlc29sdmUobnVsbCBhcyBhbnkpO1xuICAgIH0pO1xuICB9XG5cbiAgX3RoZW5VbndyYXA8VT4odHJhbnNmb3JtOiAoZGF0YTogVCkgPT4gVSk6IEFQSVByb21pc2U8VT4ge1xuICAgIHJldHVybiBuZXcgQVBJUHJvbWlzZSh0aGlzLnJlc3BvbnNlUHJvbWlzZSwgYXN5bmMgKHByb3BzKSA9PiB0cmFuc2Zvcm0oYXdhaXQgdGhpcy5wYXJzZVJlc3BvbnNlKHByb3BzKSkpO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldHMgdGhlIHJhdyBgUmVzcG9uc2VgIGluc3RhbmNlIGluc3RlYWQgb2YgcGFyc2luZyB0aGUgcmVzcG9uc2VcbiAgICogZGF0YS5cbiAgICpcbiAgICogSWYgeW91IHdhbnQgdG8gcGFyc2UgdGhlIHJlc3BvbnNlIGJvZHkgYnV0IHN0aWxsIGdldCB0aGUgYFJlc3BvbnNlYFxuICAgKiBpbnN0YW5jZSwgeW91IGNhbiB1c2Uge0BsaW5rIHdpdGhSZXNwb25zZSgpfS5cbiAgICpcbiAgICogXHVEODNEXHVEQzRCIEdldHRpbmcgdGhlIHdyb25nIFR5cGVTY3JpcHQgdHlwZSBmb3IgYFJlc3BvbnNlYD9cbiAgICogVHJ5IHNldHRpbmcgYFwibW9kdWxlUmVzb2x1dGlvblwiOiBcIk5vZGVOZXh0XCJgIGlmIHlvdSBjYW4sXG4gICAqIG9yIGFkZCBvbmUgb2YgdGhlc2UgaW1wb3J0cyBiZWZvcmUgeW91ciBmaXJzdCBgaW1wb3J0IFx1MjAyNiBmcm9tICdAYW50aHJvcGljLWFpL3NkaydgOlxuICAgKiAtIGBpbXBvcnQgJ0BhbnRocm9waWMtYWkvc2RrL3NoaW1zL25vZGUnYCAoaWYgeW91J3JlIHJ1bm5pbmcgb24gTm9kZSlcbiAgICogLSBgaW1wb3J0ICdAYW50aHJvcGljLWFpL3Nkay9zaGltcy93ZWInYCAob3RoZXJ3aXNlKVxuICAgKi9cbiAgYXNSZXNwb25zZSgpOiBQcm9taXNlPFJlc3BvbnNlPiB7XG4gICAgcmV0dXJuIHRoaXMucmVzcG9uc2VQcm9taXNlLnRoZW4oKHApID0+IHAucmVzcG9uc2UpO1xuICB9XG4gIC8qKlxuICAgKiBHZXRzIHRoZSBwYXJzZWQgcmVzcG9uc2UgZGF0YSBhbmQgdGhlIHJhdyBgUmVzcG9uc2VgIGluc3RhbmNlLlxuICAgKlxuICAgKiBJZiB5b3UganVzdCB3YW50IHRvIGdldCB0aGUgcmF3IGBSZXNwb25zZWAgaW5zdGFuY2Ugd2l0aG91dCBwYXJzaW5nIGl0LFxuICAgKiB5b3UgY2FuIHVzZSB7QGxpbmsgYXNSZXNwb25zZSgpfS5cbiAgICpcbiAgICpcbiAgICogXHVEODNEXHVEQzRCIEdldHRpbmcgdGhlIHdyb25nIFR5cGVTY3JpcHQgdHlwZSBmb3IgYFJlc3BvbnNlYD9cbiAgICogVHJ5IHNldHRpbmcgYFwibW9kdWxlUmVzb2x1dGlvblwiOiBcIk5vZGVOZXh0XCJgIGlmIHlvdSBjYW4sXG4gICAqIG9yIGFkZCBvbmUgb2YgdGhlc2UgaW1wb3J0cyBiZWZvcmUgeW91ciBmaXJzdCBgaW1wb3J0IFx1MjAyNiBmcm9tICdAYW50aHJvcGljLWFpL3NkaydgOlxuICAgKiAtIGBpbXBvcnQgJ0BhbnRocm9waWMtYWkvc2RrL3NoaW1zL25vZGUnYCAoaWYgeW91J3JlIHJ1bm5pbmcgb24gTm9kZSlcbiAgICogLSBgaW1wb3J0ICdAYW50aHJvcGljLWFpL3Nkay9zaGltcy93ZWInYCAob3RoZXJ3aXNlKVxuICAgKi9cbiAgYXN5bmMgd2l0aFJlc3BvbnNlKCk6IFByb21pc2U8eyBkYXRhOiBUOyByZXNwb25zZTogUmVzcG9uc2UgfT4ge1xuICAgIGNvbnN0IFtkYXRhLCByZXNwb25zZV0gPSBhd2FpdCBQcm9taXNlLmFsbChbdGhpcy5wYXJzZSgpLCB0aGlzLmFzUmVzcG9uc2UoKV0pO1xuICAgIHJldHVybiB7IGRhdGEsIHJlc3BvbnNlIH07XG4gIH1cblxuICBwcml2YXRlIHBhcnNlKCk6IFByb21pc2U8VD4ge1xuICAgIGlmICghdGhpcy5wYXJzZWRQcm9taXNlKSB7XG4gICAgICB0aGlzLnBhcnNlZFByb21pc2UgPSB0aGlzLnJlc3BvbnNlUHJvbWlzZS50aGVuKHRoaXMucGFyc2VSZXNwb25zZSk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnBhcnNlZFByb21pc2U7XG4gIH1cblxuICBvdmVycmlkZSB0aGVuPFRSZXN1bHQxID0gVCwgVFJlc3VsdDIgPSBuZXZlcj4oXG4gICAgb25mdWxmaWxsZWQ/OiAoKHZhbHVlOiBUKSA9PiBUUmVzdWx0MSB8IFByb21pc2VMaWtlPFRSZXN1bHQxPikgfCB1bmRlZmluZWQgfCBudWxsLFxuICAgIG9ucmVqZWN0ZWQ/OiAoKHJlYXNvbjogYW55KSA9PiBUUmVzdWx0MiB8IFByb21pc2VMaWtlPFRSZXN1bHQyPikgfCB1bmRlZmluZWQgfCBudWxsLFxuICApOiBQcm9taXNlPFRSZXN1bHQxIHwgVFJlc3VsdDI+IHtcbiAgICByZXR1cm4gdGhpcy5wYXJzZSgpLnRoZW4ob25mdWxmaWxsZWQsIG9ucmVqZWN0ZWQpO1xuICB9XG5cbiAgb3ZlcnJpZGUgY2F0Y2g8VFJlc3VsdCA9IG5ldmVyPihcbiAgICBvbnJlamVjdGVkPzogKChyZWFzb246IGFueSkgPT4gVFJlc3VsdCB8IFByb21pc2VMaWtlPFRSZXN1bHQ+KSB8IHVuZGVmaW5lZCB8IG51bGwsXG4gICk6IFByb21pc2U8VCB8IFRSZXN1bHQ+IHtcbiAgICByZXR1cm4gdGhpcy5wYXJzZSgpLmNhdGNoKG9ucmVqZWN0ZWQpO1xuICB9XG5cbiAgb3ZlcnJpZGUgZmluYWxseShvbmZpbmFsbHk/OiAoKCkgPT4gdm9pZCkgfCB1bmRlZmluZWQgfCBudWxsKTogUHJvbWlzZTxUPiB7XG4gICAgcmV0dXJuIHRoaXMucGFyc2UoKS5maW5hbGx5KG9uZmluYWxseSk7XG4gIH1cbn1cblxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIEFQSUNsaWVudCB7XG4gIGJhc2VVUkw6IHN0cmluZztcbiAgbWF4UmV0cmllczogbnVtYmVyO1xuICB0aW1lb3V0OiBudW1iZXI7XG4gIGh0dHBBZ2VudDogQWdlbnQgfCB1bmRlZmluZWQ7XG5cbiAgcHJpdmF0ZSBmZXRjaDogRmV0Y2g7XG4gIHByb3RlY3RlZCBpZGVtcG90ZW5jeUhlYWRlcj86IHN0cmluZztcblxuICBjb25zdHJ1Y3Rvcih7XG4gICAgYmFzZVVSTCxcbiAgICBtYXhSZXRyaWVzID0gMixcbiAgICB0aW1lb3V0ID0gNjAwMDAwLCAvLyAxMCBtaW51dGVzXG4gICAgaHR0cEFnZW50LFxuICAgIGZldGNoOiBvdmVycmlkZW5GZXRjaCxcbiAgfToge1xuICAgIGJhc2VVUkw6IHN0cmluZztcbiAgICBtYXhSZXRyaWVzPzogbnVtYmVyIHwgdW5kZWZpbmVkO1xuICAgIHRpbWVvdXQ6IG51bWJlciB8IHVuZGVmaW5lZDtcbiAgICBodHRwQWdlbnQ6IEFnZW50IHwgdW5kZWZpbmVkO1xuICAgIGZldGNoOiBGZXRjaCB8IHVuZGVmaW5lZDtcbiAgfSkge1xuICAgIHRoaXMuYmFzZVVSTCA9IGJhc2VVUkw7XG4gICAgdGhpcy5tYXhSZXRyaWVzID0gdmFsaWRhdGVQb3NpdGl2ZUludGVnZXIoJ21heFJldHJpZXMnLCBtYXhSZXRyaWVzKTtcbiAgICB0aGlzLnRpbWVvdXQgPSB2YWxpZGF0ZVBvc2l0aXZlSW50ZWdlcigndGltZW91dCcsIHRpbWVvdXQpO1xuICAgIHRoaXMuaHR0cEFnZW50ID0gaHR0cEFnZW50O1xuXG4gICAgdGhpcy5mZXRjaCA9IG92ZXJyaWRlbkZldGNoID8/IGZldGNoO1xuICB9XG5cbiAgcHJvdGVjdGVkIGF1dGhIZWFkZXJzKG9wdHM6IEZpbmFsUmVxdWVzdE9wdGlvbnMpOiBIZWFkZXJzIHtcbiAgICByZXR1cm4ge307XG4gIH1cblxuICAvKipcbiAgICogT3ZlcnJpZGUgdGhpcyB0byBhZGQgeW91ciBvd24gZGVmYXVsdCBoZWFkZXJzLCBmb3IgZXhhbXBsZTpcbiAgICpcbiAgICogIHtcbiAgICogICAgLi4uc3VwZXIuZGVmYXVsdEhlYWRlcnMoKSxcbiAgICogICAgQXV0aG9yaXphdGlvbjogJ0JlYXJlciAxMjMnLFxuICAgKiAgfVxuICAgKi9cbiAgcHJvdGVjdGVkIGRlZmF1bHRIZWFkZXJzKG9wdHM6IEZpbmFsUmVxdWVzdE9wdGlvbnMpOiBIZWFkZXJzIHtcbiAgICByZXR1cm4ge1xuICAgICAgQWNjZXB0OiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgJ1VzZXItQWdlbnQnOiB0aGlzLmdldFVzZXJBZ2VudCgpLFxuICAgICAgLi4uZ2V0UGxhdGZvcm1IZWFkZXJzKCksXG4gICAgICAuLi50aGlzLmF1dGhIZWFkZXJzKG9wdHMpLFxuICAgIH07XG4gIH1cblxuICBwcm90ZWN0ZWQgYWJzdHJhY3QgZGVmYXVsdFF1ZXJ5KCk6IERlZmF1bHRRdWVyeSB8IHVuZGVmaW5lZDtcblxuICAvKipcbiAgICogT3ZlcnJpZGUgdGhpcyB0byBhZGQgeW91ciBvd24gaGVhZGVycyB2YWxpZGF0aW9uOlxuICAgKi9cbiAgcHJvdGVjdGVkIHZhbGlkYXRlSGVhZGVycyhoZWFkZXJzOiBIZWFkZXJzLCBjdXN0b21IZWFkZXJzOiBIZWFkZXJzKSB7fVxuXG4gIHByb3RlY3RlZCBkZWZhdWx0SWRlbXBvdGVuY3lLZXkoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYHN0YWlubGVzcy1ub2RlLXJldHJ5LSR7dXVpZDQoKX1gO1xuICB9XG5cbiAgZ2V0PFJlcSwgUnNwPihwYXRoOiBzdHJpbmcsIG9wdHM/OiBQcm9taXNlT3JWYWx1ZTxSZXF1ZXN0T3B0aW9uczxSZXE+Pik6IEFQSVByb21pc2U8UnNwPiB7XG4gICAgcmV0dXJuIHRoaXMubWV0aG9kUmVxdWVzdCgnZ2V0JywgcGF0aCwgb3B0cyk7XG4gIH1cblxuICBwb3N0PFJlcSwgUnNwPihwYXRoOiBzdHJpbmcsIG9wdHM/OiBQcm9taXNlT3JWYWx1ZTxSZXF1ZXN0T3B0aW9uczxSZXE+Pik6IEFQSVByb21pc2U8UnNwPiB7XG4gICAgcmV0dXJuIHRoaXMubWV0aG9kUmVxdWVzdCgncG9zdCcsIHBhdGgsIG9wdHMpO1xuICB9XG5cbiAgcGF0Y2g8UmVxLCBSc3A+KHBhdGg6IHN0cmluZywgb3B0cz86IFByb21pc2VPclZhbHVlPFJlcXVlc3RPcHRpb25zPFJlcT4+KTogQVBJUHJvbWlzZTxSc3A+IHtcbiAgICByZXR1cm4gdGhpcy5tZXRob2RSZXF1ZXN0KCdwYXRjaCcsIHBhdGgsIG9wdHMpO1xuICB9XG5cbiAgcHV0PFJlcSwgUnNwPihwYXRoOiBzdHJpbmcsIG9wdHM/OiBQcm9taXNlT3JWYWx1ZTxSZXF1ZXN0T3B0aW9uczxSZXE+Pik6IEFQSVByb21pc2U8UnNwPiB7XG4gICAgcmV0dXJuIHRoaXMubWV0aG9kUmVxdWVzdCgncHV0JywgcGF0aCwgb3B0cyk7XG4gIH1cblxuICBkZWxldGU8UmVxLCBSc3A+KHBhdGg6IHN0cmluZywgb3B0cz86IFByb21pc2VPclZhbHVlPFJlcXVlc3RPcHRpb25zPFJlcT4+KTogQVBJUHJvbWlzZTxSc3A+IHtcbiAgICByZXR1cm4gdGhpcy5tZXRob2RSZXF1ZXN0KCdkZWxldGUnLCBwYXRoLCBvcHRzKTtcbiAgfVxuXG4gIHByaXZhdGUgbWV0aG9kUmVxdWVzdDxSZXEsIFJzcD4oXG4gICAgbWV0aG9kOiBIVFRQTWV0aG9kLFxuICAgIHBhdGg6IHN0cmluZyxcbiAgICBvcHRzPzogUHJvbWlzZU9yVmFsdWU8UmVxdWVzdE9wdGlvbnM8UmVxPj4sXG4gICk6IEFQSVByb21pc2U8UnNwPiB7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdChcbiAgICAgIFByb21pc2UucmVzb2x2ZShvcHRzKS50aGVuKGFzeW5jIChvcHRzKSA9PiB7XG4gICAgICAgIGNvbnN0IGJvZHkgPVxuICAgICAgICAgIG9wdHMgJiYgaXNCbG9iTGlrZShvcHRzPy5ib2R5KSA/IG5ldyBEYXRhVmlldyhhd2FpdCBvcHRzLmJvZHkuYXJyYXlCdWZmZXIoKSlcbiAgICAgICAgICA6IG9wdHM/LmJvZHkgaW5zdGFuY2VvZiBEYXRhVmlldyA/IG9wdHMuYm9keVxuICAgICAgICAgIDogb3B0cz8uYm9keSBpbnN0YW5jZW9mIEFycmF5QnVmZmVyID8gbmV3IERhdGFWaWV3KG9wdHMuYm9keSlcbiAgICAgICAgICA6IG9wdHMgJiYgQXJyYXlCdWZmZXIuaXNWaWV3KG9wdHM/LmJvZHkpID8gbmV3IERhdGFWaWV3KG9wdHMuYm9keS5idWZmZXIpXG4gICAgICAgICAgOiBvcHRzPy5ib2R5O1xuICAgICAgICByZXR1cm4geyBtZXRob2QsIHBhdGgsIC4uLm9wdHMsIGJvZHkgfTtcbiAgICAgIH0pLFxuICAgICk7XG4gIH1cblxuICBnZXRBUElMaXN0PEl0ZW0sIFBhZ2VDbGFzcyBleHRlbmRzIEFic3RyYWN0UGFnZTxJdGVtPiA9IEFic3RyYWN0UGFnZTxJdGVtPj4oXG4gICAgcGF0aDogc3RyaW5nLFxuICAgIFBhZ2U6IG5ldyAoLi4uYXJnczogYW55W10pID0+IFBhZ2VDbGFzcyxcbiAgICBvcHRzPzogUmVxdWVzdE9wdGlvbnM8YW55PixcbiAgKTogUGFnZVByb21pc2U8UGFnZUNsYXNzLCBJdGVtPiB7XG4gICAgcmV0dXJuIHRoaXMucmVxdWVzdEFQSUxpc3QoUGFnZSwgeyBtZXRob2Q6ICdnZXQnLCBwYXRoLCAuLi5vcHRzIH0pO1xuICB9XG5cbiAgcHJpdmF0ZSBjYWxjdWxhdGVDb250ZW50TGVuZ3RoKGJvZHk6IHVua25vd24pOiBzdHJpbmcgfCBudWxsIHtcbiAgICBpZiAodHlwZW9mIGJvZHkgPT09ICdzdHJpbmcnKSB7XG4gICAgICBpZiAodHlwZW9mIEJ1ZmZlciAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgcmV0dXJuIEJ1ZmZlci5ieXRlTGVuZ3RoKGJvZHksICd1dGY4JykudG9TdHJpbmcoKTtcbiAgICAgIH1cblxuICAgICAgaWYgKHR5cGVvZiBUZXh0RW5jb2RlciAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgY29uc3QgZW5jb2RlciA9IG5ldyBUZXh0RW5jb2RlcigpO1xuICAgICAgICBjb25zdCBlbmNvZGVkID0gZW5jb2Rlci5lbmNvZGUoYm9keSk7XG4gICAgICAgIHJldHVybiBlbmNvZGVkLmxlbmd0aC50b1N0cmluZygpO1xuICAgICAgfVxuICAgIH0gZWxzZSBpZiAoQXJyYXlCdWZmZXIuaXNWaWV3KGJvZHkpKSB7XG4gICAgICByZXR1cm4gYm9keS5ieXRlTGVuZ3RoLnRvU3RyaW5nKCk7XG4gICAgfVxuXG4gICAgcmV0dXJuIG51bGw7XG4gIH1cblxuICBidWlsZFJlcXVlc3Q8UmVxPihcbiAgICBvcHRpb25zOiBGaW5hbFJlcXVlc3RPcHRpb25zPFJlcT4sXG4gICAgeyByZXRyeUNvdW50ID0gMCB9OiB7IHJldHJ5Q291bnQ/OiBudW1iZXIgfSA9IHt9LFxuICApOiB7IHJlcTogUmVxdWVzdEluaXQ7IHVybDogc3RyaW5nOyB0aW1lb3V0OiBudW1iZXIgfSB7XG4gICAgY29uc3QgeyBtZXRob2QsIHBhdGgsIHF1ZXJ5LCBoZWFkZXJzOiBoZWFkZXJzID0ge30gfSA9IG9wdGlvbnM7XG5cbiAgICBjb25zdCBib2R5ID1cbiAgICAgIEFycmF5QnVmZmVyLmlzVmlldyhvcHRpb25zLmJvZHkpIHx8IChvcHRpb25zLl9fYmluYXJ5UmVxdWVzdCAmJiB0eXBlb2Ygb3B0aW9ucy5ib2R5ID09PSAnc3RyaW5nJykgP1xuICAgICAgICBvcHRpb25zLmJvZHlcbiAgICAgIDogaXNNdWx0aXBhcnRCb2R5KG9wdGlvbnMuYm9keSkgPyBvcHRpb25zLmJvZHkuYm9keVxuICAgICAgOiBvcHRpb25zLmJvZHkgPyBKU09OLnN0cmluZ2lmeShvcHRpb25zLmJvZHksIG51bGwsIDIpXG4gICAgICA6IG51bGw7XG4gICAgY29uc3QgY29udGVudExlbmd0aCA9IHRoaXMuY2FsY3VsYXRlQ29udGVudExlbmd0aChib2R5KTtcblxuICAgIGNvbnN0IHVybCA9IHRoaXMuYnVpbGRVUkwocGF0aCEsIHF1ZXJ5KTtcbiAgICBpZiAoJ3RpbWVvdXQnIGluIG9wdGlvbnMpIHZhbGlkYXRlUG9zaXRpdmVJbnRlZ2VyKCd0aW1lb3V0Jywgb3B0aW9ucy50aW1lb3V0KTtcbiAgICBjb25zdCB0aW1lb3V0ID0gb3B0aW9ucy50aW1lb3V0ID8/IHRoaXMudGltZW91dDtcbiAgICBjb25zdCBodHRwQWdlbnQgPSBvcHRpb25zLmh0dHBBZ2VudCA/PyB0aGlzLmh0dHBBZ2VudCA/PyBnZXREZWZhdWx0QWdlbnQodXJsKTtcbiAgICBjb25zdCBtaW5BZ2VudFRpbWVvdXQgPSB0aW1lb3V0ICsgMTAwMDtcbiAgICBpZiAoXG4gICAgICB0eXBlb2YgKGh0dHBBZ2VudCBhcyBhbnkpPy5vcHRpb25zPy50aW1lb3V0ID09PSAnbnVtYmVyJyAmJlxuICAgICAgbWluQWdlbnRUaW1lb3V0ID4gKChodHRwQWdlbnQgYXMgYW55KS5vcHRpb25zLnRpbWVvdXQgPz8gMClcbiAgICApIHtcbiAgICAgIC8vIEFsbG93IGFueSBnaXZlbiByZXF1ZXN0IHRvIGJ1bXAgb3VyIGFnZW50IGFjdGl2ZSBzb2NrZXQgdGltZW91dC5cbiAgICAgIC8vIFRoaXMgbWF5IHNlZW0gc3RyYW5nZSwgYnV0IGxlYWtpbmcgYWN0aXZlIHNvY2tldHMgc2hvdWxkIGJlIHJhcmUgYW5kIG5vdCBwYXJ0aWN1bGFybHkgcHJvYmxlbWF0aWMsXG4gICAgICAvLyBhbmQgd2l0aG91dCBtdXRhdGluZyBhZ2VudCB3ZSB3b3VsZCBuZWVkIHRvIGNyZWF0ZSBtb3JlIG9mIHRoZW0uXG4gICAgICAvLyBUaGlzIHRyYWRlb2ZmIG9wdGltaXplcyBmb3IgcGVyZm9ybWFuY2UuXG4gICAgICAoaHR0cEFnZW50IGFzIGFueSkub3B0aW9ucy50aW1lb3V0ID0gbWluQWdlbnRUaW1lb3V0O1xuICAgIH1cblxuICAgIGlmICh0aGlzLmlkZW1wb3RlbmN5SGVhZGVyICYmIG1ldGhvZCAhPT0gJ2dldCcpIHtcbiAgICAgIGlmICghb3B0aW9ucy5pZGVtcG90ZW5jeUtleSkgb3B0aW9ucy5pZGVtcG90ZW5jeUtleSA9IHRoaXMuZGVmYXVsdElkZW1wb3RlbmN5S2V5KCk7XG4gICAgICBoZWFkZXJzW3RoaXMuaWRlbXBvdGVuY3lIZWFkZXJdID0gb3B0aW9ucy5pZGVtcG90ZW5jeUtleTtcbiAgICB9XG5cbiAgICBjb25zdCByZXFIZWFkZXJzID0gdGhpcy5idWlsZEhlYWRlcnMoeyBvcHRpb25zLCBoZWFkZXJzLCBjb250ZW50TGVuZ3RoLCByZXRyeUNvdW50IH0pO1xuXG4gICAgY29uc3QgcmVxOiBSZXF1ZXN0SW5pdCA9IHtcbiAgICAgIG1ldGhvZCxcbiAgICAgIC4uLihib2R5ICYmIHsgYm9keTogYm9keSBhcyBhbnkgfSksXG4gICAgICBoZWFkZXJzOiByZXFIZWFkZXJzLFxuICAgICAgLi4uKGh0dHBBZ2VudCAmJiB7IGFnZW50OiBodHRwQWdlbnQgfSksXG4gICAgICAvLyBAdHMtaWdub3JlIG5vZGUtZmV0Y2ggdXNlcyBhIGN1c3RvbSBBYm9ydFNpZ25hbCB0eXBlIHRoYXQgaXNcbiAgICAgIC8vIG5vdCBjb21wYXRpYmxlIHdpdGggc3RhbmRhcmQgd2ViIHR5cGVzXG4gICAgICBzaWduYWw6IG9wdGlvbnMuc2lnbmFsID8/IG51bGwsXG4gICAgfTtcblxuICAgIHJldHVybiB7IHJlcSwgdXJsLCB0aW1lb3V0IH07XG4gIH1cblxuICBwcml2YXRlIGJ1aWxkSGVhZGVycyh7XG4gICAgb3B0aW9ucyxcbiAgICBoZWFkZXJzLFxuICAgIGNvbnRlbnRMZW5ndGgsXG4gICAgcmV0cnlDb3VudCxcbiAgfToge1xuICAgIG9wdGlvbnM6IEZpbmFsUmVxdWVzdE9wdGlvbnM7XG4gICAgaGVhZGVyczogUmVjb3JkPHN0cmluZywgc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZD47XG4gICAgY29udGVudExlbmd0aDogc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZDtcbiAgICByZXRyeUNvdW50OiBudW1iZXI7XG4gIH0pOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+IHtcbiAgICBjb25zdCByZXFIZWFkZXJzOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0ge307XG4gICAgaWYgKGNvbnRlbnRMZW5ndGgpIHtcbiAgICAgIHJlcUhlYWRlcnNbJ2NvbnRlbnQtbGVuZ3RoJ10gPSBjb250ZW50TGVuZ3RoO1xuICAgIH1cblxuICAgIGNvbnN0IGRlZmF1bHRIZWFkZXJzID0gdGhpcy5kZWZhdWx0SGVhZGVycyhvcHRpb25zKTtcbiAgICBhcHBseUhlYWRlcnNNdXQocmVxSGVhZGVycywgZGVmYXVsdEhlYWRlcnMpO1xuICAgIGFwcGx5SGVhZGVyc011dChyZXFIZWFkZXJzLCBoZWFkZXJzKTtcblxuICAgIC8vIGxldCBidWlsdGluIGZldGNoIHNldCB0aGUgQ29udGVudC1UeXBlIGZvciBtdWx0aXBhcnQgYm9kaWVzXG4gICAgaWYgKGlzTXVsdGlwYXJ0Qm9keShvcHRpb25zLmJvZHkpICYmIHNoaW1zS2luZCAhPT0gJ25vZGUnKSB7XG4gICAgICBkZWxldGUgcmVxSGVhZGVyc1snY29udGVudC10eXBlJ107XG4gICAgfVxuXG4gICAgLy8gRG9uJ3Qgc2V0IHRoZSByZXRyeSBjb3VudCBoZWFkZXIgaWYgaXQgd2FzIGFscmVhZHkgc2V0IG9yIHJlbW92ZWQgYnkgdGhlIGNhbGxlci4gV2UgY2hlY2sgYGhlYWRlcnNgLFxuICAgIC8vIHdoaWNoIGNhbiBjb250YWluIG51bGxzLCBpbnN0ZWFkIG9mIGByZXFIZWFkZXJzYCB0byBhY2NvdW50IGZvciB0aGUgcmVtb3ZhbCBjYXNlLlxuICAgIGlmIChnZXRIZWFkZXIoaGVhZGVycywgJ3gtc3RhaW5sZXNzLXJldHJ5LWNvdW50JykgPT09IHVuZGVmaW5lZCkge1xuICAgICAgcmVxSGVhZGVyc1sneC1zdGFpbmxlc3MtcmV0cnktY291bnQnXSA9IFN0cmluZyhyZXRyeUNvdW50KTtcbiAgICB9XG5cbiAgICB0aGlzLnZhbGlkYXRlSGVhZGVycyhyZXFIZWFkZXJzLCBoZWFkZXJzKTtcblxuICAgIHJldHVybiByZXFIZWFkZXJzO1xuICB9XG5cbiAgLyoqXG4gICAqIFVzZWQgYXMgYSBjYWxsYmFjayBmb3IgbXV0YXRpbmcgdGhlIGdpdmVuIGBGaW5hbFJlcXVlc3RPcHRpb25zYCBvYmplY3QuXG4gICAqL1xuICBwcm90ZWN0ZWQgYXN5bmMgcHJlcGFyZU9wdGlvbnMob3B0aW9uczogRmluYWxSZXF1ZXN0T3B0aW9ucyk6IFByb21pc2U8dm9pZD4ge31cblxuICAvKipcbiAgICogVXNlZCBhcyBhIGNhbGxiYWNrIGZvciBtdXRhdGluZyB0aGUgZ2l2ZW4gYFJlcXVlc3RJbml0YCBvYmplY3QuXG4gICAqXG4gICAqIFRoaXMgaXMgdXNlZnVsIGZvciBjYXNlcyB3aGVyZSB5b3Ugd2FudCB0byBhZGQgY2VydGFpbiBoZWFkZXJzIGJhc2VkIG9mZiBvZlxuICAgKiB0aGUgcmVxdWVzdCBwcm9wZXJ0aWVzLCBlLmcuIGBtZXRob2RgIG9yIGB1cmxgLlxuICAgKi9cbiAgcHJvdGVjdGVkIGFzeW5jIHByZXBhcmVSZXF1ZXN0KFxuICAgIHJlcXVlc3Q6IFJlcXVlc3RJbml0LFxuICAgIHsgdXJsLCBvcHRpb25zIH06IHsgdXJsOiBzdHJpbmc7IG9wdGlvbnM6IEZpbmFsUmVxdWVzdE9wdGlvbnMgfSxcbiAgKTogUHJvbWlzZTx2b2lkPiB7fVxuXG4gIHByb3RlY3RlZCBwYXJzZUhlYWRlcnMoaGVhZGVyczogSGVhZGVyc0luaXQgfCBudWxsIHwgdW5kZWZpbmVkKTogUmVjb3JkPHN0cmluZywgc3RyaW5nPiB7XG4gICAgcmV0dXJuIChcbiAgICAgICFoZWFkZXJzID8ge31cbiAgICAgIDogU3ltYm9sLml0ZXJhdG9yIGluIGhlYWRlcnMgP1xuICAgICAgICBPYmplY3QuZnJvbUVudHJpZXMoQXJyYXkuZnJvbShoZWFkZXJzIGFzIEl0ZXJhYmxlPHN0cmluZ1tdPikubWFwKChoZWFkZXIpID0+IFsuLi5oZWFkZXJdKSlcbiAgICAgIDogeyAuLi5oZWFkZXJzIH1cbiAgICApO1xuICB9XG5cbiAgcHJvdGVjdGVkIG1ha2VTdGF0dXNFcnJvcihcbiAgICBzdGF0dXM6IG51bWJlciB8IHVuZGVmaW5lZCxcbiAgICBlcnJvcjogT2JqZWN0IHwgdW5kZWZpbmVkLFxuICAgIG1lc3NhZ2U6IHN0cmluZyB8IHVuZGVmaW5lZCxcbiAgICBoZWFkZXJzOiBIZWFkZXJzIHwgdW5kZWZpbmVkLFxuICApIHtcbiAgICByZXR1cm4gQVBJRXJyb3IuZ2VuZXJhdGUoc3RhdHVzLCBlcnJvciwgbWVzc2FnZSwgaGVhZGVycyk7XG4gIH1cblxuICByZXF1ZXN0PFJlcSwgUnNwPihcbiAgICBvcHRpb25zOiBQcm9taXNlT3JWYWx1ZTxGaW5hbFJlcXVlc3RPcHRpb25zPFJlcT4+LFxuICAgIHJlbWFpbmluZ1JldHJpZXM6IG51bWJlciB8IG51bGwgPSBudWxsLFxuICApOiBBUElQcm9taXNlPFJzcD4ge1xuICAgIHJldHVybiBuZXcgQVBJUHJvbWlzZSh0aGlzLm1ha2VSZXF1ZXN0KG9wdGlvbnMsIHJlbWFpbmluZ1JldHJpZXMpKTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgbWFrZVJlcXVlc3Q8UmVxPihcbiAgICBvcHRpb25zSW5wdXQ6IFByb21pc2VPclZhbHVlPEZpbmFsUmVxdWVzdE9wdGlvbnM8UmVxPj4sXG4gICAgcmV0cmllc1JlbWFpbmluZzogbnVtYmVyIHwgbnVsbCxcbiAgKTogUHJvbWlzZTxBUElSZXNwb25zZVByb3BzPiB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IGF3YWl0IG9wdGlvbnNJbnB1dDtcbiAgICBjb25zdCBtYXhSZXRyaWVzID0gb3B0aW9ucy5tYXhSZXRyaWVzID8/IHRoaXMubWF4UmV0cmllcztcbiAgICBpZiAocmV0cmllc1JlbWFpbmluZyA9PSBudWxsKSB7XG4gICAgICByZXRyaWVzUmVtYWluaW5nID0gbWF4UmV0cmllcztcbiAgICB9XG5cbiAgICBhd2FpdCB0aGlzLnByZXBhcmVPcHRpb25zKG9wdGlvbnMpO1xuXG4gICAgY29uc3QgeyByZXEsIHVybCwgdGltZW91dCB9ID0gdGhpcy5idWlsZFJlcXVlc3Qob3B0aW9ucywgeyByZXRyeUNvdW50OiBtYXhSZXRyaWVzIC0gcmV0cmllc1JlbWFpbmluZyB9KTtcblxuICAgIGF3YWl0IHRoaXMucHJlcGFyZVJlcXVlc3QocmVxLCB7IHVybCwgb3B0aW9ucyB9KTtcblxuICAgIGRlYnVnKCdyZXF1ZXN0JywgdXJsLCBvcHRpb25zLCByZXEuaGVhZGVycyk7XG5cbiAgICBpZiAob3B0aW9ucy5zaWduYWw/LmFib3J0ZWQpIHtcbiAgICAgIHRocm93IG5ldyBBUElVc2VyQWJvcnRFcnJvcigpO1xuICAgIH1cblxuICAgIGNvbnN0IGNvbnRyb2xsZXIgPSBuZXcgQWJvcnRDb250cm9sbGVyKCk7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLmZldGNoV2l0aFRpbWVvdXQodXJsLCByZXEsIHRpbWVvdXQsIGNvbnRyb2xsZXIpLmNhdGNoKGNhc3RUb0Vycm9yKTtcblxuICAgIGlmIChyZXNwb25zZSBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICBpZiAob3B0aW9ucy5zaWduYWw/LmFib3J0ZWQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEFQSVVzZXJBYm9ydEVycm9yKCk7XG4gICAgICB9XG4gICAgICBpZiAocmV0cmllc1JlbWFpbmluZykge1xuICAgICAgICByZXR1cm4gdGhpcy5yZXRyeVJlcXVlc3Qob3B0aW9ucywgcmV0cmllc1JlbWFpbmluZyk7XG4gICAgICB9XG4gICAgICBpZiAocmVzcG9uc2UubmFtZSA9PT0gJ0Fib3J0RXJyb3InKSB7XG4gICAgICAgIHRocm93IG5ldyBBUElDb25uZWN0aW9uVGltZW91dEVycm9yKCk7XG4gICAgICB9XG4gICAgICB0aHJvdyBuZXcgQVBJQ29ubmVjdGlvbkVycm9yKHsgY2F1c2U6IHJlc3BvbnNlIH0pO1xuICAgIH1cblxuICAgIGNvbnN0IHJlc3BvbnNlSGVhZGVycyA9IGNyZWF0ZVJlc3BvbnNlSGVhZGVycyhyZXNwb25zZS5oZWFkZXJzKTtcblxuICAgIGlmICghcmVzcG9uc2Uub2spIHtcbiAgICAgIGlmIChyZXRyaWVzUmVtYWluaW5nICYmIHRoaXMuc2hvdWxkUmV0cnkocmVzcG9uc2UpKSB7XG4gICAgICAgIGNvbnN0IHJldHJ5TWVzc2FnZSA9IGByZXRyeWluZywgJHtyZXRyaWVzUmVtYWluaW5nfSBhdHRlbXB0cyByZW1haW5pbmdgO1xuICAgICAgICBkZWJ1ZyhgcmVzcG9uc2UgKGVycm9yOyAke3JldHJ5TWVzc2FnZX0pYCwgcmVzcG9uc2Uuc3RhdHVzLCB1cmwsIHJlc3BvbnNlSGVhZGVycyk7XG4gICAgICAgIHJldHVybiB0aGlzLnJldHJ5UmVxdWVzdChvcHRpb25zLCByZXRyaWVzUmVtYWluaW5nLCByZXNwb25zZUhlYWRlcnMpO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBlcnJUZXh0ID0gYXdhaXQgcmVzcG9uc2UudGV4dCgpLmNhdGNoKChlKSA9PiBjYXN0VG9FcnJvcihlKS5tZXNzYWdlKTtcbiAgICAgIGNvbnN0IGVyckpTT04gPSBzYWZlSlNPTihlcnJUZXh0KTtcbiAgICAgIGNvbnN0IGVyck1lc3NhZ2UgPSBlcnJKU09OID8gdW5kZWZpbmVkIDogZXJyVGV4dDtcbiAgICAgIGNvbnN0IHJldHJ5TWVzc2FnZSA9IHJldHJpZXNSZW1haW5pbmcgPyBgKGVycm9yOyBubyBtb3JlIHJldHJpZXMgbGVmdClgIDogYChlcnJvcjsgbm90IHJldHJ5YWJsZSlgO1xuXG4gICAgICBkZWJ1ZyhgcmVzcG9uc2UgKGVycm9yOyAke3JldHJ5TWVzc2FnZX0pYCwgcmVzcG9uc2Uuc3RhdHVzLCB1cmwsIHJlc3BvbnNlSGVhZGVycywgZXJyTWVzc2FnZSk7XG5cbiAgICAgIGNvbnN0IGVyciA9IHRoaXMubWFrZVN0YXR1c0Vycm9yKHJlc3BvbnNlLnN0YXR1cywgZXJySlNPTiwgZXJyTWVzc2FnZSwgcmVzcG9uc2VIZWFkZXJzKTtcbiAgICAgIHRocm93IGVycjtcbiAgICB9XG5cbiAgICByZXR1cm4geyByZXNwb25zZSwgb3B0aW9ucywgY29udHJvbGxlciB9O1xuICB9XG5cbiAgcmVxdWVzdEFQSUxpc3Q8SXRlbSA9IHVua25vd24sIFBhZ2VDbGFzcyBleHRlbmRzIEFic3RyYWN0UGFnZTxJdGVtPiA9IEFic3RyYWN0UGFnZTxJdGVtPj4oXG4gICAgUGFnZTogbmV3ICguLi5hcmdzOiBDb25zdHJ1Y3RvclBhcmFtZXRlcnM8dHlwZW9mIEFic3RyYWN0UGFnZT4pID0+IFBhZ2VDbGFzcyxcbiAgICBvcHRpb25zOiBGaW5hbFJlcXVlc3RPcHRpb25zLFxuICApOiBQYWdlUHJvbWlzZTxQYWdlQ2xhc3MsIEl0ZW0+IHtcbiAgICBjb25zdCByZXF1ZXN0ID0gdGhpcy5tYWtlUmVxdWVzdChvcHRpb25zLCBudWxsKTtcbiAgICByZXR1cm4gbmV3IFBhZ2VQcm9taXNlPFBhZ2VDbGFzcywgSXRlbT4odGhpcywgcmVxdWVzdCwgUGFnZSk7XG4gIH1cblxuICBidWlsZFVSTDxSZXE+KHBhdGg6IHN0cmluZywgcXVlcnk6IFJlcSB8IG51bGwgfCB1bmRlZmluZWQpOiBzdHJpbmcge1xuICAgIGNvbnN0IHVybCA9XG4gICAgICBpc0Fic29sdXRlVVJMKHBhdGgpID9cbiAgICAgICAgbmV3IFVSTChwYXRoKVxuICAgICAgOiBuZXcgVVJMKHRoaXMuYmFzZVVSTCArICh0aGlzLmJhc2VVUkwuZW5kc1dpdGgoJy8nKSAmJiBwYXRoLnN0YXJ0c1dpdGgoJy8nKSA/IHBhdGguc2xpY2UoMSkgOiBwYXRoKSk7XG5cbiAgICBjb25zdCBkZWZhdWx0UXVlcnkgPSB0aGlzLmRlZmF1bHRRdWVyeSgpO1xuICAgIGlmICghaXNFbXB0eU9iaihkZWZhdWx0UXVlcnkpKSB7XG4gICAgICBxdWVyeSA9IHsgLi4uZGVmYXVsdFF1ZXJ5LCAuLi5xdWVyeSB9IGFzIFJlcTtcbiAgICB9XG5cbiAgICBpZiAodHlwZW9mIHF1ZXJ5ID09PSAnb2JqZWN0JyAmJiBxdWVyeSAmJiAhQXJyYXkuaXNBcnJheShxdWVyeSkpIHtcbiAgICAgIHVybC5zZWFyY2ggPSB0aGlzLnN0cmluZ2lmeVF1ZXJ5KHF1ZXJ5IGFzIFJlY29yZDxzdHJpbmcsIHVua25vd24+KTtcbiAgICB9XG5cbiAgICByZXR1cm4gdXJsLnRvU3RyaW5nKCk7XG4gIH1cblxuICBwcm90ZWN0ZWQgc3RyaW5naWZ5UXVlcnkocXVlcnk6IFJlY29yZDxzdHJpbmcsIHVua25vd24+KTogc3RyaW5nIHtcbiAgICByZXR1cm4gT2JqZWN0LmVudHJpZXMocXVlcnkpXG4gICAgICAuZmlsdGVyKChbXywgdmFsdWVdKSA9PiB0eXBlb2YgdmFsdWUgIT09ICd1bmRlZmluZWQnKVxuICAgICAgLm1hcCgoW2tleSwgdmFsdWVdKSA9PiB7XG4gICAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnIHx8IHR5cGVvZiB2YWx1ZSA9PT0gJ251bWJlcicgfHwgdHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbicpIHtcbiAgICAgICAgICByZXR1cm4gYCR7ZW5jb2RlVVJJQ29tcG9uZW50KGtleSl9PSR7ZW5jb2RlVVJJQ29tcG9uZW50KHZhbHVlKX1gO1xuICAgICAgICB9XG4gICAgICAgIGlmICh2YWx1ZSA9PT0gbnVsbCkge1xuICAgICAgICAgIHJldHVybiBgJHtlbmNvZGVVUklDb21wb25lbnQoa2V5KX09YDtcbiAgICAgICAgfVxuICAgICAgICB0aHJvdyBuZXcgQW50aHJvcGljRXJyb3IoXG4gICAgICAgICAgYENhbm5vdCBzdHJpbmdpZnkgdHlwZSAke3R5cGVvZiB2YWx1ZX07IEV4cGVjdGVkIHN0cmluZywgbnVtYmVyLCBib29sZWFuLCBvciBudWxsLiBJZiB5b3UgbmVlZCB0byBwYXNzIG5lc3RlZCBxdWVyeSBwYXJhbWV0ZXJzLCB5b3UgY2FuIG1hbnVhbGx5IGVuY29kZSB0aGVtLCBlLmcuIHsgcXVlcnk6IHsgJ2Zvb1trZXkxXSc6IHZhbHVlMSwgJ2Zvb1trZXkyXSc6IHZhbHVlMiB9IH0sIGFuZCBwbGVhc2Ugb3BlbiBhIEdpdEh1YiBpc3N1ZSByZXF1ZXN0aW5nIGJldHRlciBzdXBwb3J0IGZvciB5b3VyIHVzZSBjYXNlLmAsXG4gICAgICAgICk7XG4gICAgICB9KVxuICAgICAgLmpvaW4oJyYnKTtcbiAgfVxuXG4gIGFzeW5jIGZldGNoV2l0aFRpbWVvdXQoXG4gICAgdXJsOiBSZXF1ZXN0SW5mbyxcbiAgICBpbml0OiBSZXF1ZXN0SW5pdCB8IHVuZGVmaW5lZCxcbiAgICBtczogbnVtYmVyLFxuICAgIGNvbnRyb2xsZXI6IEFib3J0Q29udHJvbGxlcixcbiAgKTogUHJvbWlzZTxSZXNwb25zZT4ge1xuICAgIGNvbnN0IHsgc2lnbmFsLCAuLi5vcHRpb25zIH0gPSBpbml0IHx8IHt9O1xuICAgIGlmIChzaWduYWwpIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKCdhYm9ydCcsICgpID0+IGNvbnRyb2xsZXIuYWJvcnQoKSk7XG5cbiAgICBjb25zdCB0aW1lb3V0ID0gc2V0VGltZW91dCgoKSA9PiBjb250cm9sbGVyLmFib3J0KCksIG1zKTtcblxuICAgIHJldHVybiAoXG4gICAgICB0aGlzLmdldFJlcXVlc3RDbGllbnQoKVxuICAgICAgICAvLyB1c2UgdW5kZWZpbmVkIHRoaXMgYmluZGluZzsgZmV0Y2ggZXJyb3JzIGlmIGJvdW5kIHRvIHNvbWV0aGluZyBlbHNlIGluIGJyb3dzZXIvY2xvdWRmbGFyZVxuICAgICAgICAuZmV0Y2guY2FsbCh1bmRlZmluZWQsIHVybCwgeyBzaWduYWw6IGNvbnRyb2xsZXIuc2lnbmFsIGFzIGFueSwgLi4ub3B0aW9ucyB9KVxuICAgICAgICAuZmluYWxseSgoKSA9PiB7XG4gICAgICAgICAgY2xlYXJUaW1lb3V0KHRpbWVvdXQpO1xuICAgICAgICB9KVxuICAgICk7XG4gIH1cblxuICBwcm90ZWN0ZWQgZ2V0UmVxdWVzdENsaWVudCgpOiBSZXF1ZXN0Q2xpZW50IHtcbiAgICByZXR1cm4geyBmZXRjaDogdGhpcy5mZXRjaCB9O1xuICB9XG5cbiAgcHJpdmF0ZSBzaG91bGRSZXRyeShyZXNwb25zZTogUmVzcG9uc2UpOiBib29sZWFuIHtcbiAgICAvLyBOb3RlIHRoaXMgaXMgbm90IGEgc3RhbmRhcmQgaGVhZGVyLlxuICAgIGNvbnN0IHNob3VsZFJldHJ5SGVhZGVyID0gcmVzcG9uc2UuaGVhZGVycy5nZXQoJ3gtc2hvdWxkLXJldHJ5Jyk7XG5cbiAgICAvLyBJZiB0aGUgc2VydmVyIGV4cGxpY2l0bHkgc2F5cyB3aGV0aGVyIG9yIG5vdCB0byByZXRyeSwgb2JleS5cbiAgICBpZiAoc2hvdWxkUmV0cnlIZWFkZXIgPT09ICd0cnVlJykgcmV0dXJuIHRydWU7XG4gICAgaWYgKHNob3VsZFJldHJ5SGVhZGVyID09PSAnZmFsc2UnKSByZXR1cm4gZmFsc2U7XG5cbiAgICAvLyBSZXRyeSBvbiByZXF1ZXN0IHRpbWVvdXRzLlxuICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDQwOCkgcmV0dXJuIHRydWU7XG5cbiAgICAvLyBSZXRyeSBvbiBsb2NrIHRpbWVvdXRzLlxuICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPT09IDQwOSkgcmV0dXJuIHRydWU7XG5cbiAgICAvLyBSZXRyeSBvbiByYXRlIGxpbWl0cy5cbiAgICBpZiAocmVzcG9uc2Uuc3RhdHVzID09PSA0MjkpIHJldHVybiB0cnVlO1xuXG4gICAgLy8gUmV0cnkgaW50ZXJuYWwgZXJyb3JzLlxuICAgIGlmIChyZXNwb25zZS5zdGF0dXMgPj0gNTAwKSByZXR1cm4gdHJ1ZTtcblxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgcmV0cnlSZXF1ZXN0KFxuICAgIG9wdGlvbnM6IEZpbmFsUmVxdWVzdE9wdGlvbnMsXG4gICAgcmV0cmllc1JlbWFpbmluZzogbnVtYmVyLFxuICAgIHJlc3BvbnNlSGVhZGVycz86IEhlYWRlcnMgfCB1bmRlZmluZWQsXG4gICk6IFByb21pc2U8QVBJUmVzcG9uc2VQcm9wcz4ge1xuICAgIGxldCB0aW1lb3V0TWlsbGlzOiBudW1iZXIgfCB1bmRlZmluZWQ7XG5cbiAgICAvLyBOb3RlIHRoZSBgcmV0cnktYWZ0ZXItbXNgIGhlYWRlciBtYXkgbm90IGJlIHN0YW5kYXJkLCBidXQgaXMgYSBnb29kIGlkZWEgYW5kIHdlJ2QgbGlrZSBwcm9hY3RpdmUgc3VwcG9ydCBmb3IgaXQuXG4gICAgY29uc3QgcmV0cnlBZnRlck1pbGxpc0hlYWRlciA9IHJlc3BvbnNlSGVhZGVycz8uWydyZXRyeS1hZnRlci1tcyddO1xuICAgIGlmIChyZXRyeUFmdGVyTWlsbGlzSGVhZGVyKSB7XG4gICAgICBjb25zdCB0aW1lb3V0TXMgPSBwYXJzZUZsb2F0KHJldHJ5QWZ0ZXJNaWxsaXNIZWFkZXIpO1xuICAgICAgaWYgKCFOdW1iZXIuaXNOYU4odGltZW91dE1zKSkge1xuICAgICAgICB0aW1lb3V0TWlsbGlzID0gdGltZW91dE1zO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIEFib3V0IHRoZSBSZXRyeS1BZnRlciBoZWFkZXI6IGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0hUVFAvSGVhZGVycy9SZXRyeS1BZnRlclxuICAgIGNvbnN0IHJldHJ5QWZ0ZXJIZWFkZXIgPSByZXNwb25zZUhlYWRlcnM/LlsncmV0cnktYWZ0ZXInXTtcbiAgICBpZiAocmV0cnlBZnRlckhlYWRlciAmJiAhdGltZW91dE1pbGxpcykge1xuICAgICAgY29uc3QgdGltZW91dFNlY29uZHMgPSBwYXJzZUZsb2F0KHJldHJ5QWZ0ZXJIZWFkZXIpO1xuICAgICAgaWYgKCFOdW1iZXIuaXNOYU4odGltZW91dFNlY29uZHMpKSB7XG4gICAgICAgIHRpbWVvdXRNaWxsaXMgPSB0aW1lb3V0U2Vjb25kcyAqIDEwMDA7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB0aW1lb3V0TWlsbGlzID0gRGF0ZS5wYXJzZShyZXRyeUFmdGVySGVhZGVyKSAtIERhdGUubm93KCk7XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gSWYgdGhlIEFQSSBhc2tzIHVzIHRvIHdhaXQgYSBjZXJ0YWluIGFtb3VudCBvZiB0aW1lIChhbmQgaXQncyBhIHJlYXNvbmFibGUgYW1vdW50KSxcbiAgICAvLyBqdXN0IGRvIHdoYXQgaXQgc2F5cywgYnV0IG90aGVyd2lzZSBjYWxjdWxhdGUgYSBkZWZhdWx0XG4gICAgaWYgKCEodGltZW91dE1pbGxpcyAmJiAwIDw9IHRpbWVvdXRNaWxsaXMgJiYgdGltZW91dE1pbGxpcyA8IDYwICogMTAwMCkpIHtcbiAgICAgIGNvbnN0IG1heFJldHJpZXMgPSBvcHRpb25zLm1heFJldHJpZXMgPz8gdGhpcy5tYXhSZXRyaWVzO1xuICAgICAgdGltZW91dE1pbGxpcyA9IHRoaXMuY2FsY3VsYXRlRGVmYXVsdFJldHJ5VGltZW91dE1pbGxpcyhyZXRyaWVzUmVtYWluaW5nLCBtYXhSZXRyaWVzKTtcbiAgICB9XG4gICAgYXdhaXQgc2xlZXAodGltZW91dE1pbGxpcyk7XG5cbiAgICByZXR1cm4gdGhpcy5tYWtlUmVxdWVzdChvcHRpb25zLCByZXRyaWVzUmVtYWluaW5nIC0gMSk7XG4gIH1cblxuICBwcml2YXRlIGNhbGN1bGF0ZURlZmF1bHRSZXRyeVRpbWVvdXRNaWxsaXMocmV0cmllc1JlbWFpbmluZzogbnVtYmVyLCBtYXhSZXRyaWVzOiBudW1iZXIpOiBudW1iZXIge1xuICAgIGNvbnN0IGluaXRpYWxSZXRyeURlbGF5ID0gMC41O1xuICAgIGNvbnN0IG1heFJldHJ5RGVsYXkgPSA4LjA7XG5cbiAgICBjb25zdCBudW1SZXRyaWVzID0gbWF4UmV0cmllcyAtIHJldHJpZXNSZW1haW5pbmc7XG5cbiAgICAvLyBBcHBseSBleHBvbmVudGlhbCBiYWNrb2ZmLCBidXQgbm90IG1vcmUgdGhhbiB0aGUgbWF4LlxuICAgIGNvbnN0IHNsZWVwU2Vjb25kcyA9IE1hdGgubWluKGluaXRpYWxSZXRyeURlbGF5ICogTWF0aC5wb3coMiwgbnVtUmV0cmllcyksIG1heFJldHJ5RGVsYXkpO1xuXG4gICAgLy8gQXBwbHkgc29tZSBqaXR0ZXIsIHRha2UgdXAgdG8gYXQgbW9zdCAyNSBwZXJjZW50IG9mIHRoZSByZXRyeSB0aW1lLlxuICAgIGNvbnN0IGppdHRlciA9IDEgLSBNYXRoLnJhbmRvbSgpICogMC4yNTtcblxuICAgIHJldHVybiBzbGVlcFNlY29uZHMgKiBqaXR0ZXIgKiAxMDAwO1xuICB9XG5cbiAgcHJpdmF0ZSBnZXRVc2VyQWdlbnQoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYCR7dGhpcy5jb25zdHJ1Y3Rvci5uYW1lfS9KUyAke1ZFUlNJT059YDtcbiAgfVxufVxuXG5leHBvcnQgdHlwZSBQYWdlSW5mbyA9IHsgdXJsOiBVUkwgfSB8IHsgcGFyYW1zOiBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IG51bGwgfTtcblxuZXhwb3J0IGFic3RyYWN0IGNsYXNzIEFic3RyYWN0UGFnZTxJdGVtPiBpbXBsZW1lbnRzIEFzeW5jSXRlcmFibGU8SXRlbT4ge1xuICAjY2xpZW50OiBBUElDbGllbnQ7XG4gIHByb3RlY3RlZCBvcHRpb25zOiBGaW5hbFJlcXVlc3RPcHRpb25zO1xuXG4gIHByb3RlY3RlZCByZXNwb25zZTogUmVzcG9uc2U7XG4gIHByb3RlY3RlZCBib2R5OiB1bmtub3duO1xuXG4gIGNvbnN0cnVjdG9yKGNsaWVudDogQVBJQ2xpZW50LCByZXNwb25zZTogUmVzcG9uc2UsIGJvZHk6IHVua25vd24sIG9wdGlvbnM6IEZpbmFsUmVxdWVzdE9wdGlvbnMpIHtcbiAgICB0aGlzLiNjbGllbnQgPSBjbGllbnQ7XG4gICAgdGhpcy5vcHRpb25zID0gb3B0aW9ucztcbiAgICB0aGlzLnJlc3BvbnNlID0gcmVzcG9uc2U7XG4gICAgdGhpcy5ib2R5ID0gYm9keTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAZGVwcmVjYXRlZCBVc2UgbmV4dFBhZ2VJbmZvIGluc3RlYWRcbiAgICovXG4gIGFic3RyYWN0IG5leHRQYWdlUGFyYW1zKCk6IFBhcnRpYWw8UmVjb3JkPHN0cmluZywgdW5rbm93bj4+IHwgbnVsbDtcbiAgYWJzdHJhY3QgbmV4dFBhZ2VJbmZvKCk6IFBhZ2VJbmZvIHwgbnVsbDtcblxuICBhYnN0cmFjdCBnZXRQYWdpbmF0ZWRJdGVtcygpOiBJdGVtW107XG5cbiAgaGFzTmV4dFBhZ2UoKTogYm9vbGVhbiB7XG4gICAgY29uc3QgaXRlbXMgPSB0aGlzLmdldFBhZ2luYXRlZEl0ZW1zKCk7XG4gICAgaWYgKCFpdGVtcy5sZW5ndGgpIHJldHVybiBmYWxzZTtcbiAgICByZXR1cm4gdGhpcy5uZXh0UGFnZUluZm8oKSAhPSBudWxsO1xuICB9XG5cbiAgYXN5bmMgZ2V0TmV4dFBhZ2UoKTogUHJvbWlzZTx0aGlzPiB7XG4gICAgY29uc3QgbmV4dEluZm8gPSB0aGlzLm5leHRQYWdlSW5mbygpO1xuICAgIGlmICghbmV4dEluZm8pIHtcbiAgICAgIHRocm93IG5ldyBBbnRocm9waWNFcnJvcihcbiAgICAgICAgJ05vIG5leHQgcGFnZSBleHBlY3RlZDsgcGxlYXNlIGNoZWNrIGAuaGFzTmV4dFBhZ2UoKWAgYmVmb3JlIGNhbGxpbmcgYC5nZXROZXh0UGFnZSgpYC4nLFxuICAgICAgKTtcbiAgICB9XG4gICAgY29uc3QgbmV4dE9wdGlvbnMgPSB7IC4uLnRoaXMub3B0aW9ucyB9O1xuICAgIGlmICgncGFyYW1zJyBpbiBuZXh0SW5mbyAmJiB0eXBlb2YgbmV4dE9wdGlvbnMucXVlcnkgPT09ICdvYmplY3QnKSB7XG4gICAgICBuZXh0T3B0aW9ucy5xdWVyeSA9IHsgLi4ubmV4dE9wdGlvbnMucXVlcnksIC4uLm5leHRJbmZvLnBhcmFtcyB9O1xuICAgIH0gZWxzZSBpZiAoJ3VybCcgaW4gbmV4dEluZm8pIHtcbiAgICAgIGNvbnN0IHBhcmFtcyA9IFsuLi5PYmplY3QuZW50cmllcyhuZXh0T3B0aW9ucy5xdWVyeSB8fCB7fSksIC4uLm5leHRJbmZvLnVybC5zZWFyY2hQYXJhbXMuZW50cmllcygpXTtcbiAgICAgIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIHBhcmFtcykge1xuICAgICAgICBuZXh0SW5mby51cmwuc2VhcmNoUGFyYW1zLnNldChrZXksIHZhbHVlIGFzIGFueSk7XG4gICAgICB9XG4gICAgICBuZXh0T3B0aW9ucy5xdWVyeSA9IHVuZGVmaW5lZDtcbiAgICAgIG5leHRPcHRpb25zLnBhdGggPSBuZXh0SW5mby51cmwudG9TdHJpbmcoKTtcbiAgICB9XG4gICAgcmV0dXJuIGF3YWl0IHRoaXMuI2NsaWVudC5yZXF1ZXN0QVBJTGlzdCh0aGlzLmNvbnN0cnVjdG9yIGFzIGFueSwgbmV4dE9wdGlvbnMpO1xuICB9XG5cbiAgYXN5bmMgKml0ZXJQYWdlcygpIHtcbiAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXRoaXMtYWxpYXNcbiAgICBsZXQgcGFnZTogQWJzdHJhY3RQYWdlPEl0ZW0+ID0gdGhpcztcbiAgICB5aWVsZCBwYWdlO1xuICAgIHdoaWxlIChwYWdlLmhhc05leHRQYWdlKCkpIHtcbiAgICAgIHBhZ2UgPSBhd2FpdCBwYWdlLmdldE5leHRQYWdlKCk7XG4gICAgICB5aWVsZCBwYWdlO1xuICAgIH1cbiAgfVxuXG4gIGFzeW5jICpbU3ltYm9sLmFzeW5jSXRlcmF0b3JdKCkge1xuICAgIGZvciBhd2FpdCAoY29uc3QgcGFnZSBvZiB0aGlzLml0ZXJQYWdlcygpKSB7XG4gICAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgcGFnZS5nZXRQYWdpbmF0ZWRJdGVtcygpKSB7XG4gICAgICAgIHlpZWxkIGl0ZW07XG4gICAgICB9XG4gICAgfVxuICB9XG59XG5cbi8qKlxuICogVGhpcyBzdWJjbGFzcyBvZiBQcm9taXNlIHdpbGwgcmVzb2x2ZSB0byBhbiBpbnN0YW50aWF0ZWQgUGFnZSBvbmNlIHRoZSByZXF1ZXN0IGNvbXBsZXRlcy5cbiAqXG4gKiBJdCBhbHNvIGltcGxlbWVudHMgQXN5bmNJdGVyYWJsZSB0byBhbGxvdyBhdXRvLXBhZ2luYXRpbmcgaXRlcmF0aW9uIG9uIGFuIHVuYXdhaXRlZCBsaXN0IGNhbGwsIGVnOlxuICpcbiAqICAgIGZvciBhd2FpdCAoY29uc3QgaXRlbSBvZiBjbGllbnQuaXRlbXMubGlzdCgpKSB7XG4gKiAgICAgIGNvbnNvbGUubG9nKGl0ZW0pXG4gKiAgICB9XG4gKi9cbmV4cG9ydCBjbGFzcyBQYWdlUHJvbWlzZTxcbiAgICBQYWdlQ2xhc3MgZXh0ZW5kcyBBYnN0cmFjdFBhZ2U8SXRlbT4sXG4gICAgSXRlbSA9IFJldHVyblR5cGU8UGFnZUNsYXNzWydnZXRQYWdpbmF0ZWRJdGVtcyddPltudW1iZXJdLFxuICA+XG4gIGV4dGVuZHMgQVBJUHJvbWlzZTxQYWdlQ2xhc3M+XG4gIGltcGxlbWVudHMgQXN5bmNJdGVyYWJsZTxJdGVtPlxue1xuICBjb25zdHJ1Y3RvcihcbiAgICBjbGllbnQ6IEFQSUNsaWVudCxcbiAgICByZXF1ZXN0OiBQcm9taXNlPEFQSVJlc3BvbnNlUHJvcHM+LFxuICAgIFBhZ2U6IG5ldyAoLi4uYXJnczogQ29uc3RydWN0b3JQYXJhbWV0ZXJzPHR5cGVvZiBBYnN0cmFjdFBhZ2U+KSA9PiBQYWdlQ2xhc3MsXG4gICkge1xuICAgIHN1cGVyKFxuICAgICAgcmVxdWVzdCxcbiAgICAgIGFzeW5jIChwcm9wcykgPT4gbmV3IFBhZ2UoY2xpZW50LCBwcm9wcy5yZXNwb25zZSwgYXdhaXQgZGVmYXVsdFBhcnNlUmVzcG9uc2UocHJvcHMpLCBwcm9wcy5vcHRpb25zKSxcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIEFsbG93IGF1dG8tcGFnaW5hdGluZyBpdGVyYXRpb24gb24gYW4gdW5hd2FpdGVkIGxpc3QgY2FsbCwgZWc6XG4gICAqXG4gICAqICAgIGZvciBhd2FpdCAoY29uc3QgaXRlbSBvZiBjbGllbnQuaXRlbXMubGlzdCgpKSB7XG4gICAqICAgICAgY29uc29sZS5sb2coaXRlbSlcbiAgICogICAgfVxuICAgKi9cbiAgYXN5bmMgKltTeW1ib2wuYXN5bmNJdGVyYXRvcl0oKSB7XG4gICAgY29uc3QgcGFnZSA9IGF3YWl0IHRoaXM7XG4gICAgZm9yIGF3YWl0IChjb25zdCBpdGVtIG9mIHBhZ2UpIHtcbiAgICAgIHlpZWxkIGl0ZW07XG4gICAgfVxuICB9XG59XG5cbmV4cG9ydCBjb25zdCBjcmVhdGVSZXNwb25zZUhlYWRlcnMgPSAoXG4gIGhlYWRlcnM6IEF3YWl0ZWQ8UmV0dXJuVHlwZTxGZXRjaD4+WydoZWFkZXJzJ10sXG4pOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+ID0+IHtcbiAgcmV0dXJuIG5ldyBQcm94eShcbiAgICBPYmplY3QuZnJvbUVudHJpZXMoXG4gICAgICAvLyBAdHMtaWdub3JlXG4gICAgICBoZWFkZXJzLmVudHJpZXMoKSxcbiAgICApLFxuICAgIHtcbiAgICAgIGdldCh0YXJnZXQsIG5hbWUpIHtcbiAgICAgICAgY29uc3Qga2V5ID0gbmFtZS50b1N0cmluZygpO1xuICAgICAgICByZXR1cm4gdGFyZ2V0W2tleS50b0xvd2VyQ2FzZSgpXSB8fCB0YXJnZXRba2V5XTtcbiAgICAgIH0sXG4gICAgfSxcbiAgKTtcbn07XG5cbnR5cGUgSFRUUE1ldGhvZCA9ICdnZXQnIHwgJ3Bvc3QnIHwgJ3B1dCcgfCAncGF0Y2gnIHwgJ2RlbGV0ZSc7XG5cbmV4cG9ydCB0eXBlIFJlcXVlc3RDbGllbnQgPSB7IGZldGNoOiBGZXRjaCB9O1xuZXhwb3J0IHR5cGUgSGVhZGVycyA9IFJlY29yZDxzdHJpbmcsIHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQ+O1xuZXhwb3J0IHR5cGUgRGVmYXVsdFF1ZXJ5ID0gUmVjb3JkPHN0cmluZywgc3RyaW5nIHwgdW5kZWZpbmVkPjtcbmV4cG9ydCB0eXBlIEtleXNFbnVtPFQ+ID0geyBbUCBpbiBrZXlvZiBSZXF1aXJlZDxUPl06IHRydWUgfTtcblxuZXhwb3J0IHR5cGUgUmVxdWVzdE9wdGlvbnM8XG4gIFJlcSA9IHVua25vd24gfCBSZWNvcmQ8c3RyaW5nLCB1bmtub3duPiB8IFJlYWRhYmxlIHwgQmxvYkxpa2UgfCBBcnJheUJ1ZmZlclZpZXcgfCBBcnJheUJ1ZmZlcixcbj4gPSB7XG4gIG1ldGhvZD86IEhUVFBNZXRob2Q7XG4gIHBhdGg/OiBzdHJpbmc7XG4gIHF1ZXJ5PzogUmVxIHwgdW5kZWZpbmVkO1xuICBib2R5PzogUmVxIHwgbnVsbCB8IHVuZGVmaW5lZDtcbiAgaGVhZGVycz86IEhlYWRlcnMgfCB1bmRlZmluZWQ7XG5cbiAgbWF4UmV0cmllcz86IG51bWJlcjtcbiAgc3RyZWFtPzogYm9vbGVhbiB8IHVuZGVmaW5lZDtcbiAgdGltZW91dD86IG51bWJlcjtcbiAgaHR0cEFnZW50PzogQWdlbnQ7XG4gIHNpZ25hbD86IEFib3J0U2lnbmFsIHwgdW5kZWZpbmVkIHwgbnVsbDtcbiAgaWRlbXBvdGVuY3lLZXk/OiBzdHJpbmc7XG5cbiAgX19iaW5hcnlSZXF1ZXN0PzogYm9vbGVhbiB8IHVuZGVmaW5lZDtcbiAgX19iaW5hcnlSZXNwb25zZT86IGJvb2xlYW4gfCB1bmRlZmluZWQ7XG4gIF9fc3RyZWFtQ2xhc3M/OiB0eXBlb2YgU3RyZWFtO1xufTtcblxuLy8gVGhpcyBpcyByZXF1aXJlZCBzbyB0aGF0IHdlIGNhbiBkZXRlcm1pbmUgaWYgYSBnaXZlbiBvYmplY3QgbWF0Y2hlcyB0aGUgUmVxdWVzdE9wdGlvbnNcbi8vIHR5cGUgYXQgcnVudGltZS4gV2hpbGUgdGhpcyByZXF1aXJlcyBkdXBsaWNhdGlvbiwgaXQgaXMgZW5mb3JjZWQgYnkgdGhlIFR5cGVTY3JpcHRcbi8vIGNvbXBpbGVyIHN1Y2ggdGhhdCBhbnkgbWlzc2luZyAvIGV4dHJhbmVvdXMga2V5cyB3aWxsIGNhdXNlIGFuIGVycm9yLlxuY29uc3QgcmVxdWVzdE9wdGlvbnNLZXlzOiBLZXlzRW51bTxSZXF1ZXN0T3B0aW9ucz4gPSB7XG4gIG1ldGhvZDogdHJ1ZSxcbiAgcGF0aDogdHJ1ZSxcbiAgcXVlcnk6IHRydWUsXG4gIGJvZHk6IHRydWUsXG4gIGhlYWRlcnM6IHRydWUsXG5cbiAgbWF4UmV0cmllczogdHJ1ZSxcbiAgc3RyZWFtOiB0cnVlLFxuICB0aW1lb3V0OiB0cnVlLFxuICBodHRwQWdlbnQ6IHRydWUsXG4gIHNpZ25hbDogdHJ1ZSxcbiAgaWRlbXBvdGVuY3lLZXk6IHRydWUsXG5cbiAgX19iaW5hcnlSZXF1ZXN0OiB0cnVlLFxuICBfX2JpbmFyeVJlc3BvbnNlOiB0cnVlLFxuICBfX3N0cmVhbUNsYXNzOiB0cnVlLFxufTtcblxuZXhwb3J0IGNvbnN0IGlzUmVxdWVzdE9wdGlvbnMgPSAob2JqOiB1bmtub3duKTogb2JqIGlzIFJlcXVlc3RPcHRpb25zID0+IHtcbiAgcmV0dXJuIChcbiAgICB0eXBlb2Ygb2JqID09PSAnb2JqZWN0JyAmJlxuICAgIG9iaiAhPT0gbnVsbCAmJlxuICAgICFpc0VtcHR5T2JqKG9iaikgJiZcbiAgICBPYmplY3Qua2V5cyhvYmopLmV2ZXJ5KChrKSA9PiBoYXNPd24ocmVxdWVzdE9wdGlvbnNLZXlzLCBrKSlcbiAgKTtcbn07XG5cbmV4cG9ydCB0eXBlIEZpbmFsUmVxdWVzdE9wdGlvbnM8UmVxID0gdW5rbm93biB8IFJlY29yZDxzdHJpbmcsIHVua25vd24+IHwgUmVhZGFibGUgfCBEYXRhVmlldz4gPVxuICBSZXF1ZXN0T3B0aW9uczxSZXE+ICYge1xuICAgIG1ldGhvZDogSFRUUE1ldGhvZDtcbiAgICBwYXRoOiBzdHJpbmc7XG4gIH07XG5cbmRlY2xhcmUgY29uc3QgRGVubzogYW55O1xuZGVjbGFyZSBjb25zdCBFZGdlUnVudGltZTogYW55O1xudHlwZSBBcmNoID0gJ3gzMicgfCAneDY0JyB8ICdhcm0nIHwgJ2FybTY0JyB8IGBvdGhlcjoke3N0cmluZ31gIHwgJ3Vua25vd24nO1xudHlwZSBQbGF0Zm9ybU5hbWUgPVxuICB8ICdNYWNPUydcbiAgfCAnTGludXgnXG4gIHwgJ1dpbmRvd3MnXG4gIHwgJ0ZyZWVCU0QnXG4gIHwgJ09wZW5CU0QnXG4gIHwgJ2lPUydcbiAgfCAnQW5kcm9pZCdcbiAgfCBgT3RoZXI6JHtzdHJpbmd9YFxuICB8ICdVbmtub3duJztcbnR5cGUgQnJvd3NlciA9ICdpZScgfCAnZWRnZScgfCAnY2hyb21lJyB8ICdmaXJlZm94JyB8ICdzYWZhcmknO1xudHlwZSBQbGF0Zm9ybVByb3BlcnRpZXMgPSB7XG4gICdYLVN0YWlubGVzcy1MYW5nJzogJ2pzJztcbiAgJ1gtU3RhaW5sZXNzLVBhY2thZ2UtVmVyc2lvbic6IHN0cmluZztcbiAgJ1gtU3RhaW5sZXNzLU9TJzogUGxhdGZvcm1OYW1lO1xuICAnWC1TdGFpbmxlc3MtQXJjaCc6IEFyY2g7XG4gICdYLVN0YWlubGVzcy1SdW50aW1lJzogJ25vZGUnIHwgJ2Rlbm8nIHwgJ2VkZ2UnIHwgYGJyb3dzZXI6JHtCcm93c2VyfWAgfCAndW5rbm93bic7XG4gICdYLVN0YWlubGVzcy1SdW50aW1lLVZlcnNpb24nOiBzdHJpbmc7XG59O1xuY29uc3QgZ2V0UGxhdGZvcm1Qcm9wZXJ0aWVzID0gKCk6IFBsYXRmb3JtUHJvcGVydGllcyA9PiB7XG4gIGlmICh0eXBlb2YgRGVubyAhPT0gJ3VuZGVmaW5lZCcgJiYgRGVuby5idWlsZCAhPSBudWxsKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICdYLVN0YWlubGVzcy1MYW5nJzogJ2pzJyxcbiAgICAgICdYLVN0YWlubGVzcy1QYWNrYWdlLVZlcnNpb24nOiBWRVJTSU9OLFxuICAgICAgJ1gtU3RhaW5sZXNzLU9TJzogbm9ybWFsaXplUGxhdGZvcm0oRGVuby5idWlsZC5vcyksXG4gICAgICAnWC1TdGFpbmxlc3MtQXJjaCc6IG5vcm1hbGl6ZUFyY2goRGVuby5idWlsZC5hcmNoKSxcbiAgICAgICdYLVN0YWlubGVzcy1SdW50aW1lJzogJ2Rlbm8nLFxuICAgICAgJ1gtU3RhaW5sZXNzLVJ1bnRpbWUtVmVyc2lvbic6XG4gICAgICAgIHR5cGVvZiBEZW5vLnZlcnNpb24gPT09ICdzdHJpbmcnID8gRGVuby52ZXJzaW9uIDogRGVuby52ZXJzaW9uPy5kZW5vID8/ICd1bmtub3duJyxcbiAgICB9O1xuICB9XG4gIGlmICh0eXBlb2YgRWRnZVJ1bnRpbWUgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICdYLVN0YWlubGVzcy1MYW5nJzogJ2pzJyxcbiAgICAgICdYLVN0YWlubGVzcy1QYWNrYWdlLVZlcnNpb24nOiBWRVJTSU9OLFxuICAgICAgJ1gtU3RhaW5sZXNzLU9TJzogJ1Vua25vd24nLFxuICAgICAgJ1gtU3RhaW5sZXNzLUFyY2gnOiBgb3RoZXI6JHtFZGdlUnVudGltZX1gLFxuICAgICAgJ1gtU3RhaW5sZXNzLVJ1bnRpbWUnOiAnZWRnZScsXG4gICAgICAnWC1TdGFpbmxlc3MtUnVudGltZS1WZXJzaW9uJzogcHJvY2Vzcy52ZXJzaW9uLFxuICAgIH07XG4gIH1cbiAgLy8gQ2hlY2sgaWYgTm9kZS5qc1xuICBpZiAoT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHR5cGVvZiBwcm9jZXNzICE9PSAndW5kZWZpbmVkJyA/IHByb2Nlc3MgOiAwKSA9PT0gJ1tvYmplY3QgcHJvY2Vzc10nKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgICdYLVN0YWlubGVzcy1MYW5nJzogJ2pzJyxcbiAgICAgICdYLVN0YWlubGVzcy1QYWNrYWdlLVZlcnNpb24nOiBWRVJTSU9OLFxuICAgICAgJ1gtU3RhaW5sZXNzLU9TJzogbm9ybWFsaXplUGxhdGZvcm0ocHJvY2Vzcy5wbGF0Zm9ybSksXG4gICAgICAnWC1TdGFpbmxlc3MtQXJjaCc6IG5vcm1hbGl6ZUFyY2gocHJvY2Vzcy5hcmNoKSxcbiAgICAgICdYLVN0YWlubGVzcy1SdW50aW1lJzogJ25vZGUnLFxuICAgICAgJ1gtU3RhaW5sZXNzLVJ1bnRpbWUtVmVyc2lvbic6IHByb2Nlc3MudmVyc2lvbixcbiAgICB9O1xuICB9XG5cbiAgY29uc3QgYnJvd3NlckluZm8gPSBnZXRCcm93c2VySW5mbygpO1xuICBpZiAoYnJvd3NlckluZm8pIHtcbiAgICByZXR1cm4ge1xuICAgICAgJ1gtU3RhaW5sZXNzLUxhbmcnOiAnanMnLFxuICAgICAgJ1gtU3RhaW5sZXNzLVBhY2thZ2UtVmVyc2lvbic6IFZFUlNJT04sXG4gICAgICAnWC1TdGFpbmxlc3MtT1MnOiAnVW5rbm93bicsXG4gICAgICAnWC1TdGFpbmxlc3MtQXJjaCc6ICd1bmtub3duJyxcbiAgICAgICdYLVN0YWlubGVzcy1SdW50aW1lJzogYGJyb3dzZXI6JHticm93c2VySW5mby5icm93c2VyfWAsXG4gICAgICAnWC1TdGFpbmxlc3MtUnVudGltZS1WZXJzaW9uJzogYnJvd3NlckluZm8udmVyc2lvbixcbiAgICB9O1xuICB9XG5cbiAgLy8gVE9ETyBhZGQgc3VwcG9ydCBmb3IgQ2xvdWRmbGFyZSB3b3JrZXJzLCBldGMuXG4gIHJldHVybiB7XG4gICAgJ1gtU3RhaW5sZXNzLUxhbmcnOiAnanMnLFxuICAgICdYLVN0YWlubGVzcy1QYWNrYWdlLVZlcnNpb24nOiBWRVJTSU9OLFxuICAgICdYLVN0YWlubGVzcy1PUyc6ICdVbmtub3duJyxcbiAgICAnWC1TdGFpbmxlc3MtQXJjaCc6ICd1bmtub3duJyxcbiAgICAnWC1TdGFpbmxlc3MtUnVudGltZSc6ICd1bmtub3duJyxcbiAgICAnWC1TdGFpbmxlc3MtUnVudGltZS1WZXJzaW9uJzogJ3Vua25vd24nLFxuICB9O1xufTtcblxudHlwZSBCcm93c2VySW5mbyA9IHtcbiAgYnJvd3NlcjogQnJvd3NlcjtcbiAgdmVyc2lvbjogc3RyaW5nO1xufTtcblxuZGVjbGFyZSBjb25zdCBuYXZpZ2F0b3I6IHsgdXNlckFnZW50OiBzdHJpbmcgfSB8IHVuZGVmaW5lZDtcblxuLy8gTm90ZTogbW9kaWZpZWQgZnJvbSBodHRwczovL2dpdGh1Yi5jb20vSlMtRGV2VG9vbHMvaG9zdC1lbnZpcm9ubWVudC9ibG9iL2IxYWI3OWVjZGUzN2RiNWQ2ZTE2M2MwNTBlNTRmZTdkMjg3ZDdjOTIvc3JjL2lzb21vcnBoaWMuYnJvd3Nlci50c1xuZnVuY3Rpb24gZ2V0QnJvd3NlckluZm8oKTogQnJvd3NlckluZm8gfCBudWxsIHtcbiAgaWYgKHR5cGVvZiBuYXZpZ2F0b3IgPT09ICd1bmRlZmluZWQnIHx8ICFuYXZpZ2F0b3IpIHtcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIC8vIE5PVEU6IFRoZSBvcmRlciBtYXR0ZXJzIGhlcmUhXG4gIGNvbnN0IGJyb3dzZXJQYXR0ZXJucyA9IFtcbiAgICB7IGtleTogJ2VkZ2UnIGFzIGNvbnN0LCBwYXR0ZXJuOiAvRWRnZSg/OlxcVysoXFxkKylcXC4oXFxkKykoPzpcXC4oXFxkKykpPyk/LyB9LFxuICAgIHsga2V5OiAnaWUnIGFzIGNvbnN0LCBwYXR0ZXJuOiAvTVNJRSg/OlxcVysoXFxkKylcXC4oXFxkKykoPzpcXC4oXFxkKykpPyk/LyB9LFxuICAgIHsga2V5OiAnaWUnIGFzIGNvbnN0LCBwYXR0ZXJuOiAvVHJpZGVudCg/Oi4qcnZcXDooXFxkKylcXC4oXFxkKykoPzpcXC4oXFxkKykpPyk/LyB9LFxuICAgIHsga2V5OiAnY2hyb21lJyBhcyBjb25zdCwgcGF0dGVybjogL0Nocm9tZSg/OlxcVysoXFxkKylcXC4oXFxkKykoPzpcXC4oXFxkKykpPyk/LyB9LFxuICAgIHsga2V5OiAnZmlyZWZveCcgYXMgY29uc3QsIHBhdHRlcm46IC9GaXJlZm94KD86XFxXKyhcXGQrKVxcLihcXGQrKSg/OlxcLihcXGQrKSk/KT8vIH0sXG4gICAgeyBrZXk6ICdzYWZhcmknIGFzIGNvbnN0LCBwYXR0ZXJuOiAvKD86VmVyc2lvblxcVysoXFxkKylcXC4oXFxkKykoPzpcXC4oXFxkKykpPyk/KD86XFxXK01vYmlsZVxcUyopP1xcVytTYWZhcmkvIH0sXG4gIF07XG5cbiAgLy8gRmluZCB0aGUgRklSU1QgbWF0Y2hpbmcgYnJvd3NlclxuICBmb3IgKGNvbnN0IHsga2V5LCBwYXR0ZXJuIH0gb2YgYnJvd3NlclBhdHRlcm5zKSB7XG4gICAgY29uc3QgbWF0Y2ggPSBwYXR0ZXJuLmV4ZWMobmF2aWdhdG9yLnVzZXJBZ2VudCk7XG4gICAgaWYgKG1hdGNoKSB7XG4gICAgICBjb25zdCBtYWpvciA9IG1hdGNoWzFdIHx8IDA7XG4gICAgICBjb25zdCBtaW5vciA9IG1hdGNoWzJdIHx8IDA7XG4gICAgICBjb25zdCBwYXRjaCA9IG1hdGNoWzNdIHx8IDA7XG5cbiAgICAgIHJldHVybiB7IGJyb3dzZXI6IGtleSwgdmVyc2lvbjogYCR7bWFqb3J9LiR7bWlub3J9LiR7cGF0Y2h9YCB9O1xuICAgIH1cbiAgfVxuXG4gIHJldHVybiBudWxsO1xufVxuXG5jb25zdCBub3JtYWxpemVBcmNoID0gKGFyY2g6IHN0cmluZyk6IEFyY2ggPT4ge1xuICAvLyBOb2RlIGRvY3M6XG4gIC8vIC0gaHR0cHM6Ly9ub2RlanMub3JnL2FwaS9wcm9jZXNzLmh0bWwjcHJvY2Vzc2FyY2hcbiAgLy8gRGVubyBkb2NzOlxuICAvLyAtIGh0dHBzOi8vZG9jLmRlbm8ubGFuZC9kZW5vL3N0YWJsZS9+L0Rlbm8uYnVpbGRcbiAgaWYgKGFyY2ggPT09ICd4MzInKSByZXR1cm4gJ3gzMic7XG4gIGlmIChhcmNoID09PSAneDg2XzY0JyB8fCBhcmNoID09PSAneDY0JykgcmV0dXJuICd4NjQnO1xuICBpZiAoYXJjaCA9PT0gJ2FybScpIHJldHVybiAnYXJtJztcbiAgaWYgKGFyY2ggPT09ICdhYXJjaDY0JyB8fCBhcmNoID09PSAnYXJtNjQnKSByZXR1cm4gJ2FybTY0JztcbiAgaWYgKGFyY2gpIHJldHVybiBgb3RoZXI6JHthcmNofWA7XG4gIHJldHVybiAndW5rbm93bic7XG59O1xuXG5jb25zdCBub3JtYWxpemVQbGF0Zm9ybSA9IChwbGF0Zm9ybTogc3RyaW5nKTogUGxhdGZvcm1OYW1lID0+IHtcbiAgLy8gTm9kZSBwbGF0Zm9ybXM6XG4gIC8vIC0gaHR0cHM6Ly9ub2RlanMub3JnL2FwaS9wcm9jZXNzLmh0bWwjcHJvY2Vzc3BsYXRmb3JtXG4gIC8vIERlbm8gcGxhdGZvcm1zOlxuICAvLyAtIGh0dHBzOi8vZG9jLmRlbm8ubGFuZC9kZW5vL3N0YWJsZS9+L0Rlbm8uYnVpbGRcbiAgLy8gLSBodHRwczovL2dpdGh1Yi5jb20vZGVub2xhbmQvZGVuby9pc3N1ZXMvMTQ3OTlcblxuICBwbGF0Zm9ybSA9IHBsYXRmb3JtLnRvTG93ZXJDYXNlKCk7XG5cbiAgLy8gTk9URTogdGhpcyBpT1MgY2hlY2sgaXMgdW50ZXN0ZWQgYW5kIG1heSBub3Qgd29ya1xuICAvLyBOb2RlIGRvZXMgbm90IHdvcmsgbmF0aXZlbHkgb24gSU9TLCB0aGVyZSBpcyBhIGZvcmsgYXRcbiAgLy8gaHR0cHM6Ly9naXRodWIuY29tL25vZGVqcy1tb2JpbGUvbm9kZWpzLW1vYmlsZVxuICAvLyBob3dldmVyIGl0IGlzIHVua25vd24gYXQgdGhlIHRpbWUgb2Ygd3JpdGluZyBob3cgdG8gZGV0ZWN0IGlmIGl0IGlzIHJ1bm5pbmdcbiAgaWYgKHBsYXRmb3JtLmluY2x1ZGVzKCdpb3MnKSkgcmV0dXJuICdpT1MnO1xuICBpZiAocGxhdGZvcm0gPT09ICdhbmRyb2lkJykgcmV0dXJuICdBbmRyb2lkJztcbiAgaWYgKHBsYXRmb3JtID09PSAnZGFyd2luJykgcmV0dXJuICdNYWNPUyc7XG4gIGlmIChwbGF0Zm9ybSA9PT0gJ3dpbjMyJykgcmV0dXJuICdXaW5kb3dzJztcbiAgaWYgKHBsYXRmb3JtID09PSAnZnJlZWJzZCcpIHJldHVybiAnRnJlZUJTRCc7XG4gIGlmIChwbGF0Zm9ybSA9PT0gJ29wZW5ic2QnKSByZXR1cm4gJ09wZW5CU0QnO1xuICBpZiAocGxhdGZvcm0gPT09ICdsaW51eCcpIHJldHVybiAnTGludXgnO1xuICBpZiAocGxhdGZvcm0pIHJldHVybiBgT3RoZXI6JHtwbGF0Zm9ybX1gO1xuICByZXR1cm4gJ1Vua25vd24nO1xufTtcblxubGV0IF9wbGF0Zm9ybUhlYWRlcnM6IFBsYXRmb3JtUHJvcGVydGllcztcbmNvbnN0IGdldFBsYXRmb3JtSGVhZGVycyA9ICgpID0+IHtcbiAgcmV0dXJuIChfcGxhdGZvcm1IZWFkZXJzID8/PSBnZXRQbGF0Zm9ybVByb3BlcnRpZXMoKSk7XG59O1xuXG5leHBvcnQgY29uc3Qgc2FmZUpTT04gPSAodGV4dDogc3RyaW5nKSA9PiB7XG4gIHRyeSB7XG4gICAgcmV0dXJuIEpTT04ucGFyc2UodGV4dCk7XG4gIH0gY2F0Y2ggKGVycikge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbn07XG5cbi8vIGh0dHBzOi8vc3RhY2tvdmVyZmxvdy5jb20vYS8xOTcwOTg0NlxuY29uc3Qgc3RhcnRzV2l0aFNjaGVtZVJlZ2V4cCA9IG5ldyBSZWdFeHAoJ14oPzpbYS16XSs6KT8vLycsICdpJyk7XG5jb25zdCBpc0Fic29sdXRlVVJMID0gKHVybDogc3RyaW5nKTogYm9vbGVhbiA9PiB7XG4gIHJldHVybiBzdGFydHNXaXRoU2NoZW1lUmVnZXhwLnRlc3QodXJsKTtcbn07XG5cbmV4cG9ydCBjb25zdCBzbGVlcCA9IChtczogbnVtYmVyKSA9PiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4gc2V0VGltZW91dChyZXNvbHZlLCBtcykpO1xuXG5jb25zdCB2YWxpZGF0ZVBvc2l0aXZlSW50ZWdlciA9IChuYW1lOiBzdHJpbmcsIG46IHVua25vd24pOiBudW1iZXIgPT4ge1xuICBpZiAodHlwZW9mIG4gIT09ICdudW1iZXInIHx8ICFOdW1iZXIuaXNJbnRlZ2VyKG4pKSB7XG4gICAgdGhyb3cgbmV3IEFudGhyb3BpY0Vycm9yKGAke25hbWV9IG11c3QgYmUgYW4gaW50ZWdlcmApO1xuICB9XG4gIGlmIChuIDwgMCkge1xuICAgIHRocm93IG5ldyBBbnRocm9waWNFcnJvcihgJHtuYW1lfSBtdXN0IGJlIGEgcG9zaXRpdmUgaW50ZWdlcmApO1xuICB9XG4gIHJldHVybiBuO1xufTtcblxuZXhwb3J0IGNvbnN0IGNhc3RUb0Vycm9yID0gKGVycjogYW55KTogRXJyb3IgPT4ge1xuICBpZiAoZXJyIGluc3RhbmNlb2YgRXJyb3IpIHJldHVybiBlcnI7XG4gIGlmICh0eXBlb2YgZXJyID09PSAnb2JqZWN0JyAmJiBlcnIgIT09IG51bGwpIHtcbiAgICB0cnkge1xuICAgICAgcmV0dXJuIG5ldyBFcnJvcihKU09OLnN0cmluZ2lmeShlcnIpKTtcbiAgICB9IGNhdGNoIHt9XG4gIH1cbiAgcmV0dXJuIG5ldyBFcnJvcihTdHJpbmcoZXJyKSk7XG59O1xuXG5leHBvcnQgY29uc3QgZW5zdXJlUHJlc2VudCA9IDxUPih2YWx1ZTogVCB8IG51bGwgfCB1bmRlZmluZWQpOiBUID0+IHtcbiAgaWYgKHZhbHVlID09IG51bGwpIHRocm93IG5ldyBBbnRocm9waWNFcnJvcihgRXhwZWN0ZWQgYSB2YWx1ZSB0byBiZSBnaXZlbiBidXQgcmVjZWl2ZWQgJHt2YWx1ZX0gaW5zdGVhZC5gKTtcbiAgcmV0dXJuIHZhbHVlO1xufTtcblxuLyoqXG4gKiBSZWFkIGFuIGVudmlyb25tZW50IHZhcmlhYmxlLlxuICpcbiAqIFRyaW1zIGJlZ2lubmluZyBhbmQgdHJhaWxpbmcgd2hpdGVzcGFjZS5cbiAqXG4gKiBXaWxsIHJldHVybiB1bmRlZmluZWQgaWYgdGhlIGVudmlyb25tZW50IHZhcmlhYmxlIGRvZXNuJ3QgZXhpc3Qgb3IgY2Fubm90IGJlIGFjY2Vzc2VkLlxuICovXG5leHBvcnQgY29uc3QgcmVhZEVudiA9IChlbnY6IHN0cmluZyk6IHN0cmluZyB8IHVuZGVmaW5lZCA9PiB7XG4gIGlmICh0eXBlb2YgcHJvY2VzcyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm4gcHJvY2Vzcy5lbnY/LltlbnZdPy50cmltKCkgPz8gdW5kZWZpbmVkO1xuICB9XG4gIGlmICh0eXBlb2YgRGVubyAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm4gRGVuby5lbnY/LmdldD8uKGVudik/LnRyaW0oKTtcbiAgfVxuICByZXR1cm4gdW5kZWZpbmVkO1xufTtcblxuZXhwb3J0IGNvbnN0IGNvZXJjZUludGVnZXIgPSAodmFsdWU6IHVua25vd24pOiBudW1iZXIgPT4ge1xuICBpZiAodHlwZW9mIHZhbHVlID09PSAnbnVtYmVyJykgcmV0dXJuIE1hdGgucm91bmQodmFsdWUpO1xuICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykgcmV0dXJuIHBhcnNlSW50KHZhbHVlLCAxMCk7XG5cbiAgdGhyb3cgbmV3IEFudGhyb3BpY0Vycm9yKGBDb3VsZCBub3QgY29lcmNlICR7dmFsdWV9ICh0eXBlOiAke3R5cGVvZiB2YWx1ZX0pIGludG8gYSBudW1iZXJgKTtcbn07XG5cbmV4cG9ydCBjb25zdCBjb2VyY2VGbG9hdCA9ICh2YWx1ZTogdW5rbm93bik6IG51bWJlciA9PiB7XG4gIGlmICh0eXBlb2YgdmFsdWUgPT09ICdudW1iZXInKSByZXR1cm4gdmFsdWU7XG4gIGlmICh0eXBlb2YgdmFsdWUgPT09ICdzdHJpbmcnKSByZXR1cm4gcGFyc2VGbG9hdCh2YWx1ZSk7XG5cbiAgdGhyb3cgbmV3IEFudGhyb3BpY0Vycm9yKGBDb3VsZCBub3QgY29lcmNlICR7dmFsdWV9ICh0eXBlOiAke3R5cGVvZiB2YWx1ZX0pIGludG8gYSBudW1iZXJgKTtcbn07XG5cbmV4cG9ydCBjb25zdCBjb2VyY2VCb29sZWFuID0gKHZhbHVlOiB1bmtub3duKTogYm9vbGVhbiA9PiB7XG4gIGlmICh0eXBlb2YgdmFsdWUgPT09ICdib29sZWFuJykgcmV0dXJuIHZhbHVlO1xuICBpZiAodHlwZW9mIHZhbHVlID09PSAnc3RyaW5nJykgcmV0dXJuIHZhbHVlID09PSAndHJ1ZSc7XG4gIHJldHVybiBCb29sZWFuKHZhbHVlKTtcbn07XG5cbmV4cG9ydCBjb25zdCBtYXliZUNvZXJjZUludGVnZXIgPSAodmFsdWU6IHVua25vd24pOiBudW1iZXIgfCB1bmRlZmluZWQgPT4ge1xuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIGNvZXJjZUludGVnZXIodmFsdWUpO1xufTtcblxuZXhwb3J0IGNvbnN0IG1heWJlQ29lcmNlRmxvYXQgPSAodmFsdWU6IHVua25vd24pOiBudW1iZXIgfCB1bmRlZmluZWQgPT4ge1xuICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCkge1xuICAgIHJldHVybiB1bmRlZmluZWQ7XG4gIH1cbiAgcmV0dXJuIGNvZXJjZUZsb2F0KHZhbHVlKTtcbn07XG5cbmV4cG9ydCBjb25zdCBtYXliZUNvZXJjZUJvb2xlYW4gPSAodmFsdWU6IHVua25vd24pOiBib29sZWFuIHwgdW5kZWZpbmVkID0+IHtcbiAgaWYgKHZhbHVlID09PSB1bmRlZmluZWQpIHtcbiAgICByZXR1cm4gdW5kZWZpbmVkO1xuICB9XG4gIHJldHVybiBjb2VyY2VCb29sZWFuKHZhbHVlKTtcbn07XG5cbi8vIGh0dHBzOi8vc3RhY2tvdmVyZmxvdy5jb20vYS8zNDQ5MTI4N1xuZXhwb3J0IGZ1bmN0aW9uIGlzRW1wdHlPYmoob2JqOiBPYmplY3QgfCBudWxsIHwgdW5kZWZpbmVkKTogYm9vbGVhbiB7XG4gIGlmICghb2JqKSByZXR1cm4gdHJ1ZTtcbiAgZm9yIChjb25zdCBfayBpbiBvYmopIHJldHVybiBmYWxzZTtcbiAgcmV0dXJuIHRydWU7XG59XG5cbi8vIGh0dHBzOi8vZXNsaW50Lm9yZy9kb2NzL2xhdGVzdC9ydWxlcy9uby1wcm90b3R5cGUtYnVpbHRpbnNcbmV4cG9ydCBmdW5jdGlvbiBoYXNPd24ob2JqOiBPYmplY3QsIGtleTogc3RyaW5nKTogYm9vbGVhbiB7XG4gIHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBrZXkpO1xufVxuXG4vKipcbiAqIENvcGllcyBoZWFkZXJzIGZyb20gXCJuZXdIZWFkZXJzXCIgb250byBcInRhcmdldEhlYWRlcnNcIixcbiAqIHVzaW5nIGxvd2VyLWNhc2UgZm9yIGFsbCBwcm9wZXJ0aWVzLFxuICogaWdub3JpbmcgYW55IGtleXMgd2l0aCB1bmRlZmluZWQgdmFsdWVzLFxuICogYW5kIGRlbGV0aW5nIGFueSBrZXlzIHdpdGggbnVsbCB2YWx1ZXMuXG4gKi9cbmZ1bmN0aW9uIGFwcGx5SGVhZGVyc011dCh0YXJnZXRIZWFkZXJzOiBIZWFkZXJzLCBuZXdIZWFkZXJzOiBIZWFkZXJzKTogdm9pZCB7XG4gIGZvciAoY29uc3QgayBpbiBuZXdIZWFkZXJzKSB7XG4gICAgaWYgKCFoYXNPd24obmV3SGVhZGVycywgaykpIGNvbnRpbnVlO1xuICAgIGNvbnN0IGxvd2VyS2V5ID0gay50b0xvd2VyQ2FzZSgpO1xuICAgIGlmICghbG93ZXJLZXkpIGNvbnRpbnVlO1xuXG4gICAgY29uc3QgdmFsID0gbmV3SGVhZGVyc1trXTtcblxuICAgIGlmICh2YWwgPT09IG51bGwpIHtcbiAgICAgIGRlbGV0ZSB0YXJnZXRIZWFkZXJzW2xvd2VyS2V5XTtcbiAgICB9IGVsc2UgaWYgKHZhbCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICB0YXJnZXRIZWFkZXJzW2xvd2VyS2V5XSA9IHZhbDtcbiAgICB9XG4gIH1cbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRlYnVnKGFjdGlvbjogc3RyaW5nLCAuLi5hcmdzOiBhbnlbXSkge1xuICBpZiAodHlwZW9mIHByb2Nlc3MgIT09ICd1bmRlZmluZWQnICYmIHByb2Nlc3M/LmVudj8uWydERUJVRyddID09PSAndHJ1ZScpIHtcbiAgICBjb25zb2xlLmxvZyhgQW50aHJvcGljOkRFQlVHOiR7YWN0aW9ufWAsIC4uLmFyZ3MpO1xuICB9XG59XG5cbi8qKlxuICogaHR0cHM6Ly9zdGFja292ZXJmbG93LmNvbS9hLzIxMTc1MjNcbiAqL1xuY29uc3QgdXVpZDQgPSAoKSA9PiB7XG4gIHJldHVybiAneHh4eHh4eHgteHh4eC00eHh4LXl4eHgteHh4eHh4eHh4eHh4Jy5yZXBsYWNlKC9beHldL2csIChjKSA9PiB7XG4gICAgY29uc3QgciA9IChNYXRoLnJhbmRvbSgpICogMTYpIHwgMDtcbiAgICBjb25zdCB2ID0gYyA9PT0gJ3gnID8gciA6IChyICYgMHgzKSB8IDB4ODtcbiAgICByZXR1cm4gdi50b1N0cmluZygxNik7XG4gIH0pO1xufTtcblxuZXhwb3J0IGNvbnN0IGlzUnVubmluZ0luQnJvd3NlciA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICAvLyBAdHMtaWdub3JlXG4gICAgdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICAvLyBAdHMtaWdub3JlXG4gICAgdHlwZW9mIHdpbmRvdy5kb2N1bWVudCAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICAvLyBAdHMtaWdub3JlXG4gICAgdHlwZW9mIG5hdmlnYXRvciAhPT0gJ3VuZGVmaW5lZCdcbiAgKTtcbn07XG5cbmV4cG9ydCBpbnRlcmZhY2UgSGVhZGVyc1Byb3RvY29sIHtcbiAgZ2V0OiAoaGVhZGVyOiBzdHJpbmcpID0+IHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQ7XG59XG5leHBvcnQgdHlwZSBIZWFkZXJzTGlrZSA9IFJlY29yZDxzdHJpbmcsIHN0cmluZyB8IHN0cmluZ1tdIHwgdW5kZWZpbmVkPiB8IEhlYWRlcnNQcm90b2NvbDtcblxuZXhwb3J0IGNvbnN0IGlzSGVhZGVyc1Byb3RvY29sID0gKGhlYWRlcnM6IGFueSk6IGhlYWRlcnMgaXMgSGVhZGVyc1Byb3RvY29sID0+IHtcbiAgcmV0dXJuIHR5cGVvZiBoZWFkZXJzPy5nZXQgPT09ICdmdW5jdGlvbic7XG59O1xuXG5leHBvcnQgY29uc3QgZ2V0UmVxdWlyZWRIZWFkZXIgPSAoaGVhZGVyczogSGVhZGVyc0xpa2UgfCBIZWFkZXJzLCBoZWFkZXI6IHN0cmluZyk6IHN0cmluZyA9PiB7XG4gIGNvbnN0IGZvdW5kSGVhZGVyID0gZ2V0SGVhZGVyKGhlYWRlcnMsIGhlYWRlcik7XG4gIGlmIChmb3VuZEhlYWRlciA9PT0gdW5kZWZpbmVkKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKGBDb3VsZCBub3QgZmluZCAke2hlYWRlcn0gaGVhZGVyYCk7XG4gIH1cbiAgcmV0dXJuIGZvdW5kSGVhZGVyO1xufTtcblxuZXhwb3J0IGNvbnN0IGdldEhlYWRlciA9IChoZWFkZXJzOiBIZWFkZXJzTGlrZSB8IEhlYWRlcnMsIGhlYWRlcjogc3RyaW5nKTogc3RyaW5nIHwgdW5kZWZpbmVkID0+IHtcbiAgY29uc3QgbG93ZXJDYXNlZEhlYWRlciA9IGhlYWRlci50b0xvd2VyQ2FzZSgpO1xuICBpZiAoaXNIZWFkZXJzUHJvdG9jb2woaGVhZGVycykpIHtcbiAgICAvLyB0byBkZWFsIHdpdGggdGhlIGNhc2Ugd2hlcmUgdGhlIGhlYWRlciBsb29rcyBsaWtlIFN0YWlubGVzcy1FdmVudC1JZFxuICAgIGNvbnN0IGludGVyY2Fwc0hlYWRlciA9XG4gICAgICBoZWFkZXJbMF0/LnRvVXBwZXJDYXNlKCkgK1xuICAgICAgaGVhZGVyLnN1YnN0cmluZygxKS5yZXBsYWNlKC8oW15cXHddKShcXHcpL2csIChfbSwgZzEsIGcyKSA9PiBnMSArIGcyLnRvVXBwZXJDYXNlKCkpO1xuICAgIGZvciAoY29uc3Qga2V5IG9mIFtoZWFkZXIsIGxvd2VyQ2FzZWRIZWFkZXIsIGhlYWRlci50b1VwcGVyQ2FzZSgpLCBpbnRlcmNhcHNIZWFkZXJdKSB7XG4gICAgICBjb25zdCB2YWx1ZSA9IGhlYWRlcnMuZ2V0KGtleSk7XG4gICAgICBpZiAodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgfVxuICAgIH1cbiAgfVxuXG4gIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIE9iamVjdC5lbnRyaWVzKGhlYWRlcnMpKSB7XG4gICAgaWYgKGtleS50b0xvd2VyQ2FzZSgpID09PSBsb3dlckNhc2VkSGVhZGVyKSB7XG4gICAgICBpZiAoQXJyYXkuaXNBcnJheSh2YWx1ZSkpIHtcbiAgICAgICAgaWYgKHZhbHVlLmxlbmd0aCA8PSAxKSByZXR1cm4gdmFsdWVbMF07XG4gICAgICAgIGNvbnNvbGUud2FybihgUmVjZWl2ZWQgJHt2YWx1ZS5sZW5ndGh9IGVudHJpZXMgZm9yIHRoZSAke2hlYWRlcn0gaGVhZGVyLCB1c2luZyB0aGUgZmlyc3QgZW50cnkuYCk7XG4gICAgICAgIHJldHVybiB2YWx1ZVswXTtcbiAgICAgIH1cbiAgICAgIHJldHVybiB2YWx1ZTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gdW5kZWZpbmVkO1xufTtcblxuLyoqXG4gKiBFbmNvZGVzIGEgc3RyaW5nIHRvIEJhc2U2NCBmb3JtYXQuXG4gKi9cbmV4cG9ydCBjb25zdCB0b0Jhc2U2NCA9IChzdHI6IHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQpOiBzdHJpbmcgPT4ge1xuICBpZiAoIXN0cikgcmV0dXJuICcnO1xuICBpZiAodHlwZW9mIEJ1ZmZlciAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm4gQnVmZmVyLmZyb20oc3RyKS50b1N0cmluZygnYmFzZTY0Jyk7XG4gIH1cblxuICBpZiAodHlwZW9mIGJ0b2EgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgcmV0dXJuIGJ0b2Eoc3RyKTtcbiAgfVxuXG4gIHRocm93IG5ldyBBbnRocm9waWNFcnJvcignQ2Fubm90IGdlbmVyYXRlIGI2NCBzdHJpbmc7IEV4cGVjdGVkIGBCdWZmZXJgIG9yIGBidG9hYCB0byBiZSBkZWZpbmVkJyk7XG59O1xuXG5leHBvcnQgZnVuY3Rpb24gaXNPYmoob2JqOiB1bmtub3duKTogb2JqIGlzIFJlY29yZDxzdHJpbmcsIHVua25vd24+IHtcbiAgcmV0dXJuIG9iaiAhPSBudWxsICYmIHR5cGVvZiBvYmogPT09ICdvYmplY3QnICYmICFBcnJheS5pc0FycmF5KG9iaik7XG59XG4iLCAiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cblxuaW1wb3J0ICogYXMgQ29yZSBmcm9tIFwiLi9jb3JlLmpzXCI7XG5cbmV4cG9ydCBjbGFzcyBBUElSZXNvdXJjZSB7XG4gIHByb3RlY3RlZCBfY2xpZW50OiBDb3JlLkFQSUNsaWVudDtcblxuICBjb25zdHJ1Y3RvcihjbGllbnQ6IENvcmUuQVBJQ2xpZW50KSB7XG4gICAgdGhpcy5fY2xpZW50ID0gY2xpZW50O1xuICB9XG59XG4iLCAidHlwZSBUb2tlbiA9IHtcbiAgdHlwZTogc3RyaW5nO1xuICB2YWx1ZTogc3RyaW5nO1xufTtcblxuY29uc3QgdG9rZW5pemUgPSAoaW5wdXQ6IHN0cmluZyk6IFRva2VuW10gPT4ge1xuICAgIGxldCBjdXJyZW50ID0gMDtcbiAgICBsZXQgdG9rZW5zOiBUb2tlbltdID0gW107XG5cbiAgICB3aGlsZSAoY3VycmVudCA8IGlucHV0Lmxlbmd0aCkge1xuICAgICAgbGV0IGNoYXIgPSBpbnB1dFtjdXJyZW50XTtcblxuICAgICAgaWYgKGNoYXIgPT09ICdcXFxcJykge1xuICAgICAgICBjdXJyZW50Kys7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICBpZiAoY2hhciA9PT0gJ3snKSB7XG4gICAgICAgIHRva2Vucy5wdXNoKHtcbiAgICAgICAgICB0eXBlOiAnYnJhY2UnLFxuICAgICAgICAgIHZhbHVlOiAneycsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGN1cnJlbnQrKztcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG5cbiAgICAgIGlmIChjaGFyID09PSAnfScpIHtcbiAgICAgICAgdG9rZW5zLnB1c2goe1xuICAgICAgICAgIHR5cGU6ICdicmFjZScsXG4gICAgICAgICAgdmFsdWU6ICd9JyxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY3VycmVudCsrO1xuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cblxuICAgICAgaWYgKGNoYXIgPT09ICdbJykge1xuICAgICAgICB0b2tlbnMucHVzaCh7XG4gICAgICAgICAgdHlwZTogJ3BhcmVuJyxcbiAgICAgICAgICB2YWx1ZTogJ1snLFxuICAgICAgICB9KTtcblxuICAgICAgICBjdXJyZW50Kys7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICBpZiAoY2hhciA9PT0gJ10nKSB7XG4gICAgICAgIHRva2Vucy5wdXNoKHtcbiAgICAgICAgICB0eXBlOiAncGFyZW4nLFxuICAgICAgICAgIHZhbHVlOiAnXScsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGN1cnJlbnQrKztcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG5cbiAgICAgIGlmIChjaGFyID09PSAnOicpIHtcbiAgICAgICAgdG9rZW5zLnB1c2goe1xuICAgICAgICAgIHR5cGU6ICdzZXBhcmF0b3InLFxuICAgICAgICAgIHZhbHVlOiAnOicsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGN1cnJlbnQrKztcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG5cbiAgICAgIGlmIChjaGFyID09PSAnLCcpIHtcbiAgICAgICAgdG9rZW5zLnB1c2goe1xuICAgICAgICAgIHR5cGU6ICdkZWxpbWl0ZXInLFxuICAgICAgICAgIHZhbHVlOiAnLCcsXG4gICAgICAgIH0pO1xuXG4gICAgICAgIGN1cnJlbnQrKztcbiAgICAgICAgY29udGludWU7XG4gICAgICB9XG5cbiAgICAgIGlmIChjaGFyID09PSAnXCInKSB7XG4gICAgICAgIGxldCB2YWx1ZSA9ICcnO1xuICAgICAgICBsZXQgZGFuZ2xpbmdRdW90ZSA9IGZhbHNlO1xuXG4gICAgICAgIGNoYXIgPSBpbnB1dFsrK2N1cnJlbnRdO1xuXG4gICAgICAgIHdoaWxlIChjaGFyICE9PSAnXCInKSB7XG4gICAgICAgICAgaWYgKGN1cnJlbnQgPT09IGlucHV0Lmxlbmd0aCkge1xuICAgICAgICAgICAgZGFuZ2xpbmdRdW90ZSA9IHRydWU7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoY2hhciA9PT0gJ1xcXFwnKSB7XG4gICAgICAgICAgICBjdXJyZW50Kys7XG4gICAgICAgICAgICBpZiAoY3VycmVudCA9PT0gaW5wdXQubGVuZ3RoKSB7XG4gICAgICAgICAgICAgIGRhbmdsaW5nUXVvdGUgPSB0cnVlO1xuICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHZhbHVlICs9IGNoYXIgKyBpbnB1dFtjdXJyZW50XTtcbiAgICAgICAgICAgIGNoYXIgPSBpbnB1dFsrK2N1cnJlbnRdO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICB2YWx1ZSArPSBjaGFyO1xuICAgICAgICAgICAgY2hhciA9IGlucHV0WysrY3VycmVudF07XG4gICAgICAgICAgfVxuICAgICAgICB9XG5cbiAgICAgICAgY2hhciA9IGlucHV0WysrY3VycmVudF07XG5cbiAgICAgICAgaWYgKCFkYW5nbGluZ1F1b3RlKSB7XG4gICAgICAgICAgdG9rZW5zLnB1c2goe1xuICAgICAgICAgICAgdHlwZTogJ3N0cmluZycsXG4gICAgICAgICAgICB2YWx1ZSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cblxuICAgICAgbGV0IFdISVRFU1BBQ0UgPSAvXFxzLztcbiAgICAgIGlmIChjaGFyICYmIFdISVRFU1BBQ0UudGVzdChjaGFyKSkge1xuICAgICAgICBjdXJyZW50Kys7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICBsZXQgTlVNQkVSUyA9IC9bMC05XS87XG4gICAgICBpZiAoKGNoYXIgJiYgTlVNQkVSUy50ZXN0KGNoYXIpKSB8fCBjaGFyID09PSAnLScgfHwgY2hhciA9PT0gJy4nKSB7XG4gICAgICAgIGxldCB2YWx1ZSA9ICcnO1xuXG4gICAgICAgIGlmIChjaGFyID09PSAnLScpIHtcbiAgICAgICAgICB2YWx1ZSArPSBjaGFyO1xuICAgICAgICAgIGNoYXIgPSBpbnB1dFsrK2N1cnJlbnRdO1xuICAgICAgICB9XG5cbiAgICAgICAgd2hpbGUgKChjaGFyICYmIE5VTUJFUlMudGVzdChjaGFyKSkgfHwgY2hhciA9PT0gJy4nKSB7XG4gICAgICAgICAgdmFsdWUgKz0gY2hhcjtcbiAgICAgICAgICBjaGFyID0gaW5wdXRbKytjdXJyZW50XTtcbiAgICAgICAgfVxuXG4gICAgICAgIHRva2Vucy5wdXNoKHtcbiAgICAgICAgICB0eXBlOiAnbnVtYmVyJyxcbiAgICAgICAgICB2YWx1ZSxcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnRpbnVlO1xuICAgICAgfVxuXG4gICAgICBsZXQgTEVUVEVSUyA9IC9bYS16XS9pO1xuICAgICAgaWYgKGNoYXIgJiYgTEVUVEVSUy50ZXN0KGNoYXIpKSB7XG4gICAgICAgIGxldCB2YWx1ZSA9ICcnO1xuXG4gICAgICAgIHdoaWxlIChjaGFyICYmIExFVFRFUlMudGVzdChjaGFyKSkge1xuICAgICAgICAgIGlmIChjdXJyZW50ID09PSBpbnB1dC5sZW5ndGgpIHtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIH1cbiAgICAgICAgICB2YWx1ZSArPSBjaGFyO1xuICAgICAgICAgIGNoYXIgPSBpbnB1dFsrK2N1cnJlbnRdO1xuICAgICAgICB9XG5cbiAgICAgICAgaWYgKHZhbHVlID09ICd0cnVlJyB8fCB2YWx1ZSA9PSAnZmFsc2UnIHx8IHZhbHVlID09PSAnbnVsbCcpIHtcbiAgICAgICAgICB0b2tlbnMucHVzaCh7XG4gICAgICAgICAgICB0eXBlOiAnbmFtZScsXG4gICAgICAgICAgICB2YWx1ZSxcbiAgICAgICAgICB9KTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAvLyB1bmtub3duIHRva2VuLCBlLmcuIGBudWxgIHdoaWNoIGlzbid0IHF1aXRlIGBudWxsYFxuICAgICAgICAgIGN1cnJlbnQrKztcbiAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBjb250aW51ZTtcbiAgICAgIH1cblxuICAgICAgY3VycmVudCsrO1xuICAgIH1cblxuICAgIHJldHVybiB0b2tlbnM7XG4gIH0sXG4gIHN0cmlwID0gKHRva2VuczogVG9rZW5bXSk6IFRva2VuW10gPT4ge1xuICAgIGlmICh0b2tlbnMubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gdG9rZW5zO1xuICAgIH1cblxuICAgIGxldCBsYXN0VG9rZW4gPSB0b2tlbnNbdG9rZW5zLmxlbmd0aCAtIDFdITtcblxuICAgIHN3aXRjaCAobGFzdFRva2VuLnR5cGUpIHtcbiAgICAgIGNhc2UgJ3NlcGFyYXRvcic6XG4gICAgICAgIHRva2VucyA9IHRva2Vucy5zbGljZSgwLCB0b2tlbnMubGVuZ3RoIC0gMSk7XG4gICAgICAgIHJldHVybiBzdHJpcCh0b2tlbnMpO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ251bWJlcic6XG4gICAgICAgIGxldCBsYXN0Q2hhcmFjdGVyT2ZMYXN0VG9rZW4gPSBsYXN0VG9rZW4udmFsdWVbbGFzdFRva2VuLnZhbHVlLmxlbmd0aCAtIDFdO1xuICAgICAgICBpZiAobGFzdENoYXJhY3Rlck9mTGFzdFRva2VuID09PSAnLicgfHwgbGFzdENoYXJhY3Rlck9mTGFzdFRva2VuID09PSAnLScpIHtcbiAgICAgICAgICB0b2tlbnMgPSB0b2tlbnMuc2xpY2UoMCwgdG9rZW5zLmxlbmd0aCAtIDEpO1xuICAgICAgICAgIHJldHVybiBzdHJpcCh0b2tlbnMpO1xuICAgICAgICB9XG4gICAgICBjYXNlICdzdHJpbmcnOlxuICAgICAgICBsZXQgdG9rZW5CZWZvcmVUaGVMYXN0VG9rZW4gPSB0b2tlbnNbdG9rZW5zLmxlbmd0aCAtIDJdO1xuICAgICAgICBpZiAodG9rZW5CZWZvcmVUaGVMYXN0VG9rZW4/LnR5cGUgPT09ICdkZWxpbWl0ZXInKSB7XG4gICAgICAgICAgdG9rZW5zID0gdG9rZW5zLnNsaWNlKDAsIHRva2Vucy5sZW5ndGggLSAxKTtcbiAgICAgICAgICByZXR1cm4gc3RyaXAodG9rZW5zKTtcbiAgICAgICAgfSBlbHNlIGlmICh0b2tlbkJlZm9yZVRoZUxhc3RUb2tlbj8udHlwZSA9PT0gJ2JyYWNlJyAmJiB0b2tlbkJlZm9yZVRoZUxhc3RUb2tlbi52YWx1ZSA9PT0gJ3snKSB7XG4gICAgICAgICAgdG9rZW5zID0gdG9rZW5zLnNsaWNlKDAsIHRva2Vucy5sZW5ndGggLSAxKTtcbiAgICAgICAgICByZXR1cm4gc3RyaXAodG9rZW5zKTtcbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ2RlbGltaXRlcic6XG4gICAgICAgIHRva2VucyA9IHRva2Vucy5zbGljZSgwLCB0b2tlbnMubGVuZ3RoIC0gMSk7XG4gICAgICAgIHJldHVybiBzdHJpcCh0b2tlbnMpO1xuICAgICAgICBicmVhaztcbiAgICB9XG5cbiAgICByZXR1cm4gdG9rZW5zO1xuICB9LFxuICB1bnN0cmlwID0gKHRva2VuczogVG9rZW5bXSk6IFRva2VuW10gPT4ge1xuICAgIGxldCB0YWlsOiBzdHJpbmdbXSA9IFtdO1xuXG4gICAgdG9rZW5zLm1hcCgodG9rZW4pID0+IHtcbiAgICAgIGlmICh0b2tlbi50eXBlID09PSAnYnJhY2UnKSB7XG4gICAgICAgIGlmICh0b2tlbi52YWx1ZSA9PT0gJ3snKSB7XG4gICAgICAgICAgdGFpbC5wdXNoKCd9Jyk7XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgdGFpbC5zcGxpY2UodGFpbC5sYXN0SW5kZXhPZignfScpLCAxKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgaWYgKHRva2VuLnR5cGUgPT09ICdwYXJlbicpIHtcbiAgICAgICAgaWYgKHRva2VuLnZhbHVlID09PSAnWycpIHtcbiAgICAgICAgICB0YWlsLnB1c2goJ10nKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICB0YWlsLnNwbGljZSh0YWlsLmxhc3RJbmRleE9mKCddJyksIDEpO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICBpZiAodGFpbC5sZW5ndGggPiAwKSB7XG4gICAgICB0YWlsLnJldmVyc2UoKS5tYXAoKGl0ZW0pID0+IHtcbiAgICAgICAgaWYgKGl0ZW0gPT09ICd9Jykge1xuICAgICAgICAgIHRva2Vucy5wdXNoKHtcbiAgICAgICAgICAgIHR5cGU6ICdicmFjZScsXG4gICAgICAgICAgICB2YWx1ZTogJ30nLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9IGVsc2UgaWYgKGl0ZW0gPT09ICddJykge1xuICAgICAgICAgIHRva2Vucy5wdXNoKHtcbiAgICAgICAgICAgIHR5cGU6ICdwYXJlbicsXG4gICAgICAgICAgICB2YWx1ZTogJ10nLFxuICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICB9KTtcbiAgICB9XG5cbiAgICByZXR1cm4gdG9rZW5zO1xuICB9LFxuICBnZW5lcmF0ZSA9ICh0b2tlbnM6IFRva2VuW10pOiBzdHJpbmcgPT4ge1xuICAgIGxldCBvdXRwdXQgPSAnJztcblxuICAgIHRva2Vucy5tYXAoKHRva2VuKSA9PiB7XG4gICAgICBzd2l0Y2ggKHRva2VuLnR5cGUpIHtcbiAgICAgICAgY2FzZSAnc3RyaW5nJzpcbiAgICAgICAgICBvdXRwdXQgKz0gJ1wiJyArIHRva2VuLnZhbHVlICsgJ1wiJztcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICBvdXRwdXQgKz0gdG9rZW4udmFsdWU7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICByZXR1cm4gb3V0cHV0O1xuICB9LFxuICBwYXJ0aWFsUGFyc2UgPSAoaW5wdXQ6IHN0cmluZyk6IHVua25vd24gPT4gSlNPTi5wYXJzZShnZW5lcmF0ZSh1bnN0cmlwKHN0cmlwKHRva2VuaXplKGlucHV0KSkpKSk7XG5cbmV4cG9ydCB7IHBhcnRpYWxQYXJzZSB9O1xuIiwgImltcG9ydCAqIGFzIENvcmUgZnJvbSBcIi4uL2NvcmUuanNcIjtcbmltcG9ydCB7IEFudGhyb3BpY0Vycm9yLCBBUElVc2VyQWJvcnRFcnJvciB9IGZyb20gXCIuLi9lcnJvci5qc1wiO1xuaW1wb3J0IHsgdHlwZSBDb250ZW50QmxvY2ssIHR5cGUgVGV4dEJsb2NrIH0gZnJvbSBcIi4uL3Jlc291cmNlcy9tZXNzYWdlcy5qc1wiO1xuaW1wb3J0IHtcbiAgTWVzc2FnZXMsXG4gIHR5cGUgUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlLFxuICB0eXBlIFJhd1Byb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbUV2ZW50LFxuICB0eXBlIFByb21wdENhY2hpbmdCZXRhTWVzc2FnZVBhcmFtLFxuICB0eXBlIE1lc3NhZ2VDcmVhdGVQYXJhbXMsXG4gIHR5cGUgTWVzc2FnZUNyZWF0ZVBhcmFtc0Jhc2UsXG59IGZyb20gXCIuLi9yZXNvdXJjZXMvYmV0YS9wcm9tcHQtY2FjaGluZy9tZXNzYWdlcy5qc1wiO1xuaW1wb3J0IHsgdHlwZSBSZWFkYWJsZVN0cmVhbSB9IGZyb20gXCIuLi9fc2hpbXMvaW5kZXguanNcIjtcbmltcG9ydCB7IFN0cmVhbSB9IGZyb20gXCIuLi9zdHJlYW1pbmcuanNcIjtcbmltcG9ydCB7IHBhcnRpYWxQYXJzZSB9IGZyb20gXCIuLi9fdmVuZG9yL3BhcnRpYWwtanNvbi1wYXJzZXIvcGFyc2VyLmpzXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlU3RyZWFtRXZlbnRzIHtcbiAgY29ubmVjdDogKCkgPT4gdm9pZDtcbiAgc3RyZWFtRXZlbnQ6IChldmVudDogUmF3UHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlU3RyZWFtRXZlbnQsIHNuYXBzaG90OiBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2UpID0+IHZvaWQ7XG4gIHRleHQ6ICh0ZXh0RGVsdGE6IHN0cmluZywgdGV4dFNuYXBzaG90OiBzdHJpbmcpID0+IHZvaWQ7XG4gIGlucHV0SnNvbjogKHBhcnRpYWxKc29uOiBzdHJpbmcsIGpzb25TbmFwc2hvdDogdW5rbm93bikgPT4gdm9pZDtcbiAgbWVzc2FnZTogKG1lc3NhZ2U6IFByb21wdENhY2hpbmdCZXRhTWVzc2FnZSkgPT4gdm9pZDtcbiAgY29udGVudEJsb2NrOiAoY29udGVudDogQ29udGVudEJsb2NrKSA9PiB2b2lkO1xuICBmaW5hbFByb21wdENhY2hpbmdCZXRhTWVzc2FnZTogKG1lc3NhZ2U6IFByb21wdENhY2hpbmdCZXRhTWVzc2FnZSkgPT4gdm9pZDtcbiAgZXJyb3I6IChlcnJvcjogQW50aHJvcGljRXJyb3IpID0+IHZvaWQ7XG4gIGFib3J0OiAoZXJyb3I6IEFQSVVzZXJBYm9ydEVycm9yKSA9PiB2b2lkO1xuICBlbmQ6ICgpID0+IHZvaWQ7XG59XG5cbnR5cGUgUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlU3RyZWFtRXZlbnRMaXN0ZW5lcnM8RXZlbnQgZXh0ZW5kcyBrZXlvZiBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudHM+ID1cbiAge1xuICAgIGxpc3RlbmVyOiBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudHNbRXZlbnRdO1xuICAgIG9uY2U/OiBib29sZWFuO1xuICB9W107XG5cbmNvbnN0IEpTT05fQlVGX1BST1BFUlRZID0gJ19fanNvbl9idWYnO1xuXG5leHBvcnQgY2xhc3MgUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlU3RyZWFtIGltcGxlbWVudHMgQXN5bmNJdGVyYWJsZTxSYXdQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudD4ge1xuICBtZXNzYWdlczogUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlUGFyYW1bXSA9IFtdO1xuICByZWNlaXZlZE1lc3NhZ2VzOiBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VbXSA9IFtdO1xuICAjY3VycmVudE1lc3NhZ2VTbmFwc2hvdDogUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlIHwgdW5kZWZpbmVkO1xuXG4gIGNvbnRyb2xsZXI6IEFib3J0Q29udHJvbGxlciA9IG5ldyBBYm9ydENvbnRyb2xsZXIoKTtcblxuICAjY29ubmVjdGVkUHJvbWlzZTogUHJvbWlzZTx2b2lkPjtcbiAgI3Jlc29sdmVDb25uZWN0ZWRQcm9taXNlOiAoKSA9PiB2b2lkID0gKCkgPT4ge307XG4gICNyZWplY3RDb25uZWN0ZWRQcm9taXNlOiAoZXJyb3I6IEFudGhyb3BpY0Vycm9yKSA9PiB2b2lkID0gKCkgPT4ge307XG5cbiAgI2VuZFByb21pc2U6IFByb21pc2U8dm9pZD47XG4gICNyZXNvbHZlRW5kUHJvbWlzZTogKCkgPT4gdm9pZCA9ICgpID0+IHt9O1xuICAjcmVqZWN0RW5kUHJvbWlzZTogKGVycm9yOiBBbnRocm9waWNFcnJvcikgPT4gdm9pZCA9ICgpID0+IHt9O1xuXG4gICNsaXN0ZW5lcnM6IHtcbiAgICBbRXZlbnQgaW4ga2V5b2YgUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlU3RyZWFtRXZlbnRzXT86IFByb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbUV2ZW50TGlzdGVuZXJzPEV2ZW50PjtcbiAgfSA9IHt9O1xuXG4gICNlbmRlZCA9IGZhbHNlO1xuICAjZXJyb3JlZCA9IGZhbHNlO1xuICAjYWJvcnRlZCA9IGZhbHNlO1xuICAjY2F0Y2hpbmdQcm9taXNlQ3JlYXRlZCA9IGZhbHNlO1xuXG4gIGNvbnN0cnVjdG9yKCkge1xuICAgIHRoaXMuI2Nvbm5lY3RlZFByb21pc2UgPSBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICB0aGlzLiNyZXNvbHZlQ29ubmVjdGVkUHJvbWlzZSA9IHJlc29sdmU7XG4gICAgICB0aGlzLiNyZWplY3RDb25uZWN0ZWRQcm9taXNlID0gcmVqZWN0O1xuICAgIH0pO1xuXG4gICAgdGhpcy4jZW5kUHJvbWlzZSA9IG5ldyBQcm9taXNlPHZvaWQ+KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgIHRoaXMuI3Jlc29sdmVFbmRQcm9taXNlID0gcmVzb2x2ZTtcbiAgICAgIHRoaXMuI3JlamVjdEVuZFByb21pc2UgPSByZWplY3Q7XG4gICAgfSk7XG5cbiAgICAvLyBEb24ndCBsZXQgdGhlc2UgcHJvbWlzZXMgY2F1c2UgdW5oYW5kbGVkIHJlamVjdGlvbiBlcnJvcnMuXG4gICAgLy8gd2Ugd2lsbCBtYW51YWxseSBjYXVzZSBhbiB1bmhhbmRsZWQgcmVqZWN0aW9uIGVycm9yIGxhdGVyXG4gICAgLy8gaWYgdGhlIHVzZXIgaGFzbid0IHJlZ2lzdGVyZWQgYW55IGVycm9yIGxpc3RlbmVyIG9yIGNhbGxlZFxuICAgIC8vIGFueSBwcm9taXNlLXJldHVybmluZyBtZXRob2QuXG4gICAgdGhpcy4jY29ubmVjdGVkUHJvbWlzZS5jYXRjaCgoKSA9PiB7fSk7XG4gICAgdGhpcy4jZW5kUHJvbWlzZS5jYXRjaCgoKSA9PiB7fSk7XG4gIH1cblxuICAvKipcbiAgICogSW50ZW5kZWQgZm9yIHVzZSBvbiB0aGUgZnJvbnRlbmQsIGNvbnN1bWluZyBhIHN0cmVhbSBwcm9kdWNlZCB3aXRoXG4gICAqIGAudG9SZWFkYWJsZVN0cmVhbSgpYCBvbiB0aGUgYmFja2VuZC5cbiAgICpcbiAgICogTm90ZSB0aGF0IG1lc3NhZ2VzIHNlbnQgdG8gdGhlIG1vZGVsIGRvIG5vdCBhcHBlYXIgaW4gYC5vbignbWVzc2FnZScpYFxuICAgKiBpbiB0aGlzIGNvbnRleHQuXG4gICAqL1xuICBzdGF0aWMgZnJvbVJlYWRhYmxlU3RyZWFtKHN0cmVhbTogUmVhZGFibGVTdHJlYW0pOiBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW0ge1xuICAgIGNvbnN0IHJ1bm5lciA9IG5ldyBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW0oKTtcbiAgICBydW5uZXIuX3J1bigoKSA9PiBydW5uZXIuX2Zyb21SZWFkYWJsZVN0cmVhbShzdHJlYW0pKTtcbiAgICByZXR1cm4gcnVubmVyO1xuICB9XG5cbiAgc3RhdGljIGNyZWF0ZU1lc3NhZ2UoXG4gICAgbWVzc2FnZXM6IE1lc3NhZ2VzLFxuICAgIHBhcmFtczogTWVzc2FnZUNyZWF0ZVBhcmFtc0Jhc2UsXG4gICAgb3B0aW9ucz86IENvcmUuUmVxdWVzdE9wdGlvbnMsXG4gICk6IFByb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbSB7XG4gICAgY29uc3QgcnVubmVyID0gbmV3IFByb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbSgpO1xuICAgIGZvciAoY29uc3QgbWVzc2FnZSBvZiBwYXJhbXMubWVzc2FnZXMpIHtcbiAgICAgIHJ1bm5lci5fYWRkUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlUGFyYW0obWVzc2FnZSk7XG4gICAgfVxuICAgIHJ1bm5lci5fcnVuKCgpID0+XG4gICAgICBydW5uZXIuX2NyZWF0ZVByb21wdENhY2hpbmdCZXRhTWVzc2FnZShcbiAgICAgICAgbWVzc2FnZXMsXG4gICAgICAgIHsgLi4ucGFyYW1zLCBzdHJlYW06IHRydWUgfSxcbiAgICAgICAgeyAuLi5vcHRpb25zLCBoZWFkZXJzOiB7IC4uLm9wdGlvbnM/LmhlYWRlcnMsICdYLVN0YWlubGVzcy1IZWxwZXItTWV0aG9kJzogJ3N0cmVhbScgfSB9LFxuICAgICAgKSxcbiAgICApO1xuICAgIHJldHVybiBydW5uZXI7XG4gIH1cblxuICBwcm90ZWN0ZWQgX3J1bihleGVjdXRvcjogKCkgPT4gUHJvbWlzZTxhbnk+KSB7XG4gICAgZXhlY3V0b3IoKS50aGVuKCgpID0+IHtcbiAgICAgIHRoaXMuX2VtaXRGaW5hbCgpO1xuICAgICAgdGhpcy5fZW1pdCgnZW5kJyk7XG4gICAgfSwgdGhpcy4jaGFuZGxlRXJyb3IpO1xuICB9XG5cbiAgcHJvdGVjdGVkIF9hZGRQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VQYXJhbShtZXNzYWdlOiBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VQYXJhbSkge1xuICAgIHRoaXMubWVzc2FnZXMucHVzaChtZXNzYWdlKTtcbiAgfVxuXG4gIHByb3RlY3RlZCBfYWRkUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlKG1lc3NhZ2U6IFByb21wdENhY2hpbmdCZXRhTWVzc2FnZSwgZW1pdCA9IHRydWUpIHtcbiAgICB0aGlzLnJlY2VpdmVkTWVzc2FnZXMucHVzaChtZXNzYWdlKTtcbiAgICBpZiAoZW1pdCkge1xuICAgICAgdGhpcy5fZW1pdCgnbWVzc2FnZScsIG1lc3NhZ2UpO1xuICAgIH1cbiAgfVxuXG4gIHByb3RlY3RlZCBhc3luYyBfY3JlYXRlUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlKFxuICAgIG1lc3NhZ2VzOiBNZXNzYWdlcyxcbiAgICBwYXJhbXM6IE1lc3NhZ2VDcmVhdGVQYXJhbXMsXG4gICAgb3B0aW9ucz86IENvcmUuUmVxdWVzdE9wdGlvbnMsXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IHNpZ25hbCA9IG9wdGlvbnM/LnNpZ25hbDtcbiAgICBpZiAoc2lnbmFsKSB7XG4gICAgICBpZiAoc2lnbmFsLmFib3J0ZWQpIHRoaXMuY29udHJvbGxlci5hYm9ydCgpO1xuICAgICAgc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2Fib3J0JywgKCkgPT4gdGhpcy5jb250cm9sbGVyLmFib3J0KCkpO1xuICAgIH1cbiAgICB0aGlzLiNiZWdpblJlcXVlc3QoKTtcbiAgICBjb25zdCBzdHJlYW0gPSBhd2FpdCBtZXNzYWdlcy5jcmVhdGUoXG4gICAgICB7IC4uLnBhcmFtcywgc3RyZWFtOiB0cnVlIH0sXG4gICAgICB7IC4uLm9wdGlvbnMsIHNpZ25hbDogdGhpcy5jb250cm9sbGVyLnNpZ25hbCB9LFxuICAgICk7XG4gICAgdGhpcy5fY29ubmVjdGVkKCk7XG4gICAgZm9yIGF3YWl0IChjb25zdCBldmVudCBvZiBzdHJlYW0pIHtcbiAgICAgIHRoaXMuI2FkZFN0cmVhbUV2ZW50KGV2ZW50KTtcbiAgICB9XG4gICAgaWYgKHN0cmVhbS5jb250cm9sbGVyLnNpZ25hbD8uYWJvcnRlZCkge1xuICAgICAgdGhyb3cgbmV3IEFQSVVzZXJBYm9ydEVycm9yKCk7XG4gICAgfVxuICAgIHRoaXMuI2VuZFJlcXVlc3QoKTtcbiAgfVxuXG4gIHByb3RlY3RlZCBfY29ubmVjdGVkKCkge1xuICAgIGlmICh0aGlzLmVuZGVkKSByZXR1cm47XG4gICAgdGhpcy4jcmVzb2x2ZUNvbm5lY3RlZFByb21pc2UoKTtcbiAgICB0aGlzLl9lbWl0KCdjb25uZWN0Jyk7XG4gIH1cblxuICBnZXQgZW5kZWQoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuI2VuZGVkO1xuICB9XG5cbiAgZ2V0IGVycm9yZWQoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuI2Vycm9yZWQ7XG4gIH1cblxuICBnZXQgYWJvcnRlZCgpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy4jYWJvcnRlZDtcbiAgfVxuXG4gIGFib3J0KCkge1xuICAgIHRoaXMuY29udHJvbGxlci5hYm9ydCgpO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgdGhlIGxpc3RlbmVyIGZ1bmN0aW9uIHRvIHRoZSBlbmQgb2YgdGhlIGxpc3RlbmVycyBhcnJheSBmb3IgdGhlIGV2ZW50LlxuICAgKiBObyBjaGVja3MgYXJlIG1hZGUgdG8gc2VlIGlmIHRoZSBsaXN0ZW5lciBoYXMgYWxyZWFkeSBiZWVuIGFkZGVkLiBNdWx0aXBsZSBjYWxscyBwYXNzaW5nXG4gICAqIHRoZSBzYW1lIGNvbWJpbmF0aW9uIG9mIGV2ZW50IGFuZCBsaXN0ZW5lciB3aWxsIHJlc3VsdCBpbiB0aGUgbGlzdGVuZXIgYmVpbmcgYWRkZWQsIGFuZFxuICAgKiBjYWxsZWQsIG11bHRpcGxlIHRpbWVzLlxuICAgKiBAcmV0dXJucyB0aGlzIFByb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbSwgc28gdGhhdCBjYWxscyBjYW4gYmUgY2hhaW5lZFxuICAgKi9cbiAgb248RXZlbnQgZXh0ZW5kcyBrZXlvZiBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudHM+KFxuICAgIGV2ZW50OiBFdmVudCxcbiAgICBsaXN0ZW5lcjogUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlU3RyZWFtRXZlbnRzW0V2ZW50XSxcbiAgKTogdGhpcyB7XG4gICAgY29uc3QgbGlzdGVuZXJzOiBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudExpc3RlbmVyczxFdmVudD4gPVxuICAgICAgdGhpcy4jbGlzdGVuZXJzW2V2ZW50XSB8fCAodGhpcy4jbGlzdGVuZXJzW2V2ZW50XSA9IFtdKTtcbiAgICBsaXN0ZW5lcnMucHVzaCh7IGxpc3RlbmVyIH0pO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbW92ZXMgdGhlIHNwZWNpZmllZCBsaXN0ZW5lciBmcm9tIHRoZSBsaXN0ZW5lciBhcnJheSBmb3IgdGhlIGV2ZW50LlxuICAgKiBvZmYoKSB3aWxsIHJlbW92ZSwgYXQgbW9zdCwgb25lIGluc3RhbmNlIG9mIGEgbGlzdGVuZXIgZnJvbSB0aGUgbGlzdGVuZXIgYXJyYXkuIElmIGFueSBzaW5nbGVcbiAgICogbGlzdGVuZXIgaGFzIGJlZW4gYWRkZWQgbXVsdGlwbGUgdGltZXMgdG8gdGhlIGxpc3RlbmVyIGFycmF5IGZvciB0aGUgc3BlY2lmaWVkIGV2ZW50LCB0aGVuXG4gICAqIG9mZigpIG11c3QgYmUgY2FsbGVkIG11bHRpcGxlIHRpbWVzIHRvIHJlbW92ZSBlYWNoIGluc3RhbmNlLlxuICAgKiBAcmV0dXJucyB0aGlzIFByb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbSwgc28gdGhhdCBjYWxscyBjYW4gYmUgY2hhaW5lZFxuICAgKi9cbiAgb2ZmPEV2ZW50IGV4dGVuZHMga2V5b2YgUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlU3RyZWFtRXZlbnRzPihcbiAgICBldmVudDogRXZlbnQsXG4gICAgbGlzdGVuZXI6IFByb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbUV2ZW50c1tFdmVudF0sXG4gICk6IHRoaXMge1xuICAgIGNvbnN0IGxpc3RlbmVycyA9IHRoaXMuI2xpc3RlbmVyc1tldmVudF07XG4gICAgaWYgKCFsaXN0ZW5lcnMpIHJldHVybiB0aGlzO1xuICAgIGNvbnN0IGluZGV4ID0gbGlzdGVuZXJzLmZpbmRJbmRleCgobCkgPT4gbC5saXN0ZW5lciA9PT0gbGlzdGVuZXIpO1xuICAgIGlmIChpbmRleCA+PSAwKSBsaXN0ZW5lcnMuc3BsaWNlKGluZGV4LCAxKTtcbiAgICByZXR1cm4gdGhpcztcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIGEgb25lLXRpbWUgbGlzdGVuZXIgZnVuY3Rpb24gZm9yIHRoZSBldmVudC4gVGhlIG5leHQgdGltZSB0aGUgZXZlbnQgaXMgdHJpZ2dlcmVkLFxuICAgKiB0aGlzIGxpc3RlbmVyIGlzIHJlbW92ZWQgYW5kIHRoZW4gaW52b2tlZC5cbiAgICogQHJldHVybnMgdGhpcyBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW0sIHNvIHRoYXQgY2FsbHMgY2FuIGJlIGNoYWluZWRcbiAgICovXG4gIG9uY2U8RXZlbnQgZXh0ZW5kcyBrZXlvZiBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudHM+KFxuICAgIGV2ZW50OiBFdmVudCxcbiAgICBsaXN0ZW5lcjogUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlU3RyZWFtRXZlbnRzW0V2ZW50XSxcbiAgKTogdGhpcyB7XG4gICAgY29uc3QgbGlzdGVuZXJzOiBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudExpc3RlbmVyczxFdmVudD4gPVxuICAgICAgdGhpcy4jbGlzdGVuZXJzW2V2ZW50XSB8fCAodGhpcy4jbGlzdGVuZXJzW2V2ZW50XSA9IFtdKTtcbiAgICBsaXN0ZW5lcnMucHVzaCh7IGxpc3RlbmVyLCBvbmNlOiB0cnVlIH0pO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoaXMgaXMgc2ltaWxhciB0byBgLm9uY2UoKWAsIGJ1dCByZXR1cm5zIGEgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHRoZSBuZXh0IHRpbWVcbiAgICogdGhlIGV2ZW50IGlzIHRyaWdnZXJlZCwgaW5zdGVhZCBvZiBjYWxsaW5nIGEgbGlzdGVuZXIgY2FsbGJhY2suXG4gICAqIEByZXR1cm5zIGEgUHJvbWlzZSB0aGF0IHJlc29sdmVzIHRoZSBuZXh0IHRpbWUgZ2l2ZW4gZXZlbnQgaXMgdHJpZ2dlcmVkLFxuICAgKiBvciByZWplY3RzIGlmIGFuIGVycm9yIGlzIGVtaXR0ZWQuICAoSWYgeW91IHJlcXVlc3QgdGhlICdlcnJvcicgZXZlbnQsXG4gICAqIHJldHVybnMgYSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgZXJyb3IpLlxuICAgKlxuICAgKiBFeGFtcGxlOlxuICAgKlxuICAgKiAgIGNvbnN0IG1lc3NhZ2UgPSBhd2FpdCBzdHJlYW0uZW1pdHRlZCgnbWVzc2FnZScpIC8vIHJlamVjdHMgaWYgdGhlIHN0cmVhbSBlcnJvcnNcbiAgICovXG4gIGVtaXR0ZWQ8RXZlbnQgZXh0ZW5kcyBrZXlvZiBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudHM+KFxuICAgIGV2ZW50OiBFdmVudCxcbiAgKTogUHJvbWlzZTxcbiAgICBQYXJhbWV0ZXJzPFByb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbUV2ZW50c1tFdmVudF0+IGV4dGVuZHMgW2luZmVyIFBhcmFtXSA/IFBhcmFtXG4gICAgOiBQYXJhbWV0ZXJzPFByb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbUV2ZW50c1tFdmVudF0+IGV4dGVuZHMgW10gPyB2b2lkXG4gICAgOiBQYXJhbWV0ZXJzPFByb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbUV2ZW50c1tFdmVudF0+XG4gID4ge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICB0aGlzLiNjYXRjaGluZ1Byb21pc2VDcmVhdGVkID0gdHJ1ZTtcbiAgICAgIGlmIChldmVudCAhPT0gJ2Vycm9yJykgdGhpcy5vbmNlKCdlcnJvcicsIHJlamVjdCk7XG4gICAgICB0aGlzLm9uY2UoZXZlbnQsIHJlc29sdmUgYXMgYW55KTtcbiAgICB9KTtcbiAgfVxuXG4gIGFzeW5jIGRvbmUoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdGhpcy4jY2F0Y2hpbmdQcm9taXNlQ3JlYXRlZCA9IHRydWU7XG4gICAgYXdhaXQgdGhpcy4jZW5kUHJvbWlzZTtcbiAgfVxuXG4gIGdldCBjdXJyZW50TWVzc2FnZSgpOiBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2UgfCB1bmRlZmluZWQge1xuICAgIHJldHVybiB0aGlzLiNjdXJyZW50TWVzc2FnZVNuYXBzaG90O1xuICB9XG5cbiAgI2dldEZpbmFsTWVzc2FnZSgpOiBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2Uge1xuICAgIGlmICh0aGlzLnJlY2VpdmVkTWVzc2FnZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICB0aHJvdyBuZXcgQW50aHJvcGljRXJyb3IoXG4gICAgICAgICdzdHJlYW0gZW5kZWQgd2l0aG91dCBwcm9kdWNpbmcgYSBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2Ugd2l0aCByb2xlPWFzc2lzdGFudCcsXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5yZWNlaXZlZE1lc3NhZ2VzLmF0KC0xKSE7XG4gIH1cblxuICAvKipcbiAgICogQHJldHVybnMgYSBwcm9taXNlIHRoYXQgcmVzb2x2ZXMgd2l0aCB0aGUgdGhlIGZpbmFsIGFzc2lzdGFudCBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2UgcmVzcG9uc2UsXG4gICAqIG9yIHJlamVjdHMgaWYgYW4gZXJyb3Igb2NjdXJyZWQgb3IgdGhlIHN0cmVhbSBlbmRlZCBwcmVtYXR1cmVseSB3aXRob3V0IHByb2R1Y2luZyBhIFByb21wdENhY2hpbmdCZXRhTWVzc2FnZS5cbiAgICovXG4gIGFzeW5jIGZpbmFsTWVzc2FnZSgpOiBQcm9taXNlPFByb21wdENhY2hpbmdCZXRhTWVzc2FnZT4ge1xuICAgIGF3YWl0IHRoaXMuZG9uZSgpO1xuICAgIHJldHVybiB0aGlzLiNnZXRGaW5hbE1lc3NhZ2UoKTtcbiAgfVxuXG4gICNnZXRGaW5hbFRleHQoKTogc3RyaW5nIHtcbiAgICBpZiAodGhpcy5yZWNlaXZlZE1lc3NhZ2VzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgdGhyb3cgbmV3IEFudGhyb3BpY0Vycm9yKFxuICAgICAgICAnc3RyZWFtIGVuZGVkIHdpdGhvdXQgcHJvZHVjaW5nIGEgUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlIHdpdGggcm9sZT1hc3Npc3RhbnQnLFxuICAgICAgKTtcbiAgICB9XG4gICAgY29uc3QgdGV4dEJsb2NrcyA9IHRoaXMucmVjZWl2ZWRNZXNzYWdlc1xuICAgICAgLmF0KC0xKSFcbiAgICAgIC5jb250ZW50LmZpbHRlcigoYmxvY2spOiBibG9jayBpcyBUZXh0QmxvY2sgPT4gYmxvY2sudHlwZSA9PT0gJ3RleHQnKVxuICAgICAgLm1hcCgoYmxvY2spID0+IGJsb2NrLnRleHQpO1xuICAgIGlmICh0ZXh0QmxvY2tzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgdGhyb3cgbmV3IEFudGhyb3BpY0Vycm9yKCdzdHJlYW0gZW5kZWQgd2l0aG91dCBwcm9kdWNpbmcgYSBjb250ZW50IGJsb2NrIHdpdGggdHlwZT10ZXh0Jyk7XG4gICAgfVxuICAgIHJldHVybiB0ZXh0QmxvY2tzLmpvaW4oJyAnKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBAcmV0dXJucyBhIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSB0aGUgZmluYWwgYXNzaXN0YW50IFByb21wdENhY2hpbmdCZXRhTWVzc2FnZSdzIHRleHQgcmVzcG9uc2UsIGNvbmNhdGVuYXRlZFxuICAgKiB0b2dldGhlciBpZiB0aGVyZSBhcmUgbW9yZSB0aGFuIG9uZSB0ZXh0IGJsb2Nrcy5cbiAgICogUmVqZWN0cyBpZiBhbiBlcnJvciBvY2N1cnJlZCBvciB0aGUgc3RyZWFtIGVuZGVkIHByZW1hdHVyZWx5IHdpdGhvdXQgcHJvZHVjaW5nIGEgUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlLlxuICAgKi9cbiAgYXN5bmMgZmluYWxUZXh0KCk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgYXdhaXQgdGhpcy5kb25lKCk7XG4gICAgcmV0dXJuIHRoaXMuI2dldEZpbmFsVGV4dCgpO1xuICB9XG5cbiAgI2hhbmRsZUVycm9yID0gKGVycm9yOiB1bmtub3duKSA9PiB7XG4gICAgdGhpcy4jZXJyb3JlZCA9IHRydWU7XG4gICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IgJiYgZXJyb3IubmFtZSA9PT0gJ0Fib3J0RXJyb3InKSB7XG4gICAgICBlcnJvciA9IG5ldyBBUElVc2VyQWJvcnRFcnJvcigpO1xuICAgIH1cbiAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBBUElVc2VyQWJvcnRFcnJvcikge1xuICAgICAgdGhpcy4jYWJvcnRlZCA9IHRydWU7XG4gICAgICByZXR1cm4gdGhpcy5fZW1pdCgnYWJvcnQnLCBlcnJvcik7XG4gICAgfVxuICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEFudGhyb3BpY0Vycm9yKSB7XG4gICAgICByZXR1cm4gdGhpcy5fZW1pdCgnZXJyb3InLCBlcnJvcik7XG4gICAgfVxuICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEVycm9yKSB7XG4gICAgICBjb25zdCBhbnRocm9waWNFcnJvcjogQW50aHJvcGljRXJyb3IgPSBuZXcgQW50aHJvcGljRXJyb3IoZXJyb3IubWVzc2FnZSk7XG4gICAgICAvLyBAdHMtaWdub3JlXG4gICAgICBhbnRocm9waWNFcnJvci5jYXVzZSA9IGVycm9yO1xuICAgICAgcmV0dXJuIHRoaXMuX2VtaXQoJ2Vycm9yJywgYW50aHJvcGljRXJyb3IpO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fZW1pdCgnZXJyb3InLCBuZXcgQW50aHJvcGljRXJyb3IoU3RyaW5nKGVycm9yKSkpO1xuICB9O1xuXG4gIHByb3RlY3RlZCBfZW1pdDxFdmVudCBleHRlbmRzIGtleW9mIFByb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbUV2ZW50cz4oXG4gICAgZXZlbnQ6IEV2ZW50LFxuICAgIC4uLmFyZ3M6IFBhcmFtZXRlcnM8UHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlU3RyZWFtRXZlbnRzW0V2ZW50XT5cbiAgKSB7XG4gICAgLy8gbWFrZSBzdXJlIHdlIGRvbid0IGVtaXQgYW55IFByb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbUV2ZW50cyBhZnRlciBlbmRcbiAgICBpZiAodGhpcy4jZW5kZWQpIHJldHVybjtcblxuICAgIGlmIChldmVudCA9PT0gJ2VuZCcpIHtcbiAgICAgIHRoaXMuI2VuZGVkID0gdHJ1ZTtcbiAgICAgIHRoaXMuI3Jlc29sdmVFbmRQcm9taXNlKCk7XG4gICAgfVxuXG4gICAgY29uc3QgbGlzdGVuZXJzOiBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudExpc3RlbmVyczxFdmVudD4gfCB1bmRlZmluZWQgPSB0aGlzLiNsaXN0ZW5lcnNbZXZlbnRdO1xuICAgIGlmIChsaXN0ZW5lcnMpIHtcbiAgICAgIHRoaXMuI2xpc3RlbmVyc1tldmVudF0gPSBsaXN0ZW5lcnMuZmlsdGVyKChsKSA9PiAhbC5vbmNlKSBhcyBhbnk7XG4gICAgICBsaXN0ZW5lcnMuZm9yRWFjaCgoeyBsaXN0ZW5lciB9OiBhbnkpID0+IGxpc3RlbmVyKC4uLmFyZ3MpKTtcbiAgICB9XG5cbiAgICBpZiAoZXZlbnQgPT09ICdhYm9ydCcpIHtcbiAgICAgIGNvbnN0IGVycm9yID0gYXJnc1swXSBhcyBBUElVc2VyQWJvcnRFcnJvcjtcbiAgICAgIGlmICghdGhpcy4jY2F0Y2hpbmdQcm9taXNlQ3JlYXRlZCAmJiAhbGlzdGVuZXJzPy5sZW5ndGgpIHtcbiAgICAgICAgUHJvbWlzZS5yZWplY3QoZXJyb3IpO1xuICAgICAgfVxuICAgICAgdGhpcy4jcmVqZWN0Q29ubmVjdGVkUHJvbWlzZShlcnJvcik7XG4gICAgICB0aGlzLiNyZWplY3RFbmRQcm9taXNlKGVycm9yKTtcbiAgICAgIHRoaXMuX2VtaXQoJ2VuZCcpO1xuICAgICAgcmV0dXJuO1xuICAgIH1cblxuICAgIGlmIChldmVudCA9PT0gJ2Vycm9yJykge1xuICAgICAgLy8gTk9URTogX2VtaXQoJ2Vycm9yJywgZXJyb3IpIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBmcm9tICNoYW5kbGVFcnJvcigpLlxuXG4gICAgICBjb25zdCBlcnJvciA9IGFyZ3NbMF0gYXMgQW50aHJvcGljRXJyb3I7XG4gICAgICBpZiAoIXRoaXMuI2NhdGNoaW5nUHJvbWlzZUNyZWF0ZWQgJiYgIWxpc3RlbmVycz8ubGVuZ3RoKSB7XG4gICAgICAgIC8vIFRyaWdnZXIgYW4gdW5oYW5kbGVkIHJlamVjdGlvbiBpZiB0aGUgdXNlciBoYXNuJ3QgcmVnaXN0ZXJlZCBhbnkgZXJyb3IgaGFuZGxlcnMuXG4gICAgICAgIC8vIElmIHlvdSBhcmUgc2VlaW5nIHN0YWNrIHRyYWNlcyBoZXJlLCBtYWtlIHN1cmUgdG8gaGFuZGxlIGVycm9ycyB2aWEgZWl0aGVyOlxuICAgICAgICAvLyAtIHJ1bm5lci5vbignZXJyb3InLCAoKSA9PiAuLi4pXG4gICAgICAgIC8vIC0gYXdhaXQgcnVubmVyLmRvbmUoKVxuICAgICAgICAvLyAtIGF3YWl0IHJ1bm5lci5maW5hbC4uLigpXG4gICAgICAgIC8vIC0gZXRjLlxuICAgICAgICBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gICAgICB9XG4gICAgICB0aGlzLiNyZWplY3RDb25uZWN0ZWRQcm9taXNlKGVycm9yKTtcbiAgICAgIHRoaXMuI3JlamVjdEVuZFByb21pc2UoZXJyb3IpO1xuICAgICAgdGhpcy5fZW1pdCgnZW5kJyk7XG4gICAgfVxuICB9XG5cbiAgcHJvdGVjdGVkIF9lbWl0RmluYWwoKSB7XG4gICAgY29uc3QgZmluYWxQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2UgPSB0aGlzLnJlY2VpdmVkTWVzc2FnZXMuYXQoLTEpO1xuICAgIGlmIChmaW5hbFByb21wdENhY2hpbmdCZXRhTWVzc2FnZSkge1xuICAgICAgdGhpcy5fZW1pdCgnZmluYWxQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2UnLCB0aGlzLiNnZXRGaW5hbE1lc3NhZ2UoKSk7XG4gICAgfVxuICB9XG5cbiAgI2JlZ2luUmVxdWVzdCgpIHtcbiAgICBpZiAodGhpcy5lbmRlZCkgcmV0dXJuO1xuICAgIHRoaXMuI2N1cnJlbnRNZXNzYWdlU25hcHNob3QgPSB1bmRlZmluZWQ7XG4gIH1cbiAgI2FkZFN0cmVhbUV2ZW50KGV2ZW50OiBSYXdQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudCkge1xuICAgIGlmICh0aGlzLmVuZGVkKSByZXR1cm47XG4gICAgY29uc3QgbWVzc2FnZVNuYXBzaG90ID0gdGhpcy4jYWNjdW11bGF0ZU1lc3NhZ2UoZXZlbnQpO1xuICAgIHRoaXMuX2VtaXQoJ3N0cmVhbUV2ZW50JywgZXZlbnQsIG1lc3NhZ2VTbmFwc2hvdCk7XG5cbiAgICBzd2l0Y2ggKGV2ZW50LnR5cGUpIHtcbiAgICAgIGNhc2UgJ2NvbnRlbnRfYmxvY2tfZGVsdGEnOiB7XG4gICAgICAgIGNvbnN0IGNvbnRlbnQgPSBtZXNzYWdlU25hcHNob3QuY29udGVudC5hdCgtMSkhO1xuICAgICAgICBpZiAoZXZlbnQuZGVsdGEudHlwZSA9PT0gJ3RleHRfZGVsdGEnICYmIGNvbnRlbnQudHlwZSA9PT0gJ3RleHQnKSB7XG4gICAgICAgICAgdGhpcy5fZW1pdCgndGV4dCcsIGV2ZW50LmRlbHRhLnRleHQsIGNvbnRlbnQudGV4dCB8fCAnJyk7XG4gICAgICAgIH0gZWxzZSBpZiAoZXZlbnQuZGVsdGEudHlwZSA9PT0gJ2lucHV0X2pzb25fZGVsdGEnICYmIGNvbnRlbnQudHlwZSA9PT0gJ3Rvb2xfdXNlJykge1xuICAgICAgICAgIGlmIChjb250ZW50LmlucHV0KSB7XG4gICAgICAgICAgICB0aGlzLl9lbWl0KCdpbnB1dEpzb24nLCBldmVudC5kZWx0YS5wYXJ0aWFsX2pzb24sIGNvbnRlbnQuaW5wdXQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhc2UgJ21lc3NhZ2Vfc3RvcCc6IHtcbiAgICAgICAgdGhpcy5fYWRkUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlUGFyYW0obWVzc2FnZVNuYXBzaG90KTtcbiAgICAgICAgdGhpcy5fYWRkUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlKG1lc3NhZ2VTbmFwc2hvdCwgdHJ1ZSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FzZSAnY29udGVudF9ibG9ja19zdG9wJzoge1xuICAgICAgICB0aGlzLl9lbWl0KCdjb250ZW50QmxvY2snLCBtZXNzYWdlU25hcHNob3QuY29udGVudC5hdCgtMSkhKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlICdtZXNzYWdlX3N0YXJ0Jzoge1xuICAgICAgICB0aGlzLiNjdXJyZW50TWVzc2FnZVNuYXBzaG90ID0gbWVzc2FnZVNuYXBzaG90O1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhc2UgJ2NvbnRlbnRfYmxvY2tfc3RhcnQnOlxuICAgICAgY2FzZSAnbWVzc2FnZV9kZWx0YSc6XG4gICAgICAgIGJyZWFrO1xuICAgIH1cbiAgfVxuICAjZW5kUmVxdWVzdCgpOiBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2Uge1xuICAgIGlmICh0aGlzLmVuZGVkKSB7XG4gICAgICB0aHJvdyBuZXcgQW50aHJvcGljRXJyb3IoYHN0cmVhbSBoYXMgZW5kZWQsIHRoaXMgc2hvdWxkbid0IGhhcHBlbmApO1xuICAgIH1cbiAgICBjb25zdCBzbmFwc2hvdCA9IHRoaXMuI2N1cnJlbnRNZXNzYWdlU25hcHNob3Q7XG4gICAgaWYgKCFzbmFwc2hvdCkge1xuICAgICAgdGhyb3cgbmV3IEFudGhyb3BpY0Vycm9yKGByZXF1ZXN0IGVuZGVkIHdpdGhvdXQgc2VuZGluZyBhbnkgY2h1bmtzYCk7XG4gICAgfVxuICAgIHRoaXMuI2N1cnJlbnRNZXNzYWdlU25hcHNob3QgPSB1bmRlZmluZWQ7XG4gICAgcmV0dXJuIHNuYXBzaG90O1xuICB9XG5cbiAgcHJvdGVjdGVkIGFzeW5jIF9mcm9tUmVhZGFibGVTdHJlYW0oXG4gICAgcmVhZGFibGVTdHJlYW06IFJlYWRhYmxlU3RyZWFtLFxuICAgIG9wdGlvbnM/OiBDb3JlLlJlcXVlc3RPcHRpb25zLFxuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBzaWduYWwgPSBvcHRpb25zPy5zaWduYWw7XG4gICAgaWYgKHNpZ25hbCkge1xuICAgICAgaWYgKHNpZ25hbC5hYm9ydGVkKSB0aGlzLmNvbnRyb2xsZXIuYWJvcnQoKTtcbiAgICAgIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKCdhYm9ydCcsICgpID0+IHRoaXMuY29udHJvbGxlci5hYm9ydCgpKTtcbiAgICB9XG4gICAgdGhpcy4jYmVnaW5SZXF1ZXN0KCk7XG4gICAgdGhpcy5fY29ubmVjdGVkKCk7XG4gICAgY29uc3Qgc3RyZWFtID0gU3RyZWFtLmZyb21SZWFkYWJsZVN0cmVhbTxSYXdQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudD4oXG4gICAgICByZWFkYWJsZVN0cmVhbSxcbiAgICAgIHRoaXMuY29udHJvbGxlcixcbiAgICApO1xuICAgIGZvciBhd2FpdCAoY29uc3QgZXZlbnQgb2Ygc3RyZWFtKSB7XG4gICAgICB0aGlzLiNhZGRTdHJlYW1FdmVudChldmVudCk7XG4gICAgfVxuICAgIGlmIChzdHJlYW0uY29udHJvbGxlci5zaWduYWw/LmFib3J0ZWQpIHtcbiAgICAgIHRocm93IG5ldyBBUElVc2VyQWJvcnRFcnJvcigpO1xuICAgIH1cbiAgICB0aGlzLiNlbmRSZXF1ZXN0KCk7XG4gIH1cblxuICAvKipcbiAgICogTXV0YXRlcyB0aGlzLiNjdXJyZW50UHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlIHdpdGggdGhlIGN1cnJlbnQgZXZlbnQuIEhhbmRsaW5nIHRoZSBhY2N1bXVsYXRpb24gb2YgbXVsdGlwbGUgbWVzc2FnZXNcbiAgICogd2lsbCBiZSBuZWVkZWQgdG8gYmUgaGFuZGxlZCBieSB0aGUgY2FsbGVyLCB0aGlzIG1ldGhvZCB3aWxsIHRocm93IGlmIHlvdSB0cnkgdG8gYWNjdW11bGF0ZSBmb3IgbXVsdGlwbGVcbiAgICogbWVzc2FnZXMuXG4gICAqL1xuICAjYWNjdW11bGF0ZU1lc3NhZ2UoZXZlbnQ6IFJhd1Byb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbUV2ZW50KTogUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlIHtcbiAgICBsZXQgc25hcHNob3QgPSB0aGlzLiNjdXJyZW50TWVzc2FnZVNuYXBzaG90O1xuXG4gICAgaWYgKGV2ZW50LnR5cGUgPT09ICdtZXNzYWdlX3N0YXJ0Jykge1xuICAgICAgaWYgKHNuYXBzaG90KSB7XG4gICAgICAgIHRocm93IG5ldyBBbnRocm9waWNFcnJvcihgVW5leHBlY3RlZCBldmVudCBvcmRlciwgZ290ICR7ZXZlbnQudHlwZX0gYmVmb3JlIHJlY2VpdmluZyBcIm1lc3NhZ2Vfc3RvcFwiYCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gZXZlbnQubWVzc2FnZTtcbiAgICB9XG5cbiAgICBpZiAoIXNuYXBzaG90KSB7XG4gICAgICB0aHJvdyBuZXcgQW50aHJvcGljRXJyb3IoYFVuZXhwZWN0ZWQgZXZlbnQgb3JkZXIsIGdvdCAke2V2ZW50LnR5cGV9IGJlZm9yZSBcIm1lc3NhZ2Vfc3RhcnRcImApO1xuICAgIH1cblxuICAgIHN3aXRjaCAoZXZlbnQudHlwZSkge1xuICAgICAgY2FzZSAnbWVzc2FnZV9zdG9wJzpcbiAgICAgICAgcmV0dXJuIHNuYXBzaG90O1xuICAgICAgY2FzZSAnbWVzc2FnZV9kZWx0YSc6XG4gICAgICAgIHNuYXBzaG90LnN0b3BfcmVhc29uID0gZXZlbnQuZGVsdGEuc3RvcF9yZWFzb247XG4gICAgICAgIHNuYXBzaG90LnN0b3Bfc2VxdWVuY2UgPSBldmVudC5kZWx0YS5zdG9wX3NlcXVlbmNlO1xuICAgICAgICBzbmFwc2hvdC51c2FnZS5vdXRwdXRfdG9rZW5zID0gZXZlbnQudXNhZ2Uub3V0cHV0X3Rva2VucztcbiAgICAgICAgcmV0dXJuIHNuYXBzaG90O1xuICAgICAgY2FzZSAnY29udGVudF9ibG9ja19zdGFydCc6XG4gICAgICAgIHNuYXBzaG90LmNvbnRlbnQucHVzaChldmVudC5jb250ZW50X2Jsb2NrKTtcbiAgICAgICAgcmV0dXJuIHNuYXBzaG90O1xuICAgICAgY2FzZSAnY29udGVudF9ibG9ja19kZWx0YSc6IHtcbiAgICAgICAgY29uc3Qgc25hcHNob3RDb250ZW50ID0gc25hcHNob3QuY29udGVudC5hdChldmVudC5pbmRleCk7XG4gICAgICAgIGlmIChzbmFwc2hvdENvbnRlbnQ/LnR5cGUgPT09ICd0ZXh0JyAmJiBldmVudC5kZWx0YS50eXBlID09PSAndGV4dF9kZWx0YScpIHtcbiAgICAgICAgICBzbmFwc2hvdENvbnRlbnQudGV4dCArPSBldmVudC5kZWx0YS50ZXh0O1xuICAgICAgICB9IGVsc2UgaWYgKHNuYXBzaG90Q29udGVudD8udHlwZSA9PT0gJ3Rvb2xfdXNlJyAmJiBldmVudC5kZWx0YS50eXBlID09PSAnaW5wdXRfanNvbl9kZWx0YScpIHtcbiAgICAgICAgICAvLyB3ZSBuZWVkIHRvIGtlZXAgdHJhY2sgb2YgdGhlIHJhdyBKU09OIHN0cmluZyBhcyB3ZWxsIHNvIHRoYXQgd2UgY2FuXG4gICAgICAgICAgLy8gcmUtcGFyc2UgaXQgZm9yIGVhY2ggZGVsdGEsIGZvciBub3cgd2UganVzdCBzdG9yZSBpdCBhcyBhbiB1bnR5cGVkXG4gICAgICAgICAgLy8gbm9uLWVudW1lcmFibGUgcHJvcGVydHkgb24gdGhlIHNuYXBzaG90XG4gICAgICAgICAgbGV0IGpzb25CdWYgPSAoc25hcHNob3RDb250ZW50IGFzIGFueSlbSlNPTl9CVUZfUFJPUEVSVFldIHx8ICcnO1xuICAgICAgICAgIGpzb25CdWYgKz0gZXZlbnQuZGVsdGEucGFydGlhbF9qc29uO1xuXG4gICAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHNuYXBzaG90Q29udGVudCwgSlNPTl9CVUZfUFJPUEVSVFksIHtcbiAgICAgICAgICAgIHZhbHVlOiBqc29uQnVmLFxuICAgICAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGlmIChqc29uQnVmKSB7XG4gICAgICAgICAgICBzbmFwc2hvdENvbnRlbnQuaW5wdXQgPSBwYXJ0aWFsUGFyc2UoanNvbkJ1Zik7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzbmFwc2hvdDtcbiAgICAgIH1cbiAgICAgIGNhc2UgJ2NvbnRlbnRfYmxvY2tfc3RvcCc6XG4gICAgICAgIHJldHVybiBzbmFwc2hvdDtcbiAgICB9XG4gIH1cblxuICBbU3ltYm9sLmFzeW5jSXRlcmF0b3JdKCk6IEFzeW5jSXRlcmF0b3I8UmF3UHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlU3RyZWFtRXZlbnQ+IHtcbiAgICBjb25zdCBwdXNoUXVldWU6IFJhd1Byb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbUV2ZW50W10gPSBbXTtcbiAgICBjb25zdCByZWFkUXVldWU6IHtcbiAgICAgIHJlc29sdmU6IChjaHVuazogUmF3UHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlU3RyZWFtRXZlbnQgfCB1bmRlZmluZWQpID0+IHZvaWQ7XG4gICAgICByZWplY3Q6IChlcnJvcjogdW5rbm93bikgPT4gdm9pZDtcbiAgICB9W10gPSBbXTtcbiAgICBsZXQgZG9uZSA9IGZhbHNlO1xuXG4gICAgdGhpcy5vbignc3RyZWFtRXZlbnQnLCAoZXZlbnQpID0+IHtcbiAgICAgIGNvbnN0IHJlYWRlciA9IHJlYWRRdWV1ZS5zaGlmdCgpO1xuICAgICAgaWYgKHJlYWRlcikge1xuICAgICAgICByZWFkZXIucmVzb2x2ZShldmVudCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwdXNoUXVldWUucHVzaChldmVudCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICB0aGlzLm9uKCdlbmQnLCAoKSA9PiB7XG4gICAgICBkb25lID0gdHJ1ZTtcbiAgICAgIGZvciAoY29uc3QgcmVhZGVyIG9mIHJlYWRRdWV1ZSkge1xuICAgICAgICByZWFkZXIucmVzb2x2ZSh1bmRlZmluZWQpO1xuICAgICAgfVxuICAgICAgcmVhZFF1ZXVlLmxlbmd0aCA9IDA7XG4gICAgfSk7XG5cbiAgICB0aGlzLm9uKCdhYm9ydCcsIChlcnIpID0+IHtcbiAgICAgIGRvbmUgPSB0cnVlO1xuICAgICAgZm9yIChjb25zdCByZWFkZXIgb2YgcmVhZFF1ZXVlKSB7XG4gICAgICAgIHJlYWRlci5yZWplY3QoZXJyKTtcbiAgICAgIH1cbiAgICAgIHJlYWRRdWV1ZS5sZW5ndGggPSAwO1xuICAgIH0pO1xuXG4gICAgdGhpcy5vbignZXJyb3InLCAoZXJyKSA9PiB7XG4gICAgICBkb25lID0gdHJ1ZTtcbiAgICAgIGZvciAoY29uc3QgcmVhZGVyIG9mIHJlYWRRdWV1ZSkge1xuICAgICAgICByZWFkZXIucmVqZWN0KGVycik7XG4gICAgICB9XG4gICAgICByZWFkUXVldWUubGVuZ3RoID0gMDtcbiAgICB9KTtcblxuICAgIHJldHVybiB7XG4gICAgICBuZXh0OiBhc3luYyAoKTogUHJvbWlzZTxJdGVyYXRvclJlc3VsdDxSYXdQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudD4+ID0+IHtcbiAgICAgICAgaWYgKCFwdXNoUXVldWUubGVuZ3RoKSB7XG4gICAgICAgICAgaWYgKGRvbmUpIHtcbiAgICAgICAgICAgIHJldHVybiB7IHZhbHVlOiB1bmRlZmluZWQsIGRvbmU6IHRydWUgfTtcbiAgICAgICAgICB9XG4gICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlPFJhd1Byb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbUV2ZW50IHwgdW5kZWZpbmVkPigocmVzb2x2ZSwgcmVqZWN0KSA9PlxuICAgICAgICAgICAgcmVhZFF1ZXVlLnB1c2goeyByZXNvbHZlLCByZWplY3QgfSksXG4gICAgICAgICAgKS50aGVuKChjaHVuaykgPT4gKGNodW5rID8geyB2YWx1ZTogY2h1bmssIGRvbmU6IGZhbHNlIH0gOiB7IHZhbHVlOiB1bmRlZmluZWQsIGRvbmU6IHRydWUgfSkpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGNodW5rID0gcHVzaFF1ZXVlLnNoaWZ0KCkhO1xuICAgICAgICByZXR1cm4geyB2YWx1ZTogY2h1bmssIGRvbmU6IGZhbHNlIH07XG4gICAgICB9LFxuICAgICAgcmV0dXJuOiBhc3luYyAoKSA9PiB7XG4gICAgICAgIHRoaXMuYWJvcnQoKTtcbiAgICAgICAgcmV0dXJuIHsgdmFsdWU6IHVuZGVmaW5lZCwgZG9uZTogdHJ1ZSB9O1xuICAgICAgfSxcbiAgICB9O1xuICB9XG5cbiAgdG9SZWFkYWJsZVN0cmVhbSgpOiBSZWFkYWJsZVN0cmVhbSB7XG4gICAgY29uc3Qgc3RyZWFtID0gbmV3IFN0cmVhbSh0aGlzW1N5bWJvbC5hc3luY0l0ZXJhdG9yXS5iaW5kKHRoaXMpLCB0aGlzLmNvbnRyb2xsZXIpO1xuICAgIHJldHVybiBzdHJlYW0udG9SZWFkYWJsZVN0cmVhbSgpO1xuICB9XG59XG4iLCAiLy8gRmlsZSBnZW5lcmF0ZWQgZnJvbSBvdXIgT3BlbkFQSSBzcGVjIGJ5IFN0YWlubGVzcy4gU2VlIENPTlRSSUJVVElORy5tZCBmb3IgZGV0YWlscy5cblxuaW1wb3J0IHsgQVBJUmVzb3VyY2UgfSBmcm9tIFwiLi4vLi4vLi4vcmVzb3VyY2UuanNcIjtcbmltcG9ydCB7IEFQSVByb21pc2UgfSBmcm9tIFwiLi4vLi4vLi4vY29yZS5qc1wiO1xuaW1wb3J0ICogYXMgQ29yZSBmcm9tIFwiLi4vLi4vLi4vY29yZS5qc1wiO1xuaW1wb3J0ICogYXMgUHJvbXB0Q2FjaGluZ01lc3NhZ2VzQVBJIGZyb20gXCIuL21lc3NhZ2VzLmpzXCI7XG5pbXBvcnQgKiBhcyBNZXNzYWdlc0FQSSBmcm9tIFwiLi4vLi4vbWVzc2FnZXMuanNcIjtcbmltcG9ydCB7IFN0cmVhbSB9IGZyb20gXCIuLi8uLi8uLi9zdHJlYW1pbmcuanNcIjtcbmltcG9ydCB7IFByb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbSB9IGZyb20gXCIuLi8uLi8uLi9saWIvUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlU3RyZWFtLmpzXCI7XG5cbmV4cG9ydCBjbGFzcyBNZXNzYWdlcyBleHRlbmRzIEFQSVJlc291cmNlIHtcbiAgLyoqXG4gICAqIENyZWF0ZSBhIE1lc3NhZ2UuXG4gICAqXG4gICAqIFNlbmQgYSBzdHJ1Y3R1cmVkIGxpc3Qgb2YgaW5wdXQgbWVzc2FnZXMgd2l0aCB0ZXh0IGFuZC9vciBpbWFnZSBjb250ZW50LCBhbmQgdGhlXG4gICAqIG1vZGVsIHdpbGwgZ2VuZXJhdGUgdGhlIG5leHQgbWVzc2FnZSBpbiB0aGUgY29udmVyc2F0aW9uLlxuICAgKlxuICAgKiBUaGUgTWVzc2FnZXMgQVBJIGNhbiBiZSB1c2VkIGZvciBlaXRoZXIgc2luZ2xlIHF1ZXJpZXMgb3Igc3RhdGVsZXNzIG11bHRpLXR1cm5cbiAgICogY29udmVyc2F0aW9ucy5cbiAgICovXG4gIGNyZWF0ZShcbiAgICBib2R5OiBNZXNzYWdlQ3JlYXRlUGFyYW1zTm9uU3RyZWFtaW5nLFxuICAgIG9wdGlvbnM/OiBDb3JlLlJlcXVlc3RPcHRpb25zLFxuICApOiBBUElQcm9taXNlPFByb21wdENhY2hpbmdCZXRhTWVzc2FnZT47XG4gIGNyZWF0ZShcbiAgICBib2R5OiBNZXNzYWdlQ3JlYXRlUGFyYW1zU3RyZWFtaW5nLFxuICAgIG9wdGlvbnM/OiBDb3JlLlJlcXVlc3RPcHRpb25zLFxuICApOiBBUElQcm9taXNlPFN0cmVhbTxSYXdQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudD4+O1xuICBjcmVhdGUoXG4gICAgYm9keTogTWVzc2FnZUNyZWF0ZVBhcmFtc0Jhc2UsXG4gICAgb3B0aW9ucz86IENvcmUuUmVxdWVzdE9wdGlvbnMsXG4gICk6IEFQSVByb21pc2U8U3RyZWFtPFJhd1Byb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbUV2ZW50PiB8IFByb21wdENhY2hpbmdCZXRhTWVzc2FnZT47XG4gIGNyZWF0ZShcbiAgICBib2R5OiBNZXNzYWdlQ3JlYXRlUGFyYW1zLFxuICAgIG9wdGlvbnM/OiBDb3JlLlJlcXVlc3RPcHRpb25zLFxuICApOiBBUElQcm9taXNlPFByb21wdENhY2hpbmdCZXRhTWVzc2FnZT4gfCBBUElQcm9taXNlPFN0cmVhbTxSYXdQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudD4+IHtcbiAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoJy92MS9tZXNzYWdlcz9iZXRhPXByb21wdF9jYWNoaW5nJywge1xuICAgICAgYm9keSxcbiAgICAgIHRpbWVvdXQ6ICh0aGlzLl9jbGllbnQgYXMgYW55KS5fb3B0aW9ucy50aW1lb3V0ID8/IDYwMDAwMCxcbiAgICAgIC4uLm9wdGlvbnMsXG4gICAgICBoZWFkZXJzOiB7ICdhbnRocm9waWMtYmV0YSc6ICdwcm9tcHQtY2FjaGluZy0yMDI0LTA3LTMxJywgLi4ub3B0aW9ucz8uaGVhZGVycyB9LFxuICAgICAgc3RyZWFtOiBib2R5LnN0cmVhbSA/PyBmYWxzZSxcbiAgICB9KSBhcyBBUElQcm9taXNlPFByb21wdENhY2hpbmdCZXRhTWVzc2FnZT4gfCBBUElQcm9taXNlPFN0cmVhbTxSYXdQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudD4+O1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIE1lc3NhZ2Ugc3RyZWFtXG4gICAqL1xuICBzdHJlYW0oYm9keTogTWVzc2FnZVN0cmVhbVBhcmFtcywgb3B0aW9ucz86IENvcmUuUmVxdWVzdE9wdGlvbnMpOiBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW0ge1xuICAgIHJldHVybiBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW0uY3JlYXRlTWVzc2FnZSh0aGlzLCBib2R5LCBvcHRpb25zKTtcbiAgfVxufVxuXG5leHBvcnQgdHlwZSBNZXNzYWdlU3RyZWFtUGFyYW1zID0gTWVzc2FnZUNyZWF0ZVBhcmFtc0Jhc2U7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHJvbXB0Q2FjaGluZ0JldGFDYWNoZUNvbnRyb2xFcGhlbWVyYWwge1xuICB0eXBlOiAnZXBoZW1lcmFsJztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBQcm9tcHRDYWNoaW5nQmV0YUltYWdlQmxvY2tQYXJhbSB7XG4gIHNvdXJjZTogUHJvbXB0Q2FjaGluZ0JldGFJbWFnZUJsb2NrUGFyYW0uU291cmNlO1xuXG4gIHR5cGU6ICdpbWFnZSc7XG5cbiAgY2FjaGVfY29udHJvbD86IFByb21wdENhY2hpbmdCZXRhQ2FjaGVDb250cm9sRXBoZW1lcmFsIHwgbnVsbDtcbn1cblxuZXhwb3J0IG5hbWVzcGFjZSBQcm9tcHRDYWNoaW5nQmV0YUltYWdlQmxvY2tQYXJhbSB7XG4gIGV4cG9ydCBpbnRlcmZhY2UgU291cmNlIHtcbiAgICBkYXRhOiBzdHJpbmc7XG5cbiAgICBtZWRpYV90eXBlOiAnaW1hZ2UvanBlZycgfCAnaW1hZ2UvcG5nJyB8ICdpbWFnZS9naWYnIHwgJ2ltYWdlL3dlYnAnO1xuXG4gICAgdHlwZTogJ2Jhc2U2NCc7XG4gIH1cbn1cblxuZXhwb3J0IGludGVyZmFjZSBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2Uge1xuICAvKipcbiAgICogVW5pcXVlIG9iamVjdCBpZGVudGlmaWVyLlxuICAgKlxuICAgKiBUaGUgZm9ybWF0IGFuZCBsZW5ndGggb2YgSURzIG1heSBjaGFuZ2Ugb3ZlciB0aW1lLlxuICAgKi9cbiAgaWQ6IHN0cmluZztcblxuICAvKipcbiAgICogQ29udGVudCBnZW5lcmF0ZWQgYnkgdGhlIG1vZGVsLlxuICAgKlxuICAgKiBUaGlzIGlzIGFuIGFycmF5IG9mIGNvbnRlbnQgYmxvY2tzLCBlYWNoIG9mIHdoaWNoIGhhcyBhIGB0eXBlYCB0aGF0IGRldGVybWluZXNcbiAgICogaXRzIHNoYXBlLlxuICAgKlxuICAgKiBFeGFtcGxlOlxuICAgKlxuICAgKiBgYGBqc29uXG4gICAqIFt7IFwidHlwZVwiOiBcInRleHRcIiwgXCJ0ZXh0XCI6IFwiSGksIEknbSBDbGF1ZGUuXCIgfV1cbiAgICogYGBgXG4gICAqXG4gICAqIElmIHRoZSByZXF1ZXN0IGlucHV0IGBtZXNzYWdlc2AgZW5kZWQgd2l0aCBhbiBgYXNzaXN0YW50YCB0dXJuLCB0aGVuIHRoZVxuICAgKiByZXNwb25zZSBgY29udGVudGAgd2lsbCBjb250aW51ZSBkaXJlY3RseSBmcm9tIHRoYXQgbGFzdCB0dXJuLiBZb3UgY2FuIHVzZSB0aGlzXG4gICAqIHRvIGNvbnN0cmFpbiB0aGUgbW9kZWwncyBvdXRwdXQuXG4gICAqXG4gICAqIEZvciBleGFtcGxlLCBpZiB0aGUgaW5wdXQgYG1lc3NhZ2VzYCB3ZXJlOlxuICAgKlxuICAgKiBgYGBqc29uXG4gICAqIFtcbiAgICogICB7XG4gICAqICAgICBcInJvbGVcIjogXCJ1c2VyXCIsXG4gICAqICAgICBcImNvbnRlbnRcIjogXCJXaGF0J3MgdGhlIEdyZWVrIG5hbWUgZm9yIFN1bj8gKEEpIFNvbCAoQikgSGVsaW9zIChDKSBTdW5cIlxuICAgKiAgIH0sXG4gICAqICAgeyBcInJvbGVcIjogXCJhc3Npc3RhbnRcIiwgXCJjb250ZW50XCI6IFwiVGhlIGJlc3QgYW5zd2VyIGlzIChcIiB9XG4gICAqIF1cbiAgICogYGBgXG4gICAqXG4gICAqIFRoZW4gdGhlIHJlc3BvbnNlIGBjb250ZW50YCBtaWdodCBiZTpcbiAgICpcbiAgICogYGBganNvblxuICAgKiBbeyBcInR5cGVcIjogXCJ0ZXh0XCIsIFwidGV4dFwiOiBcIkIpXCIgfV1cbiAgICogYGBgXG4gICAqL1xuICBjb250ZW50OiBBcnJheTxNZXNzYWdlc0FQSS5Db250ZW50QmxvY2s+O1xuXG4gIC8qKlxuICAgKiBUaGUgbW9kZWwgdGhhdCB3aWxsIGNvbXBsZXRlIHlvdXIgcHJvbXB0LlxcblxcblNlZVxuICAgKiBbbW9kZWxzXShodHRwczovL2RvY3MuYW50aHJvcGljLmNvbS9lbi9kb2NzL21vZGVscy1vdmVydmlldykgZm9yIGFkZGl0aW9uYWxcbiAgICogZGV0YWlscyBhbmQgb3B0aW9ucy5cbiAgICovXG4gIG1vZGVsOiBNZXNzYWdlc0FQSS5Nb2RlbDtcblxuICAvKipcbiAgICogQ29udmVyc2F0aW9uYWwgcm9sZSBvZiB0aGUgZ2VuZXJhdGVkIG1lc3NhZ2UuXG4gICAqXG4gICAqIFRoaXMgd2lsbCBhbHdheXMgYmUgYFwiYXNzaXN0YW50XCJgLlxuICAgKi9cbiAgcm9sZTogJ2Fzc2lzdGFudCc7XG5cbiAgLyoqXG4gICAqIFRoZSByZWFzb24gdGhhdCB3ZSBzdG9wcGVkLlxuICAgKlxuICAgKiBUaGlzIG1heSBiZSBvbmUgdGhlIGZvbGxvd2luZyB2YWx1ZXM6XG4gICAqXG4gICAqIC0gYFwiZW5kX3R1cm5cImA6IHRoZSBtb2RlbCByZWFjaGVkIGEgbmF0dXJhbCBzdG9wcGluZyBwb2ludFxuICAgKiAtIGBcIm1heF90b2tlbnNcImA6IHdlIGV4Y2VlZGVkIHRoZSByZXF1ZXN0ZWQgYG1heF90b2tlbnNgIG9yIHRoZSBtb2RlbCdzIG1heGltdW1cbiAgICogLSBgXCJzdG9wX3NlcXVlbmNlXCJgOiBvbmUgb2YgeW91ciBwcm92aWRlZCBjdXN0b20gYHN0b3Bfc2VxdWVuY2VzYCB3YXMgZ2VuZXJhdGVkXG4gICAqIC0gYFwidG9vbF91c2VcImA6IHRoZSBtb2RlbCBpbnZva2VkIG9uZSBvciBtb3JlIHRvb2xzXG4gICAqXG4gICAqIEluIG5vbi1zdHJlYW1pbmcgbW9kZSB0aGlzIHZhbHVlIGlzIGFsd2F5cyBub24tbnVsbC4gSW4gc3RyZWFtaW5nIG1vZGUsIGl0IGlzXG4gICAqIG51bGwgaW4gdGhlIGBtZXNzYWdlX3N0YXJ0YCBldmVudCBhbmQgbm9uLW51bGwgb3RoZXJ3aXNlLlxuICAgKi9cbiAgc3RvcF9yZWFzb246ICdlbmRfdHVybicgfCAnbWF4X3Rva2VucycgfCAnc3RvcF9zZXF1ZW5jZScgfCAndG9vbF91c2UnIHwgbnVsbDtcblxuICAvKipcbiAgICogV2hpY2ggY3VzdG9tIHN0b3Agc2VxdWVuY2Ugd2FzIGdlbmVyYXRlZCwgaWYgYW55LlxuICAgKlxuICAgKiBUaGlzIHZhbHVlIHdpbGwgYmUgYSBub24tbnVsbCBzdHJpbmcgaWYgb25lIG9mIHlvdXIgY3VzdG9tIHN0b3Agc2VxdWVuY2VzIHdhc1xuICAgKiBnZW5lcmF0ZWQuXG4gICAqL1xuICBzdG9wX3NlcXVlbmNlOiBzdHJpbmcgfCBudWxsO1xuXG4gIC8qKlxuICAgKiBPYmplY3QgdHlwZS5cbiAgICpcbiAgICogRm9yIE1lc3NhZ2VzLCB0aGlzIGlzIGFsd2F5cyBgXCJtZXNzYWdlXCJgLlxuICAgKi9cbiAgdHlwZTogJ21lc3NhZ2UnO1xuXG4gIC8qKlxuICAgKiBCaWxsaW5nIGFuZCByYXRlLWxpbWl0IHVzYWdlLlxuICAgKlxuICAgKiBBbnRocm9waWMncyBBUEkgYmlsbHMgYW5kIHJhdGUtbGltaXRzIGJ5IHRva2VuIGNvdW50cywgYXMgdG9rZW5zIHJlcHJlc2VudCB0aGVcbiAgICogdW5kZXJseWluZyBjb3N0IHRvIG91ciBzeXN0ZW1zLlxuICAgKlxuICAgKiBVbmRlciB0aGUgaG9vZCwgdGhlIEFQSSB0cmFuc2Zvcm1zIHJlcXVlc3RzIGludG8gYSBmb3JtYXQgc3VpdGFibGUgZm9yIHRoZVxuICAgKiBtb2RlbC4gVGhlIG1vZGVsJ3Mgb3V0cHV0IHRoZW4gZ29lcyB0aHJvdWdoIGEgcGFyc2luZyBzdGFnZSBiZWZvcmUgYmVjb21pbmcgYW5cbiAgICogQVBJIHJlc3BvbnNlLiBBcyBhIHJlc3VsdCwgdGhlIHRva2VuIGNvdW50cyBpbiBgdXNhZ2VgIHdpbGwgbm90IG1hdGNoIG9uZS10by1vbmVcbiAgICogd2l0aCB0aGUgZXhhY3QgdmlzaWJsZSBjb250ZW50IG9mIGFuIEFQSSByZXF1ZXN0IG9yIHJlc3BvbnNlLlxuICAgKlxuICAgKiBGb3IgZXhhbXBsZSwgYG91dHB1dF90b2tlbnNgIHdpbGwgYmUgbm9uLXplcm8sIGV2ZW4gZm9yIGFuIGVtcHR5IHN0cmluZyByZXNwb25zZVxuICAgKiBmcm9tIENsYXVkZS5cbiAgICovXG4gIHVzYWdlOiBQcm9tcHRDYWNoaW5nQmV0YVVzYWdlO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFByb21wdENhY2hpbmdCZXRhTWVzc2FnZVBhcmFtIHtcbiAgY29udGVudDpcbiAgICB8IHN0cmluZ1xuICAgIHwgQXJyYXk8XG4gICAgICAgIHwgUHJvbXB0Q2FjaGluZ0JldGFUZXh0QmxvY2tQYXJhbVxuICAgICAgICB8IFByb21wdENhY2hpbmdCZXRhSW1hZ2VCbG9ja1BhcmFtXG4gICAgICAgIHwgUHJvbXB0Q2FjaGluZ0JldGFUb29sVXNlQmxvY2tQYXJhbVxuICAgICAgICB8IFByb21wdENhY2hpbmdCZXRhVG9vbFJlc3VsdEJsb2NrUGFyYW1cbiAgICAgID47XG5cbiAgcm9sZTogJ3VzZXInIHwgJ2Fzc2lzdGFudCc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHJvbXB0Q2FjaGluZ0JldGFUZXh0QmxvY2tQYXJhbSB7XG4gIHRleHQ6IHN0cmluZztcblxuICB0eXBlOiAndGV4dCc7XG5cbiAgY2FjaGVfY29udHJvbD86IFByb21wdENhY2hpbmdCZXRhQ2FjaGVDb250cm9sRXBoZW1lcmFsIHwgbnVsbDtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBQcm9tcHRDYWNoaW5nQmV0YVRvb2wge1xuICAvKipcbiAgICogW0pTT04gc2NoZW1hXShodHRwczovL2pzb24tc2NoZW1hLm9yZy8pIGZvciB0aGlzIHRvb2wncyBpbnB1dC5cbiAgICpcbiAgICogVGhpcyBkZWZpbmVzIHRoZSBzaGFwZSBvZiB0aGUgYGlucHV0YCB0aGF0IHlvdXIgdG9vbCBhY2NlcHRzIGFuZCB0aGF0IHRoZSBtb2RlbFxuICAgKiB3aWxsIHByb2R1Y2UuXG4gICAqL1xuICBpbnB1dF9zY2hlbWE6IFByb21wdENhY2hpbmdCZXRhVG9vbC5JbnB1dFNjaGVtYTtcblxuICBuYW1lOiBzdHJpbmc7XG5cbiAgY2FjaGVfY29udHJvbD86IFByb21wdENhY2hpbmdCZXRhQ2FjaGVDb250cm9sRXBoZW1lcmFsIHwgbnVsbDtcblxuICAvKipcbiAgICogRGVzY3JpcHRpb24gb2Ygd2hhdCB0aGlzIHRvb2wgZG9lcy5cbiAgICpcbiAgICogVG9vbCBkZXNjcmlwdGlvbnMgc2hvdWxkIGJlIGFzIGRldGFpbGVkIGFzIHBvc3NpYmxlLiBUaGUgbW9yZSBpbmZvcm1hdGlvbiB0aGF0XG4gICAqIHRoZSBtb2RlbCBoYXMgYWJvdXQgd2hhdCB0aGUgdG9vbCBpcyBhbmQgaG93IHRvIHVzZSBpdCwgdGhlIGJldHRlciBpdCB3aWxsXG4gICAqIHBlcmZvcm0uIFlvdSBjYW4gdXNlIG5hdHVyYWwgbGFuZ3VhZ2UgZGVzY3JpcHRpb25zIHRvIHJlaW5mb3JjZSBpbXBvcnRhbnRcbiAgICogYXNwZWN0cyBvZiB0aGUgdG9vbCBpbnB1dCBKU09OIHNjaGVtYS5cbiAgICovXG4gIGRlc2NyaXB0aW9uPzogc3RyaW5nO1xufVxuXG5leHBvcnQgbmFtZXNwYWNlIFByb21wdENhY2hpbmdCZXRhVG9vbCB7XG4gIC8qKlxuICAgKiBbSlNPTiBzY2hlbWFdKGh0dHBzOi8vanNvbi1zY2hlbWEub3JnLykgZm9yIHRoaXMgdG9vbCdzIGlucHV0LlxuICAgKlxuICAgKiBUaGlzIGRlZmluZXMgdGhlIHNoYXBlIG9mIHRoZSBgaW5wdXRgIHRoYXQgeW91ciB0b29sIGFjY2VwdHMgYW5kIHRoYXQgdGhlIG1vZGVsXG4gICAqIHdpbGwgcHJvZHVjZS5cbiAgICovXG4gIGV4cG9ydCBpbnRlcmZhY2UgSW5wdXRTY2hlbWEge1xuICAgIHR5cGU6ICdvYmplY3QnO1xuXG4gICAgcHJvcGVydGllcz86IHVua25vd24gfCBudWxsO1xuICAgIFtrOiBzdHJpbmddOiB1bmtub3duO1xuICB9XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUHJvbXB0Q2FjaGluZ0JldGFUb29sUmVzdWx0QmxvY2tQYXJhbSB7XG4gIHRvb2xfdXNlX2lkOiBzdHJpbmc7XG5cbiAgdHlwZTogJ3Rvb2xfcmVzdWx0JztcblxuICBjYWNoZV9jb250cm9sPzogUHJvbXB0Q2FjaGluZ0JldGFDYWNoZUNvbnRyb2xFcGhlbWVyYWwgfCBudWxsO1xuXG4gIGNvbnRlbnQ/OiBzdHJpbmcgfCBBcnJheTxQcm9tcHRDYWNoaW5nQmV0YVRleHRCbG9ja1BhcmFtIHwgUHJvbXB0Q2FjaGluZ0JldGFJbWFnZUJsb2NrUGFyYW0+O1xuXG4gIGlzX2Vycm9yPzogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBQcm9tcHRDYWNoaW5nQmV0YVRvb2xVc2VCbG9ja1BhcmFtIHtcbiAgaWQ6IHN0cmluZztcblxuICBpbnB1dDogdW5rbm93bjtcblxuICBuYW1lOiBzdHJpbmc7XG5cbiAgdHlwZTogJ3Rvb2xfdXNlJztcblxuICBjYWNoZV9jb250cm9sPzogUHJvbXB0Q2FjaGluZ0JldGFDYWNoZUNvbnRyb2xFcGhlbWVyYWwgfCBudWxsO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFByb21wdENhY2hpbmdCZXRhVXNhZ2Uge1xuICAvKipcbiAgICogVGhlIG51bWJlciBvZiBpbnB1dCB0b2tlbnMgdXNlZCB0byBjcmVhdGUgdGhlIGNhY2hlIGVudHJ5LlxuICAgKi9cbiAgY2FjaGVfY3JlYXRpb25faW5wdXRfdG9rZW5zOiBudW1iZXIgfCBudWxsO1xuXG4gIC8qKlxuICAgKiBUaGUgbnVtYmVyIG9mIGlucHV0IHRva2VucyByZWFkIGZyb20gdGhlIGNhY2hlLlxuICAgKi9cbiAgY2FjaGVfcmVhZF9pbnB1dF90b2tlbnM6IG51bWJlciB8IG51bGw7XG5cbiAgLyoqXG4gICAqIFRoZSBudW1iZXIgb2YgaW5wdXQgdG9rZW5zIHdoaWNoIHdlcmUgdXNlZC5cbiAgICovXG4gIGlucHV0X3Rva2VuczogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBUaGUgbnVtYmVyIG9mIG91dHB1dCB0b2tlbnMgd2hpY2ggd2VyZSB1c2VkLlxuICAgKi9cbiAgb3V0cHV0X3Rva2VuczogbnVtYmVyO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFJhd1Byb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0YXJ0RXZlbnQge1xuICBtZXNzYWdlOiBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2U7XG5cbiAgdHlwZTogJ21lc3NhZ2Vfc3RhcnQnO1xufVxuXG5leHBvcnQgdHlwZSBSYXdQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudCA9XG4gIHwgUmF3UHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlU3RhcnRFdmVudFxuICB8IE1lc3NhZ2VzQVBJLlJhd01lc3NhZ2VEZWx0YUV2ZW50XG4gIHwgTWVzc2FnZXNBUEkuUmF3TWVzc2FnZVN0b3BFdmVudFxuICB8IE1lc3NhZ2VzQVBJLlJhd0NvbnRlbnRCbG9ja1N0YXJ0RXZlbnRcbiAgfCBNZXNzYWdlc0FQSS5SYXdDb250ZW50QmxvY2tEZWx0YUV2ZW50XG4gIHwgTWVzc2FnZXNBUEkuUmF3Q29udGVudEJsb2NrU3RvcEV2ZW50O1xuXG5leHBvcnQgdHlwZSBNZXNzYWdlQ3JlYXRlUGFyYW1zID0gTWVzc2FnZUNyZWF0ZVBhcmFtc05vblN0cmVhbWluZyB8IE1lc3NhZ2VDcmVhdGVQYXJhbXNTdHJlYW1pbmc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWVzc2FnZUNyZWF0ZVBhcmFtc0Jhc2Uge1xuICAvKipcbiAgICogVGhlIG1heGltdW0gbnVtYmVyIG9mIHRva2VucyB0byBnZW5lcmF0ZSBiZWZvcmUgc3RvcHBpbmcuXG4gICAqXG4gICAqIE5vdGUgdGhhdCBvdXIgbW9kZWxzIG1heSBzdG9wIF9iZWZvcmVfIHJlYWNoaW5nIHRoaXMgbWF4aW11bS4gVGhpcyBwYXJhbWV0ZXJcbiAgICogb25seSBzcGVjaWZpZXMgdGhlIGFic29sdXRlIG1heGltdW0gbnVtYmVyIG9mIHRva2VucyB0byBnZW5lcmF0ZS5cbiAgICpcbiAgICogRGlmZmVyZW50IG1vZGVscyBoYXZlIGRpZmZlcmVudCBtYXhpbXVtIHZhbHVlcyBmb3IgdGhpcyBwYXJhbWV0ZXIuIFNlZVxuICAgKiBbbW9kZWxzXShodHRwczovL2RvY3MuYW50aHJvcGljLmNvbS9lbi9kb2NzL21vZGVscy1vdmVydmlldykgZm9yIGRldGFpbHMuXG4gICAqL1xuICBtYXhfdG9rZW5zOiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIElucHV0IG1lc3NhZ2VzLlxuICAgKlxuICAgKiBPdXIgbW9kZWxzIGFyZSB0cmFpbmVkIHRvIG9wZXJhdGUgb24gYWx0ZXJuYXRpbmcgYHVzZXJgIGFuZCBgYXNzaXN0YW50YFxuICAgKiBjb252ZXJzYXRpb25hbCB0dXJucy4gV2hlbiBjcmVhdGluZyBhIG5ldyBgTWVzc2FnZWAsIHlvdSBzcGVjaWZ5IHRoZSBwcmlvclxuICAgKiBjb252ZXJzYXRpb25hbCB0dXJucyB3aXRoIHRoZSBgbWVzc2FnZXNgIHBhcmFtZXRlciwgYW5kIHRoZSBtb2RlbCB0aGVuIGdlbmVyYXRlc1xuICAgKiB0aGUgbmV4dCBgTWVzc2FnZWAgaW4gdGhlIGNvbnZlcnNhdGlvbi5cbiAgICpcbiAgICogRWFjaCBpbnB1dCBtZXNzYWdlIG11c3QgYmUgYW4gb2JqZWN0IHdpdGggYSBgcm9sZWAgYW5kIGBjb250ZW50YC4gWW91IGNhblxuICAgKiBzcGVjaWZ5IGEgc2luZ2xlIGB1c2VyYC1yb2xlIG1lc3NhZ2UsIG9yIHlvdSBjYW4gaW5jbHVkZSBtdWx0aXBsZSBgdXNlcmAgYW5kXG4gICAqIGBhc3Npc3RhbnRgIG1lc3NhZ2VzLiBUaGUgZmlyc3QgbWVzc2FnZSBtdXN0IGFsd2F5cyB1c2UgdGhlIGB1c2VyYCByb2xlLlxuICAgKlxuICAgKiBJZiB0aGUgZmluYWwgbWVzc2FnZSB1c2VzIHRoZSBgYXNzaXN0YW50YCByb2xlLCB0aGUgcmVzcG9uc2UgY29udGVudCB3aWxsXG4gICAqIGNvbnRpbnVlIGltbWVkaWF0ZWx5IGZyb20gdGhlIGNvbnRlbnQgaW4gdGhhdCBtZXNzYWdlLiBUaGlzIGNhbiBiZSB1c2VkIHRvXG4gICAqIGNvbnN0cmFpbiBwYXJ0IG9mIHRoZSBtb2RlbCdzIHJlc3BvbnNlLlxuICAgKlxuICAgKiBFeGFtcGxlIHdpdGggYSBzaW5nbGUgYHVzZXJgIG1lc3NhZ2U6XG4gICAqXG4gICAqIGBgYGpzb25cbiAgICogW3sgXCJyb2xlXCI6IFwidXNlclwiLCBcImNvbnRlbnRcIjogXCJIZWxsbywgQ2xhdWRlXCIgfV1cbiAgICogYGBgXG4gICAqXG4gICAqIEV4YW1wbGUgd2l0aCBtdWx0aXBsZSBjb252ZXJzYXRpb25hbCB0dXJuczpcbiAgICpcbiAgICogYGBganNvblxuICAgKiBbXG4gICAqICAgeyBcInJvbGVcIjogXCJ1c2VyXCIsIFwiY29udGVudFwiOiBcIkhlbGxvIHRoZXJlLlwiIH0sXG4gICAqICAgeyBcInJvbGVcIjogXCJhc3Npc3RhbnRcIiwgXCJjb250ZW50XCI6IFwiSGksIEknbSBDbGF1ZGUuIEhvdyBjYW4gSSBoZWxwIHlvdT9cIiB9LFxuICAgKiAgIHsgXCJyb2xlXCI6IFwidXNlclwiLCBcImNvbnRlbnRcIjogXCJDYW4geW91IGV4cGxhaW4gTExNcyBpbiBwbGFpbiBFbmdsaXNoP1wiIH1cbiAgICogXVxuICAgKiBgYGBcbiAgICpcbiAgICogRXhhbXBsZSB3aXRoIGEgcGFydGlhbGx5LWZpbGxlZCByZXNwb25zZSBmcm9tIENsYXVkZTpcbiAgICpcbiAgICogYGBganNvblxuICAgKiBbXG4gICAqICAge1xuICAgKiAgICAgXCJyb2xlXCI6IFwidXNlclwiLFxuICAgKiAgICAgXCJjb250ZW50XCI6IFwiV2hhdCdzIHRoZSBHcmVlayBuYW1lIGZvciBTdW4/IChBKSBTb2wgKEIpIEhlbGlvcyAoQykgU3VuXCJcbiAgICogICB9LFxuICAgKiAgIHsgXCJyb2xlXCI6IFwiYXNzaXN0YW50XCIsIFwiY29udGVudFwiOiBcIlRoZSBiZXN0IGFuc3dlciBpcyAoXCIgfVxuICAgKiBdXG4gICAqIGBgYFxuICAgKlxuICAgKiBFYWNoIGlucHV0IG1lc3NhZ2UgYGNvbnRlbnRgIG1heSBiZSBlaXRoZXIgYSBzaW5nbGUgYHN0cmluZ2Agb3IgYW4gYXJyYXkgb2ZcbiAgICogY29udGVudCBibG9ja3MsIHdoZXJlIGVhY2ggYmxvY2sgaGFzIGEgc3BlY2lmaWMgYHR5cGVgLiBVc2luZyBhIGBzdHJpbmdgIGZvclxuICAgKiBgY29udGVudGAgaXMgc2hvcnRoYW5kIGZvciBhbiBhcnJheSBvZiBvbmUgY29udGVudCBibG9jayBvZiB0eXBlIGBcInRleHRcImAuIFRoZVxuICAgKiBmb2xsb3dpbmcgaW5wdXQgbWVzc2FnZXMgYXJlIGVxdWl2YWxlbnQ6XG4gICAqXG4gICAqIGBgYGpzb25cbiAgICogeyBcInJvbGVcIjogXCJ1c2VyXCIsIFwiY29udGVudFwiOiBcIkhlbGxvLCBDbGF1ZGVcIiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBgYGBqc29uXG4gICAqIHsgXCJyb2xlXCI6IFwidXNlclwiLCBcImNvbnRlbnRcIjogW3sgXCJ0eXBlXCI6IFwidGV4dFwiLCBcInRleHRcIjogXCJIZWxsbywgQ2xhdWRlXCIgfV0gfVxuICAgKiBgYGBcbiAgICpcbiAgICogU3RhcnRpbmcgd2l0aCBDbGF1ZGUgMyBtb2RlbHMsIHlvdSBjYW4gYWxzbyBzZW5kIGltYWdlIGNvbnRlbnQgYmxvY2tzOlxuICAgKlxuICAgKiBgYGBqc29uXG4gICAqIHtcbiAgICogICBcInJvbGVcIjogXCJ1c2VyXCIsXG4gICAqICAgXCJjb250ZW50XCI6IFtcbiAgICogICAgIHtcbiAgICogICAgICAgXCJ0eXBlXCI6IFwiaW1hZ2VcIixcbiAgICogICAgICAgXCJzb3VyY2VcIjoge1xuICAgKiAgICAgICAgIFwidHlwZVwiOiBcImJhc2U2NFwiLFxuICAgKiAgICAgICAgIFwibWVkaWFfdHlwZVwiOiBcImltYWdlL2pwZWdcIixcbiAgICogICAgICAgICBcImRhdGFcIjogXCIvOWovNEFBUVNrWkpSZy4uLlwiXG4gICAqICAgICAgIH1cbiAgICogICAgIH0sXG4gICAqICAgICB7IFwidHlwZVwiOiBcInRleHRcIiwgXCJ0ZXh0XCI6IFwiV2hhdCBpcyBpbiB0aGlzIGltYWdlP1wiIH1cbiAgICogICBdXG4gICAqIH1cbiAgICogYGBgXG4gICAqXG4gICAqIFdlIGN1cnJlbnRseSBzdXBwb3J0IHRoZSBgYmFzZTY0YCBzb3VyY2UgdHlwZSBmb3IgaW1hZ2VzLCBhbmQgdGhlIGBpbWFnZS9qcGVnYCxcbiAgICogYGltYWdlL3BuZ2AsIGBpbWFnZS9naWZgLCBhbmQgYGltYWdlL3dlYnBgIG1lZGlhIHR5cGVzLlxuICAgKlxuICAgKiBTZWUgW2V4YW1wbGVzXShodHRwczovL2RvY3MuYW50aHJvcGljLmNvbS9lbi9hcGkvbWVzc2FnZXMtZXhhbXBsZXMjdmlzaW9uKSBmb3JcbiAgICogbW9yZSBpbnB1dCBleGFtcGxlcy5cbiAgICpcbiAgICogTm90ZSB0aGF0IGlmIHlvdSB3YW50IHRvIGluY2x1ZGUgYVxuICAgKiBbc3lzdGVtIHByb21wdF0oaHR0cHM6Ly9kb2NzLmFudGhyb3BpYy5jb20vZW4vZG9jcy9zeXN0ZW0tcHJvbXB0cyksIHlvdSBjYW4gdXNlXG4gICAqIHRoZSB0b3AtbGV2ZWwgYHN5c3RlbWAgcGFyYW1ldGVyIFx1MjAxNCB0aGVyZSBpcyBubyBgXCJzeXN0ZW1cImAgcm9sZSBmb3IgaW5wdXRcbiAgICogbWVzc2FnZXMgaW4gdGhlIE1lc3NhZ2VzIEFQSS5cbiAgICovXG4gIG1lc3NhZ2VzOiBBcnJheTxQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VQYXJhbT47XG5cbiAgLyoqXG4gICAqIFRoZSBtb2RlbCB0aGF0IHdpbGwgY29tcGxldGUgeW91ciBwcm9tcHQuXFxuXFxuU2VlXG4gICAqIFttb2RlbHNdKGh0dHBzOi8vZG9jcy5hbnRocm9waWMuY29tL2VuL2RvY3MvbW9kZWxzLW92ZXJ2aWV3KSBmb3IgYWRkaXRpb25hbFxuICAgKiBkZXRhaWxzIGFuZCBvcHRpb25zLlxuICAgKi9cbiAgbW9kZWw6IE1lc3NhZ2VzQVBJLk1vZGVsO1xuXG4gIC8qKlxuICAgKiBBbiBvYmplY3QgZGVzY3JpYmluZyBtZXRhZGF0YSBhYm91dCB0aGUgcmVxdWVzdC5cbiAgICovXG4gIG1ldGFkYXRhPzogTWVzc2FnZUNyZWF0ZVBhcmFtcy5NZXRhZGF0YTtcblxuICAvKipcbiAgICogQ3VzdG9tIHRleHQgc2VxdWVuY2VzIHRoYXQgd2lsbCBjYXVzZSB0aGUgbW9kZWwgdG8gc3RvcCBnZW5lcmF0aW5nLlxuICAgKlxuICAgKiBPdXIgbW9kZWxzIHdpbGwgbm9ybWFsbHkgc3RvcCB3aGVuIHRoZXkgaGF2ZSBuYXR1cmFsbHkgY29tcGxldGVkIHRoZWlyIHR1cm4sXG4gICAqIHdoaWNoIHdpbGwgcmVzdWx0IGluIGEgcmVzcG9uc2UgYHN0b3BfcmVhc29uYCBvZiBgXCJlbmRfdHVyblwiYC5cbiAgICpcbiAgICogSWYgeW91IHdhbnQgdGhlIG1vZGVsIHRvIHN0b3AgZ2VuZXJhdGluZyB3aGVuIGl0IGVuY291bnRlcnMgY3VzdG9tIHN0cmluZ3Mgb2ZcbiAgICogdGV4dCwgeW91IGNhbiB1c2UgdGhlIGBzdG9wX3NlcXVlbmNlc2AgcGFyYW1ldGVyLiBJZiB0aGUgbW9kZWwgZW5jb3VudGVycyBvbmUgb2ZcbiAgICogdGhlIGN1c3RvbSBzZXF1ZW5jZXMsIHRoZSByZXNwb25zZSBgc3RvcF9yZWFzb25gIHZhbHVlIHdpbGwgYmUgYFwic3RvcF9zZXF1ZW5jZVwiYFxuICAgKiBhbmQgdGhlIHJlc3BvbnNlIGBzdG9wX3NlcXVlbmNlYCB2YWx1ZSB3aWxsIGNvbnRhaW4gdGhlIG1hdGNoZWQgc3RvcCBzZXF1ZW5jZS5cbiAgICovXG4gIHN0b3Bfc2VxdWVuY2VzPzogQXJyYXk8c3RyaW5nPjtcblxuICAvKipcbiAgICogV2hldGhlciB0byBpbmNyZW1lbnRhbGx5IHN0cmVhbSB0aGUgcmVzcG9uc2UgdXNpbmcgc2VydmVyLXNlbnQgZXZlbnRzLlxuICAgKlxuICAgKiBTZWUgW3N0cmVhbWluZ10oaHR0cHM6Ly9kb2NzLmFudGhyb3BpYy5jb20vZW4vYXBpL21lc3NhZ2VzLXN0cmVhbWluZykgZm9yXG4gICAqIGRldGFpbHMuXG4gICAqL1xuICBzdHJlYW0/OiBib29sZWFuO1xuXG4gIC8qKlxuICAgKiBTeXN0ZW0gcHJvbXB0LlxuICAgKlxuICAgKiBBIHN5c3RlbSBwcm9tcHQgaXMgYSB3YXkgb2YgcHJvdmlkaW5nIGNvbnRleHQgYW5kIGluc3RydWN0aW9ucyB0byBDbGF1ZGUsIHN1Y2hcbiAgICogYXMgc3BlY2lmeWluZyBhIHBhcnRpY3VsYXIgZ29hbCBvciByb2xlLiBTZWUgb3VyXG4gICAqIFtndWlkZSB0byBzeXN0ZW0gcHJvbXB0c10oaHR0cHM6Ly9kb2NzLmFudGhyb3BpYy5jb20vZW4vZG9jcy9zeXN0ZW0tcHJvbXB0cykuXG4gICAqL1xuICBzeXN0ZW0/OiBzdHJpbmcgfCBBcnJheTxQcm9tcHRDYWNoaW5nQmV0YVRleHRCbG9ja1BhcmFtPjtcblxuICAvKipcbiAgICogQW1vdW50IG9mIHJhbmRvbW5lc3MgaW5qZWN0ZWQgaW50byB0aGUgcmVzcG9uc2UuXG4gICAqXG4gICAqIERlZmF1bHRzIHRvIGAxLjBgLiBSYW5nZXMgZnJvbSBgMC4wYCB0byBgMS4wYC4gVXNlIGB0ZW1wZXJhdHVyZWAgY2xvc2VyIHRvIGAwLjBgXG4gICAqIGZvciBhbmFseXRpY2FsIC8gbXVsdGlwbGUgY2hvaWNlLCBhbmQgY2xvc2VyIHRvIGAxLjBgIGZvciBjcmVhdGl2ZSBhbmRcbiAgICogZ2VuZXJhdGl2ZSB0YXNrcy5cbiAgICpcbiAgICogTm90ZSB0aGF0IGV2ZW4gd2l0aCBgdGVtcGVyYXR1cmVgIG9mIGAwLjBgLCB0aGUgcmVzdWx0cyB3aWxsIG5vdCBiZSBmdWxseVxuICAgKiBkZXRlcm1pbmlzdGljLlxuICAgKi9cbiAgdGVtcGVyYXR1cmU/OiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIEhvdyB0aGUgbW9kZWwgc2hvdWxkIHVzZSB0aGUgcHJvdmlkZWQgdG9vbHMuIFRoZSBtb2RlbCBjYW4gdXNlIGEgc3BlY2lmaWMgdG9vbCxcbiAgICogYW55IGF2YWlsYWJsZSB0b29sLCBvciBkZWNpZGUgYnkgaXRzZWxmLlxuICAgKi9cbiAgdG9vbF9jaG9pY2U/OlxuICAgIHwgTWVzc2FnZUNyZWF0ZVBhcmFtcy5Ub29sQ2hvaWNlQXV0b1xuICAgIHwgTWVzc2FnZUNyZWF0ZVBhcmFtcy5Ub29sQ2hvaWNlQW55XG4gICAgfCBNZXNzYWdlQ3JlYXRlUGFyYW1zLlRvb2xDaG9pY2VUb29sO1xuXG4gIC8qKlxuICAgKiBEZWZpbml0aW9ucyBvZiB0b29scyB0aGF0IHRoZSBtb2RlbCBtYXkgdXNlLlxuICAgKlxuICAgKiBJZiB5b3UgaW5jbHVkZSBgdG9vbHNgIGluIHlvdXIgQVBJIHJlcXVlc3QsIHRoZSBtb2RlbCBtYXkgcmV0dXJuIGB0b29sX3VzZWBcbiAgICogY29udGVudCBibG9ja3MgdGhhdCByZXByZXNlbnQgdGhlIG1vZGVsJ3MgdXNlIG9mIHRob3NlIHRvb2xzLiBZb3UgY2FuIHRoZW4gcnVuXG4gICAqIHRob3NlIHRvb2xzIHVzaW5nIHRoZSB0b29sIGlucHV0IGdlbmVyYXRlZCBieSB0aGUgbW9kZWwgYW5kIHRoZW4gb3B0aW9uYWxseVxuICAgKiByZXR1cm4gcmVzdWx0cyBiYWNrIHRvIHRoZSBtb2RlbCB1c2luZyBgdG9vbF9yZXN1bHRgIGNvbnRlbnQgYmxvY2tzLlxuICAgKlxuICAgKiBFYWNoIHRvb2wgZGVmaW5pdGlvbiBpbmNsdWRlczpcbiAgICpcbiAgICogLSBgbmFtZWA6IE5hbWUgb2YgdGhlIHRvb2wuXG4gICAqIC0gYGRlc2NyaXB0aW9uYDogT3B0aW9uYWwsIGJ1dCBzdHJvbmdseS1yZWNvbW1lbmRlZCBkZXNjcmlwdGlvbiBvZiB0aGUgdG9vbC5cbiAgICogLSBgaW5wdXRfc2NoZW1hYDogW0pTT04gc2NoZW1hXShodHRwczovL2pzb24tc2NoZW1hLm9yZy8pIGZvciB0aGUgdG9vbCBgaW5wdXRgXG4gICAqICAgc2hhcGUgdGhhdCB0aGUgbW9kZWwgd2lsbCBwcm9kdWNlIGluIGB0b29sX3VzZWAgb3V0cHV0IGNvbnRlbnQgYmxvY2tzLlxuICAgKlxuICAgKiBGb3IgZXhhbXBsZSwgaWYgeW91IGRlZmluZWQgYHRvb2xzYCBhczpcbiAgICpcbiAgICogYGBganNvblxuICAgKiBbXG4gICAqICAge1xuICAgKiAgICAgXCJuYW1lXCI6IFwiZ2V0X3N0b2NrX3ByaWNlXCIsXG4gICAqICAgICBcImRlc2NyaXB0aW9uXCI6IFwiR2V0IHRoZSBjdXJyZW50IHN0b2NrIHByaWNlIGZvciBhIGdpdmVuIHRpY2tlciBzeW1ib2wuXCIsXG4gICAqICAgICBcImlucHV0X3NjaGVtYVwiOiB7XG4gICAqICAgICAgIFwidHlwZVwiOiBcIm9iamVjdFwiLFxuICAgKiAgICAgICBcInByb3BlcnRpZXNcIjoge1xuICAgKiAgICAgICAgIFwidGlja2VyXCI6IHtcbiAgICogICAgICAgICAgIFwidHlwZVwiOiBcInN0cmluZ1wiLFxuICAgKiAgICAgICAgICAgXCJkZXNjcmlwdGlvblwiOiBcIlRoZSBzdG9jayB0aWNrZXIgc3ltYm9sLCBlLmcuIEFBUEwgZm9yIEFwcGxlIEluYy5cIlxuICAgKiAgICAgICAgIH1cbiAgICogICAgICAgfSxcbiAgICogICAgICAgXCJyZXF1aXJlZFwiOiBbXCJ0aWNrZXJcIl1cbiAgICogICAgIH1cbiAgICogICB9XG4gICAqIF1cbiAgICogYGBgXG4gICAqXG4gICAqIEFuZCB0aGVuIGFza2VkIHRoZSBtb2RlbCBcIldoYXQncyB0aGUgUyZQIDUwMCBhdCB0b2RheT9cIiwgdGhlIG1vZGVsIG1pZ2h0IHByb2R1Y2VcbiAgICogYHRvb2xfdXNlYCBjb250ZW50IGJsb2NrcyBpbiB0aGUgcmVzcG9uc2UgbGlrZSB0aGlzOlxuICAgKlxuICAgKiBgYGBqc29uXG4gICAqIFtcbiAgICogICB7XG4gICAqICAgICBcInR5cGVcIjogXCJ0b29sX3VzZVwiLFxuICAgKiAgICAgXCJpZFwiOiBcInRvb2x1XzAxRDdGTHJmaDRHWXE3eVQxVUxGZXlNVlwiLFxuICAgKiAgICAgXCJuYW1lXCI6IFwiZ2V0X3N0b2NrX3ByaWNlXCIsXG4gICAqICAgICBcImlucHV0XCI6IHsgXCJ0aWNrZXJcIjogXCJeR1NQQ1wiIH1cbiAgICogICB9XG4gICAqIF1cbiAgICogYGBgXG4gICAqXG4gICAqIFlvdSBtaWdodCB0aGVuIHJ1biB5b3VyIGBnZXRfc3RvY2tfcHJpY2VgIHRvb2wgd2l0aCBge1widGlja2VyXCI6IFwiXkdTUENcIn1gIGFzIGFuXG4gICAqIGlucHV0LCBhbmQgcmV0dXJuIHRoZSBmb2xsb3dpbmcgYmFjayB0byB0aGUgbW9kZWwgaW4gYSBzdWJzZXF1ZW50IGB1c2VyYFxuICAgKiBtZXNzYWdlOlxuICAgKlxuICAgKiBgYGBqc29uXG4gICAqIFtcbiAgICogICB7XG4gICAqICAgICBcInR5cGVcIjogXCJ0b29sX3Jlc3VsdFwiLFxuICAgKiAgICAgXCJ0b29sX3VzZV9pZFwiOiBcInRvb2x1XzAxRDdGTHJmaDRHWXE3eVQxVUxGZXlNVlwiLFxuICAgKiAgICAgXCJjb250ZW50XCI6IFwiMjU5Ljc1IFVTRFwiXG4gICAqICAgfVxuICAgKiBdXG4gICAqIGBgYFxuICAgKlxuICAgKiBUb29scyBjYW4gYmUgdXNlZCBmb3Igd29ya2Zsb3dzIHRoYXQgaW5jbHVkZSBydW5uaW5nIGNsaWVudC1zaWRlIHRvb2xzIGFuZFxuICAgKiBmdW5jdGlvbnMsIG9yIG1vcmUgZ2VuZXJhbGx5IHdoZW5ldmVyIHlvdSB3YW50IHRoZSBtb2RlbCB0byBwcm9kdWNlIGEgcGFydGljdWxhclxuICAgKiBKU09OIHN0cnVjdHVyZSBvZiBvdXRwdXQuXG4gICAqXG4gICAqIFNlZSBvdXIgW2d1aWRlXShodHRwczovL2RvY3MuYW50aHJvcGljLmNvbS9lbi9kb2NzL3Rvb2wtdXNlKSBmb3IgbW9yZSBkZXRhaWxzLlxuICAgKi9cbiAgdG9vbHM/OiBBcnJheTxQcm9tcHRDYWNoaW5nQmV0YVRvb2w+O1xuXG4gIC8qKlxuICAgKiBPbmx5IHNhbXBsZSBmcm9tIHRoZSB0b3AgSyBvcHRpb25zIGZvciBlYWNoIHN1YnNlcXVlbnQgdG9rZW4uXG4gICAqXG4gICAqIFVzZWQgdG8gcmVtb3ZlIFwibG9uZyB0YWlsXCIgbG93IHByb2JhYmlsaXR5IHJlc3BvbnNlcy5cbiAgICogW0xlYXJuIG1vcmUgdGVjaG5pY2FsIGRldGFpbHMgaGVyZV0oaHR0cHM6Ly90b3dhcmRzZGF0YXNjaWVuY2UuY29tL2hvdy10by1zYW1wbGUtZnJvbS1sYW5ndWFnZS1tb2RlbHMtNjgyYmNlYjk3Mjc3KS5cbiAgICpcbiAgICogUmVjb21tZW5kZWQgZm9yIGFkdmFuY2VkIHVzZSBjYXNlcyBvbmx5LiBZb3UgdXN1YWxseSBvbmx5IG5lZWQgdG8gdXNlXG4gICAqIGB0ZW1wZXJhdHVyZWAuXG4gICAqL1xuICB0b3Bfaz86IG51bWJlcjtcblxuICAvKipcbiAgICogVXNlIG51Y2xldXMgc2FtcGxpbmcuXG4gICAqXG4gICAqIEluIG51Y2xldXMgc2FtcGxpbmcsIHdlIGNvbXB1dGUgdGhlIGN1bXVsYXRpdmUgZGlzdHJpYnV0aW9uIG92ZXIgYWxsIHRoZSBvcHRpb25zXG4gICAqIGZvciBlYWNoIHN1YnNlcXVlbnQgdG9rZW4gaW4gZGVjcmVhc2luZyBwcm9iYWJpbGl0eSBvcmRlciBhbmQgY3V0IGl0IG9mZiBvbmNlIGl0XG4gICAqIHJlYWNoZXMgYSBwYXJ0aWN1bGFyIHByb2JhYmlsaXR5IHNwZWNpZmllZCBieSBgdG9wX3BgLiBZb3Ugc2hvdWxkIGVpdGhlciBhbHRlclxuICAgKiBgdGVtcGVyYXR1cmVgIG9yIGB0b3BfcGAsIGJ1dCBub3QgYm90aC5cbiAgICpcbiAgICogUmVjb21tZW5kZWQgZm9yIGFkdmFuY2VkIHVzZSBjYXNlcyBvbmx5LiBZb3UgdXN1YWxseSBvbmx5IG5lZWQgdG8gdXNlXG4gICAqIGB0ZW1wZXJhdHVyZWAuXG4gICAqL1xuICB0b3BfcD86IG51bWJlcjtcbn1cblxuZXhwb3J0IG5hbWVzcGFjZSBNZXNzYWdlQ3JlYXRlUGFyYW1zIHtcbiAgLyoqXG4gICAqIEFuIG9iamVjdCBkZXNjcmliaW5nIG1ldGFkYXRhIGFib3V0IHRoZSByZXF1ZXN0LlxuICAgKi9cbiAgZXhwb3J0IGludGVyZmFjZSBNZXRhZGF0YSB7XG4gICAgLyoqXG4gICAgICogQW4gZXh0ZXJuYWwgaWRlbnRpZmllciBmb3IgdGhlIHVzZXIgd2hvIGlzIGFzc29jaWF0ZWQgd2l0aCB0aGUgcmVxdWVzdC5cbiAgICAgKlxuICAgICAqIFRoaXMgc2hvdWxkIGJlIGEgdXVpZCwgaGFzaCB2YWx1ZSwgb3Igb3RoZXIgb3BhcXVlIGlkZW50aWZpZXIuIEFudGhyb3BpYyBtYXkgdXNlXG4gICAgICogdGhpcyBpZCB0byBoZWxwIGRldGVjdCBhYnVzZS4gRG8gbm90IGluY2x1ZGUgYW55IGlkZW50aWZ5aW5nIGluZm9ybWF0aW9uIHN1Y2ggYXNcbiAgICAgKiBuYW1lLCBlbWFpbCBhZGRyZXNzLCBvciBwaG9uZSBudW1iZXIuXG4gICAgICovXG4gICAgdXNlcl9pZD86IHN0cmluZyB8IG51bGw7XG4gIH1cblxuICAvKipcbiAgICogVGhlIG1vZGVsIHdpbGwgYXV0b21hdGljYWxseSBkZWNpZGUgd2hldGhlciB0byB1c2UgdG9vbHMuXG4gICAqL1xuICBleHBvcnQgaW50ZXJmYWNlIFRvb2xDaG9pY2VBdXRvIHtcbiAgICB0eXBlOiAnYXV0byc7XG5cbiAgICAvKipcbiAgICAgKiBXaGV0aGVyIHRvIGRpc2FibGUgcGFyYWxsZWwgdG9vbCB1c2UuXG4gICAgICpcbiAgICAgKiBEZWZhdWx0cyB0byBgZmFsc2VgLiBJZiBzZXQgdG8gYHRydWVgLCB0aGUgbW9kZWwgd2lsbCBvdXRwdXQgYXQgbW9zdCBvbmUgdG9vbFxuICAgICAqIHVzZS5cbiAgICAgKi9cbiAgICBkaXNhYmxlX3BhcmFsbGVsX3Rvb2xfdXNlPzogYm9vbGVhbjtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGUgbW9kZWwgd2lsbCB1c2UgYW55IGF2YWlsYWJsZSB0b29scy5cbiAgICovXG4gIGV4cG9ydCBpbnRlcmZhY2UgVG9vbENob2ljZUFueSB7XG4gICAgdHlwZTogJ2FueSc7XG5cbiAgICAvKipcbiAgICAgKiBXaGV0aGVyIHRvIGRpc2FibGUgcGFyYWxsZWwgdG9vbCB1c2UuXG4gICAgICpcbiAgICAgKiBEZWZhdWx0cyB0byBgZmFsc2VgLiBJZiBzZXQgdG8gYHRydWVgLCB0aGUgbW9kZWwgd2lsbCBvdXRwdXQgZXhhY3RseSBvbmUgdG9vbFxuICAgICAqIHVzZS5cbiAgICAgKi9cbiAgICBkaXNhYmxlX3BhcmFsbGVsX3Rvb2xfdXNlPzogYm9vbGVhbjtcbiAgfVxuXG4gIC8qKlxuICAgKiBUaGUgbW9kZWwgd2lsbCB1c2UgdGhlIHNwZWNpZmllZCB0b29sIHdpdGggYHRvb2xfY2hvaWNlLm5hbWVgLlxuICAgKi9cbiAgZXhwb3J0IGludGVyZmFjZSBUb29sQ2hvaWNlVG9vbCB7XG4gICAgLyoqXG4gICAgICogVGhlIG5hbWUgb2YgdGhlIHRvb2wgdG8gdXNlLlxuICAgICAqL1xuICAgIG5hbWU6IHN0cmluZztcblxuICAgIHR5cGU6ICd0b29sJztcblxuICAgIC8qKlxuICAgICAqIFdoZXRoZXIgdG8gZGlzYWJsZSBwYXJhbGxlbCB0b29sIHVzZS5cbiAgICAgKlxuICAgICAqIERlZmF1bHRzIHRvIGBmYWxzZWAuIElmIHNldCB0byBgdHJ1ZWAsIHRoZSBtb2RlbCB3aWxsIG91dHB1dCBleGFjdGx5IG9uZSB0b29sXG4gICAgICogdXNlLlxuICAgICAqL1xuICAgIGRpc2FibGVfcGFyYWxsZWxfdG9vbF91c2U/OiBib29sZWFuO1xuICB9XG5cbiAgZXhwb3J0IHR5cGUgTWVzc2FnZUNyZWF0ZVBhcmFtc05vblN0cmVhbWluZyA9IFByb21wdENhY2hpbmdNZXNzYWdlc0FQSS5NZXNzYWdlQ3JlYXRlUGFyYW1zTm9uU3RyZWFtaW5nO1xuICBleHBvcnQgdHlwZSBNZXNzYWdlQ3JlYXRlUGFyYW1zU3RyZWFtaW5nID0gUHJvbXB0Q2FjaGluZ01lc3NhZ2VzQVBJLk1lc3NhZ2VDcmVhdGVQYXJhbXNTdHJlYW1pbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWVzc2FnZUNyZWF0ZVBhcmFtc05vblN0cmVhbWluZyBleHRlbmRzIE1lc3NhZ2VDcmVhdGVQYXJhbXNCYXNlIHtcbiAgLyoqXG4gICAqIFdoZXRoZXIgdG8gaW5jcmVtZW50YWxseSBzdHJlYW0gdGhlIHJlc3BvbnNlIHVzaW5nIHNlcnZlci1zZW50IGV2ZW50cy5cbiAgICpcbiAgICogU2VlIFtzdHJlYW1pbmddKGh0dHBzOi8vZG9jcy5hbnRocm9waWMuY29tL2VuL2FwaS9tZXNzYWdlcy1zdHJlYW1pbmcpIGZvclxuICAgKiBkZXRhaWxzLlxuICAgKi9cbiAgc3RyZWFtPzogZmFsc2U7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWVzc2FnZUNyZWF0ZVBhcmFtc1N0cmVhbWluZyBleHRlbmRzIE1lc3NhZ2VDcmVhdGVQYXJhbXNCYXNlIHtcbiAgLyoqXG4gICAqIFdoZXRoZXIgdG8gaW5jcmVtZW50YWxseSBzdHJlYW0gdGhlIHJlc3BvbnNlIHVzaW5nIHNlcnZlci1zZW50IGV2ZW50cy5cbiAgICpcbiAgICogU2VlIFtzdHJlYW1pbmddKGh0dHBzOi8vZG9jcy5hbnRocm9waWMuY29tL2VuL2FwaS9tZXNzYWdlcy1zdHJlYW1pbmcpIGZvclxuICAgKiBkZXRhaWxzLlxuICAgKi9cbiAgc3RyZWFtOiB0cnVlO1xufVxuXG5leHBvcnQgbmFtZXNwYWNlIE1lc3NhZ2VzIHtcbiAgZXhwb3J0IGltcG9ydCBQcm9tcHRDYWNoaW5nQmV0YUNhY2hlQ29udHJvbEVwaGVtZXJhbCA9IFByb21wdENhY2hpbmdNZXNzYWdlc0FQSS5Qcm9tcHRDYWNoaW5nQmV0YUNhY2hlQ29udHJvbEVwaGVtZXJhbDtcbiAgZXhwb3J0IGltcG9ydCBQcm9tcHRDYWNoaW5nQmV0YUltYWdlQmxvY2tQYXJhbSA9IFByb21wdENhY2hpbmdNZXNzYWdlc0FQSS5Qcm9tcHRDYWNoaW5nQmV0YUltYWdlQmxvY2tQYXJhbTtcbiAgZXhwb3J0IGltcG9ydCBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2UgPSBQcm9tcHRDYWNoaW5nTWVzc2FnZXNBUEkuUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlO1xuICBleHBvcnQgaW1wb3J0IFByb21wdENhY2hpbmdCZXRhTWVzc2FnZVBhcmFtID0gUHJvbXB0Q2FjaGluZ01lc3NhZ2VzQVBJLlByb21wdENhY2hpbmdCZXRhTWVzc2FnZVBhcmFtO1xuICBleHBvcnQgaW1wb3J0IFByb21wdENhY2hpbmdCZXRhVGV4dEJsb2NrUGFyYW0gPSBQcm9tcHRDYWNoaW5nTWVzc2FnZXNBUEkuUHJvbXB0Q2FjaGluZ0JldGFUZXh0QmxvY2tQYXJhbTtcbiAgZXhwb3J0IGltcG9ydCBQcm9tcHRDYWNoaW5nQmV0YVRvb2wgPSBQcm9tcHRDYWNoaW5nTWVzc2FnZXNBUEkuUHJvbXB0Q2FjaGluZ0JldGFUb29sO1xuICBleHBvcnQgaW1wb3J0IFByb21wdENhY2hpbmdCZXRhVG9vbFJlc3VsdEJsb2NrUGFyYW0gPSBQcm9tcHRDYWNoaW5nTWVzc2FnZXNBUEkuUHJvbXB0Q2FjaGluZ0JldGFUb29sUmVzdWx0QmxvY2tQYXJhbTtcbiAgZXhwb3J0IGltcG9ydCBQcm9tcHRDYWNoaW5nQmV0YVRvb2xVc2VCbG9ja1BhcmFtID0gUHJvbXB0Q2FjaGluZ01lc3NhZ2VzQVBJLlByb21wdENhY2hpbmdCZXRhVG9vbFVzZUJsb2NrUGFyYW07XG4gIGV4cG9ydCBpbXBvcnQgUHJvbXB0Q2FjaGluZ0JldGFVc2FnZSA9IFByb21wdENhY2hpbmdNZXNzYWdlc0FQSS5Qcm9tcHRDYWNoaW5nQmV0YVVzYWdlO1xuICBleHBvcnQgaW1wb3J0IFJhd1Byb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0YXJ0RXZlbnQgPSBQcm9tcHRDYWNoaW5nTWVzc2FnZXNBUEkuUmF3UHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlU3RhcnRFdmVudDtcbiAgZXhwb3J0IGltcG9ydCBSYXdQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudCA9IFByb21wdENhY2hpbmdNZXNzYWdlc0FQSS5SYXdQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudDtcbiAgZXhwb3J0IGltcG9ydCBNZXNzYWdlQ3JlYXRlUGFyYW1zID0gUHJvbXB0Q2FjaGluZ01lc3NhZ2VzQVBJLk1lc3NhZ2VDcmVhdGVQYXJhbXM7XG4gIGV4cG9ydCBpbXBvcnQgTWVzc2FnZUNyZWF0ZVBhcmFtc05vblN0cmVhbWluZyA9IFByb21wdENhY2hpbmdNZXNzYWdlc0FQSS5NZXNzYWdlQ3JlYXRlUGFyYW1zTm9uU3RyZWFtaW5nO1xuICBleHBvcnQgaW1wb3J0IE1lc3NhZ2VDcmVhdGVQYXJhbXNTdHJlYW1pbmcgPSBQcm9tcHRDYWNoaW5nTWVzc2FnZXNBUEkuTWVzc2FnZUNyZWF0ZVBhcmFtc1N0cmVhbWluZztcbn1cbiIsICIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuXG5pbXBvcnQgeyBBUElSZXNvdXJjZSB9IGZyb20gXCIuLi8uLi8uLi9yZXNvdXJjZS5qc1wiO1xuaW1wb3J0ICogYXMgTWVzc2FnZXNBUEkgZnJvbSBcIi4vbWVzc2FnZXMuanNcIjtcblxuZXhwb3J0IGNsYXNzIFByb21wdENhY2hpbmcgZXh0ZW5kcyBBUElSZXNvdXJjZSB7XG4gIG1lc3NhZ2VzOiBNZXNzYWdlc0FQSS5NZXNzYWdlcyA9IG5ldyBNZXNzYWdlc0FQSS5NZXNzYWdlcyh0aGlzLl9jbGllbnQpO1xufVxuXG5leHBvcnQgbmFtZXNwYWNlIFByb21wdENhY2hpbmcge1xuICBleHBvcnQgaW1wb3J0IE1lc3NhZ2VzID0gTWVzc2FnZXNBUEkuTWVzc2FnZXM7XG4gIGV4cG9ydCBpbXBvcnQgUHJvbXB0Q2FjaGluZ0JldGFDYWNoZUNvbnRyb2xFcGhlbWVyYWwgPSBNZXNzYWdlc0FQSS5Qcm9tcHRDYWNoaW5nQmV0YUNhY2hlQ29udHJvbEVwaGVtZXJhbDtcbiAgZXhwb3J0IGltcG9ydCBQcm9tcHRDYWNoaW5nQmV0YUltYWdlQmxvY2tQYXJhbSA9IE1lc3NhZ2VzQVBJLlByb21wdENhY2hpbmdCZXRhSW1hZ2VCbG9ja1BhcmFtO1xuICBleHBvcnQgaW1wb3J0IFByb21wdENhY2hpbmdCZXRhTWVzc2FnZSA9IE1lc3NhZ2VzQVBJLlByb21wdENhY2hpbmdCZXRhTWVzc2FnZTtcbiAgZXhwb3J0IGltcG9ydCBQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VQYXJhbSA9IE1lc3NhZ2VzQVBJLlByb21wdENhY2hpbmdCZXRhTWVzc2FnZVBhcmFtO1xuICBleHBvcnQgaW1wb3J0IFByb21wdENhY2hpbmdCZXRhVGV4dEJsb2NrUGFyYW0gPSBNZXNzYWdlc0FQSS5Qcm9tcHRDYWNoaW5nQmV0YVRleHRCbG9ja1BhcmFtO1xuICBleHBvcnQgaW1wb3J0IFByb21wdENhY2hpbmdCZXRhVG9vbCA9IE1lc3NhZ2VzQVBJLlByb21wdENhY2hpbmdCZXRhVG9vbDtcbiAgZXhwb3J0IGltcG9ydCBQcm9tcHRDYWNoaW5nQmV0YVRvb2xSZXN1bHRCbG9ja1BhcmFtID0gTWVzc2FnZXNBUEkuUHJvbXB0Q2FjaGluZ0JldGFUb29sUmVzdWx0QmxvY2tQYXJhbTtcbiAgZXhwb3J0IGltcG9ydCBQcm9tcHRDYWNoaW5nQmV0YVRvb2xVc2VCbG9ja1BhcmFtID0gTWVzc2FnZXNBUEkuUHJvbXB0Q2FjaGluZ0JldGFUb29sVXNlQmxvY2tQYXJhbTtcbiAgZXhwb3J0IGltcG9ydCBQcm9tcHRDYWNoaW5nQmV0YVVzYWdlID0gTWVzc2FnZXNBUEkuUHJvbXB0Q2FjaGluZ0JldGFVc2FnZTtcbiAgZXhwb3J0IGltcG9ydCBSYXdQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdGFydEV2ZW50ID0gTWVzc2FnZXNBUEkuUmF3UHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlU3RhcnRFdmVudDtcbiAgZXhwb3J0IGltcG9ydCBSYXdQcm9tcHRDYWNoaW5nQmV0YU1lc3NhZ2VTdHJlYW1FdmVudCA9IE1lc3NhZ2VzQVBJLlJhd1Byb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbUV2ZW50O1xuICBleHBvcnQgaW1wb3J0IE1lc3NhZ2VDcmVhdGVQYXJhbXMgPSBNZXNzYWdlc0FQSS5NZXNzYWdlQ3JlYXRlUGFyYW1zO1xuICBleHBvcnQgaW1wb3J0IE1lc3NhZ2VDcmVhdGVQYXJhbXNOb25TdHJlYW1pbmcgPSBNZXNzYWdlc0FQSS5NZXNzYWdlQ3JlYXRlUGFyYW1zTm9uU3RyZWFtaW5nO1xuICBleHBvcnQgaW1wb3J0IE1lc3NhZ2VDcmVhdGVQYXJhbXNTdHJlYW1pbmcgPSBNZXNzYWdlc0FQSS5NZXNzYWdlQ3JlYXRlUGFyYW1zU3RyZWFtaW5nO1xufVxuIiwgIi8vIEZpbGUgZ2VuZXJhdGVkIGZyb20gb3VyIE9wZW5BUEkgc3BlYyBieSBTdGFpbmxlc3MuIFNlZSBDT05UUklCVVRJTkcubWQgZm9yIGRldGFpbHMuXG5cbmltcG9ydCB7IEFQSVJlc291cmNlIH0gZnJvbSBcIi4uLy4uL3Jlc291cmNlLmpzXCI7XG5pbXBvcnQgKiBhcyBQcm9tcHRDYWNoaW5nQVBJIGZyb20gXCIuL3Byb21wdC1jYWNoaW5nL3Byb21wdC1jYWNoaW5nLmpzXCI7XG5cbmV4cG9ydCBjbGFzcyBCZXRhIGV4dGVuZHMgQVBJUmVzb3VyY2Uge1xuICBwcm9tcHRDYWNoaW5nOiBQcm9tcHRDYWNoaW5nQVBJLlByb21wdENhY2hpbmcgPSBuZXcgUHJvbXB0Q2FjaGluZ0FQSS5Qcm9tcHRDYWNoaW5nKHRoaXMuX2NsaWVudCk7XG59XG5cbmV4cG9ydCBuYW1lc3BhY2UgQmV0YSB7XG4gIGV4cG9ydCBpbXBvcnQgUHJvbXB0Q2FjaGluZyA9IFByb21wdENhY2hpbmdBUEkuUHJvbXB0Q2FjaGluZztcbn1cbiIsICIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuXG5pbXBvcnQgeyBBUElSZXNvdXJjZSB9IGZyb20gXCIuLi9yZXNvdXJjZS5qc1wiO1xuaW1wb3J0IHsgQVBJUHJvbWlzZSB9IGZyb20gXCIuLi9jb3JlLmpzXCI7XG5pbXBvcnQgKiBhcyBDb3JlIGZyb20gXCIuLi9jb3JlLmpzXCI7XG5pbXBvcnQgKiBhcyBDb21wbGV0aW9uc0FQSSBmcm9tIFwiLi9jb21wbGV0aW9ucy5qc1wiO1xuaW1wb3J0ICogYXMgTWVzc2FnZXNBUEkgZnJvbSBcIi4vbWVzc2FnZXMuanNcIjtcbmltcG9ydCB7IFN0cmVhbSB9IGZyb20gXCIuLi9zdHJlYW1pbmcuanNcIjtcblxuZXhwb3J0IGNsYXNzIENvbXBsZXRpb25zIGV4dGVuZHMgQVBJUmVzb3VyY2Uge1xuICAvKipcbiAgICogW0xlZ2FjeV0gQ3JlYXRlIGEgVGV4dCBDb21wbGV0aW9uLlxuICAgKlxuICAgKiBUaGUgVGV4dCBDb21wbGV0aW9ucyBBUEkgaXMgYSBsZWdhY3kgQVBJLiBXZSByZWNvbW1lbmQgdXNpbmcgdGhlXG4gICAqIFtNZXNzYWdlcyBBUEldKGh0dHBzOi8vZG9jcy5hbnRocm9waWMuY29tL2VuL2FwaS9tZXNzYWdlcykgZ29pbmcgZm9yd2FyZC5cbiAgICpcbiAgICogRnV0dXJlIG1vZGVscyBhbmQgZmVhdHVyZXMgd2lsbCBub3QgYmUgY29tcGF0aWJsZSB3aXRoIFRleHQgQ29tcGxldGlvbnMuIFNlZSBvdXJcbiAgICogW21pZ3JhdGlvbiBndWlkZV0oaHR0cHM6Ly9kb2NzLmFudGhyb3BpYy5jb20vZW4vYXBpL21pZ3JhdGluZy1mcm9tLXRleHQtY29tcGxldGlvbnMtdG8tbWVzc2FnZXMpXG4gICAqIGZvciBndWlkYW5jZSBpbiBtaWdyYXRpbmcgZnJvbSBUZXh0IENvbXBsZXRpb25zIHRvIE1lc3NhZ2VzLlxuICAgKi9cbiAgY3JlYXRlKGJvZHk6IENvbXBsZXRpb25DcmVhdGVQYXJhbXNOb25TdHJlYW1pbmcsIG9wdGlvbnM/OiBDb3JlLlJlcXVlc3RPcHRpb25zKTogQVBJUHJvbWlzZTxDb21wbGV0aW9uPjtcbiAgY3JlYXRlKFxuICAgIGJvZHk6IENvbXBsZXRpb25DcmVhdGVQYXJhbXNTdHJlYW1pbmcsXG4gICAgb3B0aW9ucz86IENvcmUuUmVxdWVzdE9wdGlvbnMsXG4gICk6IEFQSVByb21pc2U8U3RyZWFtPENvbXBsZXRpb24+PjtcbiAgY3JlYXRlKFxuICAgIGJvZHk6IENvbXBsZXRpb25DcmVhdGVQYXJhbXNCYXNlLFxuICAgIG9wdGlvbnM/OiBDb3JlLlJlcXVlc3RPcHRpb25zLFxuICApOiBBUElQcm9taXNlPFN0cmVhbTxDb21wbGV0aW9uPiB8IENvbXBsZXRpb24+O1xuICBjcmVhdGUoXG4gICAgYm9keTogQ29tcGxldGlvbkNyZWF0ZVBhcmFtcyxcbiAgICBvcHRpb25zPzogQ29yZS5SZXF1ZXN0T3B0aW9ucyxcbiAgKTogQVBJUHJvbWlzZTxDb21wbGV0aW9uPiB8IEFQSVByb21pc2U8U3RyZWFtPENvbXBsZXRpb24+PiB7XG4gICAgcmV0dXJuIHRoaXMuX2NsaWVudC5wb3N0KCcvdjEvY29tcGxldGUnLCB7XG4gICAgICBib2R5LFxuICAgICAgdGltZW91dDogKHRoaXMuX2NsaWVudCBhcyBhbnkpLl9vcHRpb25zLnRpbWVvdXQgPz8gNjAwMDAwLFxuICAgICAgLi4ub3B0aW9ucyxcbiAgICAgIHN0cmVhbTogYm9keS5zdHJlYW0gPz8gZmFsc2UsXG4gICAgfSkgYXMgQVBJUHJvbWlzZTxDb21wbGV0aW9uPiB8IEFQSVByb21pc2U8U3RyZWFtPENvbXBsZXRpb24+PjtcbiAgfVxufVxuXG5leHBvcnQgaW50ZXJmYWNlIENvbXBsZXRpb24ge1xuICAvKipcbiAgICogVW5pcXVlIG9iamVjdCBpZGVudGlmaWVyLlxuICAgKlxuICAgKiBUaGUgZm9ybWF0IGFuZCBsZW5ndGggb2YgSURzIG1heSBjaGFuZ2Ugb3ZlciB0aW1lLlxuICAgKi9cbiAgaWQ6IHN0cmluZztcblxuICAvKipcbiAgICogVGhlIHJlc3VsdGluZyBjb21wbGV0aW9uIHVwIHRvIGFuZCBleGNsdWRpbmcgdGhlIHN0b3Agc2VxdWVuY2VzLlxuICAgKi9cbiAgY29tcGxldGlvbjogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBUaGUgbW9kZWwgdGhhdCB3aWxsIGNvbXBsZXRlIHlvdXIgcHJvbXB0LlxcblxcblNlZVxuICAgKiBbbW9kZWxzXShodHRwczovL2RvY3MuYW50aHJvcGljLmNvbS9lbi9kb2NzL21vZGVscy1vdmVydmlldykgZm9yIGFkZGl0aW9uYWxcbiAgICogZGV0YWlscyBhbmQgb3B0aW9ucy5cbiAgICovXG4gIG1vZGVsOiBNZXNzYWdlc0FQSS5Nb2RlbDtcblxuICAvKipcbiAgICogVGhlIHJlYXNvbiB0aGF0IHdlIHN0b3BwZWQuXG4gICAqXG4gICAqIFRoaXMgbWF5IGJlIG9uZSB0aGUgZm9sbG93aW5nIHZhbHVlczpcbiAgICpcbiAgICogLSBgXCJzdG9wX3NlcXVlbmNlXCJgOiB3ZSByZWFjaGVkIGEgc3RvcCBzZXF1ZW5jZSBcdTIwMTQgZWl0aGVyIHByb3ZpZGVkIGJ5IHlvdSB2aWEgdGhlXG4gICAqICAgYHN0b3Bfc2VxdWVuY2VzYCBwYXJhbWV0ZXIsIG9yIGEgc3RvcCBzZXF1ZW5jZSBidWlsdCBpbnRvIHRoZSBtb2RlbFxuICAgKiAtIGBcIm1heF90b2tlbnNcImA6IHdlIGV4Y2VlZGVkIGBtYXhfdG9rZW5zX3RvX3NhbXBsZWAgb3IgdGhlIG1vZGVsJ3MgbWF4aW11bVxuICAgKi9cbiAgc3RvcF9yZWFzb246IHN0cmluZyB8IG51bGw7XG5cbiAgLyoqXG4gICAqIE9iamVjdCB0eXBlLlxuICAgKlxuICAgKiBGb3IgVGV4dCBDb21wbGV0aW9ucywgdGhpcyBpcyBhbHdheXMgYFwiY29tcGxldGlvblwiYC5cbiAgICovXG4gIHR5cGU6ICdjb21wbGV0aW9uJztcbn1cblxuZXhwb3J0IHR5cGUgQ29tcGxldGlvbkNyZWF0ZVBhcmFtcyA9IENvbXBsZXRpb25DcmVhdGVQYXJhbXNOb25TdHJlYW1pbmcgfCBDb21wbGV0aW9uQ3JlYXRlUGFyYW1zU3RyZWFtaW5nO1xuXG5leHBvcnQgaW50ZXJmYWNlIENvbXBsZXRpb25DcmVhdGVQYXJhbXNCYXNlIHtcbiAgLyoqXG4gICAqIFRoZSBtYXhpbXVtIG51bWJlciBvZiB0b2tlbnMgdG8gZ2VuZXJhdGUgYmVmb3JlIHN0b3BwaW5nLlxuICAgKlxuICAgKiBOb3RlIHRoYXQgb3VyIG1vZGVscyBtYXkgc3RvcCBfYmVmb3JlXyByZWFjaGluZyB0aGlzIG1heGltdW0uIFRoaXMgcGFyYW1ldGVyXG4gICAqIG9ubHkgc3BlY2lmaWVzIHRoZSBhYnNvbHV0ZSBtYXhpbXVtIG51bWJlciBvZiB0b2tlbnMgdG8gZ2VuZXJhdGUuXG4gICAqL1xuICBtYXhfdG9rZW5zX3RvX3NhbXBsZTogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBUaGUgbW9kZWwgdGhhdCB3aWxsIGNvbXBsZXRlIHlvdXIgcHJvbXB0LlxcblxcblNlZVxuICAgKiBbbW9kZWxzXShodHRwczovL2RvY3MuYW50aHJvcGljLmNvbS9lbi9kb2NzL21vZGVscy1vdmVydmlldykgZm9yIGFkZGl0aW9uYWxcbiAgICogZGV0YWlscyBhbmQgb3B0aW9ucy5cbiAgICovXG4gIG1vZGVsOiBNZXNzYWdlc0FQSS5Nb2RlbDtcblxuICAvKipcbiAgICogVGhlIHByb21wdCB0aGF0IHlvdSB3YW50IENsYXVkZSB0byBjb21wbGV0ZS5cbiAgICpcbiAgICogRm9yIHByb3BlciByZXNwb25zZSBnZW5lcmF0aW9uIHlvdSB3aWxsIG5lZWQgdG8gZm9ybWF0IHlvdXIgcHJvbXB0IHVzaW5nXG4gICAqIGFsdGVybmF0aW5nIGBcXG5cXG5IdW1hbjpgIGFuZCBgXFxuXFxuQXNzaXN0YW50OmAgY29udmVyc2F0aW9uYWwgdHVybnMuIEZvciBleGFtcGxlOlxuICAgKlxuICAgKiBgYGBcbiAgICogXCJcXG5cXG5IdW1hbjoge3VzZXJRdWVzdGlvbn1cXG5cXG5Bc3Npc3RhbnQ6XCJcbiAgICogYGBgXG4gICAqXG4gICAqIFNlZSBbcHJvbXB0IHZhbGlkYXRpb25dKGh0dHBzOi8vZG9jcy5hbnRocm9waWMuY29tL2VuL2FwaS9wcm9tcHQtdmFsaWRhdGlvbikgYW5kXG4gICAqIG91ciBndWlkZSB0b1xuICAgKiBbcHJvbXB0IGRlc2lnbl0oaHR0cHM6Ly9kb2NzLmFudGhyb3BpYy5jb20vZW4vZG9jcy9pbnRyby10by1wcm9tcHRpbmcpIGZvciBtb3JlXG4gICAqIGRldGFpbHMuXG4gICAqL1xuICBwcm9tcHQ6IHN0cmluZztcblxuICAvKipcbiAgICogQW4gb2JqZWN0IGRlc2NyaWJpbmcgbWV0YWRhdGEgYWJvdXQgdGhlIHJlcXVlc3QuXG4gICAqL1xuICBtZXRhZGF0YT86IENvbXBsZXRpb25DcmVhdGVQYXJhbXMuTWV0YWRhdGE7XG5cbiAgLyoqXG4gICAqIFNlcXVlbmNlcyB0aGF0IHdpbGwgY2F1c2UgdGhlIG1vZGVsIHRvIHN0b3AgZ2VuZXJhdGluZy5cbiAgICpcbiAgICogT3VyIG1vZGVscyBzdG9wIG9uIGBcIlxcblxcbkh1bWFuOlwiYCwgYW5kIG1heSBpbmNsdWRlIGFkZGl0aW9uYWwgYnVpbHQtaW4gc3RvcFxuICAgKiBzZXF1ZW5jZXMgaW4gdGhlIGZ1dHVyZS4gQnkgcHJvdmlkaW5nIHRoZSBzdG9wX3NlcXVlbmNlcyBwYXJhbWV0ZXIsIHlvdSBtYXlcbiAgICogaW5jbHVkZSBhZGRpdGlvbmFsIHN0cmluZ3MgdGhhdCB3aWxsIGNhdXNlIHRoZSBtb2RlbCB0byBzdG9wIGdlbmVyYXRpbmcuXG4gICAqL1xuICBzdG9wX3NlcXVlbmNlcz86IEFycmF5PHN0cmluZz47XG5cbiAgLyoqXG4gICAqIFdoZXRoZXIgdG8gaW5jcmVtZW50YWxseSBzdHJlYW0gdGhlIHJlc3BvbnNlIHVzaW5nIHNlcnZlci1zZW50IGV2ZW50cy5cbiAgICpcbiAgICogU2VlIFtzdHJlYW1pbmddKGh0dHBzOi8vZG9jcy5hbnRocm9waWMuY29tL2VuL2FwaS9zdHJlYW1pbmcpIGZvciBkZXRhaWxzLlxuICAgKi9cbiAgc3RyZWFtPzogYm9vbGVhbjtcblxuICAvKipcbiAgICogQW1vdW50IG9mIHJhbmRvbW5lc3MgaW5qZWN0ZWQgaW50byB0aGUgcmVzcG9uc2UuXG4gICAqXG4gICAqIERlZmF1bHRzIHRvIGAxLjBgLiBSYW5nZXMgZnJvbSBgMC4wYCB0byBgMS4wYC4gVXNlIGB0ZW1wZXJhdHVyZWAgY2xvc2VyIHRvIGAwLjBgXG4gICAqIGZvciBhbmFseXRpY2FsIC8gbXVsdGlwbGUgY2hvaWNlLCBhbmQgY2xvc2VyIHRvIGAxLjBgIGZvciBjcmVhdGl2ZSBhbmRcbiAgICogZ2VuZXJhdGl2ZSB0YXNrcy5cbiAgICpcbiAgICogTm90ZSB0aGF0IGV2ZW4gd2l0aCBgdGVtcGVyYXR1cmVgIG9mIGAwLjBgLCB0aGUgcmVzdWx0cyB3aWxsIG5vdCBiZSBmdWxseVxuICAgKiBkZXRlcm1pbmlzdGljLlxuICAgKi9cbiAgdGVtcGVyYXR1cmU/OiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIE9ubHkgc2FtcGxlIGZyb20gdGhlIHRvcCBLIG9wdGlvbnMgZm9yIGVhY2ggc3Vic2VxdWVudCB0b2tlbi5cbiAgICpcbiAgICogVXNlZCB0byByZW1vdmUgXCJsb25nIHRhaWxcIiBsb3cgcHJvYmFiaWxpdHkgcmVzcG9uc2VzLlxuICAgKiBbTGVhcm4gbW9yZSB0ZWNobmljYWwgZGV0YWlscyBoZXJlXShodHRwczovL3Rvd2FyZHNkYXRhc2NpZW5jZS5jb20vaG93LXRvLXNhbXBsZS1mcm9tLWxhbmd1YWdlLW1vZGVscy02ODJiY2ViOTcyNzcpLlxuICAgKlxuICAgKiBSZWNvbW1lbmRlZCBmb3IgYWR2YW5jZWQgdXNlIGNhc2VzIG9ubHkuIFlvdSB1c3VhbGx5IG9ubHkgbmVlZCB0byB1c2VcbiAgICogYHRlbXBlcmF0dXJlYC5cbiAgICovXG4gIHRvcF9rPzogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBVc2UgbnVjbGV1cyBzYW1wbGluZy5cbiAgICpcbiAgICogSW4gbnVjbGV1cyBzYW1wbGluZywgd2UgY29tcHV0ZSB0aGUgY3VtdWxhdGl2ZSBkaXN0cmlidXRpb24gb3ZlciBhbGwgdGhlIG9wdGlvbnNcbiAgICogZm9yIGVhY2ggc3Vic2VxdWVudCB0b2tlbiBpbiBkZWNyZWFzaW5nIHByb2JhYmlsaXR5IG9yZGVyIGFuZCBjdXQgaXQgb2ZmIG9uY2UgaXRcbiAgICogcmVhY2hlcyBhIHBhcnRpY3VsYXIgcHJvYmFiaWxpdHkgc3BlY2lmaWVkIGJ5IGB0b3BfcGAuIFlvdSBzaG91bGQgZWl0aGVyIGFsdGVyXG4gICAqIGB0ZW1wZXJhdHVyZWAgb3IgYHRvcF9wYCwgYnV0IG5vdCBib3RoLlxuICAgKlxuICAgKiBSZWNvbW1lbmRlZCBmb3IgYWR2YW5jZWQgdXNlIGNhc2VzIG9ubHkuIFlvdSB1c3VhbGx5IG9ubHkgbmVlZCB0byB1c2VcbiAgICogYHRlbXBlcmF0dXJlYC5cbiAgICovXG4gIHRvcF9wPzogbnVtYmVyO1xufVxuXG5leHBvcnQgbmFtZXNwYWNlIENvbXBsZXRpb25DcmVhdGVQYXJhbXMge1xuICAvKipcbiAgICogQW4gb2JqZWN0IGRlc2NyaWJpbmcgbWV0YWRhdGEgYWJvdXQgdGhlIHJlcXVlc3QuXG4gICAqL1xuICBleHBvcnQgaW50ZXJmYWNlIE1ldGFkYXRhIHtcbiAgICAvKipcbiAgICAgKiBBbiBleHRlcm5hbCBpZGVudGlmaWVyIGZvciB0aGUgdXNlciB3aG8gaXMgYXNzb2NpYXRlZCB3aXRoIHRoZSByZXF1ZXN0LlxuICAgICAqXG4gICAgICogVGhpcyBzaG91bGQgYmUgYSB1dWlkLCBoYXNoIHZhbHVlLCBvciBvdGhlciBvcGFxdWUgaWRlbnRpZmllci4gQW50aHJvcGljIG1heSB1c2VcbiAgICAgKiB0aGlzIGlkIHRvIGhlbHAgZGV0ZWN0IGFidXNlLiBEbyBub3QgaW5jbHVkZSBhbnkgaWRlbnRpZnlpbmcgaW5mb3JtYXRpb24gc3VjaCBhc1xuICAgICAqIG5hbWUsIGVtYWlsIGFkZHJlc3MsIG9yIHBob25lIG51bWJlci5cbiAgICAgKi9cbiAgICB1c2VyX2lkPzogc3RyaW5nIHwgbnVsbDtcbiAgfVxuXG4gIGV4cG9ydCB0eXBlIENvbXBsZXRpb25DcmVhdGVQYXJhbXNOb25TdHJlYW1pbmcgPSBDb21wbGV0aW9uc0FQSS5Db21wbGV0aW9uQ3JlYXRlUGFyYW1zTm9uU3RyZWFtaW5nO1xuICBleHBvcnQgdHlwZSBDb21wbGV0aW9uQ3JlYXRlUGFyYW1zU3RyZWFtaW5nID0gQ29tcGxldGlvbnNBUEkuQ29tcGxldGlvbkNyZWF0ZVBhcmFtc1N0cmVhbWluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDb21wbGV0aW9uQ3JlYXRlUGFyYW1zTm9uU3RyZWFtaW5nIGV4dGVuZHMgQ29tcGxldGlvbkNyZWF0ZVBhcmFtc0Jhc2Uge1xuICAvKipcbiAgICogV2hldGhlciB0byBpbmNyZW1lbnRhbGx5IHN0cmVhbSB0aGUgcmVzcG9uc2UgdXNpbmcgc2VydmVyLXNlbnQgZXZlbnRzLlxuICAgKlxuICAgKiBTZWUgW3N0cmVhbWluZ10oaHR0cHM6Ly9kb2NzLmFudGhyb3BpYy5jb20vZW4vYXBpL3N0cmVhbWluZykgZm9yIGRldGFpbHMuXG4gICAqL1xuICBzdHJlYW0/OiBmYWxzZTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBDb21wbGV0aW9uQ3JlYXRlUGFyYW1zU3RyZWFtaW5nIGV4dGVuZHMgQ29tcGxldGlvbkNyZWF0ZVBhcmFtc0Jhc2Uge1xuICAvKipcbiAgICogV2hldGhlciB0byBpbmNyZW1lbnRhbGx5IHN0cmVhbSB0aGUgcmVzcG9uc2UgdXNpbmcgc2VydmVyLXNlbnQgZXZlbnRzLlxuICAgKlxuICAgKiBTZWUgW3N0cmVhbWluZ10oaHR0cHM6Ly9kb2NzLmFudGhyb3BpYy5jb20vZW4vYXBpL3N0cmVhbWluZykgZm9yIGRldGFpbHMuXG4gICAqL1xuICBzdHJlYW06IHRydWU7XG59XG5cbmV4cG9ydCBuYW1lc3BhY2UgQ29tcGxldGlvbnMge1xuICBleHBvcnQgaW1wb3J0IENvbXBsZXRpb24gPSBDb21wbGV0aW9uc0FQSS5Db21wbGV0aW9uO1xuICBleHBvcnQgaW1wb3J0IENvbXBsZXRpb25DcmVhdGVQYXJhbXMgPSBDb21wbGV0aW9uc0FQSS5Db21wbGV0aW9uQ3JlYXRlUGFyYW1zO1xuICBleHBvcnQgaW1wb3J0IENvbXBsZXRpb25DcmVhdGVQYXJhbXNOb25TdHJlYW1pbmcgPSBDb21wbGV0aW9uc0FQSS5Db21wbGV0aW9uQ3JlYXRlUGFyYW1zTm9uU3RyZWFtaW5nO1xuICBleHBvcnQgaW1wb3J0IENvbXBsZXRpb25DcmVhdGVQYXJhbXNTdHJlYW1pbmcgPSBDb21wbGV0aW9uc0FQSS5Db21wbGV0aW9uQ3JlYXRlUGFyYW1zU3RyZWFtaW5nO1xufVxuIiwgImltcG9ydCAqIGFzIENvcmUgZnJvbSBcIi4uL2NvcmUuanNcIjtcbmltcG9ydCB7IEFudGhyb3BpY0Vycm9yLCBBUElVc2VyQWJvcnRFcnJvciB9IGZyb20gXCIuLi9lcnJvci5qc1wiO1xuaW1wb3J0IHtcbiAgdHlwZSBDb250ZW50QmxvY2ssXG4gIE1lc3NhZ2VzLFxuICB0eXBlIE1lc3NhZ2UsXG4gIHR5cGUgTWVzc2FnZVN0cmVhbUV2ZW50LFxuICB0eXBlIE1lc3NhZ2VQYXJhbSxcbiAgdHlwZSBNZXNzYWdlQ3JlYXRlUGFyYW1zLFxuICB0eXBlIE1lc3NhZ2VDcmVhdGVQYXJhbXNCYXNlLFxuICB0eXBlIFRleHRCbG9jayxcbn0gZnJvbSBcIi4uL3Jlc291cmNlcy9tZXNzYWdlcy5qc1wiO1xuaW1wb3J0IHsgdHlwZSBSZWFkYWJsZVN0cmVhbSB9IGZyb20gXCIuLi9fc2hpbXMvaW5kZXguanNcIjtcbmltcG9ydCB7IFN0cmVhbSB9IGZyb20gXCIuLi9zdHJlYW1pbmcuanNcIjtcbmltcG9ydCB7IHBhcnRpYWxQYXJzZSB9IGZyb20gXCIuLi9fdmVuZG9yL3BhcnRpYWwtanNvbi1wYXJzZXIvcGFyc2VyLmpzXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWVzc2FnZVN0cmVhbUV2ZW50cyB7XG4gIGNvbm5lY3Q6ICgpID0+IHZvaWQ7XG4gIHN0cmVhbUV2ZW50OiAoZXZlbnQ6IE1lc3NhZ2VTdHJlYW1FdmVudCwgc25hcHNob3Q6IE1lc3NhZ2UpID0+IHZvaWQ7XG4gIHRleHQ6ICh0ZXh0RGVsdGE6IHN0cmluZywgdGV4dFNuYXBzaG90OiBzdHJpbmcpID0+IHZvaWQ7XG4gIGlucHV0SnNvbjogKHBhcnRpYWxKc29uOiBzdHJpbmcsIGpzb25TbmFwc2hvdDogdW5rbm93bikgPT4gdm9pZDtcbiAgbWVzc2FnZTogKG1lc3NhZ2U6IE1lc3NhZ2UpID0+IHZvaWQ7XG4gIGNvbnRlbnRCbG9jazogKGNvbnRlbnQ6IENvbnRlbnRCbG9jaykgPT4gdm9pZDtcbiAgZmluYWxNZXNzYWdlOiAobWVzc2FnZTogTWVzc2FnZSkgPT4gdm9pZDtcbiAgZXJyb3I6IChlcnJvcjogQW50aHJvcGljRXJyb3IpID0+IHZvaWQ7XG4gIGFib3J0OiAoZXJyb3I6IEFQSVVzZXJBYm9ydEVycm9yKSA9PiB2b2lkO1xuICBlbmQ6ICgpID0+IHZvaWQ7XG59XG5cbnR5cGUgTWVzc2FnZVN0cmVhbUV2ZW50TGlzdGVuZXJzPEV2ZW50IGV4dGVuZHMga2V5b2YgTWVzc2FnZVN0cmVhbUV2ZW50cz4gPSB7XG4gIGxpc3RlbmVyOiBNZXNzYWdlU3RyZWFtRXZlbnRzW0V2ZW50XTtcbiAgb25jZT86IGJvb2xlYW47XG59W107XG5cbmNvbnN0IEpTT05fQlVGX1BST1BFUlRZID0gJ19fanNvbl9idWYnO1xuXG5leHBvcnQgY2xhc3MgTWVzc2FnZVN0cmVhbSBpbXBsZW1lbnRzIEFzeW5jSXRlcmFibGU8TWVzc2FnZVN0cmVhbUV2ZW50PiB7XG4gIG1lc3NhZ2VzOiBNZXNzYWdlUGFyYW1bXSA9IFtdO1xuICByZWNlaXZlZE1lc3NhZ2VzOiBNZXNzYWdlW10gPSBbXTtcbiAgI2N1cnJlbnRNZXNzYWdlU25hcHNob3Q6IE1lc3NhZ2UgfCB1bmRlZmluZWQ7XG5cbiAgY29udHJvbGxlcjogQWJvcnRDb250cm9sbGVyID0gbmV3IEFib3J0Q29udHJvbGxlcigpO1xuXG4gICNjb25uZWN0ZWRQcm9taXNlOiBQcm9taXNlPHZvaWQ+O1xuICAjcmVzb2x2ZUNvbm5lY3RlZFByb21pc2U6ICgpID0+IHZvaWQgPSAoKSA9PiB7fTtcbiAgI3JlamVjdENvbm5lY3RlZFByb21pc2U6IChlcnJvcjogQW50aHJvcGljRXJyb3IpID0+IHZvaWQgPSAoKSA9PiB7fTtcblxuICAjZW5kUHJvbWlzZTogUHJvbWlzZTx2b2lkPjtcbiAgI3Jlc29sdmVFbmRQcm9taXNlOiAoKSA9PiB2b2lkID0gKCkgPT4ge307XG4gICNyZWplY3RFbmRQcm9taXNlOiAoZXJyb3I6IEFudGhyb3BpY0Vycm9yKSA9PiB2b2lkID0gKCkgPT4ge307XG5cbiAgI2xpc3RlbmVyczogeyBbRXZlbnQgaW4ga2V5b2YgTWVzc2FnZVN0cmVhbUV2ZW50c10/OiBNZXNzYWdlU3RyZWFtRXZlbnRMaXN0ZW5lcnM8RXZlbnQ+IH0gPSB7fTtcblxuICAjZW5kZWQgPSBmYWxzZTtcbiAgI2Vycm9yZWQgPSBmYWxzZTtcbiAgI2Fib3J0ZWQgPSBmYWxzZTtcbiAgI2NhdGNoaW5nUHJvbWlzZUNyZWF0ZWQgPSBmYWxzZTtcblxuICBjb25zdHJ1Y3RvcigpIHtcbiAgICB0aGlzLiNjb25uZWN0ZWRQcm9taXNlID0gbmV3IFByb21pc2U8dm9pZD4oKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgdGhpcy4jcmVzb2x2ZUNvbm5lY3RlZFByb21pc2UgPSByZXNvbHZlO1xuICAgICAgdGhpcy4jcmVqZWN0Q29ubmVjdGVkUHJvbWlzZSA9IHJlamVjdDtcbiAgICB9KTtcblxuICAgIHRoaXMuI2VuZFByb21pc2UgPSBuZXcgUHJvbWlzZTx2b2lkPigocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICB0aGlzLiNyZXNvbHZlRW5kUHJvbWlzZSA9IHJlc29sdmU7XG4gICAgICB0aGlzLiNyZWplY3RFbmRQcm9taXNlID0gcmVqZWN0O1xuICAgIH0pO1xuXG4gICAgLy8gRG9uJ3QgbGV0IHRoZXNlIHByb21pc2VzIGNhdXNlIHVuaGFuZGxlZCByZWplY3Rpb24gZXJyb3JzLlxuICAgIC8vIHdlIHdpbGwgbWFudWFsbHkgY2F1c2UgYW4gdW5oYW5kbGVkIHJlamVjdGlvbiBlcnJvciBsYXRlclxuICAgIC8vIGlmIHRoZSB1c2VyIGhhc24ndCByZWdpc3RlcmVkIGFueSBlcnJvciBsaXN0ZW5lciBvciBjYWxsZWRcbiAgICAvLyBhbnkgcHJvbWlzZS1yZXR1cm5pbmcgbWV0aG9kLlxuICAgIHRoaXMuI2Nvbm5lY3RlZFByb21pc2UuY2F0Y2goKCkgPT4ge30pO1xuICAgIHRoaXMuI2VuZFByb21pc2UuY2F0Y2goKCkgPT4ge30pO1xuICB9XG5cbiAgLyoqXG4gICAqIEludGVuZGVkIGZvciB1c2Ugb24gdGhlIGZyb250ZW5kLCBjb25zdW1pbmcgYSBzdHJlYW0gcHJvZHVjZWQgd2l0aFxuICAgKiBgLnRvUmVhZGFibGVTdHJlYW0oKWAgb24gdGhlIGJhY2tlbmQuXG4gICAqXG4gICAqIE5vdGUgdGhhdCBtZXNzYWdlcyBzZW50IHRvIHRoZSBtb2RlbCBkbyBub3QgYXBwZWFyIGluIGAub24oJ21lc3NhZ2UnKWBcbiAgICogaW4gdGhpcyBjb250ZXh0LlxuICAgKi9cbiAgc3RhdGljIGZyb21SZWFkYWJsZVN0cmVhbShzdHJlYW06IFJlYWRhYmxlU3RyZWFtKTogTWVzc2FnZVN0cmVhbSB7XG4gICAgY29uc3QgcnVubmVyID0gbmV3IE1lc3NhZ2VTdHJlYW0oKTtcbiAgICBydW5uZXIuX3J1bigoKSA9PiBydW5uZXIuX2Zyb21SZWFkYWJsZVN0cmVhbShzdHJlYW0pKTtcbiAgICByZXR1cm4gcnVubmVyO1xuICB9XG5cbiAgc3RhdGljIGNyZWF0ZU1lc3NhZ2UoXG4gICAgbWVzc2FnZXM6IE1lc3NhZ2VzLFxuICAgIHBhcmFtczogTWVzc2FnZUNyZWF0ZVBhcmFtc0Jhc2UsXG4gICAgb3B0aW9ucz86IENvcmUuUmVxdWVzdE9wdGlvbnMsXG4gICk6IE1lc3NhZ2VTdHJlYW0ge1xuICAgIGNvbnN0IHJ1bm5lciA9IG5ldyBNZXNzYWdlU3RyZWFtKCk7XG4gICAgZm9yIChjb25zdCBtZXNzYWdlIG9mIHBhcmFtcy5tZXNzYWdlcykge1xuICAgICAgcnVubmVyLl9hZGRNZXNzYWdlUGFyYW0obWVzc2FnZSk7XG4gICAgfVxuICAgIHJ1bm5lci5fcnVuKCgpID0+XG4gICAgICBydW5uZXIuX2NyZWF0ZU1lc3NhZ2UoXG4gICAgICAgIG1lc3NhZ2VzLFxuICAgICAgICB7IC4uLnBhcmFtcywgc3RyZWFtOiB0cnVlIH0sXG4gICAgICAgIHsgLi4ub3B0aW9ucywgaGVhZGVyczogeyAuLi5vcHRpb25zPy5oZWFkZXJzLCAnWC1TdGFpbmxlc3MtSGVscGVyLU1ldGhvZCc6ICdzdHJlYW0nIH0gfSxcbiAgICAgICksXG4gICAgKTtcbiAgICByZXR1cm4gcnVubmVyO1xuICB9XG5cbiAgcHJvdGVjdGVkIF9ydW4oZXhlY3V0b3I6ICgpID0+IFByb21pc2U8YW55Pikge1xuICAgIGV4ZWN1dG9yKCkudGhlbigoKSA9PiB7XG4gICAgICB0aGlzLl9lbWl0RmluYWwoKTtcbiAgICAgIHRoaXMuX2VtaXQoJ2VuZCcpO1xuICAgIH0sIHRoaXMuI2hhbmRsZUVycm9yKTtcbiAgfVxuXG4gIHByb3RlY3RlZCBfYWRkTWVzc2FnZVBhcmFtKG1lc3NhZ2U6IE1lc3NhZ2VQYXJhbSkge1xuICAgIHRoaXMubWVzc2FnZXMucHVzaChtZXNzYWdlKTtcbiAgfVxuXG4gIHByb3RlY3RlZCBfYWRkTWVzc2FnZShtZXNzYWdlOiBNZXNzYWdlLCBlbWl0ID0gdHJ1ZSkge1xuICAgIHRoaXMucmVjZWl2ZWRNZXNzYWdlcy5wdXNoKG1lc3NhZ2UpO1xuICAgIGlmIChlbWl0KSB7XG4gICAgICB0aGlzLl9lbWl0KCdtZXNzYWdlJywgbWVzc2FnZSk7XG4gICAgfVxuICB9XG5cbiAgcHJvdGVjdGVkIGFzeW5jIF9jcmVhdGVNZXNzYWdlKFxuICAgIG1lc3NhZ2VzOiBNZXNzYWdlcyxcbiAgICBwYXJhbXM6IE1lc3NhZ2VDcmVhdGVQYXJhbXMsXG4gICAgb3B0aW9ucz86IENvcmUuUmVxdWVzdE9wdGlvbnMsXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IHNpZ25hbCA9IG9wdGlvbnM/LnNpZ25hbDtcbiAgICBpZiAoc2lnbmFsKSB7XG4gICAgICBpZiAoc2lnbmFsLmFib3J0ZWQpIHRoaXMuY29udHJvbGxlci5hYm9ydCgpO1xuICAgICAgc2lnbmFsLmFkZEV2ZW50TGlzdGVuZXIoJ2Fib3J0JywgKCkgPT4gdGhpcy5jb250cm9sbGVyLmFib3J0KCkpO1xuICAgIH1cbiAgICB0aGlzLiNiZWdpblJlcXVlc3QoKTtcbiAgICBjb25zdCBzdHJlYW0gPSBhd2FpdCBtZXNzYWdlcy5jcmVhdGUoXG4gICAgICB7IC4uLnBhcmFtcywgc3RyZWFtOiB0cnVlIH0sXG4gICAgICB7IC4uLm9wdGlvbnMsIHNpZ25hbDogdGhpcy5jb250cm9sbGVyLnNpZ25hbCB9LFxuICAgICk7XG4gICAgdGhpcy5fY29ubmVjdGVkKCk7XG4gICAgZm9yIGF3YWl0IChjb25zdCBldmVudCBvZiBzdHJlYW0pIHtcbiAgICAgIHRoaXMuI2FkZFN0cmVhbUV2ZW50KGV2ZW50KTtcbiAgICB9XG4gICAgaWYgKHN0cmVhbS5jb250cm9sbGVyLnNpZ25hbD8uYWJvcnRlZCkge1xuICAgICAgdGhyb3cgbmV3IEFQSVVzZXJBYm9ydEVycm9yKCk7XG4gICAgfVxuICAgIHRoaXMuI2VuZFJlcXVlc3QoKTtcbiAgfVxuXG4gIHByb3RlY3RlZCBfY29ubmVjdGVkKCkge1xuICAgIGlmICh0aGlzLmVuZGVkKSByZXR1cm47XG4gICAgdGhpcy4jcmVzb2x2ZUNvbm5lY3RlZFByb21pc2UoKTtcbiAgICB0aGlzLl9lbWl0KCdjb25uZWN0Jyk7XG4gIH1cblxuICBnZXQgZW5kZWQoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuI2VuZGVkO1xuICB9XG5cbiAgZ2V0IGVycm9yZWQoKTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIHRoaXMuI2Vycm9yZWQ7XG4gIH1cblxuICBnZXQgYWJvcnRlZCgpOiBib29sZWFuIHtcbiAgICByZXR1cm4gdGhpcy4jYWJvcnRlZDtcbiAgfVxuXG4gIGFib3J0KCkge1xuICAgIHRoaXMuY29udHJvbGxlci5hYm9ydCgpO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgdGhlIGxpc3RlbmVyIGZ1bmN0aW9uIHRvIHRoZSBlbmQgb2YgdGhlIGxpc3RlbmVycyBhcnJheSBmb3IgdGhlIGV2ZW50LlxuICAgKiBObyBjaGVja3MgYXJlIG1hZGUgdG8gc2VlIGlmIHRoZSBsaXN0ZW5lciBoYXMgYWxyZWFkeSBiZWVuIGFkZGVkLiBNdWx0aXBsZSBjYWxscyBwYXNzaW5nXG4gICAqIHRoZSBzYW1lIGNvbWJpbmF0aW9uIG9mIGV2ZW50IGFuZCBsaXN0ZW5lciB3aWxsIHJlc3VsdCBpbiB0aGUgbGlzdGVuZXIgYmVpbmcgYWRkZWQsIGFuZFxuICAgKiBjYWxsZWQsIG11bHRpcGxlIHRpbWVzLlxuICAgKiBAcmV0dXJucyB0aGlzIE1lc3NhZ2VTdHJlYW0sIHNvIHRoYXQgY2FsbHMgY2FuIGJlIGNoYWluZWRcbiAgICovXG4gIG9uPEV2ZW50IGV4dGVuZHMga2V5b2YgTWVzc2FnZVN0cmVhbUV2ZW50cz4oZXZlbnQ6IEV2ZW50LCBsaXN0ZW5lcjogTWVzc2FnZVN0cmVhbUV2ZW50c1tFdmVudF0pOiB0aGlzIHtcbiAgICBjb25zdCBsaXN0ZW5lcnM6IE1lc3NhZ2VTdHJlYW1FdmVudExpc3RlbmVyczxFdmVudD4gPVxuICAgICAgdGhpcy4jbGlzdGVuZXJzW2V2ZW50XSB8fCAodGhpcy4jbGlzdGVuZXJzW2V2ZW50XSA9IFtdKTtcbiAgICBsaXN0ZW5lcnMucHVzaCh7IGxpc3RlbmVyIH0pO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIFJlbW92ZXMgdGhlIHNwZWNpZmllZCBsaXN0ZW5lciBmcm9tIHRoZSBsaXN0ZW5lciBhcnJheSBmb3IgdGhlIGV2ZW50LlxuICAgKiBvZmYoKSB3aWxsIHJlbW92ZSwgYXQgbW9zdCwgb25lIGluc3RhbmNlIG9mIGEgbGlzdGVuZXIgZnJvbSB0aGUgbGlzdGVuZXIgYXJyYXkuIElmIGFueSBzaW5nbGVcbiAgICogbGlzdGVuZXIgaGFzIGJlZW4gYWRkZWQgbXVsdGlwbGUgdGltZXMgdG8gdGhlIGxpc3RlbmVyIGFycmF5IGZvciB0aGUgc3BlY2lmaWVkIGV2ZW50LCB0aGVuXG4gICAqIG9mZigpIG11c3QgYmUgY2FsbGVkIG11bHRpcGxlIHRpbWVzIHRvIHJlbW92ZSBlYWNoIGluc3RhbmNlLlxuICAgKiBAcmV0dXJucyB0aGlzIE1lc3NhZ2VTdHJlYW0sIHNvIHRoYXQgY2FsbHMgY2FuIGJlIGNoYWluZWRcbiAgICovXG4gIG9mZjxFdmVudCBleHRlbmRzIGtleW9mIE1lc3NhZ2VTdHJlYW1FdmVudHM+KGV2ZW50OiBFdmVudCwgbGlzdGVuZXI6IE1lc3NhZ2VTdHJlYW1FdmVudHNbRXZlbnRdKTogdGhpcyB7XG4gICAgY29uc3QgbGlzdGVuZXJzID0gdGhpcy4jbGlzdGVuZXJzW2V2ZW50XTtcbiAgICBpZiAoIWxpc3RlbmVycykgcmV0dXJuIHRoaXM7XG4gICAgY29uc3QgaW5kZXggPSBsaXN0ZW5lcnMuZmluZEluZGV4KChsKSA9PiBsLmxpc3RlbmVyID09PSBsaXN0ZW5lcik7XG4gICAgaWYgKGluZGV4ID49IDApIGxpc3RlbmVycy5zcGxpY2UoaW5kZXgsIDEpO1xuICAgIHJldHVybiB0aGlzO1xuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgYSBvbmUtdGltZSBsaXN0ZW5lciBmdW5jdGlvbiBmb3IgdGhlIGV2ZW50LiBUaGUgbmV4dCB0aW1lIHRoZSBldmVudCBpcyB0cmlnZ2VyZWQsXG4gICAqIHRoaXMgbGlzdGVuZXIgaXMgcmVtb3ZlZCBhbmQgdGhlbiBpbnZva2VkLlxuICAgKiBAcmV0dXJucyB0aGlzIE1lc3NhZ2VTdHJlYW0sIHNvIHRoYXQgY2FsbHMgY2FuIGJlIGNoYWluZWRcbiAgICovXG4gIG9uY2U8RXZlbnQgZXh0ZW5kcyBrZXlvZiBNZXNzYWdlU3RyZWFtRXZlbnRzPihldmVudDogRXZlbnQsIGxpc3RlbmVyOiBNZXNzYWdlU3RyZWFtRXZlbnRzW0V2ZW50XSk6IHRoaXMge1xuICAgIGNvbnN0IGxpc3RlbmVyczogTWVzc2FnZVN0cmVhbUV2ZW50TGlzdGVuZXJzPEV2ZW50PiA9XG4gICAgICB0aGlzLiNsaXN0ZW5lcnNbZXZlbnRdIHx8ICh0aGlzLiNsaXN0ZW5lcnNbZXZlbnRdID0gW10pO1xuICAgIGxpc3RlbmVycy5wdXNoKHsgbGlzdGVuZXIsIG9uY2U6IHRydWUgfSk7XG4gICAgcmV0dXJuIHRoaXM7XG4gIH1cblxuICAvKipcbiAgICogVGhpcyBpcyBzaW1pbGFyIHRvIGAub25jZSgpYCwgYnV0IHJldHVybnMgYSBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgdGhlIG5leHQgdGltZVxuICAgKiB0aGUgZXZlbnQgaXMgdHJpZ2dlcmVkLCBpbnN0ZWFkIG9mIGNhbGxpbmcgYSBsaXN0ZW5lciBjYWxsYmFjay5cbiAgICogQHJldHVybnMgYSBQcm9taXNlIHRoYXQgcmVzb2x2ZXMgdGhlIG5leHQgdGltZSBnaXZlbiBldmVudCBpcyB0cmlnZ2VyZWQsXG4gICAqIG9yIHJlamVjdHMgaWYgYW4gZXJyb3IgaXMgZW1pdHRlZC4gIChJZiB5b3UgcmVxdWVzdCB0aGUgJ2Vycm9yJyBldmVudCxcbiAgICogcmV0dXJucyBhIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSBlcnJvcikuXG4gICAqXG4gICAqIEV4YW1wbGU6XG4gICAqXG4gICAqICAgY29uc3QgbWVzc2FnZSA9IGF3YWl0IHN0cmVhbS5lbWl0dGVkKCdtZXNzYWdlJykgLy8gcmVqZWN0cyBpZiB0aGUgc3RyZWFtIGVycm9yc1xuICAgKi9cbiAgZW1pdHRlZDxFdmVudCBleHRlbmRzIGtleW9mIE1lc3NhZ2VTdHJlYW1FdmVudHM+KFxuICAgIGV2ZW50OiBFdmVudCxcbiAgKTogUHJvbWlzZTxcbiAgICBQYXJhbWV0ZXJzPE1lc3NhZ2VTdHJlYW1FdmVudHNbRXZlbnRdPiBleHRlbmRzIFtpbmZlciBQYXJhbV0gPyBQYXJhbVxuICAgIDogUGFyYW1ldGVyczxNZXNzYWdlU3RyZWFtRXZlbnRzW0V2ZW50XT4gZXh0ZW5kcyBbXSA/IHZvaWRcbiAgICA6IFBhcmFtZXRlcnM8TWVzc2FnZVN0cmVhbUV2ZW50c1tFdmVudF0+XG4gID4ge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICB0aGlzLiNjYXRjaGluZ1Byb21pc2VDcmVhdGVkID0gdHJ1ZTtcbiAgICAgIGlmIChldmVudCAhPT0gJ2Vycm9yJykgdGhpcy5vbmNlKCdlcnJvcicsIHJlamVjdCk7XG4gICAgICB0aGlzLm9uY2UoZXZlbnQsIHJlc29sdmUgYXMgYW55KTtcbiAgICB9KTtcbiAgfVxuXG4gIGFzeW5jIGRvbmUoKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdGhpcy4jY2F0Y2hpbmdQcm9taXNlQ3JlYXRlZCA9IHRydWU7XG4gICAgYXdhaXQgdGhpcy4jZW5kUHJvbWlzZTtcbiAgfVxuXG4gIGdldCBjdXJyZW50TWVzc2FnZSgpOiBNZXNzYWdlIHwgdW5kZWZpbmVkIHtcbiAgICByZXR1cm4gdGhpcy4jY3VycmVudE1lc3NhZ2VTbmFwc2hvdDtcbiAgfVxuXG4gICNnZXRGaW5hbE1lc3NhZ2UoKTogTWVzc2FnZSB7XG4gICAgaWYgKHRoaXMucmVjZWl2ZWRNZXNzYWdlcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHRocm93IG5ldyBBbnRocm9waWNFcnJvcignc3RyZWFtIGVuZGVkIHdpdGhvdXQgcHJvZHVjaW5nIGEgTWVzc2FnZSB3aXRoIHJvbGU9YXNzaXN0YW50Jyk7XG4gICAgfVxuICAgIHJldHVybiB0aGlzLnJlY2VpdmVkTWVzc2FnZXMuYXQoLTEpITtcbiAgfVxuXG4gIC8qKlxuICAgKiBAcmV0dXJucyBhIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aXRoIHRoZSB0aGUgZmluYWwgYXNzaXN0YW50IE1lc3NhZ2UgcmVzcG9uc2UsXG4gICAqIG9yIHJlamVjdHMgaWYgYW4gZXJyb3Igb2NjdXJyZWQgb3IgdGhlIHN0cmVhbSBlbmRlZCBwcmVtYXR1cmVseSB3aXRob3V0IHByb2R1Y2luZyBhIE1lc3NhZ2UuXG4gICAqL1xuICBhc3luYyBmaW5hbE1lc3NhZ2UoKTogUHJvbWlzZTxNZXNzYWdlPiB7XG4gICAgYXdhaXQgdGhpcy5kb25lKCk7XG4gICAgcmV0dXJuIHRoaXMuI2dldEZpbmFsTWVzc2FnZSgpO1xuICB9XG5cbiAgI2dldEZpbmFsVGV4dCgpOiBzdHJpbmcge1xuICAgIGlmICh0aGlzLnJlY2VpdmVkTWVzc2FnZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICB0aHJvdyBuZXcgQW50aHJvcGljRXJyb3IoJ3N0cmVhbSBlbmRlZCB3aXRob3V0IHByb2R1Y2luZyBhIE1lc3NhZ2Ugd2l0aCByb2xlPWFzc2lzdGFudCcpO1xuICAgIH1cbiAgICBjb25zdCB0ZXh0QmxvY2tzID0gdGhpcy5yZWNlaXZlZE1lc3NhZ2VzXG4gICAgICAuYXQoLTEpIVxuICAgICAgLmNvbnRlbnQuZmlsdGVyKChibG9jayk6IGJsb2NrIGlzIFRleHRCbG9jayA9PiBibG9jay50eXBlID09PSAndGV4dCcpXG4gICAgICAubWFwKChibG9jaykgPT4gYmxvY2sudGV4dCk7XG4gICAgaWYgKHRleHRCbG9ja3MubGVuZ3RoID09PSAwKSB7XG4gICAgICB0aHJvdyBuZXcgQW50aHJvcGljRXJyb3IoJ3N0cmVhbSBlbmRlZCB3aXRob3V0IHByb2R1Y2luZyBhIGNvbnRlbnQgYmxvY2sgd2l0aCB0eXBlPXRleHQnKTtcbiAgICB9XG4gICAgcmV0dXJuIHRleHRCbG9ja3Muam9pbignICcpO1xuICB9XG5cbiAgLyoqXG4gICAqIEByZXR1cm5zIGEgcHJvbWlzZSB0aGF0IHJlc29sdmVzIHdpdGggdGhlIHRoZSBmaW5hbCBhc3Npc3RhbnQgTWVzc2FnZSdzIHRleHQgcmVzcG9uc2UsIGNvbmNhdGVuYXRlZFxuICAgKiB0b2dldGhlciBpZiB0aGVyZSBhcmUgbW9yZSB0aGFuIG9uZSB0ZXh0IGJsb2Nrcy5cbiAgICogUmVqZWN0cyBpZiBhbiBlcnJvciBvY2N1cnJlZCBvciB0aGUgc3RyZWFtIGVuZGVkIHByZW1hdHVyZWx5IHdpdGhvdXQgcHJvZHVjaW5nIGEgTWVzc2FnZS5cbiAgICovXG4gIGFzeW5jIGZpbmFsVGV4dCgpOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIGF3YWl0IHRoaXMuZG9uZSgpO1xuICAgIHJldHVybiB0aGlzLiNnZXRGaW5hbFRleHQoKTtcbiAgfVxuXG4gICNoYW5kbGVFcnJvciA9IChlcnJvcjogdW5rbm93bikgPT4ge1xuICAgIHRoaXMuI2Vycm9yZWQgPSB0cnVlO1xuICAgIGlmIChlcnJvciBpbnN0YW5jZW9mIEVycm9yICYmIGVycm9yLm5hbWUgPT09ICdBYm9ydEVycm9yJykge1xuICAgICAgZXJyb3IgPSBuZXcgQVBJVXNlckFib3J0RXJyb3IoKTtcbiAgICB9XG4gICAgaWYgKGVycm9yIGluc3RhbmNlb2YgQVBJVXNlckFib3J0RXJyb3IpIHtcbiAgICAgIHRoaXMuI2Fib3J0ZWQgPSB0cnVlO1xuICAgICAgcmV0dXJuIHRoaXMuX2VtaXQoJ2Fib3J0JywgZXJyb3IpO1xuICAgIH1cbiAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBBbnRocm9waWNFcnJvcikge1xuICAgICAgcmV0dXJuIHRoaXMuX2VtaXQoJ2Vycm9yJywgZXJyb3IpO1xuICAgIH1cbiAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgY29uc3QgYW50aHJvcGljRXJyb3I6IEFudGhyb3BpY0Vycm9yID0gbmV3IEFudGhyb3BpY0Vycm9yKGVycm9yLm1lc3NhZ2UpO1xuICAgICAgLy8gQHRzLWlnbm9yZVxuICAgICAgYW50aHJvcGljRXJyb3IuY2F1c2UgPSBlcnJvcjtcbiAgICAgIHJldHVybiB0aGlzLl9lbWl0KCdlcnJvcicsIGFudGhyb3BpY0Vycm9yKTtcbiAgICB9XG4gICAgcmV0dXJuIHRoaXMuX2VtaXQoJ2Vycm9yJywgbmV3IEFudGhyb3BpY0Vycm9yKFN0cmluZyhlcnJvcikpKTtcbiAgfTtcblxuICBwcm90ZWN0ZWQgX2VtaXQ8RXZlbnQgZXh0ZW5kcyBrZXlvZiBNZXNzYWdlU3RyZWFtRXZlbnRzPihcbiAgICBldmVudDogRXZlbnQsXG4gICAgLi4uYXJnczogUGFyYW1ldGVyczxNZXNzYWdlU3RyZWFtRXZlbnRzW0V2ZW50XT5cbiAgKSB7XG4gICAgLy8gbWFrZSBzdXJlIHdlIGRvbid0IGVtaXQgYW55IE1lc3NhZ2VTdHJlYW1FdmVudHMgYWZ0ZXIgZW5kXG4gICAgaWYgKHRoaXMuI2VuZGVkKSByZXR1cm47XG5cbiAgICBpZiAoZXZlbnQgPT09ICdlbmQnKSB7XG4gICAgICB0aGlzLiNlbmRlZCA9IHRydWU7XG4gICAgICB0aGlzLiNyZXNvbHZlRW5kUHJvbWlzZSgpO1xuICAgIH1cblxuICAgIGNvbnN0IGxpc3RlbmVyczogTWVzc2FnZVN0cmVhbUV2ZW50TGlzdGVuZXJzPEV2ZW50PiB8IHVuZGVmaW5lZCA9IHRoaXMuI2xpc3RlbmVyc1tldmVudF07XG4gICAgaWYgKGxpc3RlbmVycykge1xuICAgICAgdGhpcy4jbGlzdGVuZXJzW2V2ZW50XSA9IGxpc3RlbmVycy5maWx0ZXIoKGwpID0+ICFsLm9uY2UpIGFzIGFueTtcbiAgICAgIGxpc3RlbmVycy5mb3JFYWNoKCh7IGxpc3RlbmVyIH06IGFueSkgPT4gbGlzdGVuZXIoLi4uYXJncykpO1xuICAgIH1cblxuICAgIGlmIChldmVudCA9PT0gJ2Fib3J0Jykge1xuICAgICAgY29uc3QgZXJyb3IgPSBhcmdzWzBdIGFzIEFQSVVzZXJBYm9ydEVycm9yO1xuICAgICAgaWYgKCF0aGlzLiNjYXRjaGluZ1Byb21pc2VDcmVhdGVkICYmICFsaXN0ZW5lcnM/Lmxlbmd0aCkge1xuICAgICAgICBQcm9taXNlLnJlamVjdChlcnJvcik7XG4gICAgICB9XG4gICAgICB0aGlzLiNyZWplY3RDb25uZWN0ZWRQcm9taXNlKGVycm9yKTtcbiAgICAgIHRoaXMuI3JlamVjdEVuZFByb21pc2UoZXJyb3IpO1xuICAgICAgdGhpcy5fZW1pdCgnZW5kJyk7XG4gICAgICByZXR1cm47XG4gICAgfVxuXG4gICAgaWYgKGV2ZW50ID09PSAnZXJyb3InKSB7XG4gICAgICAvLyBOT1RFOiBfZW1pdCgnZXJyb3InLCBlcnJvcikgc2hvdWxkIG9ubHkgYmUgY2FsbGVkIGZyb20gI2hhbmRsZUVycm9yKCkuXG5cbiAgICAgIGNvbnN0IGVycm9yID0gYXJnc1swXSBhcyBBbnRocm9waWNFcnJvcjtcbiAgICAgIGlmICghdGhpcy4jY2F0Y2hpbmdQcm9taXNlQ3JlYXRlZCAmJiAhbGlzdGVuZXJzPy5sZW5ndGgpIHtcbiAgICAgICAgLy8gVHJpZ2dlciBhbiB1bmhhbmRsZWQgcmVqZWN0aW9uIGlmIHRoZSB1c2VyIGhhc24ndCByZWdpc3RlcmVkIGFueSBlcnJvciBoYW5kbGVycy5cbiAgICAgICAgLy8gSWYgeW91IGFyZSBzZWVpbmcgc3RhY2sgdHJhY2VzIGhlcmUsIG1ha2Ugc3VyZSB0byBoYW5kbGUgZXJyb3JzIHZpYSBlaXRoZXI6XG4gICAgICAgIC8vIC0gcnVubmVyLm9uKCdlcnJvcicsICgpID0+IC4uLilcbiAgICAgICAgLy8gLSBhd2FpdCBydW5uZXIuZG9uZSgpXG4gICAgICAgIC8vIC0gYXdhaXQgcnVubmVyLmZpbmFsLi4uKClcbiAgICAgICAgLy8gLSBldGMuXG4gICAgICAgIFByb21pc2UucmVqZWN0KGVycm9yKTtcbiAgICAgIH1cbiAgICAgIHRoaXMuI3JlamVjdENvbm5lY3RlZFByb21pc2UoZXJyb3IpO1xuICAgICAgdGhpcy4jcmVqZWN0RW5kUHJvbWlzZShlcnJvcik7XG4gICAgICB0aGlzLl9lbWl0KCdlbmQnKTtcbiAgICB9XG4gIH1cblxuICBwcm90ZWN0ZWQgX2VtaXRGaW5hbCgpIHtcbiAgICBjb25zdCBmaW5hbE1lc3NhZ2UgPSB0aGlzLnJlY2VpdmVkTWVzc2FnZXMuYXQoLTEpO1xuICAgIGlmIChmaW5hbE1lc3NhZ2UpIHtcbiAgICAgIHRoaXMuX2VtaXQoJ2ZpbmFsTWVzc2FnZScsIHRoaXMuI2dldEZpbmFsTWVzc2FnZSgpKTtcbiAgICB9XG4gIH1cblxuICAjYmVnaW5SZXF1ZXN0KCkge1xuICAgIGlmICh0aGlzLmVuZGVkKSByZXR1cm47XG4gICAgdGhpcy4jY3VycmVudE1lc3NhZ2VTbmFwc2hvdCA9IHVuZGVmaW5lZDtcbiAgfVxuICAjYWRkU3RyZWFtRXZlbnQoZXZlbnQ6IE1lc3NhZ2VTdHJlYW1FdmVudCkge1xuICAgIGlmICh0aGlzLmVuZGVkKSByZXR1cm47XG4gICAgY29uc3QgbWVzc2FnZVNuYXBzaG90ID0gdGhpcy4jYWNjdW11bGF0ZU1lc3NhZ2UoZXZlbnQpO1xuICAgIHRoaXMuX2VtaXQoJ3N0cmVhbUV2ZW50JywgZXZlbnQsIG1lc3NhZ2VTbmFwc2hvdCk7XG5cbiAgICBzd2l0Y2ggKGV2ZW50LnR5cGUpIHtcbiAgICAgIGNhc2UgJ2NvbnRlbnRfYmxvY2tfZGVsdGEnOiB7XG4gICAgICAgIGNvbnN0IGNvbnRlbnQgPSBtZXNzYWdlU25hcHNob3QuY29udGVudC5hdCgtMSkhO1xuICAgICAgICBpZiAoZXZlbnQuZGVsdGEudHlwZSA9PT0gJ3RleHRfZGVsdGEnICYmIGNvbnRlbnQudHlwZSA9PT0gJ3RleHQnKSB7XG4gICAgICAgICAgdGhpcy5fZW1pdCgndGV4dCcsIGV2ZW50LmRlbHRhLnRleHQsIGNvbnRlbnQudGV4dCB8fCAnJyk7XG4gICAgICAgIH0gZWxzZSBpZiAoZXZlbnQuZGVsdGEudHlwZSA9PT0gJ2lucHV0X2pzb25fZGVsdGEnICYmIGNvbnRlbnQudHlwZSA9PT0gJ3Rvb2xfdXNlJykge1xuICAgICAgICAgIGlmIChjb250ZW50LmlucHV0KSB7XG4gICAgICAgICAgICB0aGlzLl9lbWl0KCdpbnB1dEpzb24nLCBldmVudC5kZWx0YS5wYXJ0aWFsX2pzb24sIGNvbnRlbnQuaW5wdXQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhc2UgJ21lc3NhZ2Vfc3RvcCc6IHtcbiAgICAgICAgdGhpcy5fYWRkTWVzc2FnZVBhcmFtKG1lc3NhZ2VTbmFwc2hvdCk7XG4gICAgICAgIHRoaXMuX2FkZE1lc3NhZ2UobWVzc2FnZVNuYXBzaG90LCB0cnVlKTtcbiAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgICBjYXNlICdjb250ZW50X2Jsb2NrX3N0b3AnOiB7XG4gICAgICAgIHRoaXMuX2VtaXQoJ2NvbnRlbnRCbG9jaycsIG1lc3NhZ2VTbmFwc2hvdC5jb250ZW50LmF0KC0xKSEpO1xuICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICAgIGNhc2UgJ21lc3NhZ2Vfc3RhcnQnOiB7XG4gICAgICAgIHRoaXMuI2N1cnJlbnRNZXNzYWdlU25hcHNob3QgPSBtZXNzYWdlU25hcHNob3Q7XG4gICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgICAgY2FzZSAnY29udGVudF9ibG9ja19zdGFydCc6XG4gICAgICBjYXNlICdtZXNzYWdlX2RlbHRhJzpcbiAgICAgICAgYnJlYWs7XG4gICAgfVxuICB9XG4gICNlbmRSZXF1ZXN0KCk6IE1lc3NhZ2Uge1xuICAgIGlmICh0aGlzLmVuZGVkKSB7XG4gICAgICB0aHJvdyBuZXcgQW50aHJvcGljRXJyb3IoYHN0cmVhbSBoYXMgZW5kZWQsIHRoaXMgc2hvdWxkbid0IGhhcHBlbmApO1xuICAgIH1cbiAgICBjb25zdCBzbmFwc2hvdCA9IHRoaXMuI2N1cnJlbnRNZXNzYWdlU25hcHNob3Q7XG4gICAgaWYgKCFzbmFwc2hvdCkge1xuICAgICAgdGhyb3cgbmV3IEFudGhyb3BpY0Vycm9yKGByZXF1ZXN0IGVuZGVkIHdpdGhvdXQgc2VuZGluZyBhbnkgY2h1bmtzYCk7XG4gICAgfVxuICAgIHRoaXMuI2N1cnJlbnRNZXNzYWdlU25hcHNob3QgPSB1bmRlZmluZWQ7XG4gICAgcmV0dXJuIHNuYXBzaG90O1xuICB9XG5cbiAgcHJvdGVjdGVkIGFzeW5jIF9mcm9tUmVhZGFibGVTdHJlYW0oXG4gICAgcmVhZGFibGVTdHJlYW06IFJlYWRhYmxlU3RyZWFtLFxuICAgIG9wdGlvbnM/OiBDb3JlLlJlcXVlc3RPcHRpb25zLFxuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBzaWduYWwgPSBvcHRpb25zPy5zaWduYWw7XG4gICAgaWYgKHNpZ25hbCkge1xuICAgICAgaWYgKHNpZ25hbC5hYm9ydGVkKSB0aGlzLmNvbnRyb2xsZXIuYWJvcnQoKTtcbiAgICAgIHNpZ25hbC5hZGRFdmVudExpc3RlbmVyKCdhYm9ydCcsICgpID0+IHRoaXMuY29udHJvbGxlci5hYm9ydCgpKTtcbiAgICB9XG4gICAgdGhpcy4jYmVnaW5SZXF1ZXN0KCk7XG4gICAgdGhpcy5fY29ubmVjdGVkKCk7XG4gICAgY29uc3Qgc3RyZWFtID0gU3RyZWFtLmZyb21SZWFkYWJsZVN0cmVhbTxNZXNzYWdlU3RyZWFtRXZlbnQ+KHJlYWRhYmxlU3RyZWFtLCB0aGlzLmNvbnRyb2xsZXIpO1xuICAgIGZvciBhd2FpdCAoY29uc3QgZXZlbnQgb2Ygc3RyZWFtKSB7XG4gICAgICB0aGlzLiNhZGRTdHJlYW1FdmVudChldmVudCk7XG4gICAgfVxuICAgIGlmIChzdHJlYW0uY29udHJvbGxlci5zaWduYWw/LmFib3J0ZWQpIHtcbiAgICAgIHRocm93IG5ldyBBUElVc2VyQWJvcnRFcnJvcigpO1xuICAgIH1cbiAgICB0aGlzLiNlbmRSZXF1ZXN0KCk7XG4gIH1cblxuICAvKipcbiAgICogTXV0YXRlcyB0aGlzLiNjdXJyZW50TWVzc2FnZSB3aXRoIHRoZSBjdXJyZW50IGV2ZW50LiBIYW5kbGluZyB0aGUgYWNjdW11bGF0aW9uIG9mIG11bHRpcGxlIG1lc3NhZ2VzXG4gICAqIHdpbGwgYmUgbmVlZGVkIHRvIGJlIGhhbmRsZWQgYnkgdGhlIGNhbGxlciwgdGhpcyBtZXRob2Qgd2lsbCB0aHJvdyBpZiB5b3UgdHJ5IHRvIGFjY3VtdWxhdGUgZm9yIG11bHRpcGxlXG4gICAqIG1lc3NhZ2VzLlxuICAgKi9cbiAgI2FjY3VtdWxhdGVNZXNzYWdlKGV2ZW50OiBNZXNzYWdlU3RyZWFtRXZlbnQpOiBNZXNzYWdlIHtcbiAgICBsZXQgc25hcHNob3QgPSB0aGlzLiNjdXJyZW50TWVzc2FnZVNuYXBzaG90O1xuXG4gICAgaWYgKGV2ZW50LnR5cGUgPT09ICdtZXNzYWdlX3N0YXJ0Jykge1xuICAgICAgaWYgKHNuYXBzaG90KSB7XG4gICAgICAgIHRocm93IG5ldyBBbnRocm9waWNFcnJvcihgVW5leHBlY3RlZCBldmVudCBvcmRlciwgZ290ICR7ZXZlbnQudHlwZX0gYmVmb3JlIHJlY2VpdmluZyBcIm1lc3NhZ2Vfc3RvcFwiYCk7XG4gICAgICB9XG4gICAgICByZXR1cm4gZXZlbnQubWVzc2FnZTtcbiAgICB9XG5cbiAgICBpZiAoIXNuYXBzaG90KSB7XG4gICAgICB0aHJvdyBuZXcgQW50aHJvcGljRXJyb3IoYFVuZXhwZWN0ZWQgZXZlbnQgb3JkZXIsIGdvdCAke2V2ZW50LnR5cGV9IGJlZm9yZSBcIm1lc3NhZ2Vfc3RhcnRcImApO1xuICAgIH1cblxuICAgIHN3aXRjaCAoZXZlbnQudHlwZSkge1xuICAgICAgY2FzZSAnbWVzc2FnZV9zdG9wJzpcbiAgICAgICAgcmV0dXJuIHNuYXBzaG90O1xuICAgICAgY2FzZSAnbWVzc2FnZV9kZWx0YSc6XG4gICAgICAgIHNuYXBzaG90LnN0b3BfcmVhc29uID0gZXZlbnQuZGVsdGEuc3RvcF9yZWFzb247XG4gICAgICAgIHNuYXBzaG90LnN0b3Bfc2VxdWVuY2UgPSBldmVudC5kZWx0YS5zdG9wX3NlcXVlbmNlO1xuICAgICAgICBzbmFwc2hvdC51c2FnZS5vdXRwdXRfdG9rZW5zID0gZXZlbnQudXNhZ2Uub3V0cHV0X3Rva2VucztcbiAgICAgICAgcmV0dXJuIHNuYXBzaG90O1xuICAgICAgY2FzZSAnY29udGVudF9ibG9ja19zdGFydCc6XG4gICAgICAgIHNuYXBzaG90LmNvbnRlbnQucHVzaChldmVudC5jb250ZW50X2Jsb2NrKTtcbiAgICAgICAgcmV0dXJuIHNuYXBzaG90O1xuICAgICAgY2FzZSAnY29udGVudF9ibG9ja19kZWx0YSc6IHtcbiAgICAgICAgY29uc3Qgc25hcHNob3RDb250ZW50ID0gc25hcHNob3QuY29udGVudC5hdChldmVudC5pbmRleCk7XG4gICAgICAgIGlmIChzbmFwc2hvdENvbnRlbnQ/LnR5cGUgPT09ICd0ZXh0JyAmJiBldmVudC5kZWx0YS50eXBlID09PSAndGV4dF9kZWx0YScpIHtcbiAgICAgICAgICBzbmFwc2hvdENvbnRlbnQudGV4dCArPSBldmVudC5kZWx0YS50ZXh0O1xuICAgICAgICB9IGVsc2UgaWYgKHNuYXBzaG90Q29udGVudD8udHlwZSA9PT0gJ3Rvb2xfdXNlJyAmJiBldmVudC5kZWx0YS50eXBlID09PSAnaW5wdXRfanNvbl9kZWx0YScpIHtcbiAgICAgICAgICAvLyB3ZSBuZWVkIHRvIGtlZXAgdHJhY2sgb2YgdGhlIHJhdyBKU09OIHN0cmluZyBhcyB3ZWxsIHNvIHRoYXQgd2UgY2FuXG4gICAgICAgICAgLy8gcmUtcGFyc2UgaXQgZm9yIGVhY2ggZGVsdGEsIGZvciBub3cgd2UganVzdCBzdG9yZSBpdCBhcyBhbiB1bnR5cGVkXG4gICAgICAgICAgLy8gbm9uLWVudW1lcmFibGUgcHJvcGVydHkgb24gdGhlIHNuYXBzaG90XG4gICAgICAgICAgbGV0IGpzb25CdWYgPSAoc25hcHNob3RDb250ZW50IGFzIGFueSlbSlNPTl9CVUZfUFJPUEVSVFldIHx8ICcnO1xuICAgICAgICAgIGpzb25CdWYgKz0gZXZlbnQuZGVsdGEucGFydGlhbF9qc29uO1xuXG4gICAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KHNuYXBzaG90Q29udGVudCwgSlNPTl9CVUZfUFJPUEVSVFksIHtcbiAgICAgICAgICAgIHZhbHVlOiBqc29uQnVmLFxuICAgICAgICAgICAgZW51bWVyYWJsZTogZmFsc2UsXG4gICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICB9KTtcblxuICAgICAgICAgIGlmIChqc29uQnVmKSB7XG4gICAgICAgICAgICBzbmFwc2hvdENvbnRlbnQuaW5wdXQgPSBwYXJ0aWFsUGFyc2UoanNvbkJ1Zik7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzbmFwc2hvdDtcbiAgICAgIH1cbiAgICAgIGNhc2UgJ2NvbnRlbnRfYmxvY2tfc3RvcCc6XG4gICAgICAgIHJldHVybiBzbmFwc2hvdDtcbiAgICB9XG4gIH1cblxuICBbU3ltYm9sLmFzeW5jSXRlcmF0b3JdKCk6IEFzeW5jSXRlcmF0b3I8TWVzc2FnZVN0cmVhbUV2ZW50PiB7XG4gICAgY29uc3QgcHVzaFF1ZXVlOiBNZXNzYWdlU3RyZWFtRXZlbnRbXSA9IFtdO1xuICAgIGNvbnN0IHJlYWRRdWV1ZToge1xuICAgICAgcmVzb2x2ZTogKGNodW5rOiBNZXNzYWdlU3RyZWFtRXZlbnQgfCB1bmRlZmluZWQpID0+IHZvaWQ7XG4gICAgICByZWplY3Q6IChlcnJvcjogdW5rbm93bikgPT4gdm9pZDtcbiAgICB9W10gPSBbXTtcbiAgICBsZXQgZG9uZSA9IGZhbHNlO1xuXG4gICAgdGhpcy5vbignc3RyZWFtRXZlbnQnLCAoZXZlbnQpID0+IHtcbiAgICAgIGNvbnN0IHJlYWRlciA9IHJlYWRRdWV1ZS5zaGlmdCgpO1xuICAgICAgaWYgKHJlYWRlcikge1xuICAgICAgICByZWFkZXIucmVzb2x2ZShldmVudCk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBwdXNoUXVldWUucHVzaChldmVudCk7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICB0aGlzLm9uKCdlbmQnLCAoKSA9PiB7XG4gICAgICBkb25lID0gdHJ1ZTtcbiAgICAgIGZvciAoY29uc3QgcmVhZGVyIG9mIHJlYWRRdWV1ZSkge1xuICAgICAgICByZWFkZXIucmVzb2x2ZSh1bmRlZmluZWQpO1xuICAgICAgfVxuICAgICAgcmVhZFF1ZXVlLmxlbmd0aCA9IDA7XG4gICAgfSk7XG5cbiAgICB0aGlzLm9uKCdhYm9ydCcsIChlcnIpID0+IHtcbiAgICAgIGRvbmUgPSB0cnVlO1xuICAgICAgZm9yIChjb25zdCByZWFkZXIgb2YgcmVhZFF1ZXVlKSB7XG4gICAgICAgIHJlYWRlci5yZWplY3QoZXJyKTtcbiAgICAgIH1cbiAgICAgIHJlYWRRdWV1ZS5sZW5ndGggPSAwO1xuICAgIH0pO1xuXG4gICAgdGhpcy5vbignZXJyb3InLCAoZXJyKSA9PiB7XG4gICAgICBkb25lID0gdHJ1ZTtcbiAgICAgIGZvciAoY29uc3QgcmVhZGVyIG9mIHJlYWRRdWV1ZSkge1xuICAgICAgICByZWFkZXIucmVqZWN0KGVycik7XG4gICAgICB9XG4gICAgICByZWFkUXVldWUubGVuZ3RoID0gMDtcbiAgICB9KTtcblxuICAgIHJldHVybiB7XG4gICAgICBuZXh0OiBhc3luYyAoKTogUHJvbWlzZTxJdGVyYXRvclJlc3VsdDxNZXNzYWdlU3RyZWFtRXZlbnQ+PiA9PiB7XG4gICAgICAgIGlmICghcHVzaFF1ZXVlLmxlbmd0aCkge1xuICAgICAgICAgIGlmIChkb25lKSB7XG4gICAgICAgICAgICByZXR1cm4geyB2YWx1ZTogdW5kZWZpbmVkLCBkb25lOiB0cnVlIH07XG4gICAgICAgICAgfVxuICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZTxNZXNzYWdlU3RyZWFtRXZlbnQgfCB1bmRlZmluZWQ+KChyZXNvbHZlLCByZWplY3QpID0+XG4gICAgICAgICAgICByZWFkUXVldWUucHVzaCh7IHJlc29sdmUsIHJlamVjdCB9KSxcbiAgICAgICAgICApLnRoZW4oKGNodW5rKSA9PiAoY2h1bmsgPyB7IHZhbHVlOiBjaHVuaywgZG9uZTogZmFsc2UgfSA6IHsgdmFsdWU6IHVuZGVmaW5lZCwgZG9uZTogdHJ1ZSB9KSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgY2h1bmsgPSBwdXNoUXVldWUuc2hpZnQoKSE7XG4gICAgICAgIHJldHVybiB7IHZhbHVlOiBjaHVuaywgZG9uZTogZmFsc2UgfTtcbiAgICAgIH0sXG4gICAgICByZXR1cm46IGFzeW5jICgpID0+IHtcbiAgICAgICAgdGhpcy5hYm9ydCgpO1xuICAgICAgICByZXR1cm4geyB2YWx1ZTogdW5kZWZpbmVkLCBkb25lOiB0cnVlIH07XG4gICAgICB9LFxuICAgIH07XG4gIH1cblxuICB0b1JlYWRhYmxlU3RyZWFtKCk6IFJlYWRhYmxlU3RyZWFtIHtcbiAgICBjb25zdCBzdHJlYW0gPSBuZXcgU3RyZWFtKHRoaXNbU3ltYm9sLmFzeW5jSXRlcmF0b3JdLmJpbmQodGhpcyksIHRoaXMuY29udHJvbGxlcik7XG4gICAgcmV0dXJuIHN0cmVhbS50b1JlYWRhYmxlU3RyZWFtKCk7XG4gIH1cbn1cbiIsICIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuXG5pbXBvcnQgeyBBUElSZXNvdXJjZSB9IGZyb20gXCIuLi9yZXNvdXJjZS5qc1wiO1xuaW1wb3J0IHsgQVBJUHJvbWlzZSB9IGZyb20gXCIuLi9jb3JlLmpzXCI7XG5pbXBvcnQgKiBhcyBDb3JlIGZyb20gXCIuLi9jb3JlLmpzXCI7XG5pbXBvcnQgKiBhcyBNZXNzYWdlc0FQSSBmcm9tIFwiLi9tZXNzYWdlcy5qc1wiO1xuaW1wb3J0IHsgU3RyZWFtIH0gZnJvbSBcIi4uL3N0cmVhbWluZy5qc1wiO1xuaW1wb3J0IHsgTWVzc2FnZVN0cmVhbSB9IGZyb20gXCIuLi9saWIvTWVzc2FnZVN0cmVhbS5qc1wiO1xuXG5leHBvcnQgeyBNZXNzYWdlU3RyZWFtIH0gZnJvbSBcIi4uL2xpYi9NZXNzYWdlU3RyZWFtLmpzXCI7XG5cbmV4cG9ydCBjbGFzcyBNZXNzYWdlcyBleHRlbmRzIEFQSVJlc291cmNlIHtcbiAgLyoqXG4gICAqIENyZWF0ZSBhIE1lc3NhZ2UuXG4gICAqXG4gICAqIFNlbmQgYSBzdHJ1Y3R1cmVkIGxpc3Qgb2YgaW5wdXQgbWVzc2FnZXMgd2l0aCB0ZXh0IGFuZC9vciBpbWFnZSBjb250ZW50LCBhbmQgdGhlXG4gICAqIG1vZGVsIHdpbGwgZ2VuZXJhdGUgdGhlIG5leHQgbWVzc2FnZSBpbiB0aGUgY29udmVyc2F0aW9uLlxuICAgKlxuICAgKiBUaGUgTWVzc2FnZXMgQVBJIGNhbiBiZSB1c2VkIGZvciBlaXRoZXIgc2luZ2xlIHF1ZXJpZXMgb3Igc3RhdGVsZXNzIG11bHRpLXR1cm5cbiAgICogY29udmVyc2F0aW9ucy5cbiAgICovXG4gIGNyZWF0ZShib2R5OiBNZXNzYWdlQ3JlYXRlUGFyYW1zTm9uU3RyZWFtaW5nLCBvcHRpb25zPzogQ29yZS5SZXF1ZXN0T3B0aW9ucyk6IEFQSVByb21pc2U8TWVzc2FnZT47XG4gIGNyZWF0ZShcbiAgICBib2R5OiBNZXNzYWdlQ3JlYXRlUGFyYW1zU3RyZWFtaW5nLFxuICAgIG9wdGlvbnM/OiBDb3JlLlJlcXVlc3RPcHRpb25zLFxuICApOiBBUElQcm9taXNlPFN0cmVhbTxSYXdNZXNzYWdlU3RyZWFtRXZlbnQ+PjtcbiAgY3JlYXRlKFxuICAgIGJvZHk6IE1lc3NhZ2VDcmVhdGVQYXJhbXNCYXNlLFxuICAgIG9wdGlvbnM/OiBDb3JlLlJlcXVlc3RPcHRpb25zLFxuICApOiBBUElQcm9taXNlPFN0cmVhbTxSYXdNZXNzYWdlU3RyZWFtRXZlbnQ+IHwgTWVzc2FnZT47XG4gIGNyZWF0ZShcbiAgICBib2R5OiBNZXNzYWdlQ3JlYXRlUGFyYW1zLFxuICAgIG9wdGlvbnM/OiBDb3JlLlJlcXVlc3RPcHRpb25zLFxuICApOiBBUElQcm9taXNlPE1lc3NhZ2U+IHwgQVBJUHJvbWlzZTxTdHJlYW08UmF3TWVzc2FnZVN0cmVhbUV2ZW50Pj4ge1xuICAgIGlmIChib2R5Lm1vZGVsIGluIERFUFJFQ0FURURfTU9ERUxTKSB7XG4gICAgICBjb25zb2xlLndhcm4oXG4gICAgICAgIGBUaGUgbW9kZWwgJyR7Ym9keS5tb2RlbH0nIGlzIGRlcHJlY2F0ZWQgYW5kIHdpbGwgcmVhY2ggZW5kLW9mLWxpZmUgb24gJHtcbiAgICAgICAgICBERVBSRUNBVEVEX01PREVMU1tib2R5Lm1vZGVsXVxuICAgICAgICB9XFxuUGxlYXNlIG1pZ3JhdGUgdG8gYSBuZXdlciBtb2RlbC4gVmlzaXQgaHR0cHM6Ly9kb2NzLmFudGhyb3BpYy5jb20vZW4vZG9jcy9yZXNvdXJjZXMvbW9kZWwtZGVwcmVjYXRpb25zIGZvciBtb3JlIGluZm9ybWF0aW9uLmAsXG4gICAgICApO1xuICAgIH1cbiAgICByZXR1cm4gdGhpcy5fY2xpZW50LnBvc3QoJy92MS9tZXNzYWdlcycsIHtcbiAgICAgIGJvZHksXG4gICAgICB0aW1lb3V0OiAodGhpcy5fY2xpZW50IGFzIGFueSkuX29wdGlvbnMudGltZW91dCA/PyA2MDAwMDAsXG4gICAgICAuLi5vcHRpb25zLFxuICAgICAgc3RyZWFtOiBib2R5LnN0cmVhbSA/PyBmYWxzZSxcbiAgICB9KSBhcyBBUElQcm9taXNlPE1lc3NhZ2U+IHwgQVBJUHJvbWlzZTxTdHJlYW08UmF3TWVzc2FnZVN0cmVhbUV2ZW50Pj47XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIGEgTWVzc2FnZSBzdHJlYW1cbiAgICovXG4gIHN0cmVhbShib2R5OiBNZXNzYWdlU3RyZWFtUGFyYW1zLCBvcHRpb25zPzogQ29yZS5SZXF1ZXN0T3B0aW9ucyk6IE1lc3NhZ2VTdHJlYW0ge1xuICAgIHJldHVybiBNZXNzYWdlU3RyZWFtLmNyZWF0ZU1lc3NhZ2UodGhpcywgYm9keSwgb3B0aW9ucyk7XG4gIH1cbn1cblxuZXhwb3J0IHR5cGUgQ29udGVudEJsb2NrID0gVGV4dEJsb2NrIHwgVG9vbFVzZUJsb2NrO1xuXG5leHBvcnQgdHlwZSBDb250ZW50QmxvY2tEZWx0YUV2ZW50ID0gUmF3Q29udGVudEJsb2NrRGVsdGFFdmVudDtcblxuZXhwb3J0IHR5cGUgQ29udGVudEJsb2NrU3RhcnRFdmVudCA9IFJhd0NvbnRlbnRCbG9ja1N0YXJ0RXZlbnQ7XG5cbmV4cG9ydCB0eXBlIENvbnRlbnRCbG9ja1N0b3BFdmVudCA9IFJhd0NvbnRlbnRCbG9ja1N0b3BFdmVudDtcblxuZXhwb3J0IGludGVyZmFjZSBJbWFnZUJsb2NrUGFyYW0ge1xuICBzb3VyY2U6IEltYWdlQmxvY2tQYXJhbS5Tb3VyY2U7XG5cbiAgdHlwZTogJ2ltYWdlJztcbn1cblxuZXhwb3J0IG5hbWVzcGFjZSBJbWFnZUJsb2NrUGFyYW0ge1xuICBleHBvcnQgaW50ZXJmYWNlIFNvdXJjZSB7XG4gICAgZGF0YTogc3RyaW5nO1xuXG4gICAgbWVkaWFfdHlwZTogJ2ltYWdlL2pwZWcnIHwgJ2ltYWdlL3BuZycgfCAnaW1hZ2UvZ2lmJyB8ICdpbWFnZS93ZWJwJztcblxuICAgIHR5cGU6ICdiYXNlNjQnO1xuICB9XG59XG5cbmV4cG9ydCB0eXBlIElucHV0SnNvbkRlbHRhID0gSW5wdXRKU09ORGVsdGE7XG5cbmV4cG9ydCBpbnRlcmZhY2UgSW5wdXRKU09ORGVsdGEge1xuICBwYXJ0aWFsX2pzb246IHN0cmluZztcblxuICB0eXBlOiAnaW5wdXRfanNvbl9kZWx0YSc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgTWVzc2FnZSB7XG4gIC8qKlxuICAgKiBVbmlxdWUgb2JqZWN0IGlkZW50aWZpZXIuXG4gICAqXG4gICAqIFRoZSBmb3JtYXQgYW5kIGxlbmd0aCBvZiBJRHMgbWF5IGNoYW5nZSBvdmVyIHRpbWUuXG4gICAqL1xuICBpZDogc3RyaW5nO1xuXG4gIC8qKlxuICAgKiBDb250ZW50IGdlbmVyYXRlZCBieSB0aGUgbW9kZWwuXG4gICAqXG4gICAqIFRoaXMgaXMgYW4gYXJyYXkgb2YgY29udGVudCBibG9ja3MsIGVhY2ggb2Ygd2hpY2ggaGFzIGEgYHR5cGVgIHRoYXQgZGV0ZXJtaW5lc1xuICAgKiBpdHMgc2hhcGUuXG4gICAqXG4gICAqIEV4YW1wbGU6XG4gICAqXG4gICAqIGBgYGpzb25cbiAgICogW3sgXCJ0eXBlXCI6IFwidGV4dFwiLCBcInRleHRcIjogXCJIaSwgSSdtIENsYXVkZS5cIiB9XVxuICAgKiBgYGBcbiAgICpcbiAgICogSWYgdGhlIHJlcXVlc3QgaW5wdXQgYG1lc3NhZ2VzYCBlbmRlZCB3aXRoIGFuIGBhc3Npc3RhbnRgIHR1cm4sIHRoZW4gdGhlXG4gICAqIHJlc3BvbnNlIGBjb250ZW50YCB3aWxsIGNvbnRpbnVlIGRpcmVjdGx5IGZyb20gdGhhdCBsYXN0IHR1cm4uIFlvdSBjYW4gdXNlIHRoaXNcbiAgICogdG8gY29uc3RyYWluIHRoZSBtb2RlbCdzIG91dHB1dC5cbiAgICpcbiAgICogRm9yIGV4YW1wbGUsIGlmIHRoZSBpbnB1dCBgbWVzc2FnZXNgIHdlcmU6XG4gICAqXG4gICAqIGBgYGpzb25cbiAgICogW1xuICAgKiAgIHtcbiAgICogICAgIFwicm9sZVwiOiBcInVzZXJcIixcbiAgICogICAgIFwiY29udGVudFwiOiBcIldoYXQncyB0aGUgR3JlZWsgbmFtZSBmb3IgU3VuPyAoQSkgU29sIChCKSBIZWxpb3MgKEMpIFN1blwiXG4gICAqICAgfSxcbiAgICogICB7IFwicm9sZVwiOiBcImFzc2lzdGFudFwiLCBcImNvbnRlbnRcIjogXCJUaGUgYmVzdCBhbnN3ZXIgaXMgKFwiIH1cbiAgICogXVxuICAgKiBgYGBcbiAgICpcbiAgICogVGhlbiB0aGUgcmVzcG9uc2UgYGNvbnRlbnRgIG1pZ2h0IGJlOlxuICAgKlxuICAgKiBgYGBqc29uXG4gICAqIFt7IFwidHlwZVwiOiBcInRleHRcIiwgXCJ0ZXh0XCI6IFwiQilcIiB9XVxuICAgKiBgYGBcbiAgICovXG4gIGNvbnRlbnQ6IEFycmF5PENvbnRlbnRCbG9jaz47XG5cbiAgLyoqXG4gICAqIFRoZSBtb2RlbCB0aGF0IHdpbGwgY29tcGxldGUgeW91ciBwcm9tcHQuXFxuXFxuU2VlXG4gICAqIFttb2RlbHNdKGh0dHBzOi8vZG9jcy5hbnRocm9waWMuY29tL2VuL2RvY3MvbW9kZWxzLW92ZXJ2aWV3KSBmb3IgYWRkaXRpb25hbFxuICAgKiBkZXRhaWxzIGFuZCBvcHRpb25zLlxuICAgKi9cbiAgbW9kZWw6IE1vZGVsO1xuXG4gIC8qKlxuICAgKiBDb252ZXJzYXRpb25hbCByb2xlIG9mIHRoZSBnZW5lcmF0ZWQgbWVzc2FnZS5cbiAgICpcbiAgICogVGhpcyB3aWxsIGFsd2F5cyBiZSBgXCJhc3Npc3RhbnRcImAuXG4gICAqL1xuICByb2xlOiAnYXNzaXN0YW50JztcblxuICAvKipcbiAgICogVGhlIHJlYXNvbiB0aGF0IHdlIHN0b3BwZWQuXG4gICAqXG4gICAqIFRoaXMgbWF5IGJlIG9uZSB0aGUgZm9sbG93aW5nIHZhbHVlczpcbiAgICpcbiAgICogLSBgXCJlbmRfdHVyblwiYDogdGhlIG1vZGVsIHJlYWNoZWQgYSBuYXR1cmFsIHN0b3BwaW5nIHBvaW50XG4gICAqIC0gYFwibWF4X3Rva2Vuc1wiYDogd2UgZXhjZWVkZWQgdGhlIHJlcXVlc3RlZCBgbWF4X3Rva2Vuc2Agb3IgdGhlIG1vZGVsJ3MgbWF4aW11bVxuICAgKiAtIGBcInN0b3Bfc2VxdWVuY2VcImA6IG9uZSBvZiB5b3VyIHByb3ZpZGVkIGN1c3RvbSBgc3RvcF9zZXF1ZW5jZXNgIHdhcyBnZW5lcmF0ZWRcbiAgICogLSBgXCJ0b29sX3VzZVwiYDogdGhlIG1vZGVsIGludm9rZWQgb25lIG9yIG1vcmUgdG9vbHNcbiAgICpcbiAgICogSW4gbm9uLXN0cmVhbWluZyBtb2RlIHRoaXMgdmFsdWUgaXMgYWx3YXlzIG5vbi1udWxsLiBJbiBzdHJlYW1pbmcgbW9kZSwgaXQgaXNcbiAgICogbnVsbCBpbiB0aGUgYG1lc3NhZ2Vfc3RhcnRgIGV2ZW50IGFuZCBub24tbnVsbCBvdGhlcndpc2UuXG4gICAqL1xuICBzdG9wX3JlYXNvbjogJ2VuZF90dXJuJyB8ICdtYXhfdG9rZW5zJyB8ICdzdG9wX3NlcXVlbmNlJyB8ICd0b29sX3VzZScgfCBudWxsO1xuXG4gIC8qKlxuICAgKiBXaGljaCBjdXN0b20gc3RvcCBzZXF1ZW5jZSB3YXMgZ2VuZXJhdGVkLCBpZiBhbnkuXG4gICAqXG4gICAqIFRoaXMgdmFsdWUgd2lsbCBiZSBhIG5vbi1udWxsIHN0cmluZyBpZiBvbmUgb2YgeW91ciBjdXN0b20gc3RvcCBzZXF1ZW5jZXMgd2FzXG4gICAqIGdlbmVyYXRlZC5cbiAgICovXG4gIHN0b3Bfc2VxdWVuY2U6IHN0cmluZyB8IG51bGw7XG5cbiAgLyoqXG4gICAqIE9iamVjdCB0eXBlLlxuICAgKlxuICAgKiBGb3IgTWVzc2FnZXMsIHRoaXMgaXMgYWx3YXlzIGBcIm1lc3NhZ2VcImAuXG4gICAqL1xuICB0eXBlOiAnbWVzc2FnZSc7XG5cbiAgLyoqXG4gICAqIEJpbGxpbmcgYW5kIHJhdGUtbGltaXQgdXNhZ2UuXG4gICAqXG4gICAqIEFudGhyb3BpYydzIEFQSSBiaWxscyBhbmQgcmF0ZS1saW1pdHMgYnkgdG9rZW4gY291bnRzLCBhcyB0b2tlbnMgcmVwcmVzZW50IHRoZVxuICAgKiB1bmRlcmx5aW5nIGNvc3QgdG8gb3VyIHN5c3RlbXMuXG4gICAqXG4gICAqIFVuZGVyIHRoZSBob29kLCB0aGUgQVBJIHRyYW5zZm9ybXMgcmVxdWVzdHMgaW50byBhIGZvcm1hdCBzdWl0YWJsZSBmb3IgdGhlXG4gICAqIG1vZGVsLiBUaGUgbW9kZWwncyBvdXRwdXQgdGhlbiBnb2VzIHRocm91Z2ggYSBwYXJzaW5nIHN0YWdlIGJlZm9yZSBiZWNvbWluZyBhblxuICAgKiBBUEkgcmVzcG9uc2UuIEFzIGEgcmVzdWx0LCB0aGUgdG9rZW4gY291bnRzIGluIGB1c2FnZWAgd2lsbCBub3QgbWF0Y2ggb25lLXRvLW9uZVxuICAgKiB3aXRoIHRoZSBleGFjdCB2aXNpYmxlIGNvbnRlbnQgb2YgYW4gQVBJIHJlcXVlc3Qgb3IgcmVzcG9uc2UuXG4gICAqXG4gICAqIEZvciBleGFtcGxlLCBgb3V0cHV0X3Rva2Vuc2Agd2lsbCBiZSBub24temVybywgZXZlbiBmb3IgYW4gZW1wdHkgc3RyaW5nIHJlc3BvbnNlXG4gICAqIGZyb20gQ2xhdWRlLlxuICAgKi9cbiAgdXNhZ2U6IFVzYWdlO1xufVxuXG5leHBvcnQgdHlwZSBNZXNzYWdlRGVsdGFFdmVudCA9IFJhd01lc3NhZ2VEZWx0YUV2ZW50O1xuXG5leHBvcnQgaW50ZXJmYWNlIE1lc3NhZ2VEZWx0YVVzYWdlIHtcbiAgLyoqXG4gICAqIFRoZSBjdW11bGF0aXZlIG51bWJlciBvZiBvdXRwdXQgdG9rZW5zIHdoaWNoIHdlcmUgdXNlZC5cbiAgICovXG4gIG91dHB1dF90b2tlbnM6IG51bWJlcjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNZXNzYWdlUGFyYW0ge1xuICBjb250ZW50OiBzdHJpbmcgfCBBcnJheTxUZXh0QmxvY2tQYXJhbSB8IEltYWdlQmxvY2tQYXJhbSB8IFRvb2xVc2VCbG9ja1BhcmFtIHwgVG9vbFJlc3VsdEJsb2NrUGFyYW0+O1xuXG4gIHJvbGU6ICd1c2VyJyB8ICdhc3Npc3RhbnQnO1xufVxuXG5leHBvcnQgdHlwZSBNZXNzYWdlU3RhcnRFdmVudCA9IFJhd01lc3NhZ2VTdGFydEV2ZW50O1xuXG5leHBvcnQgdHlwZSBNZXNzYWdlU3RvcEV2ZW50ID0gUmF3TWVzc2FnZVN0b3BFdmVudDtcblxuZXhwb3J0IHR5cGUgTWVzc2FnZVN0cmVhbUV2ZW50ID0gUmF3TWVzc2FnZVN0cmVhbUV2ZW50O1xuXG4vKipcbiAqIFRoZSBtb2RlbCB0aGF0IHdpbGwgY29tcGxldGUgeW91ciBwcm9tcHQuXFxuXFxuU2VlXG4gKiBbbW9kZWxzXShodHRwczovL2RvY3MuYW50aHJvcGljLmNvbS9lbi9kb2NzL21vZGVscy1vdmVydmlldykgZm9yIGFkZGl0aW9uYWxcbiAqIGRldGFpbHMgYW5kIG9wdGlvbnMuXG4gKi9cbmV4cG9ydCB0eXBlIE1vZGVsID1cbiAgfCAoc3RyaW5nICYge30pXG4gIHwgJ2NsYXVkZS0zLTUtc29ubmV0LTIwMjQwNjIwJ1xuICB8ICdjbGF1ZGUtMy1vcHVzLTIwMjQwMjI5J1xuICB8ICdjbGF1ZGUtMy1zb25uZXQtMjAyNDAyMjknXG4gIHwgJ2NsYXVkZS0zLWhhaWt1LTIwMjQwMzA3J1xuICB8ICdjbGF1ZGUtMi4xJ1xuICB8ICdjbGF1ZGUtMi4wJ1xuICB8ICdjbGF1ZGUtaW5zdGFudC0xLjInO1xuXG50eXBlIERlcHJlY2F0ZWRNb2RlbHNUeXBlID0ge1xuICBbSyBpbiBNb2RlbF0/OiBzdHJpbmc7XG59O1xuXG5jb25zdCBERVBSRUNBVEVEX01PREVMUzogRGVwcmVjYXRlZE1vZGVsc1R5cGUgPSB7XG4gICdjbGF1ZGUtMS4zJzogJ05vdmVtYmVyIDZ0aCwgMjAyNCcsXG4gICdjbGF1ZGUtMS4zLTEwMGsnOiAnTm92ZW1iZXIgNnRoLCAyMDI0JyxcbiAgJ2NsYXVkZS1pbnN0YW50LTEuMSc6ICdOb3ZlbWJlciA2dGgsIDIwMjQnLFxuICAnY2xhdWRlLWluc3RhbnQtMS4xLTEwMGsnOiAnTm92ZW1iZXIgNnRoLCAyMDI0JyxcbiAgJ2NsYXVkZS1pbnN0YW50LTEuMic6ICdOb3ZlbWJlciA2dGgsIDIwMjQnLFxufTtcblxuZXhwb3J0IGludGVyZmFjZSBSYXdDb250ZW50QmxvY2tEZWx0YUV2ZW50IHtcbiAgZGVsdGE6IFRleHREZWx0YSB8IElucHV0SlNPTkRlbHRhO1xuXG4gIGluZGV4OiBudW1iZXI7XG5cbiAgdHlwZTogJ2NvbnRlbnRfYmxvY2tfZGVsdGEnO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFJhd0NvbnRlbnRCbG9ja1N0YXJ0RXZlbnQge1xuICBjb250ZW50X2Jsb2NrOiBUZXh0QmxvY2sgfCBUb29sVXNlQmxvY2s7XG5cbiAgaW5kZXg6IG51bWJlcjtcblxuICB0eXBlOiAnY29udGVudF9ibG9ja19zdGFydCc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgUmF3Q29udGVudEJsb2NrU3RvcEV2ZW50IHtcbiAgaW5kZXg6IG51bWJlcjtcblxuICB0eXBlOiAnY29udGVudF9ibG9ja19zdG9wJztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBSYXdNZXNzYWdlRGVsdGFFdmVudCB7XG4gIGRlbHRhOiBSYXdNZXNzYWdlRGVsdGFFdmVudC5EZWx0YTtcblxuICB0eXBlOiAnbWVzc2FnZV9kZWx0YSc7XG5cbiAgLyoqXG4gICAqIEJpbGxpbmcgYW5kIHJhdGUtbGltaXQgdXNhZ2UuXG4gICAqXG4gICAqIEFudGhyb3BpYydzIEFQSSBiaWxscyBhbmQgcmF0ZS1saW1pdHMgYnkgdG9rZW4gY291bnRzLCBhcyB0b2tlbnMgcmVwcmVzZW50IHRoZVxuICAgKiB1bmRlcmx5aW5nIGNvc3QgdG8gb3VyIHN5c3RlbXMuXG4gICAqXG4gICAqIFVuZGVyIHRoZSBob29kLCB0aGUgQVBJIHRyYW5zZm9ybXMgcmVxdWVzdHMgaW50byBhIGZvcm1hdCBzdWl0YWJsZSBmb3IgdGhlXG4gICAqIG1vZGVsLiBUaGUgbW9kZWwncyBvdXRwdXQgdGhlbiBnb2VzIHRocm91Z2ggYSBwYXJzaW5nIHN0YWdlIGJlZm9yZSBiZWNvbWluZyBhblxuICAgKiBBUEkgcmVzcG9uc2UuIEFzIGEgcmVzdWx0LCB0aGUgdG9rZW4gY291bnRzIGluIGB1c2FnZWAgd2lsbCBub3QgbWF0Y2ggb25lLXRvLW9uZVxuICAgKiB3aXRoIHRoZSBleGFjdCB2aXNpYmxlIGNvbnRlbnQgb2YgYW4gQVBJIHJlcXVlc3Qgb3IgcmVzcG9uc2UuXG4gICAqXG4gICAqIEZvciBleGFtcGxlLCBgb3V0cHV0X3Rva2Vuc2Agd2lsbCBiZSBub24temVybywgZXZlbiBmb3IgYW4gZW1wdHkgc3RyaW5nIHJlc3BvbnNlXG4gICAqIGZyb20gQ2xhdWRlLlxuICAgKi9cbiAgdXNhZ2U6IE1lc3NhZ2VEZWx0YVVzYWdlO1xufVxuXG5leHBvcnQgbmFtZXNwYWNlIFJhd01lc3NhZ2VEZWx0YUV2ZW50IHtcbiAgZXhwb3J0IGludGVyZmFjZSBEZWx0YSB7XG4gICAgc3RvcF9yZWFzb246ICdlbmRfdHVybicgfCAnbWF4X3Rva2VucycgfCAnc3RvcF9zZXF1ZW5jZScgfCAndG9vbF91c2UnIHwgbnVsbDtcblxuICAgIHN0b3Bfc2VxdWVuY2U6IHN0cmluZyB8IG51bGw7XG4gIH1cbn1cblxuZXhwb3J0IGludGVyZmFjZSBSYXdNZXNzYWdlU3RhcnRFdmVudCB7XG4gIG1lc3NhZ2U6IE1lc3NhZ2U7XG5cbiAgdHlwZTogJ21lc3NhZ2Vfc3RhcnQnO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFJhd01lc3NhZ2VTdG9wRXZlbnQge1xuICB0eXBlOiAnbWVzc2FnZV9zdG9wJztcbn1cblxuZXhwb3J0IHR5cGUgUmF3TWVzc2FnZVN0cmVhbUV2ZW50ID1cbiAgfCBSYXdNZXNzYWdlU3RhcnRFdmVudFxuICB8IFJhd01lc3NhZ2VEZWx0YUV2ZW50XG4gIHwgUmF3TWVzc2FnZVN0b3BFdmVudFxuICB8IFJhd0NvbnRlbnRCbG9ja1N0YXJ0RXZlbnRcbiAgfCBSYXdDb250ZW50QmxvY2tEZWx0YUV2ZW50XG4gIHwgUmF3Q29udGVudEJsb2NrU3RvcEV2ZW50O1xuXG5leHBvcnQgaW50ZXJmYWNlIFRleHRCbG9jayB7XG4gIHRleHQ6IHN0cmluZztcblxuICB0eXBlOiAndGV4dCc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgVGV4dEJsb2NrUGFyYW0ge1xuICB0ZXh0OiBzdHJpbmc7XG5cbiAgdHlwZTogJ3RleHQnO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFRleHREZWx0YSB7XG4gIHRleHQ6IHN0cmluZztcblxuICB0eXBlOiAndGV4dF9kZWx0YSc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgVG9vbCB7XG4gIC8qKlxuICAgKiBbSlNPTiBzY2hlbWFdKGh0dHBzOi8vanNvbi1zY2hlbWEub3JnLykgZm9yIHRoaXMgdG9vbCdzIGlucHV0LlxuICAgKlxuICAgKiBUaGlzIGRlZmluZXMgdGhlIHNoYXBlIG9mIHRoZSBgaW5wdXRgIHRoYXQgeW91ciB0b29sIGFjY2VwdHMgYW5kIHRoYXQgdGhlIG1vZGVsXG4gICAqIHdpbGwgcHJvZHVjZS5cbiAgICovXG4gIGlucHV0X3NjaGVtYTogVG9vbC5JbnB1dFNjaGVtYTtcblxuICBuYW1lOiBzdHJpbmc7XG5cbiAgLyoqXG4gICAqIERlc2NyaXB0aW9uIG9mIHdoYXQgdGhpcyB0b29sIGRvZXMuXG4gICAqXG4gICAqIFRvb2wgZGVzY3JpcHRpb25zIHNob3VsZCBiZSBhcyBkZXRhaWxlZCBhcyBwb3NzaWJsZS4gVGhlIG1vcmUgaW5mb3JtYXRpb24gdGhhdFxuICAgKiB0aGUgbW9kZWwgaGFzIGFib3V0IHdoYXQgdGhlIHRvb2wgaXMgYW5kIGhvdyB0byB1c2UgaXQsIHRoZSBiZXR0ZXIgaXQgd2lsbFxuICAgKiBwZXJmb3JtLiBZb3UgY2FuIHVzZSBuYXR1cmFsIGxhbmd1YWdlIGRlc2NyaXB0aW9ucyB0byByZWluZm9yY2UgaW1wb3J0YW50XG4gICAqIGFzcGVjdHMgb2YgdGhlIHRvb2wgaW5wdXQgSlNPTiBzY2hlbWEuXG4gICAqL1xuICBkZXNjcmlwdGlvbj86IHN0cmluZztcbn1cblxuZXhwb3J0IG5hbWVzcGFjZSBUb29sIHtcbiAgLyoqXG4gICAqIFtKU09OIHNjaGVtYV0oaHR0cHM6Ly9qc29uLXNjaGVtYS5vcmcvKSBmb3IgdGhpcyB0b29sJ3MgaW5wdXQuXG4gICAqXG4gICAqIFRoaXMgZGVmaW5lcyB0aGUgc2hhcGUgb2YgdGhlIGBpbnB1dGAgdGhhdCB5b3VyIHRvb2wgYWNjZXB0cyBhbmQgdGhhdCB0aGUgbW9kZWxcbiAgICogd2lsbCBwcm9kdWNlLlxuICAgKi9cbiAgZXhwb3J0IGludGVyZmFjZSBJbnB1dFNjaGVtYSB7XG4gICAgdHlwZTogJ29iamVjdCc7XG5cbiAgICBwcm9wZXJ0aWVzPzogdW5rbm93biB8IG51bGw7XG4gICAgW2s6IHN0cmluZ106IHVua25vd247XG4gIH1cbn1cblxuZXhwb3J0IGludGVyZmFjZSBUb29sUmVzdWx0QmxvY2tQYXJhbSB7XG4gIHRvb2xfdXNlX2lkOiBzdHJpbmc7XG5cbiAgdHlwZTogJ3Rvb2xfcmVzdWx0JztcblxuICBjb250ZW50Pzogc3RyaW5nIHwgQXJyYXk8VGV4dEJsb2NrUGFyYW0gfCBJbWFnZUJsb2NrUGFyYW0+O1xuXG4gIGlzX2Vycm9yPzogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBUb29sVXNlQmxvY2sge1xuICBpZDogc3RyaW5nO1xuXG4gIGlucHV0OiB1bmtub3duO1xuXG4gIG5hbWU6IHN0cmluZztcblxuICB0eXBlOiAndG9vbF91c2UnO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFRvb2xVc2VCbG9ja1BhcmFtIHtcbiAgaWQ6IHN0cmluZztcblxuICBpbnB1dDogdW5rbm93bjtcblxuICBuYW1lOiBzdHJpbmc7XG5cbiAgdHlwZTogJ3Rvb2xfdXNlJztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBVc2FnZSB7XG4gIC8qKlxuICAgKiBUaGUgbnVtYmVyIG9mIGlucHV0IHRva2VucyB3aGljaCB3ZXJlIHVzZWQuXG4gICAqL1xuICBpbnB1dF90b2tlbnM6IG51bWJlcjtcblxuICAvKipcbiAgICogVGhlIG51bWJlciBvZiBvdXRwdXQgdG9rZW5zIHdoaWNoIHdlcmUgdXNlZC5cbiAgICovXG4gIG91dHB1dF90b2tlbnM6IG51bWJlcjtcbn1cblxuZXhwb3J0IHR5cGUgTWVzc2FnZUNyZWF0ZVBhcmFtcyA9IE1lc3NhZ2VDcmVhdGVQYXJhbXNOb25TdHJlYW1pbmcgfCBNZXNzYWdlQ3JlYXRlUGFyYW1zU3RyZWFtaW5nO1xuXG5leHBvcnQgaW50ZXJmYWNlIE1lc3NhZ2VDcmVhdGVQYXJhbXNCYXNlIHtcbiAgLyoqXG4gICAqIFRoZSBtYXhpbXVtIG51bWJlciBvZiB0b2tlbnMgdG8gZ2VuZXJhdGUgYmVmb3JlIHN0b3BwaW5nLlxuICAgKlxuICAgKiBOb3RlIHRoYXQgb3VyIG1vZGVscyBtYXkgc3RvcCBfYmVmb3JlXyByZWFjaGluZyB0aGlzIG1heGltdW0uIFRoaXMgcGFyYW1ldGVyXG4gICAqIG9ubHkgc3BlY2lmaWVzIHRoZSBhYnNvbHV0ZSBtYXhpbXVtIG51bWJlciBvZiB0b2tlbnMgdG8gZ2VuZXJhdGUuXG4gICAqXG4gICAqIERpZmZlcmVudCBtb2RlbHMgaGF2ZSBkaWZmZXJlbnQgbWF4aW11bSB2YWx1ZXMgZm9yIHRoaXMgcGFyYW1ldGVyLiBTZWVcbiAgICogW21vZGVsc10oaHR0cHM6Ly9kb2NzLmFudGhyb3BpYy5jb20vZW4vZG9jcy9tb2RlbHMtb3ZlcnZpZXcpIGZvciBkZXRhaWxzLlxuICAgKi9cbiAgbWF4X3Rva2VuczogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBJbnB1dCBtZXNzYWdlcy5cbiAgICpcbiAgICogT3VyIG1vZGVscyBhcmUgdHJhaW5lZCB0byBvcGVyYXRlIG9uIGFsdGVybmF0aW5nIGB1c2VyYCBhbmQgYGFzc2lzdGFudGBcbiAgICogY29udmVyc2F0aW9uYWwgdHVybnMuIFdoZW4gY3JlYXRpbmcgYSBuZXcgYE1lc3NhZ2VgLCB5b3Ugc3BlY2lmeSB0aGUgcHJpb3JcbiAgICogY29udmVyc2F0aW9uYWwgdHVybnMgd2l0aCB0aGUgYG1lc3NhZ2VzYCBwYXJhbWV0ZXIsIGFuZCB0aGUgbW9kZWwgdGhlbiBnZW5lcmF0ZXNcbiAgICogdGhlIG5leHQgYE1lc3NhZ2VgIGluIHRoZSBjb252ZXJzYXRpb24uXG4gICAqXG4gICAqIEVhY2ggaW5wdXQgbWVzc2FnZSBtdXN0IGJlIGFuIG9iamVjdCB3aXRoIGEgYHJvbGVgIGFuZCBgY29udGVudGAuIFlvdSBjYW5cbiAgICogc3BlY2lmeSBhIHNpbmdsZSBgdXNlcmAtcm9sZSBtZXNzYWdlLCBvciB5b3UgY2FuIGluY2x1ZGUgbXVsdGlwbGUgYHVzZXJgIGFuZFxuICAgKiBgYXNzaXN0YW50YCBtZXNzYWdlcy4gVGhlIGZpcnN0IG1lc3NhZ2UgbXVzdCBhbHdheXMgdXNlIHRoZSBgdXNlcmAgcm9sZS5cbiAgICpcbiAgICogSWYgdGhlIGZpbmFsIG1lc3NhZ2UgdXNlcyB0aGUgYGFzc2lzdGFudGAgcm9sZSwgdGhlIHJlc3BvbnNlIGNvbnRlbnQgd2lsbFxuICAgKiBjb250aW51ZSBpbW1lZGlhdGVseSBmcm9tIHRoZSBjb250ZW50IGluIHRoYXQgbWVzc2FnZS4gVGhpcyBjYW4gYmUgdXNlZCB0b1xuICAgKiBjb25zdHJhaW4gcGFydCBvZiB0aGUgbW9kZWwncyByZXNwb25zZS5cbiAgICpcbiAgICogRXhhbXBsZSB3aXRoIGEgc2luZ2xlIGB1c2VyYCBtZXNzYWdlOlxuICAgKlxuICAgKiBgYGBqc29uXG4gICAqIFt7IFwicm9sZVwiOiBcInVzZXJcIiwgXCJjb250ZW50XCI6IFwiSGVsbG8sIENsYXVkZVwiIH1dXG4gICAqIGBgYFxuICAgKlxuICAgKiBFeGFtcGxlIHdpdGggbXVsdGlwbGUgY29udmVyc2F0aW9uYWwgdHVybnM6XG4gICAqXG4gICAqIGBgYGpzb25cbiAgICogW1xuICAgKiAgIHsgXCJyb2xlXCI6IFwidXNlclwiLCBcImNvbnRlbnRcIjogXCJIZWxsbyB0aGVyZS5cIiB9LFxuICAgKiAgIHsgXCJyb2xlXCI6IFwiYXNzaXN0YW50XCIsIFwiY29udGVudFwiOiBcIkhpLCBJJ20gQ2xhdWRlLiBIb3cgY2FuIEkgaGVscCB5b3U/XCIgfSxcbiAgICogICB7IFwicm9sZVwiOiBcInVzZXJcIiwgXCJjb250ZW50XCI6IFwiQ2FuIHlvdSBleHBsYWluIExMTXMgaW4gcGxhaW4gRW5nbGlzaD9cIiB9XG4gICAqIF1cbiAgICogYGBgXG4gICAqXG4gICAqIEV4YW1wbGUgd2l0aCBhIHBhcnRpYWxseS1maWxsZWQgcmVzcG9uc2UgZnJvbSBDbGF1ZGU6XG4gICAqXG4gICAqIGBgYGpzb25cbiAgICogW1xuICAgKiAgIHtcbiAgICogICAgIFwicm9sZVwiOiBcInVzZXJcIixcbiAgICogICAgIFwiY29udGVudFwiOiBcIldoYXQncyB0aGUgR3JlZWsgbmFtZSBmb3IgU3VuPyAoQSkgU29sIChCKSBIZWxpb3MgKEMpIFN1blwiXG4gICAqICAgfSxcbiAgICogICB7IFwicm9sZVwiOiBcImFzc2lzdGFudFwiLCBcImNvbnRlbnRcIjogXCJUaGUgYmVzdCBhbnN3ZXIgaXMgKFwiIH1cbiAgICogXVxuICAgKiBgYGBcbiAgICpcbiAgICogRWFjaCBpbnB1dCBtZXNzYWdlIGBjb250ZW50YCBtYXkgYmUgZWl0aGVyIGEgc2luZ2xlIGBzdHJpbmdgIG9yIGFuIGFycmF5IG9mXG4gICAqIGNvbnRlbnQgYmxvY2tzLCB3aGVyZSBlYWNoIGJsb2NrIGhhcyBhIHNwZWNpZmljIGB0eXBlYC4gVXNpbmcgYSBgc3RyaW5nYCBmb3JcbiAgICogYGNvbnRlbnRgIGlzIHNob3J0aGFuZCBmb3IgYW4gYXJyYXkgb2Ygb25lIGNvbnRlbnQgYmxvY2sgb2YgdHlwZSBgXCJ0ZXh0XCJgLiBUaGVcbiAgICogZm9sbG93aW5nIGlucHV0IG1lc3NhZ2VzIGFyZSBlcXVpdmFsZW50OlxuICAgKlxuICAgKiBgYGBqc29uXG4gICAqIHsgXCJyb2xlXCI6IFwidXNlclwiLCBcImNvbnRlbnRcIjogXCJIZWxsbywgQ2xhdWRlXCIgfVxuICAgKiBgYGBcbiAgICpcbiAgICogYGBganNvblxuICAgKiB7IFwicm9sZVwiOiBcInVzZXJcIiwgXCJjb250ZW50XCI6IFt7IFwidHlwZVwiOiBcInRleHRcIiwgXCJ0ZXh0XCI6IFwiSGVsbG8sIENsYXVkZVwiIH1dIH1cbiAgICogYGBgXG4gICAqXG4gICAqIFN0YXJ0aW5nIHdpdGggQ2xhdWRlIDMgbW9kZWxzLCB5b3UgY2FuIGFsc28gc2VuZCBpbWFnZSBjb250ZW50IGJsb2NrczpcbiAgICpcbiAgICogYGBganNvblxuICAgKiB7XG4gICAqICAgXCJyb2xlXCI6IFwidXNlclwiLFxuICAgKiAgIFwiY29udGVudFwiOiBbXG4gICAqICAgICB7XG4gICAqICAgICAgIFwidHlwZVwiOiBcImltYWdlXCIsXG4gICAqICAgICAgIFwic291cmNlXCI6IHtcbiAgICogICAgICAgICBcInR5cGVcIjogXCJiYXNlNjRcIixcbiAgICogICAgICAgICBcIm1lZGlhX3R5cGVcIjogXCJpbWFnZS9qcGVnXCIsXG4gICAqICAgICAgICAgXCJkYXRhXCI6IFwiLzlqLzRBQVFTa1pKUmcuLi5cIlxuICAgKiAgICAgICB9XG4gICAqICAgICB9LFxuICAgKiAgICAgeyBcInR5cGVcIjogXCJ0ZXh0XCIsIFwidGV4dFwiOiBcIldoYXQgaXMgaW4gdGhpcyBpbWFnZT9cIiB9XG4gICAqICAgXVxuICAgKiB9XG4gICAqIGBgYFxuICAgKlxuICAgKiBXZSBjdXJyZW50bHkgc3VwcG9ydCB0aGUgYGJhc2U2NGAgc291cmNlIHR5cGUgZm9yIGltYWdlcywgYW5kIHRoZSBgaW1hZ2UvanBlZ2AsXG4gICAqIGBpbWFnZS9wbmdgLCBgaW1hZ2UvZ2lmYCwgYW5kIGBpbWFnZS93ZWJwYCBtZWRpYSB0eXBlcy5cbiAgICpcbiAgICogU2VlIFtleGFtcGxlc10oaHR0cHM6Ly9kb2NzLmFudGhyb3BpYy5jb20vZW4vYXBpL21lc3NhZ2VzLWV4YW1wbGVzI3Zpc2lvbikgZm9yXG4gICAqIG1vcmUgaW5wdXQgZXhhbXBsZXMuXG4gICAqXG4gICAqIE5vdGUgdGhhdCBpZiB5b3Ugd2FudCB0byBpbmNsdWRlIGFcbiAgICogW3N5c3RlbSBwcm9tcHRdKGh0dHBzOi8vZG9jcy5hbnRocm9waWMuY29tL2VuL2RvY3Mvc3lzdGVtLXByb21wdHMpLCB5b3UgY2FuIHVzZVxuICAgKiB0aGUgdG9wLWxldmVsIGBzeXN0ZW1gIHBhcmFtZXRlciBcdTIwMTQgdGhlcmUgaXMgbm8gYFwic3lzdGVtXCJgIHJvbGUgZm9yIGlucHV0XG4gICAqIG1lc3NhZ2VzIGluIHRoZSBNZXNzYWdlcyBBUEkuXG4gICAqL1xuICBtZXNzYWdlczogQXJyYXk8TWVzc2FnZVBhcmFtPjtcblxuICAvKipcbiAgICogVGhlIG1vZGVsIHRoYXQgd2lsbCBjb21wbGV0ZSB5b3VyIHByb21wdC5cXG5cXG5TZWVcbiAgICogW21vZGVsc10oaHR0cHM6Ly9kb2NzLmFudGhyb3BpYy5jb20vZW4vZG9jcy9tb2RlbHMtb3ZlcnZpZXcpIGZvciBhZGRpdGlvbmFsXG4gICAqIGRldGFpbHMgYW5kIG9wdGlvbnMuXG4gICAqL1xuICBtb2RlbDogTW9kZWw7XG5cbiAgLyoqXG4gICAqIEFuIG9iamVjdCBkZXNjcmliaW5nIG1ldGFkYXRhIGFib3V0IHRoZSByZXF1ZXN0LlxuICAgKi9cbiAgbWV0YWRhdGE/OiBNZXNzYWdlQ3JlYXRlUGFyYW1zLk1ldGFkYXRhO1xuXG4gIC8qKlxuICAgKiBDdXN0b20gdGV4dCBzZXF1ZW5jZXMgdGhhdCB3aWxsIGNhdXNlIHRoZSBtb2RlbCB0byBzdG9wIGdlbmVyYXRpbmcuXG4gICAqXG4gICAqIE91ciBtb2RlbHMgd2lsbCBub3JtYWxseSBzdG9wIHdoZW4gdGhleSBoYXZlIG5hdHVyYWxseSBjb21wbGV0ZWQgdGhlaXIgdHVybixcbiAgICogd2hpY2ggd2lsbCByZXN1bHQgaW4gYSByZXNwb25zZSBgc3RvcF9yZWFzb25gIG9mIGBcImVuZF90dXJuXCJgLlxuICAgKlxuICAgKiBJZiB5b3Ugd2FudCB0aGUgbW9kZWwgdG8gc3RvcCBnZW5lcmF0aW5nIHdoZW4gaXQgZW5jb3VudGVycyBjdXN0b20gc3RyaW5ncyBvZlxuICAgKiB0ZXh0LCB5b3UgY2FuIHVzZSB0aGUgYHN0b3Bfc2VxdWVuY2VzYCBwYXJhbWV0ZXIuIElmIHRoZSBtb2RlbCBlbmNvdW50ZXJzIG9uZSBvZlxuICAgKiB0aGUgY3VzdG9tIHNlcXVlbmNlcywgdGhlIHJlc3BvbnNlIGBzdG9wX3JlYXNvbmAgdmFsdWUgd2lsbCBiZSBgXCJzdG9wX3NlcXVlbmNlXCJgXG4gICAqIGFuZCB0aGUgcmVzcG9uc2UgYHN0b3Bfc2VxdWVuY2VgIHZhbHVlIHdpbGwgY29udGFpbiB0aGUgbWF0Y2hlZCBzdG9wIHNlcXVlbmNlLlxuICAgKi9cbiAgc3RvcF9zZXF1ZW5jZXM/OiBBcnJheTxzdHJpbmc+O1xuXG4gIC8qKlxuICAgKiBXaGV0aGVyIHRvIGluY3JlbWVudGFsbHkgc3RyZWFtIHRoZSByZXNwb25zZSB1c2luZyBzZXJ2ZXItc2VudCBldmVudHMuXG4gICAqXG4gICAqIFNlZSBbc3RyZWFtaW5nXShodHRwczovL2RvY3MuYW50aHJvcGljLmNvbS9lbi9hcGkvbWVzc2FnZXMtc3RyZWFtaW5nKSBmb3JcbiAgICogZGV0YWlscy5cbiAgICovXG4gIHN0cmVhbT86IGJvb2xlYW47XG5cbiAgLyoqXG4gICAqIFN5c3RlbSBwcm9tcHQuXG4gICAqXG4gICAqIEEgc3lzdGVtIHByb21wdCBpcyBhIHdheSBvZiBwcm92aWRpbmcgY29udGV4dCBhbmQgaW5zdHJ1Y3Rpb25zIHRvIENsYXVkZSwgc3VjaFxuICAgKiBhcyBzcGVjaWZ5aW5nIGEgcGFydGljdWxhciBnb2FsIG9yIHJvbGUuIFNlZSBvdXJcbiAgICogW2d1aWRlIHRvIHN5c3RlbSBwcm9tcHRzXShodHRwczovL2RvY3MuYW50aHJvcGljLmNvbS9lbi9kb2NzL3N5c3RlbS1wcm9tcHRzKS5cbiAgICovXG4gIHN5c3RlbT86IHN0cmluZyB8IEFycmF5PFRleHRCbG9ja1BhcmFtPjtcblxuICAvKipcbiAgICogQW1vdW50IG9mIHJhbmRvbW5lc3MgaW5qZWN0ZWQgaW50byB0aGUgcmVzcG9uc2UuXG4gICAqXG4gICAqIERlZmF1bHRzIHRvIGAxLjBgLiBSYW5nZXMgZnJvbSBgMC4wYCB0byBgMS4wYC4gVXNlIGB0ZW1wZXJhdHVyZWAgY2xvc2VyIHRvIGAwLjBgXG4gICAqIGZvciBhbmFseXRpY2FsIC8gbXVsdGlwbGUgY2hvaWNlLCBhbmQgY2xvc2VyIHRvIGAxLjBgIGZvciBjcmVhdGl2ZSBhbmRcbiAgICogZ2VuZXJhdGl2ZSB0YXNrcy5cbiAgICpcbiAgICogTm90ZSB0aGF0IGV2ZW4gd2l0aCBgdGVtcGVyYXR1cmVgIG9mIGAwLjBgLCB0aGUgcmVzdWx0cyB3aWxsIG5vdCBiZSBmdWxseVxuICAgKiBkZXRlcm1pbmlzdGljLlxuICAgKi9cbiAgdGVtcGVyYXR1cmU/OiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIEhvdyB0aGUgbW9kZWwgc2hvdWxkIHVzZSB0aGUgcHJvdmlkZWQgdG9vbHMuIFRoZSBtb2RlbCBjYW4gdXNlIGEgc3BlY2lmaWMgdG9vbCxcbiAgICogYW55IGF2YWlsYWJsZSB0b29sLCBvciBkZWNpZGUgYnkgaXRzZWxmLlxuICAgKi9cbiAgdG9vbF9jaG9pY2U/OlxuICAgIHwgTWVzc2FnZUNyZWF0ZVBhcmFtcy5Ub29sQ2hvaWNlQXV0b1xuICAgIHwgTWVzc2FnZUNyZWF0ZVBhcmFtcy5Ub29sQ2hvaWNlQW55XG4gICAgfCBNZXNzYWdlQ3JlYXRlUGFyYW1zLlRvb2xDaG9pY2VUb29sO1xuXG4gIC8qKlxuICAgKiBEZWZpbml0aW9ucyBvZiB0b29scyB0aGF0IHRoZSBtb2RlbCBtYXkgdXNlLlxuICAgKlxuICAgKiBJZiB5b3UgaW5jbHVkZSBgdG9vbHNgIGluIHlvdXIgQVBJIHJlcXVlc3QsIHRoZSBtb2RlbCBtYXkgcmV0dXJuIGB0b29sX3VzZWBcbiAgICogY29udGVudCBibG9ja3MgdGhhdCByZXByZXNlbnQgdGhlIG1vZGVsJ3MgdXNlIG9mIHRob3NlIHRvb2xzLiBZb3UgY2FuIHRoZW4gcnVuXG4gICAqIHRob3NlIHRvb2xzIHVzaW5nIHRoZSB0b29sIGlucHV0IGdlbmVyYXRlZCBieSB0aGUgbW9kZWwgYW5kIHRoZW4gb3B0aW9uYWxseVxuICAgKiByZXR1cm4gcmVzdWx0cyBiYWNrIHRvIHRoZSBtb2RlbCB1c2luZyBgdG9vbF9yZXN1bHRgIGNvbnRlbnQgYmxvY2tzLlxuICAgKlxuICAgKiBFYWNoIHRvb2wgZGVmaW5pdGlvbiBpbmNsdWRlczpcbiAgICpcbiAgICogLSBgbmFtZWA6IE5hbWUgb2YgdGhlIHRvb2wuXG4gICAqIC0gYGRlc2NyaXB0aW9uYDogT3B0aW9uYWwsIGJ1dCBzdHJvbmdseS1yZWNvbW1lbmRlZCBkZXNjcmlwdGlvbiBvZiB0aGUgdG9vbC5cbiAgICogLSBgaW5wdXRfc2NoZW1hYDogW0pTT04gc2NoZW1hXShodHRwczovL2pzb24tc2NoZW1hLm9yZy8pIGZvciB0aGUgdG9vbCBgaW5wdXRgXG4gICAqICAgc2hhcGUgdGhhdCB0aGUgbW9kZWwgd2lsbCBwcm9kdWNlIGluIGB0b29sX3VzZWAgb3V0cHV0IGNvbnRlbnQgYmxvY2tzLlxuICAgKlxuICAgKiBGb3IgZXhhbXBsZSwgaWYgeW91IGRlZmluZWQgYHRvb2xzYCBhczpcbiAgICpcbiAgICogYGBganNvblxuICAgKiBbXG4gICAqICAge1xuICAgKiAgICAgXCJuYW1lXCI6IFwiZ2V0X3N0b2NrX3ByaWNlXCIsXG4gICAqICAgICBcImRlc2NyaXB0aW9uXCI6IFwiR2V0IHRoZSBjdXJyZW50IHN0b2NrIHByaWNlIGZvciBhIGdpdmVuIHRpY2tlciBzeW1ib2wuXCIsXG4gICAqICAgICBcImlucHV0X3NjaGVtYVwiOiB7XG4gICAqICAgICAgIFwidHlwZVwiOiBcIm9iamVjdFwiLFxuICAgKiAgICAgICBcInByb3BlcnRpZXNcIjoge1xuICAgKiAgICAgICAgIFwidGlja2VyXCI6IHtcbiAgICogICAgICAgICAgIFwidHlwZVwiOiBcInN0cmluZ1wiLFxuICAgKiAgICAgICAgICAgXCJkZXNjcmlwdGlvblwiOiBcIlRoZSBzdG9jayB0aWNrZXIgc3ltYm9sLCBlLmcuIEFBUEwgZm9yIEFwcGxlIEluYy5cIlxuICAgKiAgICAgICAgIH1cbiAgICogICAgICAgfSxcbiAgICogICAgICAgXCJyZXF1aXJlZFwiOiBbXCJ0aWNrZXJcIl1cbiAgICogICAgIH1cbiAgICogICB9XG4gICAqIF1cbiAgICogYGBgXG4gICAqXG4gICAqIEFuZCB0aGVuIGFza2VkIHRoZSBtb2RlbCBcIldoYXQncyB0aGUgUyZQIDUwMCBhdCB0b2RheT9cIiwgdGhlIG1vZGVsIG1pZ2h0IHByb2R1Y2VcbiAgICogYHRvb2xfdXNlYCBjb250ZW50IGJsb2NrcyBpbiB0aGUgcmVzcG9uc2UgbGlrZSB0aGlzOlxuICAgKlxuICAgKiBgYGBqc29uXG4gICAqIFtcbiAgICogICB7XG4gICAqICAgICBcInR5cGVcIjogXCJ0b29sX3VzZVwiLFxuICAgKiAgICAgXCJpZFwiOiBcInRvb2x1XzAxRDdGTHJmaDRHWXE3eVQxVUxGZXlNVlwiLFxuICAgKiAgICAgXCJuYW1lXCI6IFwiZ2V0X3N0b2NrX3ByaWNlXCIsXG4gICAqICAgICBcImlucHV0XCI6IHsgXCJ0aWNrZXJcIjogXCJeR1NQQ1wiIH1cbiAgICogICB9XG4gICAqIF1cbiAgICogYGBgXG4gICAqXG4gICAqIFlvdSBtaWdodCB0aGVuIHJ1biB5b3VyIGBnZXRfc3RvY2tfcHJpY2VgIHRvb2wgd2l0aCBge1widGlja2VyXCI6IFwiXkdTUENcIn1gIGFzIGFuXG4gICAqIGlucHV0LCBhbmQgcmV0dXJuIHRoZSBmb2xsb3dpbmcgYmFjayB0byB0aGUgbW9kZWwgaW4gYSBzdWJzZXF1ZW50IGB1c2VyYFxuICAgKiBtZXNzYWdlOlxuICAgKlxuICAgKiBgYGBqc29uXG4gICAqIFtcbiAgICogICB7XG4gICAqICAgICBcInR5cGVcIjogXCJ0b29sX3Jlc3VsdFwiLFxuICAgKiAgICAgXCJ0b29sX3VzZV9pZFwiOiBcInRvb2x1XzAxRDdGTHJmaDRHWXE3eVQxVUxGZXlNVlwiLFxuICAgKiAgICAgXCJjb250ZW50XCI6IFwiMjU5Ljc1IFVTRFwiXG4gICAqICAgfVxuICAgKiBdXG4gICAqIGBgYFxuICAgKlxuICAgKiBUb29scyBjYW4gYmUgdXNlZCBmb3Igd29ya2Zsb3dzIHRoYXQgaW5jbHVkZSBydW5uaW5nIGNsaWVudC1zaWRlIHRvb2xzIGFuZFxuICAgKiBmdW5jdGlvbnMsIG9yIG1vcmUgZ2VuZXJhbGx5IHdoZW5ldmVyIHlvdSB3YW50IHRoZSBtb2RlbCB0byBwcm9kdWNlIGEgcGFydGljdWxhclxuICAgKiBKU09OIHN0cnVjdHVyZSBvZiBvdXRwdXQuXG4gICAqXG4gICAqIFNlZSBvdXIgW2d1aWRlXShodHRwczovL2RvY3MuYW50aHJvcGljLmNvbS9lbi9kb2NzL3Rvb2wtdXNlKSBmb3IgbW9yZSBkZXRhaWxzLlxuICAgKi9cbiAgdG9vbHM/OiBBcnJheTxUb29sPjtcblxuICAvKipcbiAgICogT25seSBzYW1wbGUgZnJvbSB0aGUgdG9wIEsgb3B0aW9ucyBmb3IgZWFjaCBzdWJzZXF1ZW50IHRva2VuLlxuICAgKlxuICAgKiBVc2VkIHRvIHJlbW92ZSBcImxvbmcgdGFpbFwiIGxvdyBwcm9iYWJpbGl0eSByZXNwb25zZXMuXG4gICAqIFtMZWFybiBtb3JlIHRlY2huaWNhbCBkZXRhaWxzIGhlcmVdKGh0dHBzOi8vdG93YXJkc2RhdGFzY2llbmNlLmNvbS9ob3ctdG8tc2FtcGxlLWZyb20tbGFuZ3VhZ2UtbW9kZWxzLTY4MmJjZWI5NzI3NykuXG4gICAqXG4gICAqIFJlY29tbWVuZGVkIGZvciBhZHZhbmNlZCB1c2UgY2FzZXMgb25seS4gWW91IHVzdWFsbHkgb25seSBuZWVkIHRvIHVzZVxuICAgKiBgdGVtcGVyYXR1cmVgLlxuICAgKi9cbiAgdG9wX2s/OiBudW1iZXI7XG5cbiAgLyoqXG4gICAqIFVzZSBudWNsZXVzIHNhbXBsaW5nLlxuICAgKlxuICAgKiBJbiBudWNsZXVzIHNhbXBsaW5nLCB3ZSBjb21wdXRlIHRoZSBjdW11bGF0aXZlIGRpc3RyaWJ1dGlvbiBvdmVyIGFsbCB0aGUgb3B0aW9uc1xuICAgKiBmb3IgZWFjaCBzdWJzZXF1ZW50IHRva2VuIGluIGRlY3JlYXNpbmcgcHJvYmFiaWxpdHkgb3JkZXIgYW5kIGN1dCBpdCBvZmYgb25jZSBpdFxuICAgKiByZWFjaGVzIGEgcGFydGljdWxhciBwcm9iYWJpbGl0eSBzcGVjaWZpZWQgYnkgYHRvcF9wYC4gWW91IHNob3VsZCBlaXRoZXIgYWx0ZXJcbiAgICogYHRlbXBlcmF0dXJlYCBvciBgdG9wX3BgLCBidXQgbm90IGJvdGguXG4gICAqXG4gICAqIFJlY29tbWVuZGVkIGZvciBhZHZhbmNlZCB1c2UgY2FzZXMgb25seS4gWW91IHVzdWFsbHkgb25seSBuZWVkIHRvIHVzZVxuICAgKiBgdGVtcGVyYXR1cmVgLlxuICAgKi9cbiAgdG9wX3A/OiBudW1iZXI7XG59XG5cbmV4cG9ydCBuYW1lc3BhY2UgTWVzc2FnZUNyZWF0ZVBhcmFtcyB7XG4gIC8qKlxuICAgKiBBbiBvYmplY3QgZGVzY3JpYmluZyBtZXRhZGF0YSBhYm91dCB0aGUgcmVxdWVzdC5cbiAgICovXG4gIGV4cG9ydCBpbnRlcmZhY2UgTWV0YWRhdGEge1xuICAgIC8qKlxuICAgICAqIEFuIGV4dGVybmFsIGlkZW50aWZpZXIgZm9yIHRoZSB1c2VyIHdobyBpcyBhc3NvY2lhdGVkIHdpdGggdGhlIHJlcXVlc3QuXG4gICAgICpcbiAgICAgKiBUaGlzIHNob3VsZCBiZSBhIHV1aWQsIGhhc2ggdmFsdWUsIG9yIG90aGVyIG9wYXF1ZSBpZGVudGlmaWVyLiBBbnRocm9waWMgbWF5IHVzZVxuICAgICAqIHRoaXMgaWQgdG8gaGVscCBkZXRlY3QgYWJ1c2UuIERvIG5vdCBpbmNsdWRlIGFueSBpZGVudGlmeWluZyBpbmZvcm1hdGlvbiBzdWNoIGFzXG4gICAgICogbmFtZSwgZW1haWwgYWRkcmVzcywgb3IgcGhvbmUgbnVtYmVyLlxuICAgICAqL1xuICAgIHVzZXJfaWQ/OiBzdHJpbmcgfCBudWxsO1xuICB9XG5cbiAgLyoqXG4gICAqIFRoZSBtb2RlbCB3aWxsIGF1dG9tYXRpY2FsbHkgZGVjaWRlIHdoZXRoZXIgdG8gdXNlIHRvb2xzLlxuICAgKi9cbiAgZXhwb3J0IGludGVyZmFjZSBUb29sQ2hvaWNlQXV0byB7XG4gICAgdHlwZTogJ2F1dG8nO1xuXG4gICAgLyoqXG4gICAgICogV2hldGhlciB0byBkaXNhYmxlIHBhcmFsbGVsIHRvb2wgdXNlLlxuICAgICAqXG4gICAgICogRGVmYXVsdHMgdG8gYGZhbHNlYC4gSWYgc2V0IHRvIGB0cnVlYCwgdGhlIG1vZGVsIHdpbGwgb3V0cHV0IGF0IG1vc3Qgb25lIHRvb2xcbiAgICAgKiB1c2UuXG4gICAgICovXG4gICAgZGlzYWJsZV9wYXJhbGxlbF90b29sX3VzZT86IGJvb2xlYW47XG4gIH1cblxuICAvKipcbiAgICogVGhlIG1vZGVsIHdpbGwgdXNlIGFueSBhdmFpbGFibGUgdG9vbHMuXG4gICAqL1xuICBleHBvcnQgaW50ZXJmYWNlIFRvb2xDaG9pY2VBbnkge1xuICAgIHR5cGU6ICdhbnknO1xuXG4gICAgLyoqXG4gICAgICogV2hldGhlciB0byBkaXNhYmxlIHBhcmFsbGVsIHRvb2wgdXNlLlxuICAgICAqXG4gICAgICogRGVmYXVsdHMgdG8gYGZhbHNlYC4gSWYgc2V0IHRvIGB0cnVlYCwgdGhlIG1vZGVsIHdpbGwgb3V0cHV0IGV4YWN0bHkgb25lIHRvb2xcbiAgICAgKiB1c2UuXG4gICAgICovXG4gICAgZGlzYWJsZV9wYXJhbGxlbF90b29sX3VzZT86IGJvb2xlYW47XG4gIH1cblxuICAvKipcbiAgICogVGhlIG1vZGVsIHdpbGwgdXNlIHRoZSBzcGVjaWZpZWQgdG9vbCB3aXRoIGB0b29sX2Nob2ljZS5uYW1lYC5cbiAgICovXG4gIGV4cG9ydCBpbnRlcmZhY2UgVG9vbENob2ljZVRvb2wge1xuICAgIC8qKlxuICAgICAqIFRoZSBuYW1lIG9mIHRoZSB0b29sIHRvIHVzZS5cbiAgICAgKi9cbiAgICBuYW1lOiBzdHJpbmc7XG5cbiAgICB0eXBlOiAndG9vbCc7XG5cbiAgICAvKipcbiAgICAgKiBXaGV0aGVyIHRvIGRpc2FibGUgcGFyYWxsZWwgdG9vbCB1c2UuXG4gICAgICpcbiAgICAgKiBEZWZhdWx0cyB0byBgZmFsc2VgLiBJZiBzZXQgdG8gYHRydWVgLCB0aGUgbW9kZWwgd2lsbCBvdXRwdXQgZXhhY3RseSBvbmUgdG9vbFxuICAgICAqIHVzZS5cbiAgICAgKi9cbiAgICBkaXNhYmxlX3BhcmFsbGVsX3Rvb2xfdXNlPzogYm9vbGVhbjtcbiAgfVxuXG4gIGV4cG9ydCB0eXBlIE1lc3NhZ2VDcmVhdGVQYXJhbXNOb25TdHJlYW1pbmcgPSBNZXNzYWdlc0FQSS5NZXNzYWdlQ3JlYXRlUGFyYW1zTm9uU3RyZWFtaW5nO1xuICBleHBvcnQgdHlwZSBNZXNzYWdlQ3JlYXRlUGFyYW1zU3RyZWFtaW5nID0gTWVzc2FnZXNBUEkuTWVzc2FnZUNyZWF0ZVBhcmFtc1N0cmVhbWluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNZXNzYWdlQ3JlYXRlUGFyYW1zTm9uU3RyZWFtaW5nIGV4dGVuZHMgTWVzc2FnZUNyZWF0ZVBhcmFtc0Jhc2Uge1xuICAvKipcbiAgICogV2hldGhlciB0byBpbmNyZW1lbnRhbGx5IHN0cmVhbSB0aGUgcmVzcG9uc2UgdXNpbmcgc2VydmVyLXNlbnQgZXZlbnRzLlxuICAgKlxuICAgKiBTZWUgW3N0cmVhbWluZ10oaHR0cHM6Ly9kb2NzLmFudGhyb3BpYy5jb20vZW4vYXBpL21lc3NhZ2VzLXN0cmVhbWluZykgZm9yXG4gICAqIGRldGFpbHMuXG4gICAqL1xuICBzdHJlYW0/OiBmYWxzZTtcbn1cblxuZXhwb3J0IGludGVyZmFjZSBNZXNzYWdlQ3JlYXRlUGFyYW1zU3RyZWFtaW5nIGV4dGVuZHMgTWVzc2FnZUNyZWF0ZVBhcmFtc0Jhc2Uge1xuICAvKipcbiAgICogV2hldGhlciB0byBpbmNyZW1lbnRhbGx5IHN0cmVhbSB0aGUgcmVzcG9uc2UgdXNpbmcgc2VydmVyLXNlbnQgZXZlbnRzLlxuICAgKlxuICAgKiBTZWUgW3N0cmVhbWluZ10oaHR0cHM6Ly9kb2NzLmFudGhyb3BpYy5jb20vZW4vYXBpL21lc3NhZ2VzLXN0cmVhbWluZykgZm9yXG4gICAqIGRldGFpbHMuXG4gICAqL1xuICBzdHJlYW06IHRydWU7XG59XG5cbmV4cG9ydCB0eXBlIE1lc3NhZ2VTdHJlYW1QYXJhbXMgPSBNZXNzYWdlQ3JlYXRlUGFyYW1zQmFzZTtcblxuZXhwb3J0IG5hbWVzcGFjZSBNZXNzYWdlcyB7XG4gIGV4cG9ydCBpbXBvcnQgQ29udGVudEJsb2NrID0gTWVzc2FnZXNBUEkuQ29udGVudEJsb2NrO1xuICBleHBvcnQgaW1wb3J0IENvbnRlbnRCbG9ja0RlbHRhRXZlbnQgPSBNZXNzYWdlc0FQSS5Db250ZW50QmxvY2tEZWx0YUV2ZW50O1xuICBleHBvcnQgaW1wb3J0IENvbnRlbnRCbG9ja1N0YXJ0RXZlbnQgPSBNZXNzYWdlc0FQSS5Db250ZW50QmxvY2tTdGFydEV2ZW50O1xuICBleHBvcnQgaW1wb3J0IENvbnRlbnRCbG9ja1N0b3BFdmVudCA9IE1lc3NhZ2VzQVBJLkNvbnRlbnRCbG9ja1N0b3BFdmVudDtcbiAgZXhwb3J0IGltcG9ydCBJbWFnZUJsb2NrUGFyYW0gPSBNZXNzYWdlc0FQSS5JbWFnZUJsb2NrUGFyYW07XG4gIGV4cG9ydCBpbXBvcnQgSW5wdXRKSnNvbkRlbHRhID0gTWVzc2FnZXNBUEkuSW5wdXRKc29uRGVsdGE7XG4gIGV4cG9ydCBpbXBvcnQgSW5wdXRKU09ORGVsdGEgPSBNZXNzYWdlc0FQSS5JbnB1dEpTT05EZWx0YTtcbiAgZXhwb3J0IGltcG9ydCBNZXNzYWdlID0gTWVzc2FnZXNBUEkuTWVzc2FnZTtcbiAgZXhwb3J0IGltcG9ydCBNZXNzYWdlRGVsdGFFdmVudCA9IE1lc3NhZ2VzQVBJLk1lc3NhZ2VEZWx0YUV2ZW50O1xuICBleHBvcnQgaW1wb3J0IE1lc3NhZ2VEZWx0YVVzYWdlID0gTWVzc2FnZXNBUEkuTWVzc2FnZURlbHRhVXNhZ2U7XG4gIGV4cG9ydCBpbXBvcnQgTWVzc2FnZVBhcmFtID0gTWVzc2FnZXNBUEkuTWVzc2FnZVBhcmFtO1xuICBleHBvcnQgaW1wb3J0IE1lc3NhZ2VTdGFydEV2ZW50ID0gTWVzc2FnZXNBUEkuTWVzc2FnZVN0YXJ0RXZlbnQ7XG4gIGV4cG9ydCBpbXBvcnQgTWVzc2FnZVN0b3BFdmVudCA9IE1lc3NhZ2VzQVBJLk1lc3NhZ2VTdG9wRXZlbnQ7XG4gIGV4cG9ydCBpbXBvcnQgTWVzc2FnZVN0cmVhbUV2ZW50ID0gTWVzc2FnZXNBUEkuTWVzc2FnZVN0cmVhbUV2ZW50O1xuICBleHBvcnQgaW1wb3J0IE1vZGVsID0gTWVzc2FnZXNBUEkuTW9kZWw7XG4gIGV4cG9ydCBpbXBvcnQgUmF3Q29udGVudEJsb2NrRGVsdGFFdmVudCA9IE1lc3NhZ2VzQVBJLlJhd0NvbnRlbnRCbG9ja0RlbHRhRXZlbnQ7XG4gIGV4cG9ydCBpbXBvcnQgUmF3Q29udGVudEJsb2NrU3RhcnRFdmVudCA9IE1lc3NhZ2VzQVBJLlJhd0NvbnRlbnRCbG9ja1N0YXJ0RXZlbnQ7XG4gIGV4cG9ydCBpbXBvcnQgUmF3Q29udGVudEJsb2NrU3RvcEV2ZW50ID0gTWVzc2FnZXNBUEkuUmF3Q29udGVudEJsb2NrU3RvcEV2ZW50O1xuICBleHBvcnQgaW1wb3J0IFJhd01lc3NhZ2VEZWx0YUV2ZW50ID0gTWVzc2FnZXNBUEkuUmF3TWVzc2FnZURlbHRhRXZlbnQ7XG4gIGV4cG9ydCBpbXBvcnQgUmF3TWVzc2FnZVN0YXJ0RXZlbnQgPSBNZXNzYWdlc0FQSS5SYXdNZXNzYWdlU3RhcnRFdmVudDtcbiAgZXhwb3J0IGltcG9ydCBSYXdNZXNzYWdlU3RvcEV2ZW50ID0gTWVzc2FnZXNBUEkuUmF3TWVzc2FnZVN0b3BFdmVudDtcbiAgZXhwb3J0IGltcG9ydCBSYXdNZXNzYWdlU3RyZWFtRXZlbnQgPSBNZXNzYWdlc0FQSS5SYXdNZXNzYWdlU3RyZWFtRXZlbnQ7XG4gIGV4cG9ydCBpbXBvcnQgVGV4dEJsb2NrID0gTWVzc2FnZXNBUEkuVGV4dEJsb2NrO1xuICBleHBvcnQgaW1wb3J0IFRleHRCbG9ja1BhcmFtID0gTWVzc2FnZXNBUEkuVGV4dEJsb2NrUGFyYW07XG4gIGV4cG9ydCBpbXBvcnQgVGV4dERlbHRhID0gTWVzc2FnZXNBUEkuVGV4dERlbHRhO1xuICBleHBvcnQgaW1wb3J0IFRvb2wgPSBNZXNzYWdlc0FQSS5Ub29sO1xuICBleHBvcnQgaW1wb3J0IFRvb2xSZXN1bHRCbG9ja1BhcmFtID0gTWVzc2FnZXNBUEkuVG9vbFJlc3VsdEJsb2NrUGFyYW07XG4gIGV4cG9ydCBpbXBvcnQgVG9vbFVzZUJsb2NrID0gTWVzc2FnZXNBUEkuVG9vbFVzZUJsb2NrO1xuICBleHBvcnQgaW1wb3J0IFRvb2xVc2VCbG9ja1BhcmFtID0gTWVzc2FnZXNBUEkuVG9vbFVzZUJsb2NrUGFyYW07XG4gIGV4cG9ydCBpbXBvcnQgVXNhZ2UgPSBNZXNzYWdlc0FQSS5Vc2FnZTtcbiAgZXhwb3J0IGltcG9ydCBNZXNzYWdlQ3JlYXRlUGFyYW1zID0gTWVzc2FnZXNBUEkuTWVzc2FnZUNyZWF0ZVBhcmFtcztcbiAgZXhwb3J0IGltcG9ydCBNZXNzYWdlQ3JlYXRlUGFyYW1zTm9uU3RyZWFtaW5nID0gTWVzc2FnZXNBUEkuTWVzc2FnZUNyZWF0ZVBhcmFtc05vblN0cmVhbWluZztcbiAgZXhwb3J0IGltcG9ydCBNZXNzYWdlQ3JlYXRlUGFyYW1zU3RyZWFtaW5nID0gTWVzc2FnZXNBUEkuTWVzc2FnZUNyZWF0ZVBhcmFtc1N0cmVhbWluZztcbiAgZXhwb3J0IGltcG9ydCBNZXNzYWdlU3RyZWFtUGFyYW1zID0gTWVzc2FnZXNBUEkuTWVzc2FnZVN0cmVhbVBhcmFtcztcbn1cbiIsICIvLyBGaWxlIGdlbmVyYXRlZCBmcm9tIG91ciBPcGVuQVBJIHNwZWMgYnkgU3RhaW5sZXNzLiBTZWUgQ09OVFJJQlVUSU5HLm1kIGZvciBkZXRhaWxzLlxuXG5pbXBvcnQgKiBhcyBFcnJvcnMgZnJvbSBcIi4vZXJyb3IuanNcIjtcbmltcG9ydCAqIGFzIFVwbG9hZHMgZnJvbSBcIi4vdXBsb2Fkcy5qc1wiO1xuaW1wb3J0IHsgdHlwZSBBZ2VudCB9IGZyb20gXCIuL19zaGltcy9pbmRleC5qc1wiO1xuaW1wb3J0ICogYXMgQ29yZSBmcm9tIFwiLi9jb3JlLmpzXCI7XG5pbXBvcnQgKiBhcyBBUEkgZnJvbSBcIi4vcmVzb3VyY2VzL2luZGV4LmpzXCI7XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ2xpZW50T3B0aW9ucyB7XG4gIC8qKlxuICAgKiBEZWZhdWx0cyB0byBwcm9jZXNzLmVudlsnQU5USFJPUElDX0FQSV9LRVknXS5cbiAgICovXG4gIGFwaUtleT86IHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQ7XG5cbiAgLyoqXG4gICAqIERlZmF1bHRzIHRvIHByb2Nlc3MuZW52WydBTlRIUk9QSUNfQVVUSF9UT0tFTiddLlxuICAgKi9cbiAgYXV0aFRva2VuPzogc3RyaW5nIHwgbnVsbCB8IHVuZGVmaW5lZDtcblxuICAvKipcbiAgICogT3ZlcnJpZGUgdGhlIGRlZmF1bHQgYmFzZSBVUkwgZm9yIHRoZSBBUEksIGUuZy4sIFwiaHR0cHM6Ly9hcGkuZXhhbXBsZS5jb20vdjIvXCJcbiAgICpcbiAgICogRGVmYXVsdHMgdG8gcHJvY2Vzcy5lbnZbJ0FOVEhST1BJQ19CQVNFX1VSTCddLlxuICAgKi9cbiAgYmFzZVVSTD86IHN0cmluZyB8IG51bGwgfCB1bmRlZmluZWQ7XG5cbiAgLyoqXG4gICAqIFRoZSBtYXhpbXVtIGFtb3VudCBvZiB0aW1lIChpbiBtaWxsaXNlY29uZHMpIHRoYXQgdGhlIGNsaWVudCBzaG91bGQgd2FpdCBmb3IgYSByZXNwb25zZVxuICAgKiBmcm9tIHRoZSBzZXJ2ZXIgYmVmb3JlIHRpbWluZyBvdXQgYSBzaW5nbGUgcmVxdWVzdC5cbiAgICpcbiAgICogTm90ZSB0aGF0IHJlcXVlc3QgdGltZW91dHMgYXJlIHJldHJpZWQgYnkgZGVmYXVsdCwgc28gaW4gYSB3b3JzdC1jYXNlIHNjZW5hcmlvIHlvdSBtYXkgd2FpdFxuICAgKiBtdWNoIGxvbmdlciB0aGFuIHRoaXMgdGltZW91dCBiZWZvcmUgdGhlIHByb21pc2Ugc3VjY2VlZHMgb3IgZmFpbHMuXG4gICAqL1xuICB0aW1lb3V0PzogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBBbiBIVFRQIGFnZW50IHVzZWQgdG8gbWFuYWdlIEhUVFAoUykgY29ubmVjdGlvbnMuXG4gICAqXG4gICAqIElmIG5vdCBwcm92aWRlZCwgYW4gYWdlbnQgd2lsbCBiZSBjb25zdHJ1Y3RlZCBieSBkZWZhdWx0IGluIHRoZSBOb2RlLmpzIGVudmlyb25tZW50LFxuICAgKiBvdGhlcndpc2Ugbm8gYWdlbnQgaXMgdXNlZC5cbiAgICovXG4gIGh0dHBBZ2VudD86IEFnZW50O1xuXG4gIC8qKlxuICAgKiBTcGVjaWZ5IGEgY3VzdG9tIGBmZXRjaGAgZnVuY3Rpb24gaW1wbGVtZW50YXRpb24uXG4gICAqXG4gICAqIElmIG5vdCBwcm92aWRlZCwgd2UgdXNlIGBub2RlLWZldGNoYCBvbiBOb2RlLmpzIGFuZCBvdGhlcndpc2UgZXhwZWN0IHRoYXQgYGZldGNoYCBpc1xuICAgKiBkZWZpbmVkIGdsb2JhbGx5LlxuICAgKi9cbiAgZmV0Y2g/OiBDb3JlLkZldGNoIHwgdW5kZWZpbmVkO1xuXG4gIC8qKlxuICAgKiBUaGUgbWF4aW11bSBudW1iZXIgb2YgdGltZXMgdGhhdCB0aGUgY2xpZW50IHdpbGwgcmV0cnkgYSByZXF1ZXN0IGluIGNhc2Ugb2YgYVxuICAgKiB0ZW1wb3JhcnkgZmFpbHVyZSwgbGlrZSBhIG5ldHdvcmsgZXJyb3Igb3IgYSA1WFggZXJyb3IgZnJvbSB0aGUgc2VydmVyLlxuICAgKlxuICAgKiBAZGVmYXVsdCAyXG4gICAqL1xuICBtYXhSZXRyaWVzPzogbnVtYmVyO1xuXG4gIC8qKlxuICAgKiBEZWZhdWx0IGhlYWRlcnMgdG8gaW5jbHVkZSB3aXRoIGV2ZXJ5IHJlcXVlc3QgdG8gdGhlIEFQSS5cbiAgICpcbiAgICogVGhlc2UgY2FuIGJlIHJlbW92ZWQgaW4gaW5kaXZpZHVhbCByZXF1ZXN0cyBieSBleHBsaWNpdGx5IHNldHRpbmcgdGhlXG4gICAqIGhlYWRlciB0byBgdW5kZWZpbmVkYCBvciBgbnVsbGAgaW4gcmVxdWVzdCBvcHRpb25zLlxuICAgKi9cbiAgZGVmYXVsdEhlYWRlcnM/OiBDb3JlLkhlYWRlcnM7XG5cbiAgLyoqXG4gICAqIERlZmF1bHQgcXVlcnkgcGFyYW1ldGVycyB0byBpbmNsdWRlIHdpdGggZXZlcnkgcmVxdWVzdCB0byB0aGUgQVBJLlxuICAgKlxuICAgKiBUaGVzZSBjYW4gYmUgcmVtb3ZlZCBpbiBpbmRpdmlkdWFsIHJlcXVlc3RzIGJ5IGV4cGxpY2l0bHkgc2V0dGluZyB0aGVcbiAgICogcGFyYW0gdG8gYHVuZGVmaW5lZGAgaW4gcmVxdWVzdCBvcHRpb25zLlxuICAgKi9cbiAgZGVmYXVsdFF1ZXJ5PzogQ29yZS5EZWZhdWx0UXVlcnk7XG5cbiAgLyoqXG4gICAqIEJ5IGRlZmF1bHQsIGNsaWVudC1zaWRlIHVzZSBvZiB0aGlzIGxpYnJhcnkgaXMgbm90IGFsbG93ZWQsIGFzIGl0IHJpc2tzIGV4cG9zaW5nIHlvdXIgc2VjcmV0IEFQSSBjcmVkZW50aWFscyB0byBhdHRhY2tlcnMuXG4gICAqIE9ubHkgc2V0IHRoaXMgb3B0aW9uIHRvIGB0cnVlYCBpZiB5b3UgdW5kZXJzdGFuZCB0aGUgcmlza3MgYW5kIGhhdmUgYXBwcm9wcmlhdGUgbWl0aWdhdGlvbnMgaW4gcGxhY2UuXG4gICAqL1xuICBkYW5nZXJvdXNseUFsbG93QnJvd3Nlcj86IGJvb2xlYW47XG59XG5cbi8qKlxuICogQVBJIENsaWVudCBmb3IgaW50ZXJmYWNpbmcgd2l0aCB0aGUgQW50aHJvcGljIEFQSS5cbiAqL1xuZXhwb3J0IGNsYXNzIEFudGhyb3BpYyBleHRlbmRzIENvcmUuQVBJQ2xpZW50IHtcbiAgYXBpS2V5OiBzdHJpbmcgfCBudWxsO1xuICBhdXRoVG9rZW46IHN0cmluZyB8IG51bGw7XG5cbiAgcHJpdmF0ZSBfb3B0aW9uczogQ2xpZW50T3B0aW9ucztcblxuICAvKipcbiAgICogQVBJIENsaWVudCBmb3IgaW50ZXJmYWNpbmcgd2l0aCB0aGUgQW50aHJvcGljIEFQSS5cbiAgICpcbiAgICogQHBhcmFtIHtzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkfSBbb3B0cy5hcGlLZXk9cHJvY2Vzcy5lbnZbJ0FOVEhST1BJQ19BUElfS0VZJ10gPz8gbnVsbF1cbiAgICogQHBhcmFtIHtzdHJpbmcgfCBudWxsIHwgdW5kZWZpbmVkfSBbb3B0cy5hdXRoVG9rZW49cHJvY2Vzcy5lbnZbJ0FOVEhST1BJQ19BVVRIX1RPS0VOJ10gPz8gbnVsbF1cbiAgICogQHBhcmFtIHtzdHJpbmd9IFtvcHRzLmJhc2VVUkw9cHJvY2Vzcy5lbnZbJ0FOVEhST1BJQ19CQVNFX1VSTCddID8/IGh0dHBzOi8vYXBpLmFudGhyb3BpYy5jb21dIC0gT3ZlcnJpZGUgdGhlIGRlZmF1bHQgYmFzZSBVUkwgZm9yIHRoZSBBUEkuXG4gICAqIEBwYXJhbSB7bnVtYmVyfSBbb3B0cy50aW1lb3V0PTEwIG1pbnV0ZXNdIC0gVGhlIG1heGltdW0gYW1vdW50IG9mIHRpbWUgKGluIG1pbGxpc2Vjb25kcykgdGhlIGNsaWVudCB3aWxsIHdhaXQgZm9yIGEgcmVzcG9uc2UgYmVmb3JlIHRpbWluZyBvdXQuXG4gICAqIEBwYXJhbSB7bnVtYmVyfSBbb3B0cy5odHRwQWdlbnRdIC0gQW4gSFRUUCBhZ2VudCB1c2VkIHRvIG1hbmFnZSBIVFRQKHMpIGNvbm5lY3Rpb25zLlxuICAgKiBAcGFyYW0ge0NvcmUuRmV0Y2h9IFtvcHRzLmZldGNoXSAtIFNwZWNpZnkgYSBjdXN0b20gYGZldGNoYCBmdW5jdGlvbiBpbXBsZW1lbnRhdGlvbi5cbiAgICogQHBhcmFtIHtudW1iZXJ9IFtvcHRzLm1heFJldHJpZXM9Ml0gLSBUaGUgbWF4aW11bSBudW1iZXIgb2YgdGltZXMgdGhlIGNsaWVudCB3aWxsIHJldHJ5IGEgcmVxdWVzdC5cbiAgICogQHBhcmFtIHtDb3JlLkhlYWRlcnN9IG9wdHMuZGVmYXVsdEhlYWRlcnMgLSBEZWZhdWx0IGhlYWRlcnMgdG8gaW5jbHVkZSB3aXRoIGV2ZXJ5IHJlcXVlc3QgdG8gdGhlIEFQSS5cbiAgICogQHBhcmFtIHtDb3JlLkRlZmF1bHRRdWVyeX0gb3B0cy5kZWZhdWx0UXVlcnkgLSBEZWZhdWx0IHF1ZXJ5IHBhcmFtZXRlcnMgdG8gaW5jbHVkZSB3aXRoIGV2ZXJ5IHJlcXVlc3QgdG8gdGhlIEFQSS5cbiAgICogQHBhcmFtIHtib29sZWFufSBbb3B0cy5kYW5nZXJvdXNseUFsbG93QnJvd3Nlcj1mYWxzZV0gLSBCeSBkZWZhdWx0LCBjbGllbnQtc2lkZSB1c2Ugb2YgdGhpcyBsaWJyYXJ5IGlzIG5vdCBhbGxvd2VkLCBhcyBpdCByaXNrcyBleHBvc2luZyB5b3VyIHNlY3JldCBBUEkgY3JlZGVudGlhbHMgdG8gYXR0YWNrZXJzLlxuICAgKi9cbiAgY29uc3RydWN0b3Ioe1xuICAgIGJhc2VVUkwgPSBDb3JlLnJlYWRFbnYoJ0FOVEhST1BJQ19CQVNFX1VSTCcpLFxuICAgIGFwaUtleSA9IENvcmUucmVhZEVudignQU5USFJPUElDX0FQSV9LRVknKSA/PyBudWxsLFxuICAgIGF1dGhUb2tlbiA9IENvcmUucmVhZEVudignQU5USFJPUElDX0FVVEhfVE9LRU4nKSA/PyBudWxsLFxuICAgIC4uLm9wdHNcbiAgfTogQ2xpZW50T3B0aW9ucyA9IHt9KSB7XG4gICAgY29uc3Qgb3B0aW9uczogQ2xpZW50T3B0aW9ucyA9IHtcbiAgICAgIGFwaUtleSxcbiAgICAgIGF1dGhUb2tlbixcbiAgICAgIC4uLm9wdHMsXG4gICAgICBiYXNlVVJMOiBiYXNlVVJMIHx8IGBodHRwczovL2FwaS5hbnRocm9waWMuY29tYCxcbiAgICB9O1xuXG4gICAgaWYgKCFvcHRpb25zLmRhbmdlcm91c2x5QWxsb3dCcm93c2VyICYmIENvcmUuaXNSdW5uaW5nSW5Ccm93c2VyKCkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcnMuQW50aHJvcGljRXJyb3IoXG4gICAgICAgIFwiSXQgbG9va3MgbGlrZSB5b3UncmUgcnVubmluZyBpbiBhIGJyb3dzZXItbGlrZSBlbnZpcm9ubWVudC5cXG5cXG5UaGlzIGlzIGRpc2FibGVkIGJ5IGRlZmF1bHQsIGFzIGl0IHJpc2tzIGV4cG9zaW5nIHlvdXIgc2VjcmV0IEFQSSBjcmVkZW50aWFscyB0byBhdHRhY2tlcnMuXFxuSWYgeW91IHVuZGVyc3RhbmQgdGhlIHJpc2tzIGFuZCBoYXZlIGFwcHJvcHJpYXRlIG1pdGlnYXRpb25zIGluIHBsYWNlLFxcbnlvdSBjYW4gc2V0IHRoZSBgZGFuZ2Vyb3VzbHlBbGxvd0Jyb3dzZXJgIG9wdGlvbiB0byBgdHJ1ZWAsIGUuZy4sXFxuXFxubmV3IEFudGhyb3BpYyh7IGFwaUtleSwgZGFuZ2Vyb3VzbHlBbGxvd0Jyb3dzZXI6IHRydWUgfSk7XFxuXFxuVE9ETzogbGluayFcXG5cIixcbiAgICAgICk7XG4gICAgfVxuXG4gICAgc3VwZXIoe1xuICAgICAgYmFzZVVSTDogb3B0aW9ucy5iYXNlVVJMISxcbiAgICAgIHRpbWVvdXQ6IG9wdGlvbnMudGltZW91dCA/PyA2MDAwMDAgLyogMTAgbWludXRlcyAqLyxcbiAgICAgIGh0dHBBZ2VudDogb3B0aW9ucy5odHRwQWdlbnQsXG4gICAgICBtYXhSZXRyaWVzOiBvcHRpb25zLm1heFJldHJpZXMsXG4gICAgICBmZXRjaDogb3B0aW9ucy5mZXRjaCxcbiAgICB9KTtcblxuICAgIHRoaXMuX29wdGlvbnMgPSBvcHRpb25zO1xuXG4gICAgdGhpcy5hcGlLZXkgPSBhcGlLZXk7XG4gICAgdGhpcy5hdXRoVG9rZW4gPSBhdXRoVG9rZW47XG4gIH1cblxuICBjb21wbGV0aW9uczogQVBJLkNvbXBsZXRpb25zID0gbmV3IEFQSS5Db21wbGV0aW9ucyh0aGlzKTtcbiAgbWVzc2FnZXM6IEFQSS5NZXNzYWdlcyA9IG5ldyBBUEkuTWVzc2FnZXModGhpcyk7XG4gIGJldGE6IEFQSS5CZXRhID0gbmV3IEFQSS5CZXRhKHRoaXMpO1xuXG4gIHByb3RlY3RlZCBvdmVycmlkZSBkZWZhdWx0UXVlcnkoKTogQ29yZS5EZWZhdWx0UXVlcnkgfCB1bmRlZmluZWQge1xuICAgIHJldHVybiB0aGlzLl9vcHRpb25zLmRlZmF1bHRRdWVyeTtcbiAgfVxuXG4gIHByb3RlY3RlZCBvdmVycmlkZSBkZWZhdWx0SGVhZGVycyhvcHRzOiBDb3JlLkZpbmFsUmVxdWVzdE9wdGlvbnMpOiBDb3JlLkhlYWRlcnMge1xuICAgIHJldHVybiB7XG4gICAgICAuLi5zdXBlci5kZWZhdWx0SGVhZGVycyhvcHRzKSxcbiAgICAgIC4uLih0aGlzLl9vcHRpb25zLmRhbmdlcm91c2x5QWxsb3dCcm93c2VyID9cbiAgICAgICAgeyAnYW50aHJvcGljLWRhbmdlcm91cy1kaXJlY3QtYnJvd3Nlci1hY2Nlc3MnOiAndHJ1ZScgfVxuICAgICAgOiB1bmRlZmluZWQpLFxuICAgICAgJ2FudGhyb3BpYy12ZXJzaW9uJzogJzIwMjMtMDYtMDEnLFxuICAgICAgLi4udGhpcy5fb3B0aW9ucy5kZWZhdWx0SGVhZGVycyxcbiAgICB9O1xuICB9XG5cbiAgcHJvdGVjdGVkIG92ZXJyaWRlIHZhbGlkYXRlSGVhZGVycyhoZWFkZXJzOiBDb3JlLkhlYWRlcnMsIGN1c3RvbUhlYWRlcnM6IENvcmUuSGVhZGVycykge1xuICAgIGlmICh0aGlzLmFwaUtleSAmJiBoZWFkZXJzWyd4LWFwaS1rZXknXSkge1xuICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBpZiAoY3VzdG9tSGVhZGVyc1sneC1hcGkta2V5J10gPT09IG51bGwpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICBpZiAodGhpcy5hdXRoVG9rZW4gJiYgaGVhZGVyc1snYXV0aG9yaXphdGlvbiddKSB7XG4gICAgICByZXR1cm47XG4gICAgfVxuICAgIGlmIChjdXN0b21IZWFkZXJzWydhdXRob3JpemF0aW9uJ10gPT09IG51bGwpIHtcbiAgICAgIHJldHVybjtcbiAgICB9XG5cbiAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAnQ291bGQgbm90IHJlc29sdmUgYXV0aGVudGljYXRpb24gbWV0aG9kLiBFeHBlY3RlZCBlaXRoZXIgYXBpS2V5IG9yIGF1dGhUb2tlbiB0byBiZSBzZXQuIE9yIGZvciBvbmUgb2YgdGhlIFwiWC1BcGktS2V5XCIgb3IgXCJBdXRob3JpemF0aW9uXCIgaGVhZGVycyB0byBiZSBleHBsaWNpdGx5IG9taXR0ZWQnLFxuICAgICk7XG4gIH1cblxuICBwcm90ZWN0ZWQgb3ZlcnJpZGUgYXV0aEhlYWRlcnMob3B0czogQ29yZS5GaW5hbFJlcXVlc3RPcHRpb25zKTogQ29yZS5IZWFkZXJzIHtcbiAgICBjb25zdCBhcGlLZXlBdXRoID0gdGhpcy5hcGlLZXlBdXRoKG9wdHMpO1xuICAgIGNvbnN0IGJlYXJlckF1dGggPSB0aGlzLmJlYXJlckF1dGgob3B0cyk7XG5cbiAgICBpZiAoYXBpS2V5QXV0aCAhPSBudWxsICYmICFDb3JlLmlzRW1wdHlPYmooYXBpS2V5QXV0aCkpIHtcbiAgICAgIHJldHVybiBhcGlLZXlBdXRoO1xuICAgIH1cblxuICAgIGlmIChiZWFyZXJBdXRoICE9IG51bGwgJiYgIUNvcmUuaXNFbXB0eU9iaihiZWFyZXJBdXRoKSkge1xuICAgICAgcmV0dXJuIGJlYXJlckF1dGg7XG4gICAgfVxuICAgIHJldHVybiB7fTtcbiAgfVxuXG4gIHByb3RlY3RlZCBhcGlLZXlBdXRoKG9wdHM6IENvcmUuRmluYWxSZXF1ZXN0T3B0aW9ucyk6IENvcmUuSGVhZGVycyB7XG4gICAgaWYgKHRoaXMuYXBpS2V5ID09IG51bGwpIHtcbiAgICAgIHJldHVybiB7fTtcbiAgICB9XG4gICAgcmV0dXJuIHsgJ1gtQXBpLUtleSc6IHRoaXMuYXBpS2V5IH07XG4gIH1cblxuICBwcm90ZWN0ZWQgYmVhcmVyQXV0aChvcHRzOiBDb3JlLkZpbmFsUmVxdWVzdE9wdGlvbnMpOiBDb3JlLkhlYWRlcnMge1xuICAgIGlmICh0aGlzLmF1dGhUb2tlbiA9PSBudWxsKSB7XG4gICAgICByZXR1cm4ge307XG4gICAgfVxuICAgIHJldHVybiB7IEF1dGhvcml6YXRpb246IGBCZWFyZXIgJHt0aGlzLmF1dGhUb2tlbn1gIH07XG4gIH1cblxuICBzdGF0aWMgQW50aHJvcGljID0gdGhpcztcbiAgc3RhdGljIEhVTUFOX1BST01QVCA9ICdcXG5cXG5IdW1hbjonO1xuICBzdGF0aWMgQUlfUFJPTVBUID0gJ1xcblxcbkFzc2lzdGFudDonO1xuICBzdGF0aWMgREVGQVVMVF9USU1FT1VUID0gNjAwMDAwOyAvLyAxMCBtaW51dGVzXG5cbiAgc3RhdGljIEFudGhyb3BpY0Vycm9yID0gRXJyb3JzLkFudGhyb3BpY0Vycm9yO1xuICBzdGF0aWMgQVBJRXJyb3IgPSBFcnJvcnMuQVBJRXJyb3I7XG4gIHN0YXRpYyBBUElDb25uZWN0aW9uRXJyb3IgPSBFcnJvcnMuQVBJQ29ubmVjdGlvbkVycm9yO1xuICBzdGF0aWMgQVBJQ29ubmVjdGlvblRpbWVvdXRFcnJvciA9IEVycm9ycy5BUElDb25uZWN0aW9uVGltZW91dEVycm9yO1xuICBzdGF0aWMgQVBJVXNlckFib3J0RXJyb3IgPSBFcnJvcnMuQVBJVXNlckFib3J0RXJyb3I7XG4gIHN0YXRpYyBOb3RGb3VuZEVycm9yID0gRXJyb3JzLk5vdEZvdW5kRXJyb3I7XG4gIHN0YXRpYyBDb25mbGljdEVycm9yID0gRXJyb3JzLkNvbmZsaWN0RXJyb3I7XG4gIHN0YXRpYyBSYXRlTGltaXRFcnJvciA9IEVycm9ycy5SYXRlTGltaXRFcnJvcjtcbiAgc3RhdGljIEJhZFJlcXVlc3RFcnJvciA9IEVycm9ycy5CYWRSZXF1ZXN0RXJyb3I7XG4gIHN0YXRpYyBBdXRoZW50aWNhdGlvbkVycm9yID0gRXJyb3JzLkF1dGhlbnRpY2F0aW9uRXJyb3I7XG4gIHN0YXRpYyBJbnRlcm5hbFNlcnZlckVycm9yID0gRXJyb3JzLkludGVybmFsU2VydmVyRXJyb3I7XG4gIHN0YXRpYyBQZXJtaXNzaW9uRGVuaWVkRXJyb3IgPSBFcnJvcnMuUGVybWlzc2lvbkRlbmllZEVycm9yO1xuICBzdGF0aWMgVW5wcm9jZXNzYWJsZUVudGl0eUVycm9yID0gRXJyb3JzLlVucHJvY2Vzc2FibGVFbnRpdHlFcnJvcjtcblxuICBzdGF0aWMgdG9GaWxlID0gVXBsb2Fkcy50b0ZpbGU7XG4gIHN0YXRpYyBmaWxlRnJvbVBhdGggPSBVcGxvYWRzLmZpbGVGcm9tUGF0aDtcbn1cblxuZXhwb3J0IGNvbnN0IHsgSFVNQU5fUFJPTVBULCBBSV9QUk9NUFQgfSA9IEFudGhyb3BpYztcblxuZXhwb3J0IGNvbnN0IHtcbiAgQW50aHJvcGljRXJyb3IsXG4gIEFQSUVycm9yLFxuICBBUElDb25uZWN0aW9uRXJyb3IsXG4gIEFQSUNvbm5lY3Rpb25UaW1lb3V0RXJyb3IsXG4gIEFQSVVzZXJBYm9ydEVycm9yLFxuICBOb3RGb3VuZEVycm9yLFxuICBDb25mbGljdEVycm9yLFxuICBSYXRlTGltaXRFcnJvcixcbiAgQmFkUmVxdWVzdEVycm9yLFxuICBBdXRoZW50aWNhdGlvbkVycm9yLFxuICBJbnRlcm5hbFNlcnZlckVycm9yLFxuICBQZXJtaXNzaW9uRGVuaWVkRXJyb3IsXG4gIFVucHJvY2Vzc2FibGVFbnRpdHlFcnJvcixcbn0gPSBFcnJvcnM7XG5cbmV4cG9ydCBpbXBvcnQgdG9GaWxlID0gVXBsb2Fkcy50b0ZpbGU7XG5leHBvcnQgaW1wb3J0IGZpbGVGcm9tUGF0aCA9IFVwbG9hZHMuZmlsZUZyb21QYXRoO1xuXG5leHBvcnQgbmFtZXNwYWNlIEFudGhyb3BpYyB7XG4gIGV4cG9ydCBpbXBvcnQgUmVxdWVzdE9wdGlvbnMgPSBDb3JlLlJlcXVlc3RPcHRpb25zO1xuXG4gIGV4cG9ydCBpbXBvcnQgQ29tcGxldGlvbnMgPSBBUEkuQ29tcGxldGlvbnM7XG4gIGV4cG9ydCBpbXBvcnQgQ29tcGxldGlvbiA9IEFQSS5Db21wbGV0aW9uO1xuICBleHBvcnQgaW1wb3J0IENvbXBsZXRpb25DcmVhdGVQYXJhbXMgPSBBUEkuQ29tcGxldGlvbkNyZWF0ZVBhcmFtcztcbiAgZXhwb3J0IGltcG9ydCBDb21wbGV0aW9uQ3JlYXRlUGFyYW1zTm9uU3RyZWFtaW5nID0gQVBJLkNvbXBsZXRpb25DcmVhdGVQYXJhbXNOb25TdHJlYW1pbmc7XG4gIGV4cG9ydCBpbXBvcnQgQ29tcGxldGlvbkNyZWF0ZVBhcmFtc1N0cmVhbWluZyA9IEFQSS5Db21wbGV0aW9uQ3JlYXRlUGFyYW1zU3RyZWFtaW5nO1xuXG4gIGV4cG9ydCBpbXBvcnQgTWVzc2FnZXMgPSBBUEkuTWVzc2FnZXM7XG4gIGV4cG9ydCBpbXBvcnQgQ29udGVudEJsb2NrID0gQVBJLkNvbnRlbnRCbG9jaztcbiAgZXhwb3J0IGltcG9ydCBDb250ZW50QmxvY2tEZWx0YUV2ZW50ID0gQVBJLkNvbnRlbnRCbG9ja0RlbHRhRXZlbnQ7XG4gIGV4cG9ydCBpbXBvcnQgQ29udGVudEJsb2NrU3RhcnRFdmVudCA9IEFQSS5Db250ZW50QmxvY2tTdGFydEV2ZW50O1xuICBleHBvcnQgaW1wb3J0IENvbnRlbnRCbG9ja1N0b3BFdmVudCA9IEFQSS5Db250ZW50QmxvY2tTdG9wRXZlbnQ7XG4gIGV4cG9ydCBpbXBvcnQgSW1hZ2VCbG9ja1BhcmFtID0gQVBJLkltYWdlQmxvY2tQYXJhbTtcbiAgZXhwb3J0IGltcG9ydCBJbnB1dEpTT05EZWx0YSA9IEFQSS5JbnB1dEpTT05EZWx0YTtcbiAgZXhwb3J0IGltcG9ydCBNZXNzYWdlID0gQVBJLk1lc3NhZ2U7XG4gIGV4cG9ydCBpbXBvcnQgTWVzc2FnZURlbHRhRXZlbnQgPSBBUEkuTWVzc2FnZURlbHRhRXZlbnQ7XG4gIGV4cG9ydCBpbXBvcnQgTWVzc2FnZURlbHRhVXNhZ2UgPSBBUEkuTWVzc2FnZURlbHRhVXNhZ2U7XG4gIGV4cG9ydCBpbXBvcnQgTWVzc2FnZVBhcmFtID0gQVBJLk1lc3NhZ2VQYXJhbTtcbiAgZXhwb3J0IGltcG9ydCBNZXNzYWdlU3RhcnRFdmVudCA9IEFQSS5NZXNzYWdlU3RhcnRFdmVudDtcbiAgZXhwb3J0IGltcG9ydCBNZXNzYWdlU3RvcEV2ZW50ID0gQVBJLk1lc3NhZ2VTdG9wRXZlbnQ7XG4gIGV4cG9ydCBpbXBvcnQgTWVzc2FnZVN0cmVhbUV2ZW50ID0gQVBJLk1lc3NhZ2VTdHJlYW1FdmVudDtcbiAgZXhwb3J0IGltcG9ydCBNb2RlbCA9IEFQSS5Nb2RlbDtcbiAgZXhwb3J0IGltcG9ydCBSYXdDb250ZW50QmxvY2tEZWx0YUV2ZW50ID0gQVBJLlJhd0NvbnRlbnRCbG9ja0RlbHRhRXZlbnQ7XG4gIGV4cG9ydCBpbXBvcnQgUmF3Q29udGVudEJsb2NrU3RhcnRFdmVudCA9IEFQSS5SYXdDb250ZW50QmxvY2tTdGFydEV2ZW50O1xuICBleHBvcnQgaW1wb3J0IFJhd0NvbnRlbnRCbG9ja1N0b3BFdmVudCA9IEFQSS5SYXdDb250ZW50QmxvY2tTdG9wRXZlbnQ7XG4gIGV4cG9ydCBpbXBvcnQgUmF3TWVzc2FnZURlbHRhRXZlbnQgPSBBUEkuUmF3TWVzc2FnZURlbHRhRXZlbnQ7XG4gIGV4cG9ydCBpbXBvcnQgUmF3TWVzc2FnZVN0YXJ0RXZlbnQgPSBBUEkuUmF3TWVzc2FnZVN0YXJ0RXZlbnQ7XG4gIGV4cG9ydCBpbXBvcnQgUmF3TWVzc2FnZVN0b3BFdmVudCA9IEFQSS5SYXdNZXNzYWdlU3RvcEV2ZW50O1xuICBleHBvcnQgaW1wb3J0IFJhd01lc3NhZ2VTdHJlYW1FdmVudCA9IEFQSS5SYXdNZXNzYWdlU3RyZWFtRXZlbnQ7XG4gIGV4cG9ydCBpbXBvcnQgVGV4dEJsb2NrID0gQVBJLlRleHRCbG9jaztcbiAgZXhwb3J0IGltcG9ydCBUZXh0QmxvY2tQYXJhbSA9IEFQSS5UZXh0QmxvY2tQYXJhbTtcbiAgZXhwb3J0IGltcG9ydCBUZXh0RGVsdGEgPSBBUEkuVGV4dERlbHRhO1xuICBleHBvcnQgaW1wb3J0IFRvb2wgPSBBUEkuVG9vbDtcbiAgZXhwb3J0IGltcG9ydCBUb29sUmVzdWx0QmxvY2tQYXJhbSA9IEFQSS5Ub29sUmVzdWx0QmxvY2tQYXJhbTtcbiAgZXhwb3J0IGltcG9ydCBUb29sVXNlQmxvY2sgPSBBUEkuVG9vbFVzZUJsb2NrO1xuICBleHBvcnQgaW1wb3J0IFRvb2xVc2VCbG9ja1BhcmFtID0gQVBJLlRvb2xVc2VCbG9ja1BhcmFtO1xuICBleHBvcnQgaW1wb3J0IFVzYWdlID0gQVBJLlVzYWdlO1xuICBleHBvcnQgaW1wb3J0IE1lc3NhZ2VDcmVhdGVQYXJhbXMgPSBBUEkuTWVzc2FnZUNyZWF0ZVBhcmFtcztcbiAgZXhwb3J0IGltcG9ydCBNZXNzYWdlQ3JlYXRlUGFyYW1zTm9uU3RyZWFtaW5nID0gQVBJLk1lc3NhZ2VDcmVhdGVQYXJhbXNOb25TdHJlYW1pbmc7XG4gIGV4cG9ydCBpbXBvcnQgTWVzc2FnZUNyZWF0ZVBhcmFtc1N0cmVhbWluZyA9IEFQSS5NZXNzYWdlQ3JlYXRlUGFyYW1zU3RyZWFtaW5nO1xuICBleHBvcnQgaW1wb3J0IE1lc3NhZ2VTdHJlYW1QYXJhbXMgPSBBUEkuTWVzc2FnZVN0cmVhbVBhcmFtcztcblxuICBleHBvcnQgaW1wb3J0IEJldGEgPSBBUEkuQmV0YTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQW50aHJvcGljO1xuIiwgImZ1bmN0aW9uIGFycmF5QnVmZmVyVG9CYXNlNjQoYnVmZmVyOiBBcnJheUJ1ZmZlcik6IHN0cmluZyB7XG4gIGxldCBiaW5hcnkgPSAnJ1xuICBjb25zdCBieXRlcyA9IG5ldyBVaW50OEFycmF5KGJ1ZmZlcilcbiAgZm9yIChsZXQgaSA9IDA7IGkgPCBieXRlcy5ieXRlTGVuZ3RoOyBpKyspIHtcbiAgICBiaW5hcnkgKz0gU3RyaW5nLmZyb21DaGFyQ29kZShieXRlc1tpXSlcbiAgfVxuICByZXR1cm4gYnRvYShiaW5hcnkpXG59XG5cbmV4cG9ydCBhc3luYyBmdW5jdGlvbiBnZXRJbWFnZUFzQmFzZTY0KGltYWdlVXJsOiBzdHJpbmcpOiBQcm9taXNlPHtcbiAgbWVkaWFfdHlwZTogc3RyaW5nXG4gIGRhdGE6IHN0cmluZ1xufT4ge1xuICAvLyBcdTY4QzBcdTY3RTVcdTY2MkZcdTU0MjZcdTVERjJcdTdFQ0ZcdTY2MkYgZGF0YSBVUkxcbiAgaWYgKGltYWdlVXJsLnN0YXJ0c1dpdGgoJ2RhdGE6JykpIHtcbiAgICBjb25zdCBbaGVhZGVyLCBkYXRhXSA9IGltYWdlVXJsLnNwbGl0KCcsJylcbiAgICBjb25zdCBtZWRpYV90eXBlID0gaGVhZGVyLnNwbGl0KCc6JylbMV0uc3BsaXQoJzsnKVswXVxuICAgIHJldHVybiB7IG1lZGlhX3R5cGUsIGRhdGEgfVxuICB9XG4gIC8vIFx1NTk4Mlx1Njc5Q1x1NEUwRFx1NjYyRiBkYXRhIFVSTFx1RkYwQ1x1NTIxOVx1NjMwOVx1NTM5Rlx1NjVCOVx1NkNENVx1NTkwNFx1NzQwNlxuICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKGltYWdlVXJsKVxuICBjb25zdCBhcnJheUJ1ZmZlciA9IGF3YWl0IHJlc3BvbnNlLmFycmF5QnVmZmVyKClcbiAgLy8gXHU1QzA2IEFycmF5QnVmZmVyIFx1OEY2Q1x1NjM2Mlx1NEUzQSBiYXNlNjRcbiAgY29uc3QgYmFzZTY0ID0gYXJyYXlCdWZmZXJUb0Jhc2U2NChhcnJheUJ1ZmZlcilcbiAgcmV0dXJuIHtcbiAgICBtZWRpYV90eXBlOiByZXNwb25zZS5oZWFkZXJzLmdldCgnY29udGVudC10eXBlJykgfHwgJ2ltYWdlL2pwZWcnLFxuICAgIGRhdGE6IGJhc2U2NCxcbiAgfVxufVxuIl0sCiAgIm1hcHBpbmdzIjogIjs7Ozs7OztBQUFBLFlBQVksY0FBYzs7O0FDQTFCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBTyxJQUFNLFVBQVU7OztBQzBCaEIsSUFBSSxPQUFPO0FBQ1gsSUFBSSxPQUFrQztBQUN0QyxJQUFJQSxTQUFvQztBQUN4QyxJQUFJQyxXQUF3QztBQUM1QyxJQUFJQyxZQUEwQztBQUM5QyxJQUFJQyxXQUF3QztBQUM1QyxJQUFJQyxZQUEwQztBQUM5QyxJQUFJQyxRQUFrQztBQUN0QyxJQUFJQyxRQUFrQztBQUN0QyxJQUFJQyxrQkFBc0Q7QUFDMUQsSUFBSSw2QkFBOEU7QUFDbEYsSUFBSSxrQkFBd0Q7QUFDNUQsSUFBSSxlQUFrRDtBQUN0RCxJQUFJLGlCQUFzRDtBQUUzRCxTQUFVLFNBQVMsT0FBYyxVQUE2QixFQUFFLE1BQU0sTUFBSyxHQUFFO0FBQ2pGLE1BQUksTUFBTTtBQUNSLFVBQU0sSUFBSSxNQUNSLDhDQUE4QyxNQUFNLElBQUksMkRBQTJEOztBQUd2SCxNQUFJLE1BQU07QUFDUixVQUFNLElBQUksTUFDUiwyQ0FBMkMsTUFBTSxJQUFJLCtDQUErQyxJQUFJLEtBQUs7O0FBR2pILFNBQU8sUUFBUTtBQUNmLFNBQU8sTUFBTTtBQUNiLEVBQUFQLFNBQVEsTUFBTTtBQUNkLEVBQUFDLFdBQVUsTUFBTTtBQUNoQixFQUFBQyxZQUFXLE1BQU07QUFDakIsRUFBQUMsV0FBVSxNQUFNO0FBQ2hCLEVBQUFDLFlBQVcsTUFBTTtBQUNqQixFQUFBQyxRQUFPLE1BQU07QUFDYixFQUFBQyxRQUFPLE1BQU07QUFDYixFQUFBQyxrQkFBaUIsTUFBTTtBQUN2QiwrQkFBNkIsTUFBTTtBQUNuQyxvQkFBa0IsTUFBTTtBQUN4QixpQkFBZSxNQUFNO0FBQ3JCLG1CQUFpQixNQUFNO0FBQ3pCOzs7QUMvRE0sSUFBTyxnQkFBUCxNQUFvQjtFQUN4QixZQUFtQixNQUFTO0FBQVQsU0FBQSxPQUFBO0VBQVk7RUFDL0IsS0FBSyxPQUFPLFdBQVcsSUFBQztBQUN0QixXQUFPO0VBQ1Q7Ozs7QUNBSSxTQUFVLFdBQVcsRUFBRSxpQkFBZ0IsSUFBcUMsQ0FBQSxHQUFFO0FBQ2xGLFFBQU0saUJBQ0osbUJBQ0Usa0NBQ0E7Ozs7QUFLSixNQUFJLFFBQVEsVUFBVSxXQUFXO0FBQ2pDLE1BQUk7QUFFRixhQUFTO0FBRVQsZUFBVztBQUVYLGdCQUFZO0FBRVosZUFBVztXQUNKLE9BQU87QUFDZCxVQUFNLElBQUksTUFDUixpRUFDRyxNQUFjLE9BQ2pCLEtBQUssY0FBYyxFQUFFOztBQUl6QixTQUFPO0lBQ0wsTUFBTTtJQUNOLE9BQU87SUFDUCxTQUFTO0lBQ1QsVUFBVTtJQUNWLFNBQVM7SUFDVDs7TUFFRSxPQUFPLGFBQWEsY0FBYyxXQUNoQyxNQUFNLFNBQVE7O1FBRVosY0FBQTtBQUNFLGdCQUFNLElBQUksTUFDUixxRkFBcUYsY0FBYyxFQUFFO1FBRXpHOzs7SUFHTixNQUNFLE9BQU8sU0FBUyxjQUFjLE9BQzVCLE1BQU0sS0FBSTtNQUNSLGNBQUE7QUFDRSxjQUFNLElBQUksTUFDUixpRkFBaUYsY0FBYyxFQUFFO01BRXJHOztJQUdOOztNQUVFLE9BQU8sU0FBUyxjQUFjLE9BQzVCLE1BQU0sS0FBSTs7UUFFUixjQUFBO0FBQ0UsZ0JBQU0sSUFBSSxNQUNSLGlGQUFpRixjQUFjLEVBQUU7UUFFckc7OztJQUdOOztNQUVFLE9BQU8sbUJBQW1CLGNBQWMsaUJBQ3RDLE1BQU0sZUFBYzs7UUFFbEIsY0FBQTtBQUNFLGdCQUFNLElBQUksTUFDUix1RkFBdUYsY0FBYyxFQUFFO1FBRTNHOzs7SUFHTiw0QkFBNEIsT0FFMUIsTUFDQSxVQUNnQztNQUNoQyxHQUFHO01BQ0gsTUFBTSxJQUFJLGNBQWMsSUFBSTs7SUFFOUIsaUJBQWlCLENBQUMsUUFBZ0I7SUFDbEMsY0FBYyxNQUFLO0FBQ2pCLFlBQU0sSUFBSSxNQUNSLGlLQUFpSztJQUVySztJQUNBLGdCQUFnQixDQUFDLFVBQWU7O0FBRXBDOzs7QUNqR0EsSUFBSSxDQUFPLEtBQU0sQ0FBTSxTQUFjLFdBQVcsR0FBRyxFQUFFLE1BQU0sS0FBSyxDQUFDOzs7QUNTM0QsSUFBTyxTQUFQLE1BQU8sUUFBTTtFQUdqQixZQUNVLFVBQ1IsWUFBMkI7QUFEbkIsU0FBQSxXQUFBO0FBR1IsU0FBSyxhQUFhO0VBQ3BCO0VBRUEsT0FBTyxnQkFBc0IsVUFBb0IsWUFBMkI7QUFDMUUsUUFBSSxXQUFXO0FBRWYsb0JBQWdCLFdBQVE7QUFDdEIsVUFBSSxVQUFVO0FBQ1osY0FBTSxJQUFJLE1BQU0sMEVBQTBFOztBQUU1RixpQkFBVztBQUNYLFVBQUksT0FBTztBQUNYLFVBQUk7QUFDRix5QkFBaUIsT0FBTyxpQkFBaUIsVUFBVSxVQUFVLEdBQUc7QUFDOUQsY0FBSSxJQUFJLFVBQVUsY0FBYztBQUM5QixnQkFBSTtBQUNGLG9CQUFNLEtBQUssTUFBTSxJQUFJLElBQUk7cUJBQ2xCLEdBQUc7QUFDVixzQkFBUSxNQUFNLHNDQUFzQyxJQUFJLElBQUk7QUFDNUQsc0JBQVEsTUFBTSxlQUFlLElBQUksR0FBRztBQUNwQyxvQkFBTTs7O0FBSVYsY0FDRSxJQUFJLFVBQVUsbUJBQ2QsSUFBSSxVQUFVLG1CQUNkLElBQUksVUFBVSxrQkFDZCxJQUFJLFVBQVUseUJBQ2QsSUFBSSxVQUFVLHlCQUNkLElBQUksVUFBVSxzQkFDZDtBQUNBLGdCQUFJO0FBQ0Ysb0JBQU0sS0FBSyxNQUFNLElBQUksSUFBSTtxQkFDbEIsR0FBRztBQUNWLHNCQUFRLE1BQU0sc0NBQXNDLElBQUksSUFBSTtBQUM1RCxzQkFBUSxNQUFNLGVBQWUsSUFBSSxHQUFHO0FBQ3BDLG9CQUFNOzs7QUFJVixjQUFJLElBQUksVUFBVSxRQUFRO0FBQ3hCOztBQUdGLGNBQUksSUFBSSxVQUFVLFNBQVM7QUFDekIsa0JBQU0sU0FBUyxTQUNiLFFBQ0EsY0FBYyxJQUFJLElBQUksSUFDdEIsSUFBSSxNQUNKLHNCQUFzQixTQUFTLE9BQU8sQ0FBQzs7O0FBSTdDLGVBQU87ZUFDQSxHQUFHO0FBRVYsWUFBSSxhQUFhLFNBQVMsRUFBRSxTQUFTO0FBQWM7QUFDbkQsY0FBTTs7QUFHTixZQUFJLENBQUM7QUFBTSxxQkFBVyxNQUFLOztJQUUvQjtBQUVBLFdBQU8sSUFBSSxRQUFPLFVBQVUsVUFBVTtFQUN4Qzs7Ozs7RUFNQSxPQUFPLG1CQUF5QixnQkFBZ0MsWUFBMkI7QUFDekYsUUFBSSxXQUFXO0FBRWYsb0JBQWdCLFlBQVM7QUFDdkIsWUFBTSxjQUFjLElBQUksWUFBVztBQUVuQyxZQUFNLE9BQU8sNEJBQW1DLGNBQWM7QUFDOUQsdUJBQWlCLFNBQVMsTUFBTTtBQUM5QixtQkFBVyxRQUFRLFlBQVksT0FBTyxLQUFLLEdBQUc7QUFDNUMsZ0JBQU07OztBQUlWLGlCQUFXLFFBQVEsWUFBWSxNQUFLLEdBQUk7QUFDdEMsY0FBTTs7SUFFVjtBQUVBLG9CQUFnQixXQUFRO0FBQ3RCLFVBQUksVUFBVTtBQUNaLGNBQU0sSUFBSSxNQUFNLDBFQUEwRTs7QUFFNUYsaUJBQVc7QUFDWCxVQUFJLE9BQU87QUFDWCxVQUFJO0FBQ0YseUJBQWlCLFFBQVEsVUFBUyxHQUFJO0FBQ3BDLGNBQUk7QUFBTTtBQUNWLGNBQUk7QUFBTSxrQkFBTSxLQUFLLE1BQU0sSUFBSTs7QUFFakMsZUFBTztlQUNBLEdBQUc7QUFFVixZQUFJLGFBQWEsU0FBUyxFQUFFLFNBQVM7QUFBYztBQUNuRCxjQUFNOztBQUdOLFlBQUksQ0FBQztBQUFNLHFCQUFXLE1BQUs7O0lBRS9CO0FBRUEsV0FBTyxJQUFJLFFBQU8sVUFBVSxVQUFVO0VBQ3hDO0VBRUEsQ0FBQyxPQUFPLGFBQWEsSUFBQztBQUNwQixXQUFPLEtBQUssU0FBUTtFQUN0Qjs7Ozs7RUFNQSxNQUFHO0FBQ0QsVUFBTSxPQUE2QyxDQUFBO0FBQ25ELFVBQU0sUUFBOEMsQ0FBQTtBQUNwRCxVQUFNLFdBQVcsS0FBSyxTQUFRO0FBRTlCLFVBQU0sY0FBYyxDQUFDLFVBQW9FO0FBQ3ZGLGFBQU87UUFDTCxNQUFNLE1BQUs7QUFDVCxjQUFJLE1BQU0sV0FBVyxHQUFHO0FBQ3RCLGtCQUFNLFNBQVMsU0FBUyxLQUFJO0FBQzVCLGlCQUFLLEtBQUssTUFBTTtBQUNoQixrQkFBTSxLQUFLLE1BQU07O0FBRW5CLGlCQUFPLE1BQU0sTUFBSztRQUNwQjs7SUFFSjtBQUVBLFdBQU87TUFDTCxJQUFJLFFBQU8sTUFBTSxZQUFZLElBQUksR0FBRyxLQUFLLFVBQVU7TUFDbkQsSUFBSSxRQUFPLE1BQU0sWUFBWSxLQUFLLEdBQUcsS0FBSyxVQUFVOztFQUV4RDs7Ozs7O0VBT0EsbUJBQWdCO0FBQ2QsVUFBTSxPQUFPO0FBQ2IsUUFBSTtBQUNKLFVBQU0sVUFBVSxJQUFJLFlBQVc7QUFFL0IsV0FBTyxJQUFJQyxnQkFBZTtNQUN4QixNQUFNLFFBQUs7QUFDVCxlQUFPLEtBQUssT0FBTyxhQUFhLEVBQUM7TUFDbkM7TUFDQSxNQUFNLEtBQUssTUFBUztBQUNsQixZQUFJO0FBQ0YsZ0JBQU0sRUFBRSxPQUFPLEtBQUksSUFBSyxNQUFNLEtBQUssS0FBSTtBQUN2QyxjQUFJO0FBQU0sbUJBQU8sS0FBSyxNQUFLO0FBRTNCLGdCQUFNLFFBQVEsUUFBUSxPQUFPLEtBQUssVUFBVSxLQUFLLElBQUksSUFBSTtBQUV6RCxlQUFLLFFBQVEsS0FBSztpQkFDWCxLQUFLO0FBQ1osZUFBSyxNQUFNLEdBQUc7O01BRWxCO01BQ0EsTUFBTSxTQUFNO0FBQ1YsY0FBTSxLQUFLLFNBQVE7TUFDckI7S0FDRDtFQUNIOztBQUdGLGdCQUF1QixpQkFDckIsVUFDQSxZQUEyQjtBQUUzQixNQUFJLENBQUMsU0FBUyxNQUFNO0FBQ2xCLGVBQVcsTUFBSztBQUNoQixVQUFNLElBQUksZUFBZSxtREFBbUQ7O0FBRzlFLFFBQU0sYUFBYSxJQUFJLFdBQVU7QUFDakMsUUFBTSxjQUFjLElBQUksWUFBVztBQUVuQyxRQUFNLE9BQU8sNEJBQW1DLFNBQVMsSUFBSTtBQUM3RCxtQkFBaUIsWUFBWSxjQUFjLElBQUksR0FBRztBQUNoRCxlQUFXLFFBQVEsWUFBWSxPQUFPLFFBQVEsR0FBRztBQUMvQyxZQUFNLE1BQU0sV0FBVyxPQUFPLElBQUk7QUFDbEMsVUFBSTtBQUFLLGNBQU07OztBQUluQixhQUFXLFFBQVEsWUFBWSxNQUFLLEdBQUk7QUFDdEMsVUFBTSxNQUFNLFdBQVcsT0FBTyxJQUFJO0FBQ2xDLFFBQUk7QUFBSyxZQUFNOztBQUVuQjtBQU1BLGdCQUFnQixjQUFjLFVBQXNDO0FBQ2xFLE1BQUksT0FBTyxJQUFJLFdBQVU7QUFFekIsbUJBQWlCLFNBQVMsVUFBVTtBQUNsQyxRQUFJLFNBQVMsTUFBTTtBQUNqQjs7QUFHRixVQUFNLGNBQ0osaUJBQWlCLGNBQWMsSUFBSSxXQUFXLEtBQUssSUFDakQsT0FBTyxVQUFVLFdBQVcsSUFBSSxZQUFXLEVBQUcsT0FBTyxLQUFLLElBQzFEO0FBRUosUUFBSSxVQUFVLElBQUksV0FBVyxLQUFLLFNBQVMsWUFBWSxNQUFNO0FBQzdELFlBQVEsSUFBSSxJQUFJO0FBQ2hCLFlBQVEsSUFBSSxhQUFhLEtBQUssTUFBTTtBQUNwQyxXQUFPO0FBRVAsUUFBSTtBQUNKLFlBQVEsZUFBZSx1QkFBdUIsSUFBSSxPQUFPLElBQUk7QUFDM0QsWUFBTSxLQUFLLE1BQU0sR0FBRyxZQUFZO0FBQ2hDLGFBQU8sS0FBSyxNQUFNLFlBQVk7OztBQUlsQyxNQUFJLEtBQUssU0FBUyxHQUFHO0FBQ25CLFVBQU07O0FBRVY7QUFFQSxTQUFTLHVCQUF1QixRQUFrQjtBQUloRCxRQUFNLFVBQVU7QUFDaEIsUUFBTSxXQUFXO0FBRWpCLFdBQVMsSUFBSSxHQUFHLElBQUksT0FBTyxTQUFTLEdBQUcsS0FBSztBQUMxQyxRQUFJLE9BQU8sQ0FBQyxNQUFNLFdBQVcsT0FBTyxJQUFJLENBQUMsTUFBTSxTQUFTO0FBRXRELGFBQU8sSUFBSTs7QUFFYixRQUFJLE9BQU8sQ0FBQyxNQUFNLFlBQVksT0FBTyxJQUFJLENBQUMsTUFBTSxVQUFVO0FBRXhELGFBQU8sSUFBSTs7QUFFYixRQUNFLE9BQU8sQ0FBQyxNQUFNLFlBQ2QsT0FBTyxJQUFJLENBQUMsTUFBTSxXQUNsQixJQUFJLElBQUksT0FBTyxVQUNmLE9BQU8sSUFBSSxDQUFDLE1BQU0sWUFDbEIsT0FBTyxJQUFJLENBQUMsTUFBTSxTQUNsQjtBQUVBLGFBQU8sSUFBSTs7O0FBSWYsU0FBTztBQUNUO0FBRUEsSUFBTSxhQUFOLE1BQWdCO0VBS2QsY0FBQTtBQUNFLFNBQUssUUFBUTtBQUNiLFNBQUssT0FBTyxDQUFBO0FBQ1osU0FBSyxTQUFTLENBQUE7RUFDaEI7RUFFQSxPQUFPLE1BQVk7QUFDakIsUUFBSSxLQUFLLFNBQVMsSUFBSSxHQUFHO0FBQ3ZCLGFBQU8sS0FBSyxVQUFVLEdBQUcsS0FBSyxTQUFTLENBQUM7O0FBRzFDLFFBQUksQ0FBQyxNQUFNO0FBRVQsVUFBSSxDQUFDLEtBQUssU0FBUyxDQUFDLEtBQUssS0FBSztBQUFRLGVBQU87QUFFN0MsWUFBTSxNQUF1QjtRQUMzQixPQUFPLEtBQUs7UUFDWixNQUFNLEtBQUssS0FBSyxLQUFLLElBQUk7UUFDekIsS0FBSyxLQUFLOztBQUdaLFdBQUssUUFBUTtBQUNiLFdBQUssT0FBTyxDQUFBO0FBQ1osV0FBSyxTQUFTLENBQUE7QUFFZCxhQUFPOztBQUdULFNBQUssT0FBTyxLQUFLLElBQUk7QUFFckIsUUFBSSxLQUFLLFdBQVcsR0FBRyxHQUFHO0FBQ3hCLGFBQU87O0FBR1QsUUFBSSxDQUFDLFdBQVcsR0FBRyxLQUFLLElBQUksVUFBVSxNQUFNLEdBQUc7QUFFL0MsUUFBSSxNQUFNLFdBQVcsR0FBRyxHQUFHO0FBQ3pCLGNBQVEsTUFBTSxVQUFVLENBQUM7O0FBRzNCLFFBQUksY0FBYyxTQUFTO0FBQ3pCLFdBQUssUUFBUTtlQUNKLGNBQWMsUUFBUTtBQUMvQixXQUFLLEtBQUssS0FBSyxLQUFLOztBQUd0QixXQUFPO0VBQ1Q7O0FBU0YsSUFBTSxjQUFOLE1BQU0sYUFBVztFQVNmLGNBQUE7QUFDRSxTQUFLLFNBQVMsQ0FBQTtBQUNkLFNBQUssYUFBYTtFQUNwQjtFQUVBLE9BQU8sT0FBWTtBQUNqQixRQUFJLE9BQU8sS0FBSyxXQUFXLEtBQUs7QUFFaEMsUUFBSSxLQUFLLFlBQVk7QUFDbkIsYUFBTyxPQUFPO0FBQ2QsV0FBSyxhQUFhOztBQUVwQixRQUFJLEtBQUssU0FBUyxJQUFJLEdBQUc7QUFDdkIsV0FBSyxhQUFhO0FBQ2xCLGFBQU8sS0FBSyxNQUFNLEdBQUcsRUFBRTs7QUFHekIsUUFBSSxDQUFDLE1BQU07QUFDVCxhQUFPLENBQUE7O0FBR1QsVUFBTSxrQkFBa0IsYUFBWSxjQUFjLElBQUksS0FBSyxLQUFLLFNBQVMsQ0FBQyxLQUFLLEVBQUU7QUFDakYsUUFBSSxRQUFRLEtBQUssTUFBTSxhQUFZLGNBQWM7QUFJakQsUUFBSSxpQkFBaUI7QUFDbkIsWUFBTSxJQUFHOztBQUdYLFFBQUksTUFBTSxXQUFXLEtBQUssQ0FBQyxpQkFBaUI7QUFDMUMsV0FBSyxPQUFPLEtBQUssTUFBTSxDQUFDLENBQUU7QUFDMUIsYUFBTyxDQUFBOztBQUdULFFBQUksS0FBSyxPQUFPLFNBQVMsR0FBRztBQUMxQixjQUFRLENBQUMsS0FBSyxPQUFPLEtBQUssRUFBRSxJQUFJLE1BQU0sQ0FBQyxHQUFHLEdBQUcsTUFBTSxNQUFNLENBQUMsQ0FBQztBQUMzRCxXQUFLLFNBQVMsQ0FBQTs7QUFHaEIsUUFBSSxDQUFDLGlCQUFpQjtBQUNwQixXQUFLLFNBQVMsQ0FBQyxNQUFNLElBQUcsS0FBTSxFQUFFOztBQUdsQyxXQUFPO0VBQ1Q7RUFFQSxXQUFXLE9BQVk7QUFDckIsUUFBSSxTQUFTO0FBQU0sYUFBTztBQUMxQixRQUFJLE9BQU8sVUFBVTtBQUFVLGFBQU87QUFHdEMsUUFBSSxPQUFPLFdBQVcsYUFBYTtBQUNqQyxVQUFJLGlCQUFpQixRQUFRO0FBQzNCLGVBQU8sTUFBTSxTQUFROztBQUV2QixVQUFJLGlCQUFpQixZQUFZO0FBQy9CLGVBQU8sT0FBTyxLQUFLLEtBQUssRUFBRSxTQUFROztBQUdwQyxZQUFNLElBQUksZUFDUix3Q0FBd0MsTUFBTSxZQUFZLElBQUksbUlBQW1JOztBQUtyTSxRQUFJLE9BQU8sZ0JBQWdCLGFBQWE7QUFDdEMsVUFBSSxpQkFBaUIsY0FBYyxpQkFBaUIsYUFBYTtBQUMvRCxhQUFLLGdCQUFMLEtBQUssY0FBZ0IsSUFBSSxZQUFZLE1BQU07QUFDM0MsZUFBTyxLQUFLLFlBQVksT0FBTyxLQUFLOztBQUd0QyxZQUFNLElBQUksZUFDUixvREFDRyxNQUFjLFlBQVksSUFDN0IsZ0RBQWdEOztBQUlwRCxVQUFNLElBQUksZUFDUixnR0FBZ0c7RUFFcEc7RUFFQSxRQUFLO0FBQ0gsUUFBSSxDQUFDLEtBQUssT0FBTyxVQUFVLENBQUMsS0FBSyxZQUFZO0FBQzNDLGFBQU8sQ0FBQTs7QUFHVCxVQUFNLFFBQVEsQ0FBQyxLQUFLLE9BQU8sS0FBSyxFQUFFLENBQUM7QUFDbkMsU0FBSyxTQUFTLENBQUE7QUFDZCxTQUFLLGFBQWE7QUFDbEIsV0FBTztFQUNUOztBQXBHTyxZQUFBLGdCQUFnQixvQkFBSSxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUM7QUFDcEMsWUFBQSxpQkFBaUI7QUFpSDFCLFNBQVMsVUFBVSxLQUFhLFdBQWlCO0FBQy9DLFFBQU0sUUFBUSxJQUFJLFFBQVEsU0FBUztBQUNuQyxNQUFJLFVBQVUsSUFBSTtBQUNoQixXQUFPLENBQUMsSUFBSSxVQUFVLEdBQUcsS0FBSyxHQUFHLFdBQVcsSUFBSSxVQUFVLFFBQVEsVUFBVSxNQUFNLENBQUM7O0FBR3JGLFNBQU8sQ0FBQyxLQUFLLElBQUksRUFBRTtBQUNyQjtBQVFNLFNBQVUsNEJBQStCLFFBQVc7QUFDeEQsTUFBSSxPQUFPLE9BQU8sYUFBYTtBQUFHLFdBQU87QUFFekMsUUFBTSxTQUFTLE9BQU8sVUFBUztBQUMvQixTQUFPO0lBQ0wsTUFBTSxPQUFJO0FBQ1IsVUFBSTtBQUNGLGNBQU0sU0FBUyxNQUFNLE9BQU8sS0FBSTtBQUNoQyxZQUFJLFFBQVE7QUFBTSxpQkFBTyxZQUFXO0FBQ3BDLGVBQU87ZUFDQSxHQUFHO0FBQ1YsZUFBTyxZQUFXO0FBQ2xCLGNBQU07O0lBRVY7SUFDQSxNQUFNLFNBQU07QUFDVixZQUFNLGdCQUFnQixPQUFPLE9BQU07QUFDbkMsYUFBTyxZQUFXO0FBQ2xCLFlBQU07QUFDTixhQUFPLEVBQUUsTUFBTSxNQUFNLE9BQU8sT0FBUztJQUN2QztJQUNBLENBQUMsT0FBTyxhQUFhLElBQUM7QUFDcEIsYUFBTztJQUNUOztBQUVKOzs7QUNqY08sSUFBTSxpQkFBaUIsQ0FBQyxVQUM3QixTQUFTLFFBQ1QsT0FBTyxVQUFVLFlBQ2pCLE9BQU8sTUFBTSxRQUFRLFlBQ3JCLE9BQU8sTUFBTSxTQUFTO0FBRWpCLElBQU0sYUFBYSxDQUFDLFVBQ3pCLFNBQVMsUUFDVCxPQUFPLFVBQVUsWUFDakIsT0FBTyxNQUFNLFNBQVMsWUFDdEIsT0FBTyxNQUFNLGlCQUFpQixZQUM5QixXQUFXLEtBQUs7QUFNWCxJQUFNLGFBQWEsQ0FBQyxVQUN6QixTQUFTLFFBQ1QsT0FBTyxVQUFVLFlBQ2pCLE9BQU8sTUFBTSxTQUFTLFlBQ3RCLE9BQU8sTUFBTSxTQUFTLFlBQ3RCLE9BQU8sTUFBTSxTQUFTLGNBQ3RCLE9BQU8sTUFBTSxVQUFVLGNBQ3ZCLE9BQU8sTUFBTSxnQkFBZ0I7QUFpQi9CLGVBQXNCLE9BQ3BCLE9BQ0EsTUFDQSxTQUFxQztBQUdyQyxVQUFRLE1BQU07QUFHZCxNQUFJLFdBQVcsS0FBSyxHQUFHO0FBQ3JCLFdBQU87O0FBR1QsTUFBSSxlQUFlLEtBQUssR0FBRztBQUN6QixVQUFNLE9BQU8sTUFBTSxNQUFNLEtBQUk7QUFDN0IsYUFBQSxPQUFTLElBQUksSUFBSSxNQUFNLEdBQUcsRUFBRSxTQUFTLE1BQU0sT0FBTyxFQUFFLElBQUcsS0FBTTtBQUs3RCxVQUFNLE9BQU8sV0FBVyxJQUFJLElBQUksQ0FBRSxNQUFNLEtBQUssWUFBVyxDQUFVLElBQUksQ0FBQyxJQUFJO0FBRTNFLFdBQU8sSUFBSUMsTUFBSyxNQUFNLE1BQU0sT0FBTzs7QUFHckMsUUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFLO0FBRWpDLFdBQUEsT0FBUyxRQUFRLEtBQUssS0FBSztBQUUzQixNQUFJLENBQUMsU0FBUyxNQUFNO0FBQ2xCLFVBQU0sT0FBUSxLQUFLLENBQUMsR0FBVztBQUMvQixRQUFJLE9BQU8sU0FBUyxVQUFVO0FBQzVCLGdCQUFVLEVBQUUsR0FBRyxTQUFTLEtBQUk7OztBQUloQyxTQUFPLElBQUlBLE1BQUssTUFBTSxNQUFNLE9BQU87QUFDckM7QUFFQSxlQUFlLFNBQVMsT0FBa0I7QUFDeEMsTUFBSSxRQUF5QixDQUFBO0FBQzdCLE1BQ0UsT0FBTyxVQUFVLFlBQ2pCLFlBQVksT0FBTyxLQUFLO0VBQ3hCLGlCQUFpQixhQUNqQjtBQUNBLFVBQU0sS0FBSyxLQUFLO2FBQ1AsV0FBVyxLQUFLLEdBQUc7QUFDNUIsVUFBTSxLQUFLLE1BQU0sTUFBTSxZQUFXLENBQUU7YUFFcEMsd0JBQXdCLEtBQUssR0FDN0I7QUFDQSxxQkFBaUIsU0FBUyxPQUFPO0FBQy9CLFlBQU0sS0FBSyxLQUFpQjs7U0FFekI7QUFDTCxVQUFNLElBQUksTUFDUix5QkFBeUIsT0FBTyxLQUFLLGtCQUFrQixPQUFPLGFBQzFELElBQUksWUFBWSxjQUFjLEtBQUssQ0FBQyxFQUFFOztBQUk5QyxTQUFPO0FBQ1Q7QUFFQSxTQUFTLGNBQWMsT0FBVTtBQUMvQixRQUFNLFFBQVEsT0FBTyxvQkFBb0IsS0FBSztBQUM5QyxTQUFPLElBQUksTUFBTSxJQUFJLENBQUMsTUFBTSxJQUFJLENBQUMsR0FBRyxFQUFFLEtBQUssSUFBSSxDQUFDO0FBQ2xEO0FBRUEsU0FBUyxRQUFRLE9BQVU7QUFDekIsU0FDRSx5QkFBeUIsTUFBTSxJQUFJLEtBQ25DLHlCQUF5QixNQUFNLFFBQVE7RUFFdkMseUJBQXlCLE1BQU0sSUFBSSxHQUFHLE1BQU0sT0FBTyxFQUFFLElBQUc7QUFFNUQ7QUFFQSxJQUFNLDJCQUEyQixDQUFDLE1BQW9EO0FBQ3BGLE1BQUksT0FBTyxNQUFNO0FBQVUsV0FBTztBQUNsQyxNQUFJLE9BQU8sV0FBVyxlQUFlLGFBQWE7QUFBUSxXQUFPLE9BQU8sQ0FBQztBQUN6RSxTQUFPO0FBQ1Q7QUFFQSxJQUFNLDBCQUEwQixDQUFDLFVBQy9CLFNBQVMsUUFBUSxPQUFPLFVBQVUsWUFBWSxPQUFPLE1BQU0sT0FBTyxhQUFhLE1BQU07QUFFaEYsSUFBTSxrQkFBa0IsQ0FBQyxTQUM5QixRQUFRLE9BQU8sU0FBUyxZQUFZLEtBQUssUUFBUSxLQUFLLE9BQU8sV0FBVyxNQUFNOzs7Ozs7Ozs7Ozs7Ozs7QUN2SmhGLGVBQWUscUJBQXdCLE9BQXVCO0FBQzVELFFBQU0sRUFBRSxTQUFRLElBQUs7QUFDckIsTUFBSSxNQUFNLFFBQVEsUUFBUTtBQUN4QixVQUFNLFlBQVksU0FBUyxRQUFRLFNBQVMsS0FBSyxTQUFTLFNBQVMsU0FBUyxJQUFJO0FBS2hGLFFBQUksTUFBTSxRQUFRLGVBQWU7QUFDL0IsYUFBTyxNQUFNLFFBQVEsY0FBYyxnQkFBZ0IsVUFBVSxNQUFNLFVBQVU7O0FBRy9FLFdBQU8sT0FBTyxnQkFBZ0IsVUFBVSxNQUFNLFVBQVU7O0FBSTFELE1BQUksU0FBUyxXQUFXLEtBQUs7QUFDM0IsV0FBTzs7QUFHVCxNQUFJLE1BQU0sUUFBUSxrQkFBa0I7QUFDbEMsV0FBTzs7QUFHVCxRQUFNLGNBQWMsU0FBUyxRQUFRLElBQUksY0FBYztBQUN2RCxRQUFNLFNBQ0osYUFBYSxTQUFTLGtCQUFrQixLQUFLLGFBQWEsU0FBUywwQkFBMEI7QUFDL0YsTUFBSSxRQUFRO0FBQ1YsVUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFJO0FBRWhDLFVBQU0sWUFBWSxTQUFTLFFBQVEsU0FBUyxLQUFLLFNBQVMsU0FBUyxJQUFJO0FBRXZFLFdBQU87O0FBR1QsUUFBTSxPQUFPLE1BQU0sU0FBUyxLQUFJO0FBQ2hDLFFBQU0sWUFBWSxTQUFTLFFBQVEsU0FBUyxLQUFLLFNBQVMsU0FBUyxJQUFJO0FBR3ZFLFNBQU87QUFDVDtBQU1NLElBQU8sYUFBUCxNQUFPLG9CQUFzQixRQUFVO0VBRzNDLFlBQ1UsaUJBQ0FDLGlCQUFnRSxzQkFBb0I7QUFFNUYsVUFBTSxDQUFDLFlBQVc7QUFJaEIsY0FBUSxJQUFXO0lBQ3JCLENBQUM7QUFSTyxTQUFBLGtCQUFBO0FBQ0EsU0FBQSxnQkFBQUE7RUFRVjtFQUVBLFlBQWUsV0FBeUI7QUFDdEMsV0FBTyxJQUFJLFlBQVcsS0FBSyxpQkFBaUIsT0FBTyxVQUFVLFVBQVUsTUFBTSxLQUFLLGNBQWMsS0FBSyxDQUFDLENBQUM7RUFDekc7Ozs7Ozs7Ozs7Ozs7O0VBZUEsYUFBVTtBQUNSLFdBQU8sS0FBSyxnQkFBZ0IsS0FBSyxDQUFDLE1BQU0sRUFBRSxRQUFRO0VBQ3BEOzs7Ozs7Ozs7Ozs7OztFQWNBLE1BQU0sZUFBWTtBQUNoQixVQUFNLENBQUMsTUFBTSxRQUFRLElBQUksTUFBTSxRQUFRLElBQUksQ0FBQyxLQUFLLE1BQUssR0FBSSxLQUFLLFdBQVUsQ0FBRSxDQUFDO0FBQzVFLFdBQU8sRUFBRSxNQUFNLFNBQVE7RUFDekI7RUFFUSxRQUFLO0FBQ1gsUUFBSSxDQUFDLEtBQUssZUFBZTtBQUN2QixXQUFLLGdCQUFnQixLQUFLLGdCQUFnQixLQUFLLEtBQUssYUFBYTs7QUFFbkUsV0FBTyxLQUFLO0VBQ2Q7RUFFUyxLQUNQLGFBQ0EsWUFBbUY7QUFFbkYsV0FBTyxLQUFLLE1BQUssRUFBRyxLQUFLLGFBQWEsVUFBVTtFQUNsRDtFQUVTLE1BQ1AsWUFBaUY7QUFFakYsV0FBTyxLQUFLLE1BQUssRUFBRyxNQUFNLFVBQVU7RUFDdEM7RUFFUyxRQUFRLFdBQTJDO0FBQzFELFdBQU8sS0FBSyxNQUFLLEVBQUcsUUFBUSxTQUFTO0VBQ3ZDOztBQUdJLElBQWdCLFlBQWhCLE1BQXlCO0VBUzdCLFlBQVk7SUFDVjtJQUNBLGFBQWE7SUFDYixVQUFVOztJQUNWO0lBQ0EsT0FBTztFQUFjLEdBT3RCO0FBQ0MsU0FBSyxVQUFVO0FBQ2YsU0FBSyxhQUFhLHdCQUF3QixjQUFjLFVBQVU7QUFDbEUsU0FBSyxVQUFVLHdCQUF3QixXQUFXLE9BQU87QUFDekQsU0FBSyxZQUFZO0FBRWpCLFNBQUssUUFBUSxrQkFBa0JDO0VBQ2pDO0VBRVUsWUFBWSxNQUF5QjtBQUM3QyxXQUFPLENBQUE7RUFDVDs7Ozs7Ozs7O0VBVVUsZUFBZSxNQUF5QjtBQUNoRCxXQUFPO01BQ0wsUUFBUTtNQUNSLGdCQUFnQjtNQUNoQixjQUFjLEtBQUssYUFBWTtNQUMvQixHQUFHLG1CQUFrQjtNQUNyQixHQUFHLEtBQUssWUFBWSxJQUFJOztFQUU1Qjs7OztFQU9VLGdCQUFnQixTQUFrQixlQUFzQjtFQUFHO0VBRTNELHdCQUFxQjtBQUM3QixXQUFPLHdCQUF3QixNQUFLLENBQUU7RUFDeEM7RUFFQSxJQUFjLE1BQWMsTUFBMEM7QUFDcEUsV0FBTyxLQUFLLGNBQWMsT0FBTyxNQUFNLElBQUk7RUFDN0M7RUFFQSxLQUFlLE1BQWMsTUFBMEM7QUFDckUsV0FBTyxLQUFLLGNBQWMsUUFBUSxNQUFNLElBQUk7RUFDOUM7RUFFQSxNQUFnQixNQUFjLE1BQTBDO0FBQ3RFLFdBQU8sS0FBSyxjQUFjLFNBQVMsTUFBTSxJQUFJO0VBQy9DO0VBRUEsSUFBYyxNQUFjLE1BQTBDO0FBQ3BFLFdBQU8sS0FBSyxjQUFjLE9BQU8sTUFBTSxJQUFJO0VBQzdDO0VBRUEsT0FBaUIsTUFBYyxNQUEwQztBQUN2RSxXQUFPLEtBQUssY0FBYyxVQUFVLE1BQU0sSUFBSTtFQUNoRDtFQUVRLGNBQ04sUUFDQSxNQUNBLE1BQTBDO0FBRTFDLFdBQU8sS0FBSyxRQUNWLFFBQVEsUUFBUSxJQUFJLEVBQUUsS0FBSyxPQUFPQyxVQUFRO0FBQ3hDLFlBQU0sT0FDSkEsU0FBUSxXQUFXQSxPQUFNLElBQUksSUFBSSxJQUFJLFNBQVMsTUFBTUEsTUFBSyxLQUFLLFlBQVcsQ0FBRSxJQUN6RUEsT0FBTSxnQkFBZ0IsV0FBV0EsTUFBSyxPQUN0Q0EsT0FBTSxnQkFBZ0IsY0FBYyxJQUFJLFNBQVNBLE1BQUssSUFBSSxJQUMxREEsU0FBUSxZQUFZLE9BQU9BLE9BQU0sSUFBSSxJQUFJLElBQUksU0FBU0EsTUFBSyxLQUFLLE1BQU0sSUFDdEVBLE9BQU07QUFDVixhQUFPLEVBQUUsUUFBUSxNQUFNLEdBQUdBLE9BQU0sS0FBSTtJQUN0QyxDQUFDLENBQUM7RUFFTjtFQUVBLFdBQ0UsTUFDQSxNQUNBLE1BQTBCO0FBRTFCLFdBQU8sS0FBSyxlQUFlLE1BQU0sRUFBRSxRQUFRLE9BQU8sTUFBTSxHQUFHLEtBQUksQ0FBRTtFQUNuRTtFQUVRLHVCQUF1QixNQUFhO0FBQzFDLFFBQUksT0FBTyxTQUFTLFVBQVU7QUFDNUIsVUFBSSxPQUFPLFdBQVcsYUFBYTtBQUNqQyxlQUFPLE9BQU8sV0FBVyxNQUFNLE1BQU0sRUFBRSxTQUFROztBQUdqRCxVQUFJLE9BQU8sZ0JBQWdCLGFBQWE7QUFDdEMsY0FBTSxVQUFVLElBQUksWUFBVztBQUMvQixjQUFNLFVBQVUsUUFBUSxPQUFPLElBQUk7QUFDbkMsZUFBTyxRQUFRLE9BQU8sU0FBUTs7ZUFFdkIsWUFBWSxPQUFPLElBQUksR0FBRztBQUNuQyxhQUFPLEtBQUssV0FBVyxTQUFROztBQUdqQyxXQUFPO0VBQ1Q7RUFFQSxhQUNFLFNBQ0EsRUFBRSxhQUFhLEVBQUMsSUFBOEIsQ0FBQSxHQUFFO0FBRWhELFVBQU0sRUFBRSxRQUFRLE1BQU0sT0FBTyxVQUFtQixDQUFBLEVBQUUsSUFBSztBQUV2RCxVQUFNLE9BQ0osWUFBWSxPQUFPLFFBQVEsSUFBSSxLQUFNLFFBQVEsbUJBQW1CLE9BQU8sUUFBUSxTQUFTLFdBQ3RGLFFBQVEsT0FDUixnQkFBZ0IsUUFBUSxJQUFJLElBQUksUUFBUSxLQUFLLE9BQzdDLFFBQVEsT0FBTyxLQUFLLFVBQVUsUUFBUSxNQUFNLE1BQU0sQ0FBQyxJQUNuRDtBQUNKLFVBQU0sZ0JBQWdCLEtBQUssdUJBQXVCLElBQUk7QUFFdEQsVUFBTSxNQUFNLEtBQUssU0FBUyxNQUFPLEtBQUs7QUFDdEMsUUFBSSxhQUFhO0FBQVMsOEJBQXdCLFdBQVcsUUFBUSxPQUFPO0FBQzVFLFVBQU0sVUFBVSxRQUFRLFdBQVcsS0FBSztBQUN4QyxVQUFNLFlBQVksUUFBUSxhQUFhLEtBQUssYUFBYSxnQkFBZ0IsR0FBRztBQUM1RSxVQUFNLGtCQUFrQixVQUFVO0FBQ2xDLFFBQ0UsT0FBUSxXQUFtQixTQUFTLFlBQVksWUFDaEQsbUJBQW9CLFVBQWtCLFFBQVEsV0FBVyxJQUN6RDtBQUtDLGdCQUFrQixRQUFRLFVBQVU7O0FBR3ZDLFFBQUksS0FBSyxxQkFBcUIsV0FBVyxPQUFPO0FBQzlDLFVBQUksQ0FBQyxRQUFRO0FBQWdCLGdCQUFRLGlCQUFpQixLQUFLLHNCQUFxQjtBQUNoRixjQUFRLEtBQUssaUJBQWlCLElBQUksUUFBUTs7QUFHNUMsVUFBTSxhQUFhLEtBQUssYUFBYSxFQUFFLFNBQVMsU0FBUyxlQUFlLFdBQVUsQ0FBRTtBQUVwRixVQUFNLE1BQW1CO01BQ3ZCO01BQ0EsR0FBSSxRQUFRLEVBQUUsS0FBaUI7TUFDL0IsU0FBUztNQUNULEdBQUksYUFBYSxFQUFFLE9BQU8sVUFBUzs7O01BR25DLFFBQVEsUUFBUSxVQUFVOztBQUc1QixXQUFPLEVBQUUsS0FBSyxLQUFLLFFBQU87RUFDNUI7RUFFUSxhQUFhLEVBQ25CLFNBQ0EsU0FDQSxlQUNBLFdBQVUsR0FNWDtBQUNDLFVBQU0sYUFBcUMsQ0FBQTtBQUMzQyxRQUFJLGVBQWU7QUFDakIsaUJBQVcsZ0JBQWdCLElBQUk7O0FBR2pDLFVBQU0saUJBQWlCLEtBQUssZUFBZSxPQUFPO0FBQ2xELG9CQUFnQixZQUFZLGNBQWM7QUFDMUMsb0JBQWdCLFlBQVksT0FBTztBQUduQyxRQUFJLGdCQUFnQixRQUFRLElBQUksS0FBSyxTQUFjLFFBQVE7QUFDekQsYUFBTyxXQUFXLGNBQWM7O0FBS2xDLFFBQUksVUFBVSxTQUFTLHlCQUF5QixNQUFNLFFBQVc7QUFDL0QsaUJBQVcseUJBQXlCLElBQUksT0FBTyxVQUFVOztBQUczRCxTQUFLLGdCQUFnQixZQUFZLE9BQU87QUFFeEMsV0FBTztFQUNUOzs7O0VBS1UsTUFBTSxlQUFlLFNBQTRCO0VBQWtCOzs7Ozs7O0VBUW5FLE1BQU0sZUFDZCxTQUNBLEVBQUUsS0FBSyxRQUFPLEdBQWlEO0VBQy9DO0VBRVIsYUFBYSxTQUF1QztBQUM1RCxXQUNFLENBQUMsVUFBVSxDQUFBLElBQ1QsT0FBTyxZQUFZLFVBQ25CLE9BQU8sWUFBWSxNQUFNLEtBQUssT0FBNkIsRUFBRSxJQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsSUFDekYsRUFBRSxHQUFHLFFBQU87RUFFbEI7RUFFVSxnQkFDUixRQUNBLE9BQ0EsU0FDQSxTQUE0QjtBQUU1QixXQUFPLFNBQVMsU0FBUyxRQUFRLE9BQU8sU0FBUyxPQUFPO0VBQzFEO0VBRUEsUUFDRSxTQUNBLG1CQUFrQyxNQUFJO0FBRXRDLFdBQU8sSUFBSSxXQUFXLEtBQUssWUFBWSxTQUFTLGdCQUFnQixDQUFDO0VBQ25FO0VBRVEsTUFBTSxZQUNaLGNBQ0Esa0JBQStCO0FBRS9CLFVBQU0sVUFBVSxNQUFNO0FBQ3RCLFVBQU0sYUFBYSxRQUFRLGNBQWMsS0FBSztBQUM5QyxRQUFJLG9CQUFvQixNQUFNO0FBQzVCLHlCQUFtQjs7QUFHckIsVUFBTSxLQUFLLGVBQWUsT0FBTztBQUVqQyxVQUFNLEVBQUUsS0FBSyxLQUFLLFFBQU8sSUFBSyxLQUFLLGFBQWEsU0FBUyxFQUFFLFlBQVksYUFBYSxpQkFBZ0IsQ0FBRTtBQUV0RyxVQUFNLEtBQUssZUFBZSxLQUFLLEVBQUUsS0FBSyxRQUFPLENBQUU7QUFFL0MsVUFBTSxXQUFXLEtBQUssU0FBUyxJQUFJLE9BQU87QUFFMUMsUUFBSSxRQUFRLFFBQVEsU0FBUztBQUMzQixZQUFNLElBQUksa0JBQWlCOztBQUc3QixVQUFNLGFBQWEsSUFBSSxnQkFBZTtBQUN0QyxVQUFNLFdBQVcsTUFBTSxLQUFLLGlCQUFpQixLQUFLLEtBQUssU0FBUyxVQUFVLEVBQUUsTUFBTSxXQUFXO0FBRTdGLFFBQUksb0JBQW9CLE9BQU87QUFDN0IsVUFBSSxRQUFRLFFBQVEsU0FBUztBQUMzQixjQUFNLElBQUksa0JBQWlCOztBQUU3QixVQUFJLGtCQUFrQjtBQUNwQixlQUFPLEtBQUssYUFBYSxTQUFTLGdCQUFnQjs7QUFFcEQsVUFBSSxTQUFTLFNBQVMsY0FBYztBQUNsQyxjQUFNLElBQUksMEJBQXlCOztBQUVyQyxZQUFNLElBQUksbUJBQW1CLEVBQUUsT0FBTyxTQUFRLENBQUU7O0FBR2xELFVBQU0sa0JBQWtCLHNCQUFzQixTQUFTLE9BQU87QUFFOUQsUUFBSSxDQUFDLFNBQVMsSUFBSTtBQUNoQixVQUFJLG9CQUFvQixLQUFLLFlBQVksUUFBUSxHQUFHO0FBQ2xELGNBQU1DLGdCQUFlLGFBQWEsZ0JBQWdCO0FBQ2xELGNBQU0sb0JBQW9CQSxhQUFZLEtBQUssU0FBUyxRQUFRLEtBQUssZUFBZTtBQUNoRixlQUFPLEtBQUssYUFBYSxTQUFTLGtCQUFrQixlQUFlOztBQUdyRSxZQUFNLFVBQVUsTUFBTSxTQUFTLEtBQUksRUFBRyxNQUFNLENBQUMsTUFBTSxZQUFZLENBQUMsRUFBRSxPQUFPO0FBQ3pFLFlBQU0sVUFBVSxTQUFTLE9BQU87QUFDaEMsWUFBTSxhQUFhLFVBQVUsU0FBWTtBQUN6QyxZQUFNLGVBQWUsbUJBQW1CLGtDQUFrQztBQUUxRSxZQUFNLG9CQUFvQixZQUFZLEtBQUssU0FBUyxRQUFRLEtBQUssaUJBQWlCLFVBQVU7QUFFNUYsWUFBTSxNQUFNLEtBQUssZ0JBQWdCLFNBQVMsUUFBUSxTQUFTLFlBQVksZUFBZTtBQUN0RixZQUFNOztBQUdSLFdBQU8sRUFBRSxVQUFVLFNBQVMsV0FBVTtFQUN4QztFQUVBLGVBQ0UsTUFDQSxTQUE0QjtBQUU1QixVQUFNLFVBQVUsS0FBSyxZQUFZLFNBQVMsSUFBSTtBQUM5QyxXQUFPLElBQUksWUFBNkIsTUFBTSxTQUFTLElBQUk7RUFDN0Q7RUFFQSxTQUFjLE1BQWMsT0FBNkI7QUFDdkQsVUFBTSxNQUNKLGNBQWMsSUFBSSxJQUNoQixJQUFJLElBQUksSUFBSSxJQUNaLElBQUksSUFBSSxLQUFLLFdBQVcsS0FBSyxRQUFRLFNBQVMsR0FBRyxLQUFLLEtBQUssV0FBVyxHQUFHLElBQUksS0FBSyxNQUFNLENBQUMsSUFBSSxLQUFLO0FBRXRHLFVBQU0sZUFBZSxLQUFLLGFBQVk7QUFDdEMsUUFBSSxDQUFDLFdBQVcsWUFBWSxHQUFHO0FBQzdCLGNBQVEsRUFBRSxHQUFHLGNBQWMsR0FBRyxNQUFLOztBQUdyQyxRQUFJLE9BQU8sVUFBVSxZQUFZLFNBQVMsQ0FBQyxNQUFNLFFBQVEsS0FBSyxHQUFHO0FBQy9ELFVBQUksU0FBUyxLQUFLLGVBQWUsS0FBZ0M7O0FBR25FLFdBQU8sSUFBSSxTQUFRO0VBQ3JCO0VBRVUsZUFBZSxPQUE4QjtBQUNyRCxXQUFPLE9BQU8sUUFBUSxLQUFLLEVBQ3hCLE9BQU8sQ0FBQyxDQUFDLEdBQUcsS0FBSyxNQUFNLE9BQU8sVUFBVSxXQUFXLEVBQ25ELElBQUksQ0FBQyxDQUFDLEtBQUssS0FBSyxNQUFLO0FBQ3BCLFVBQUksT0FBTyxVQUFVLFlBQVksT0FBTyxVQUFVLFlBQVksT0FBTyxVQUFVLFdBQVc7QUFDeEYsZUFBTyxHQUFHLG1CQUFtQixHQUFHLENBQUMsSUFBSSxtQkFBbUIsS0FBSyxDQUFDOztBQUVoRSxVQUFJLFVBQVUsTUFBTTtBQUNsQixlQUFPLEdBQUcsbUJBQW1CLEdBQUcsQ0FBQzs7QUFFbkMsWUFBTSxJQUFJLGVBQ1IseUJBQXlCLE9BQU8sS0FBSyxtUUFBbVE7SUFFNVMsQ0FBQyxFQUNBLEtBQUssR0FBRztFQUNiO0VBRUEsTUFBTSxpQkFDSixLQUNBLE1BQ0EsSUFDQSxZQUEyQjtBQUUzQixVQUFNLEVBQUUsUUFBUSxHQUFHLFFBQU8sSUFBSyxRQUFRLENBQUE7QUFDdkMsUUFBSTtBQUFRLGFBQU8saUJBQWlCLFNBQVMsTUFBTSxXQUFXLE1BQUssQ0FBRTtBQUVyRSxVQUFNLFVBQVUsV0FBVyxNQUFNLFdBQVcsTUFBSyxHQUFJLEVBQUU7QUFFdkQsV0FDRSxLQUFLLGlCQUFnQixFQUVsQixNQUFNLEtBQUssUUFBVyxLQUFLLEVBQUUsUUFBUSxXQUFXLFFBQWUsR0FBRyxRQUFPLENBQUUsRUFDM0UsUUFBUSxNQUFLO0FBQ1osbUJBQWEsT0FBTztJQUN0QixDQUFDO0VBRVA7RUFFVSxtQkFBZ0I7QUFDeEIsV0FBTyxFQUFFLE9BQU8sS0FBSyxNQUFLO0VBQzVCO0VBRVEsWUFBWSxVQUFrQjtBQUVwQyxVQUFNLG9CQUFvQixTQUFTLFFBQVEsSUFBSSxnQkFBZ0I7QUFHL0QsUUFBSSxzQkFBc0I7QUFBUSxhQUFPO0FBQ3pDLFFBQUksc0JBQXNCO0FBQVMsYUFBTztBQUcxQyxRQUFJLFNBQVMsV0FBVztBQUFLLGFBQU87QUFHcEMsUUFBSSxTQUFTLFdBQVc7QUFBSyxhQUFPO0FBR3BDLFFBQUksU0FBUyxXQUFXO0FBQUssYUFBTztBQUdwQyxRQUFJLFNBQVMsVUFBVTtBQUFLLGFBQU87QUFFbkMsV0FBTztFQUNUO0VBRVEsTUFBTSxhQUNaLFNBQ0Esa0JBQ0EsaUJBQXFDO0FBRXJDLFFBQUk7QUFHSixVQUFNLHlCQUF5QixrQkFBa0IsZ0JBQWdCO0FBQ2pFLFFBQUksd0JBQXdCO0FBQzFCLFlBQU0sWUFBWSxXQUFXLHNCQUFzQjtBQUNuRCxVQUFJLENBQUMsT0FBTyxNQUFNLFNBQVMsR0FBRztBQUM1Qix3QkFBZ0I7OztBQUtwQixVQUFNLG1CQUFtQixrQkFBa0IsYUFBYTtBQUN4RCxRQUFJLG9CQUFvQixDQUFDLGVBQWU7QUFDdEMsWUFBTSxpQkFBaUIsV0FBVyxnQkFBZ0I7QUFDbEQsVUFBSSxDQUFDLE9BQU8sTUFBTSxjQUFjLEdBQUc7QUFDakMsd0JBQWdCLGlCQUFpQjthQUM1QjtBQUNMLHdCQUFnQixLQUFLLE1BQU0sZ0JBQWdCLElBQUksS0FBSyxJQUFHOzs7QUFNM0QsUUFBSSxFQUFFLGlCQUFpQixLQUFLLGlCQUFpQixnQkFBZ0IsS0FBSyxNQUFPO0FBQ3ZFLFlBQU0sYUFBYSxRQUFRLGNBQWMsS0FBSztBQUM5QyxzQkFBZ0IsS0FBSyxtQ0FBbUMsa0JBQWtCLFVBQVU7O0FBRXRGLFVBQU0sTUFBTSxhQUFhO0FBRXpCLFdBQU8sS0FBSyxZQUFZLFNBQVMsbUJBQW1CLENBQUM7RUFDdkQ7RUFFUSxtQ0FBbUMsa0JBQTBCLFlBQWtCO0FBQ3JGLFVBQU0sb0JBQW9CO0FBQzFCLFVBQU0sZ0JBQWdCO0FBRXRCLFVBQU0sYUFBYSxhQUFhO0FBR2hDLFVBQU0sZUFBZSxLQUFLLElBQUksb0JBQW9CLEtBQUssSUFBSSxHQUFHLFVBQVUsR0FBRyxhQUFhO0FBR3hGLFVBQU0sU0FBUyxJQUFJLEtBQUssT0FBTSxJQUFLO0FBRW5DLFdBQU8sZUFBZSxTQUFTO0VBQ2pDO0VBRVEsZUFBWTtBQUNsQixXQUFPLEdBQUcsS0FBSyxZQUFZLElBQUksT0FBTyxPQUFPO0VBQy9DOztBQUtJLElBQWdCLGVBQWhCLE1BQTRCO0VBT2hDLFlBQVksUUFBbUIsVUFBb0IsTUFBZSxTQUE0QjtBQU45Rix5QkFBQSxJQUFBLE1BQUEsTUFBQTtBQU9FLDJCQUFBLE1BQUksc0JBQVcsUUFBTSxHQUFBO0FBQ3JCLFNBQUssVUFBVTtBQUNmLFNBQUssV0FBVztBQUNoQixTQUFLLE9BQU87RUFDZDtFQVVBLGNBQVc7QUFDVCxVQUFNLFFBQVEsS0FBSyxrQkFBaUI7QUFDcEMsUUFBSSxDQUFDLE1BQU07QUFBUSxhQUFPO0FBQzFCLFdBQU8sS0FBSyxhQUFZLEtBQU07RUFDaEM7RUFFQSxNQUFNLGNBQVc7QUFDZixVQUFNLFdBQVcsS0FBSyxhQUFZO0FBQ2xDLFFBQUksQ0FBQyxVQUFVO0FBQ2IsWUFBTSxJQUFJLGVBQ1IsdUZBQXVGOztBQUczRixVQUFNLGNBQWMsRUFBRSxHQUFHLEtBQUssUUFBTztBQUNyQyxRQUFJLFlBQVksWUFBWSxPQUFPLFlBQVksVUFBVSxVQUFVO0FBQ2pFLGtCQUFZLFFBQVEsRUFBRSxHQUFHLFlBQVksT0FBTyxHQUFHLFNBQVMsT0FBTTtlQUNyRCxTQUFTLFVBQVU7QUFDNUIsWUFBTSxTQUFTLENBQUMsR0FBRyxPQUFPLFFBQVEsWUFBWSxTQUFTLENBQUEsQ0FBRSxHQUFHLEdBQUcsU0FBUyxJQUFJLGFBQWEsUUFBTyxDQUFFO0FBQ2xHLGlCQUFXLENBQUMsS0FBSyxLQUFLLEtBQUssUUFBUTtBQUNqQyxpQkFBUyxJQUFJLGFBQWEsSUFBSSxLQUFLLEtBQVk7O0FBRWpELGtCQUFZLFFBQVE7QUFDcEIsa0JBQVksT0FBTyxTQUFTLElBQUksU0FBUTs7QUFFMUMsV0FBTyxNQUFNLHVCQUFBLE1BQUksc0JBQUEsR0FBQSxFQUFTLGVBQWUsS0FBSyxhQUFvQixXQUFXO0VBQy9FO0VBRUEsT0FBTyxZQUFTO0FBRWQsUUFBSSxPQUEyQjtBQUMvQixVQUFNO0FBQ04sV0FBTyxLQUFLLFlBQVcsR0FBSTtBQUN6QixhQUFPLE1BQU0sS0FBSyxZQUFXO0FBQzdCLFlBQU07O0VBRVY7RUFFQSxTQUFPLHVCQUFBLG9CQUFBLFFBQUEsR0FBQyxPQUFPLGNBQWEsSUFBQztBQUMzQixxQkFBaUIsUUFBUSxLQUFLLFVBQVMsR0FBSTtBQUN6QyxpQkFBVyxRQUFRLEtBQUssa0JBQWlCLEdBQUk7QUFDM0MsY0FBTTs7O0VBR1o7O0FBWUksSUFBTyxjQUFQLGNBSUksV0FBcUI7RUFHN0IsWUFDRSxRQUNBLFNBQ0EsTUFBNEU7QUFFNUUsVUFDRSxTQUNBLE9BQU8sVUFBVSxJQUFJLEtBQUssUUFBUSxNQUFNLFVBQVUsTUFBTSxxQkFBcUIsS0FBSyxHQUFHLE1BQU0sT0FBTyxDQUFDO0VBRXZHOzs7Ozs7OztFQVNBLFFBQVEsT0FBTyxhQUFhLElBQUM7QUFDM0IsVUFBTSxPQUFPLE1BQU07QUFDbkIscUJBQWlCLFFBQVEsTUFBTTtBQUM3QixZQUFNOztFQUVWOztBQUdLLElBQU0sd0JBQXdCLENBQ25DLFlBQzBCO0FBQzFCLFNBQU8sSUFBSSxNQUNULE9BQU87O0lBRUwsUUFBUSxRQUFPO0VBQUUsR0FFbkI7SUFDRSxJQUFJLFFBQVEsTUFBSTtBQUNkLFlBQU0sTUFBTSxLQUFLLFNBQVE7QUFDekIsYUFBTyxPQUFPLElBQUksWUFBVyxDQUFFLEtBQUssT0FBTyxHQUFHO0lBQ2hEO0dBQ0Q7QUFFTDtBQXlGQSxJQUFNLHdCQUF3QixNQUF5QjtBQUNyRCxNQUFJLE9BQU8sU0FBUyxlQUFlLEtBQUssU0FBUyxNQUFNO0FBQ3JELFdBQU87TUFDTCxvQkFBb0I7TUFDcEIsK0JBQStCO01BQy9CLGtCQUFrQixrQkFBa0IsS0FBSyxNQUFNLEVBQUU7TUFDakQsb0JBQW9CLGNBQWMsS0FBSyxNQUFNLElBQUk7TUFDakQsdUJBQXVCO01BQ3ZCLCtCQUNFLE9BQU8sS0FBSyxZQUFZLFdBQVcsS0FBSyxVQUFVLEtBQUssU0FBUyxRQUFROzs7QUFHOUUsTUFBSSxPQUFPLGdCQUFnQixhQUFhO0FBQ3RDLFdBQU87TUFDTCxvQkFBb0I7TUFDcEIsK0JBQStCO01BQy9CLGtCQUFrQjtNQUNsQixvQkFBb0IsU0FBUyxXQUFXO01BQ3hDLHVCQUF1QjtNQUN2QiwrQkFBK0IsUUFBUTs7O0FBSTNDLE1BQUksT0FBTyxVQUFVLFNBQVMsS0FBSyxPQUFPLFlBQVksY0FBYyxVQUFVLENBQUMsTUFBTSxvQkFBb0I7QUFDdkcsV0FBTztNQUNMLG9CQUFvQjtNQUNwQiwrQkFBK0I7TUFDL0Isa0JBQWtCLGtCQUFrQixRQUFRLFFBQVE7TUFDcEQsb0JBQW9CLGNBQWMsUUFBUSxJQUFJO01BQzlDLHVCQUF1QjtNQUN2QiwrQkFBK0IsUUFBUTs7O0FBSTNDLFFBQU0sY0FBYyxlQUFjO0FBQ2xDLE1BQUksYUFBYTtBQUNmLFdBQU87TUFDTCxvQkFBb0I7TUFDcEIsK0JBQStCO01BQy9CLGtCQUFrQjtNQUNsQixvQkFBb0I7TUFDcEIsdUJBQXVCLFdBQVcsWUFBWSxPQUFPO01BQ3JELCtCQUErQixZQUFZOzs7QUFLL0MsU0FBTztJQUNMLG9CQUFvQjtJQUNwQiwrQkFBK0I7SUFDL0Isa0JBQWtCO0lBQ2xCLG9CQUFvQjtJQUNwQix1QkFBdUI7SUFDdkIsK0JBQStCOztBQUVuQztBQVVBLFNBQVMsaUJBQWM7QUFDckIsTUFBSSxPQUFPLGNBQWMsZUFBZSxDQUFDLFdBQVc7QUFDbEQsV0FBTzs7QUFJVCxRQUFNLGtCQUFrQjtJQUN0QixFQUFFLEtBQUssUUFBaUIsU0FBUyx1Q0FBc0M7SUFDdkUsRUFBRSxLQUFLLE1BQWUsU0FBUyx1Q0FBc0M7SUFDckUsRUFBRSxLQUFLLE1BQWUsU0FBUyw2Q0FBNEM7SUFDM0UsRUFBRSxLQUFLLFVBQW1CLFNBQVMseUNBQXdDO0lBQzNFLEVBQUUsS0FBSyxXQUFvQixTQUFTLDBDQUF5QztJQUM3RSxFQUFFLEtBQUssVUFBbUIsU0FBUyxvRUFBbUU7O0FBSXhHLGFBQVcsRUFBRSxLQUFLLFFBQU8sS0FBTSxpQkFBaUI7QUFDOUMsVUFBTSxRQUFRLFFBQVEsS0FBSyxVQUFVLFNBQVM7QUFDOUMsUUFBSSxPQUFPO0FBQ1QsWUFBTSxRQUFRLE1BQU0sQ0FBQyxLQUFLO0FBQzFCLFlBQU0sUUFBUSxNQUFNLENBQUMsS0FBSztBQUMxQixZQUFNLFFBQVEsTUFBTSxDQUFDLEtBQUs7QUFFMUIsYUFBTyxFQUFFLFNBQVMsS0FBSyxTQUFTLEdBQUcsS0FBSyxJQUFJLEtBQUssSUFBSSxLQUFLLEdBQUU7OztBQUloRSxTQUFPO0FBQ1Q7QUFFQSxJQUFNLGdCQUFnQixDQUFDLFNBQXNCO0FBSzNDLE1BQUksU0FBUztBQUFPLFdBQU87QUFDM0IsTUFBSSxTQUFTLFlBQVksU0FBUztBQUFPLFdBQU87QUFDaEQsTUFBSSxTQUFTO0FBQU8sV0FBTztBQUMzQixNQUFJLFNBQVMsYUFBYSxTQUFTO0FBQVMsV0FBTztBQUNuRCxNQUFJO0FBQU0sV0FBTyxTQUFTLElBQUk7QUFDOUIsU0FBTztBQUNUO0FBRUEsSUFBTSxvQkFBb0IsQ0FBQyxhQUFrQztBQU8zRCxhQUFXLFNBQVMsWUFBVztBQU0vQixNQUFJLFNBQVMsU0FBUyxLQUFLO0FBQUcsV0FBTztBQUNyQyxNQUFJLGFBQWE7QUFBVyxXQUFPO0FBQ25DLE1BQUksYUFBYTtBQUFVLFdBQU87QUFDbEMsTUFBSSxhQUFhO0FBQVMsV0FBTztBQUNqQyxNQUFJLGFBQWE7QUFBVyxXQUFPO0FBQ25DLE1BQUksYUFBYTtBQUFXLFdBQU87QUFDbkMsTUFBSSxhQUFhO0FBQVMsV0FBTztBQUNqQyxNQUFJO0FBQVUsV0FBTyxTQUFTLFFBQVE7QUFDdEMsU0FBTztBQUNUO0FBRUEsSUFBSTtBQUNKLElBQU0scUJBQXFCLE1BQUs7QUFDOUIsU0FBUSxxQkFBQSxtQkFBcUIsc0JBQXFCO0FBQ3BEO0FBRU8sSUFBTSxXQUFXLENBQUMsU0FBZ0I7QUFDdkMsTUFBSTtBQUNGLFdBQU8sS0FBSyxNQUFNLElBQUk7V0FDZixLQUFLO0FBQ1osV0FBTzs7QUFFWDtBQUdBLElBQU0seUJBQXlCLElBQUksT0FBTyxtQkFBbUIsR0FBRztBQUNoRSxJQUFNLGdCQUFnQixDQUFDLFFBQXdCO0FBQzdDLFNBQU8sdUJBQXVCLEtBQUssR0FBRztBQUN4QztBQUVPLElBQU0sUUFBUSxDQUFDLE9BQWUsSUFBSSxRQUFRLENBQUMsWUFBWSxXQUFXLFNBQVMsRUFBRSxDQUFDO0FBRXJGLElBQU0sMEJBQTBCLENBQUMsTUFBYyxNQUFzQjtBQUNuRSxNQUFJLE9BQU8sTUFBTSxZQUFZLENBQUMsT0FBTyxVQUFVLENBQUMsR0FBRztBQUNqRCxVQUFNLElBQUksZUFBZSxHQUFHLElBQUkscUJBQXFCOztBQUV2RCxNQUFJLElBQUksR0FBRztBQUNULFVBQU0sSUFBSSxlQUFlLEdBQUcsSUFBSSw2QkFBNkI7O0FBRS9ELFNBQU87QUFDVDtBQUVPLElBQU0sY0FBYyxDQUFDLFFBQW1CO0FBQzdDLE1BQUksZUFBZTtBQUFPLFdBQU87QUFDakMsTUFBSSxPQUFPLFFBQVEsWUFBWSxRQUFRLE1BQU07QUFDM0MsUUFBSTtBQUNGLGFBQU8sSUFBSSxNQUFNLEtBQUssVUFBVSxHQUFHLENBQUM7WUFDOUI7SUFBQTs7QUFFVixTQUFPLElBQUksTUFBTSxPQUFPLEdBQUcsQ0FBQztBQUM5QjtBQWNPLElBQU0sVUFBVSxDQUFDLFFBQW1DO0FBQ3pELE1BQUksT0FBTyxZQUFZLGFBQWE7QUFDbEMsV0FBTyxRQUFRLE1BQU0sR0FBRyxHQUFHLEtBQUksS0FBTTs7QUFFdkMsTUFBSSxPQUFPLFNBQVMsYUFBYTtBQUMvQixXQUFPLEtBQUssS0FBSyxNQUFNLEdBQUcsR0FBRyxLQUFJOztBQUVuQyxTQUFPO0FBQ1Q7QUE0Q00sU0FBVSxXQUFXLEtBQThCO0FBQ3ZELE1BQUksQ0FBQztBQUFLLFdBQU87QUFDakIsYUFBVyxNQUFNO0FBQUssV0FBTztBQUM3QixTQUFPO0FBQ1Q7QUFHTSxTQUFVLE9BQU8sS0FBYSxLQUFXO0FBQzdDLFNBQU8sT0FBTyxVQUFVLGVBQWUsS0FBSyxLQUFLLEdBQUc7QUFDdEQ7QUFRQSxTQUFTLGdCQUFnQixlQUF3QixZQUFtQjtBQUNsRSxhQUFXLEtBQUssWUFBWTtBQUMxQixRQUFJLENBQUMsT0FBTyxZQUFZLENBQUM7QUFBRztBQUM1QixVQUFNLFdBQVcsRUFBRSxZQUFXO0FBQzlCLFFBQUksQ0FBQztBQUFVO0FBRWYsVUFBTSxNQUFNLFdBQVcsQ0FBQztBQUV4QixRQUFJLFFBQVEsTUFBTTtBQUNoQixhQUFPLGNBQWMsUUFBUTtlQUNwQixRQUFRLFFBQVc7QUFDNUIsb0JBQWMsUUFBUSxJQUFJOzs7QUFHaEM7QUFFTSxTQUFVLE1BQU0sV0FBbUIsTUFBVztBQUNsRCxNQUFJLE9BQU8sWUFBWSxlQUFlLFNBQVMsTUFBTSxPQUFPLE1BQU0sUUFBUTtBQUN4RSxZQUFRLElBQUksbUJBQW1CLE1BQU0sSUFBSSxHQUFHLElBQUk7O0FBRXBEO0FBS0EsSUFBTSxRQUFRLE1BQUs7QUFDakIsU0FBTyx1Q0FBdUMsUUFBUSxTQUFTLENBQUMsTUFBSztBQUNuRSxVQUFNLElBQUssS0FBSyxPQUFNLElBQUssS0FBTTtBQUNqQyxVQUFNLElBQUksTUFBTSxNQUFNLElBQUssSUFBSSxJQUFPO0FBQ3RDLFdBQU8sRUFBRSxTQUFTLEVBQUU7RUFDdEIsQ0FBQztBQUNIO0FBRU8sSUFBTSxxQkFBcUIsTUFBSztBQUNyQzs7SUFFRSxPQUFPLFdBQVc7SUFFbEIsT0FBTyxPQUFPLGFBQWE7SUFFM0IsT0FBTyxjQUFjOztBQUV6QjtBQU9PLElBQU0sb0JBQW9CLENBQUMsWUFBNEM7QUFDNUUsU0FBTyxPQUFPLFNBQVMsUUFBUTtBQUNqQztBQVVPLElBQU0sWUFBWSxDQUFDLFNBQWdDLFdBQXNDO0FBQzlGLFFBQU0sbUJBQW1CLE9BQU8sWUFBVztBQUMzQyxNQUFJLGtCQUFrQixPQUFPLEdBQUc7QUFFOUIsVUFBTSxrQkFDSixPQUFPLENBQUMsR0FBRyxZQUFXLElBQ3RCLE9BQU8sVUFBVSxDQUFDLEVBQUUsUUFBUSxnQkFBZ0IsQ0FBQyxJQUFJLElBQUksT0FBTyxLQUFLLEdBQUcsWUFBVyxDQUFFO0FBQ25GLGVBQVcsT0FBTyxDQUFDLFFBQVEsa0JBQWtCLE9BQU8sWUFBVyxHQUFJLGVBQWUsR0FBRztBQUNuRixZQUFNLFFBQVEsUUFBUSxJQUFJLEdBQUc7QUFDN0IsVUFBSSxPQUFPO0FBQ1QsZUFBTzs7OztBQUtiLGFBQVcsQ0FBQyxLQUFLLEtBQUssS0FBSyxPQUFPLFFBQVEsT0FBTyxHQUFHO0FBQ2xELFFBQUksSUFBSSxZQUFXLE1BQU8sa0JBQWtCO0FBQzFDLFVBQUksTUFBTSxRQUFRLEtBQUssR0FBRztBQUN4QixZQUFJLE1BQU0sVUFBVTtBQUFHLGlCQUFPLE1BQU0sQ0FBQztBQUNyQyxnQkFBUSxLQUFLLFlBQVksTUFBTSxNQUFNLG9CQUFvQixNQUFNLGlDQUFpQztBQUNoRyxlQUFPLE1BQU0sQ0FBQzs7QUFFaEIsYUFBTzs7O0FBSVgsU0FBTztBQUNUOzs7QVI3cENNLElBQU8saUJBQVAsY0FBOEIsTUFBSzs7QUFFbkMsSUFBTyxXQUFQLE1BQU8sa0JBQWlCLGVBQWM7RUFPMUMsWUFDRSxRQUNBLE9BQ0EsU0FDQSxTQUE0QjtBQUU1QixVQUFNLEdBQUcsVUFBUyxZQUFZLFFBQVEsT0FBTyxPQUFPLENBQUMsRUFBRTtBQUN2RCxTQUFLLFNBQVM7QUFDZCxTQUFLLFVBQVU7QUFDZixTQUFLLGFBQWEsVUFBVSxZQUFZO0FBQ3hDLFNBQUssUUFBUTtFQUNmO0VBRVEsT0FBTyxZQUFZLFFBQTRCLE9BQVksU0FBMkI7QUFDNUYsVUFBTSxNQUNKLE9BQU8sVUFDTCxPQUFPLE1BQU0sWUFBWSxXQUN2QixNQUFNLFVBQ04sS0FBSyxVQUFVLE1BQU0sT0FBTyxJQUM5QixRQUFRLEtBQUssVUFBVSxLQUFLLElBQzVCO0FBRUosUUFBSSxVQUFVLEtBQUs7QUFDakIsYUFBTyxHQUFHLE1BQU0sSUFBSSxHQUFHOztBQUV6QixRQUFJLFFBQVE7QUFDVixhQUFPLEdBQUcsTUFBTTs7QUFFbEIsUUFBSSxLQUFLO0FBQ1AsYUFBTzs7QUFFVCxXQUFPO0VBQ1Q7RUFFQSxPQUFPLFNBQ0wsUUFDQSxlQUNBLFNBQ0EsU0FBNEI7QUFFNUIsUUFBSSxDQUFDLFFBQVE7QUFDWCxhQUFPLElBQUksbUJBQW1CLEVBQUUsU0FBUyxPQUFPLFlBQVksYUFBYSxFQUFDLENBQUU7O0FBRzlFLFVBQU0sUUFBUTtBQUVkLFFBQUksV0FBVyxLQUFLO0FBQ2xCLGFBQU8sSUFBSSxnQkFBZ0IsUUFBUSxPQUFPLFNBQVMsT0FBTzs7QUFHNUQsUUFBSSxXQUFXLEtBQUs7QUFDbEIsYUFBTyxJQUFJLG9CQUFvQixRQUFRLE9BQU8sU0FBUyxPQUFPOztBQUdoRSxRQUFJLFdBQVcsS0FBSztBQUNsQixhQUFPLElBQUksc0JBQXNCLFFBQVEsT0FBTyxTQUFTLE9BQU87O0FBR2xFLFFBQUksV0FBVyxLQUFLO0FBQ2xCLGFBQU8sSUFBSSxjQUFjLFFBQVEsT0FBTyxTQUFTLE9BQU87O0FBRzFELFFBQUksV0FBVyxLQUFLO0FBQ2xCLGFBQU8sSUFBSSxjQUFjLFFBQVEsT0FBTyxTQUFTLE9BQU87O0FBRzFELFFBQUksV0FBVyxLQUFLO0FBQ2xCLGFBQU8sSUFBSSx5QkFBeUIsUUFBUSxPQUFPLFNBQVMsT0FBTzs7QUFHckUsUUFBSSxXQUFXLEtBQUs7QUFDbEIsYUFBTyxJQUFJLGVBQWUsUUFBUSxPQUFPLFNBQVMsT0FBTzs7QUFHM0QsUUFBSSxVQUFVLEtBQUs7QUFDakIsYUFBTyxJQUFJLG9CQUFvQixRQUFRLE9BQU8sU0FBUyxPQUFPOztBQUdoRSxXQUFPLElBQUksVUFBUyxRQUFRLE9BQU8sU0FBUyxPQUFPO0VBQ3JEOztBQUdJLElBQU8sb0JBQVAsY0FBaUMsU0FBUTtFQUc3QyxZQUFZLEVBQUUsUUFBTyxJQUEyQixDQUFBLEdBQUU7QUFDaEQsVUFBTSxRQUFXLFFBQVcsV0FBVyx3QkFBd0IsTUFBUztBQUh4RCxTQUFBLFNBQW9CO0VBSXRDOztBQUdJLElBQU8scUJBQVAsY0FBa0MsU0FBUTtFQUc5QyxZQUFZLEVBQUUsU0FBUyxNQUFLLEdBQStEO0FBQ3pGLFVBQU0sUUFBVyxRQUFXLFdBQVcscUJBQXFCLE1BQVM7QUFIckQsU0FBQSxTQUFvQjtBQU1wQyxRQUFJO0FBQU8sV0FBSyxRQUFRO0VBQzFCOztBQUdJLElBQU8sNEJBQVAsY0FBeUMsbUJBQWtCO0VBQy9ELFlBQVksRUFBRSxRQUFPLElBQTJCLENBQUEsR0FBRTtBQUNoRCxVQUFNLEVBQUUsU0FBUyxXQUFXLHFCQUFvQixDQUFFO0VBQ3BEOztBQUdJLElBQU8sa0JBQVAsY0FBK0IsU0FBUTtFQUE3QyxjQUFBOztBQUNvQixTQUFBLFNBQWM7RUFDbEM7O0FBRU0sSUFBTyxzQkFBUCxjQUFtQyxTQUFRO0VBQWpELGNBQUE7O0FBQ29CLFNBQUEsU0FBYztFQUNsQzs7QUFFTSxJQUFPLHdCQUFQLGNBQXFDLFNBQVE7RUFBbkQsY0FBQTs7QUFDb0IsU0FBQSxTQUFjO0VBQ2xDOztBQUVNLElBQU8sZ0JBQVAsY0FBNkIsU0FBUTtFQUEzQyxjQUFBOztBQUNvQixTQUFBLFNBQWM7RUFDbEM7O0FBRU0sSUFBTyxnQkFBUCxjQUE2QixTQUFRO0VBQTNDLGNBQUE7O0FBQ29CLFNBQUEsU0FBYztFQUNsQzs7QUFFTSxJQUFPLDJCQUFQLGNBQXdDLFNBQVE7RUFBdEQsY0FBQTs7QUFDb0IsU0FBQSxTQUFjO0VBQ2xDOztBQUVNLElBQU8saUJBQVAsY0FBOEIsU0FBUTtFQUE1QyxjQUFBOztBQUNvQixTQUFBLFNBQWM7RUFDbEM7O0FBRU0sSUFBTyxzQkFBUCxjQUFtQyxTQUFROzs7O0FTaEozQyxJQUFPLGNBQVAsTUFBa0I7RUFHdEIsWUFBWSxRQUFzQjtBQUNoQyxTQUFLLFVBQVU7RUFDakI7Ozs7QUNKRixJQUFNLFdBQVcsQ0FBQyxVQUEwQjtBQUN4QyxNQUFJLFVBQVU7QUFDZCxNQUFJLFNBQWtCLENBQUE7QUFFdEIsU0FBTyxVQUFVLE1BQU0sUUFBUTtBQUM3QixRQUFJLE9BQU8sTUFBTSxPQUFPO0FBRXhCLFFBQUksU0FBUyxNQUFNO0FBQ2pCO0FBQ0E7O0FBR0YsUUFBSSxTQUFTLEtBQUs7QUFDaEIsYUFBTyxLQUFLO1FBQ1YsTUFBTTtRQUNOLE9BQU87T0FDUjtBQUVEO0FBQ0E7O0FBR0YsUUFBSSxTQUFTLEtBQUs7QUFDaEIsYUFBTyxLQUFLO1FBQ1YsTUFBTTtRQUNOLE9BQU87T0FDUjtBQUVEO0FBQ0E7O0FBR0YsUUFBSSxTQUFTLEtBQUs7QUFDaEIsYUFBTyxLQUFLO1FBQ1YsTUFBTTtRQUNOLE9BQU87T0FDUjtBQUVEO0FBQ0E7O0FBR0YsUUFBSSxTQUFTLEtBQUs7QUFDaEIsYUFBTyxLQUFLO1FBQ1YsTUFBTTtRQUNOLE9BQU87T0FDUjtBQUVEO0FBQ0E7O0FBR0YsUUFBSSxTQUFTLEtBQUs7QUFDaEIsYUFBTyxLQUFLO1FBQ1YsTUFBTTtRQUNOLE9BQU87T0FDUjtBQUVEO0FBQ0E7O0FBR0YsUUFBSSxTQUFTLEtBQUs7QUFDaEIsYUFBTyxLQUFLO1FBQ1YsTUFBTTtRQUNOLE9BQU87T0FDUjtBQUVEO0FBQ0E7O0FBR0YsUUFBSSxTQUFTLEtBQUs7QUFDaEIsVUFBSSxRQUFRO0FBQ1osVUFBSSxnQkFBZ0I7QUFFcEIsYUFBTyxNQUFNLEVBQUUsT0FBTztBQUV0QixhQUFPLFNBQVMsS0FBSztBQUNuQixZQUFJLFlBQVksTUFBTSxRQUFRO0FBQzVCLDBCQUFnQjtBQUNoQjs7QUFHRixZQUFJLFNBQVMsTUFBTTtBQUNqQjtBQUNBLGNBQUksWUFBWSxNQUFNLFFBQVE7QUFDNUIsNEJBQWdCO0FBQ2hCOztBQUVGLG1CQUFTLE9BQU8sTUFBTSxPQUFPO0FBQzdCLGlCQUFPLE1BQU0sRUFBRSxPQUFPO2VBQ2pCO0FBQ0wsbUJBQVM7QUFDVCxpQkFBTyxNQUFNLEVBQUUsT0FBTzs7O0FBSTFCLGFBQU8sTUFBTSxFQUFFLE9BQU87QUFFdEIsVUFBSSxDQUFDLGVBQWU7QUFDbEIsZUFBTyxLQUFLO1VBQ1YsTUFBTTtVQUNOO1NBQ0Q7O0FBRUg7O0FBR0YsUUFBSSxhQUFhO0FBQ2pCLFFBQUksUUFBUSxXQUFXLEtBQUssSUFBSSxHQUFHO0FBQ2pDO0FBQ0E7O0FBR0YsUUFBSSxVQUFVO0FBQ2QsUUFBSyxRQUFRLFFBQVEsS0FBSyxJQUFJLEtBQU0sU0FBUyxPQUFPLFNBQVMsS0FBSztBQUNoRSxVQUFJLFFBQVE7QUFFWixVQUFJLFNBQVMsS0FBSztBQUNoQixpQkFBUztBQUNULGVBQU8sTUFBTSxFQUFFLE9BQU87O0FBR3hCLGFBQVEsUUFBUSxRQUFRLEtBQUssSUFBSSxLQUFNLFNBQVMsS0FBSztBQUNuRCxpQkFBUztBQUNULGVBQU8sTUFBTSxFQUFFLE9BQU87O0FBR3hCLGFBQU8sS0FBSztRQUNWLE1BQU07UUFDTjtPQUNEO0FBQ0Q7O0FBR0YsUUFBSSxVQUFVO0FBQ2QsUUFBSSxRQUFRLFFBQVEsS0FBSyxJQUFJLEdBQUc7QUFDOUIsVUFBSSxRQUFRO0FBRVosYUFBTyxRQUFRLFFBQVEsS0FBSyxJQUFJLEdBQUc7QUFDakMsWUFBSSxZQUFZLE1BQU0sUUFBUTtBQUM1Qjs7QUFFRixpQkFBUztBQUNULGVBQU8sTUFBTSxFQUFFLE9BQU87O0FBR3hCLFVBQUksU0FBUyxVQUFVLFNBQVMsV0FBVyxVQUFVLFFBQVE7QUFDM0QsZUFBTyxLQUFLO1VBQ1YsTUFBTTtVQUNOO1NBQ0Q7YUFDSTtBQUVMO0FBQ0E7O0FBRUY7O0FBR0Y7O0FBR0YsU0FBTztBQUNUO0FBcktGLElBc0tFLFFBQVEsQ0FBQyxXQUE0QjtBQUNuQyxNQUFJLE9BQU8sV0FBVyxHQUFHO0FBQ3ZCLFdBQU87O0FBR1QsTUFBSSxZQUFZLE9BQU8sT0FBTyxTQUFTLENBQUM7QUFFeEMsVUFBUSxVQUFVLE1BQU07SUFDdEIsS0FBSztBQUNILGVBQVMsT0FBTyxNQUFNLEdBQUcsT0FBTyxTQUFTLENBQUM7QUFDMUMsYUFBTyxNQUFNLE1BQU07QUFDbkI7SUFDRixLQUFLO0FBQ0gsVUFBSSwyQkFBMkIsVUFBVSxNQUFNLFVBQVUsTUFBTSxTQUFTLENBQUM7QUFDekUsVUFBSSw2QkFBNkIsT0FBTyw2QkFBNkIsS0FBSztBQUN4RSxpQkFBUyxPQUFPLE1BQU0sR0FBRyxPQUFPLFNBQVMsQ0FBQztBQUMxQyxlQUFPLE1BQU0sTUFBTTs7SUFFdkIsS0FBSztBQUNILFVBQUksMEJBQTBCLE9BQU8sT0FBTyxTQUFTLENBQUM7QUFDdEQsVUFBSSx5QkFBeUIsU0FBUyxhQUFhO0FBQ2pELGlCQUFTLE9BQU8sTUFBTSxHQUFHLE9BQU8sU0FBUyxDQUFDO0FBQzFDLGVBQU8sTUFBTSxNQUFNO2lCQUNWLHlCQUF5QixTQUFTLFdBQVcsd0JBQXdCLFVBQVUsS0FBSztBQUM3RixpQkFBUyxPQUFPLE1BQU0sR0FBRyxPQUFPLFNBQVMsQ0FBQztBQUMxQyxlQUFPLE1BQU0sTUFBTTs7QUFFckI7SUFDRixLQUFLO0FBQ0gsZUFBUyxPQUFPLE1BQU0sR0FBRyxPQUFPLFNBQVMsQ0FBQztBQUMxQyxhQUFPLE1BQU0sTUFBTTtBQUNuQjs7QUFHSixTQUFPO0FBQ1Q7QUF6TUYsSUEwTUUsVUFBVSxDQUFDLFdBQTRCO0FBQ3JDLE1BQUksT0FBaUIsQ0FBQTtBQUVyQixTQUFPLElBQUksQ0FBQyxVQUFTO0FBQ25CLFFBQUksTUFBTSxTQUFTLFNBQVM7QUFDMUIsVUFBSSxNQUFNLFVBQVUsS0FBSztBQUN2QixhQUFLLEtBQUssR0FBRzthQUNSO0FBQ0wsYUFBSyxPQUFPLEtBQUssWUFBWSxHQUFHLEdBQUcsQ0FBQzs7O0FBR3hDLFFBQUksTUFBTSxTQUFTLFNBQVM7QUFDMUIsVUFBSSxNQUFNLFVBQVUsS0FBSztBQUN2QixhQUFLLEtBQUssR0FBRzthQUNSO0FBQ0wsYUFBSyxPQUFPLEtBQUssWUFBWSxHQUFHLEdBQUcsQ0FBQzs7O0VBRzFDLENBQUM7QUFFRCxNQUFJLEtBQUssU0FBUyxHQUFHO0FBQ25CLFNBQUssUUFBTyxFQUFHLElBQUksQ0FBQyxTQUFRO0FBQzFCLFVBQUksU0FBUyxLQUFLO0FBQ2hCLGVBQU8sS0FBSztVQUNWLE1BQU07VUFDTixPQUFPO1NBQ1I7aUJBQ1EsU0FBUyxLQUFLO0FBQ3ZCLGVBQU8sS0FBSztVQUNWLE1BQU07VUFDTixPQUFPO1NBQ1I7O0lBRUwsQ0FBQzs7QUFHSCxTQUFPO0FBQ1Q7QUEvT0YsSUFnUEUsV0FBVyxDQUFDLFdBQTJCO0FBQ3JDLE1BQUksU0FBUztBQUViLFNBQU8sSUFBSSxDQUFDLFVBQVM7QUFDbkIsWUFBUSxNQUFNLE1BQU07TUFDbEIsS0FBSztBQUNILGtCQUFVLE1BQU0sTUFBTSxRQUFRO0FBQzlCO01BQ0Y7QUFDRSxrQkFBVSxNQUFNO0FBQ2hCOztFQUVOLENBQUM7QUFFRCxTQUFPO0FBQ1Q7QUEvUEYsSUFnUUUsZUFBZSxDQUFDLFVBQTJCLEtBQUssTUFBTSxTQUFTLFFBQVEsTUFBTSxTQUFTLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25PakcsSUFBTSxvQkFBb0I7QUFFcEIsSUFBTyxpQ0FBUCxNQUFPLGdDQUE4QjtFQXdCekMsY0FBQTs7QUF2QkEsU0FBQSxXQUE0QyxDQUFBO0FBQzVDLFNBQUEsbUJBQStDLENBQUE7QUFDL0MsMkRBQUEsSUFBQSxNQUFBLE1BQUE7QUFFQSxTQUFBLGFBQThCLElBQUksZ0JBQWU7QUFFakQscURBQUEsSUFBQSxNQUFBLE1BQUE7QUFDQSw0REFBQSxJQUFBLE1BQXVDLE1BQUs7SUFBRSxDQUFDO0FBQy9DLDJEQUFBLElBQUEsTUFBMkQsTUFBSztJQUFFLENBQUM7QUFFbkUsK0NBQUEsSUFBQSxNQUFBLE1BQUE7QUFDQSxzREFBQSxJQUFBLE1BQWlDLE1BQUs7SUFBRSxDQUFDO0FBQ3pDLHFEQUFBLElBQUEsTUFBcUQsTUFBSztJQUFFLENBQUM7QUFFN0QsOENBQUEsSUFBQSxNQUVJLENBQUEsQ0FBRTtBQUVOLDBDQUFBLElBQUEsTUFBUyxLQUFLO0FBQ2QsNENBQUEsSUFBQSxNQUFXLEtBQUs7QUFDaEIsNENBQUEsSUFBQSxNQUFXLEtBQUs7QUFDaEIsMkRBQUEsSUFBQSxNQUEwQixLQUFLO0FBc1AvQixnREFBQSxJQUFBLE1BQWUsQ0FBQyxVQUFrQjtBQUNoQyxNQUFBQyx3QkFBQSxNQUFJLHlDQUFZLE1BQUksR0FBQTtBQUNwQixVQUFJLGlCQUFpQixTQUFTLE1BQU0sU0FBUyxjQUFjO0FBQ3pELGdCQUFRLElBQUksa0JBQWlCOztBQUUvQixVQUFJLGlCQUFpQixtQkFBbUI7QUFDdEMsUUFBQUEsd0JBQUEsTUFBSSx5Q0FBWSxNQUFJLEdBQUE7QUFDcEIsZUFBTyxLQUFLLE1BQU0sU0FBUyxLQUFLOztBQUVsQyxVQUFJLGlCQUFpQixnQkFBZ0I7QUFDbkMsZUFBTyxLQUFLLE1BQU0sU0FBUyxLQUFLOztBQUVsQyxVQUFJLGlCQUFpQixPQUFPO0FBQzFCLGNBQU0saUJBQWlDLElBQUksZUFBZSxNQUFNLE9BQU87QUFFdkUsdUJBQWUsUUFBUTtBQUN2QixlQUFPLEtBQUssTUFBTSxTQUFTLGNBQWM7O0FBRTNDLGFBQU8sS0FBSyxNQUFNLFNBQVMsSUFBSSxlQUFlLE9BQU8sS0FBSyxDQUFDLENBQUM7SUFDOUQsQ0FBQztBQXRRQyxJQUFBQSx3QkFBQSxNQUFJLGtEQUFxQixJQUFJLFFBQWMsQ0FBQyxTQUFTLFdBQVU7QUFDN0QsTUFBQUEsd0JBQUEsTUFBSSx5REFBNEIsU0FBTyxHQUFBO0FBQ3ZDLE1BQUFBLHdCQUFBLE1BQUksd0RBQTJCLFFBQU0sR0FBQTtJQUN2QyxDQUFDLEdBQUMsR0FBQTtBQUVGLElBQUFBLHdCQUFBLE1BQUksNENBQWUsSUFBSSxRQUFjLENBQUMsU0FBUyxXQUFVO0FBQ3ZELE1BQUFBLHdCQUFBLE1BQUksbURBQXNCLFNBQU8sR0FBQTtBQUNqQyxNQUFBQSx3QkFBQSxNQUFJLGtEQUFxQixRQUFNLEdBQUE7SUFDakMsQ0FBQyxHQUFDLEdBQUE7QUFNRixJQUFBQyx3QkFBQSxNQUFJLGtEQUFBLEdBQUEsRUFBbUIsTUFBTSxNQUFLO0lBQUUsQ0FBQztBQUNyQyxJQUFBQSx3QkFBQSxNQUFJLDRDQUFBLEdBQUEsRUFBYSxNQUFNLE1BQUs7SUFBRSxDQUFDO0VBQ2pDOzs7Ozs7OztFQVNBLE9BQU8sbUJBQW1CLFFBQXNCO0FBQzlDLFVBQU0sU0FBUyxJQUFJLGdDQUE4QjtBQUNqRCxXQUFPLEtBQUssTUFBTSxPQUFPLG9CQUFvQixNQUFNLENBQUM7QUFDcEQsV0FBTztFQUNUO0VBRUEsT0FBTyxjQUNMLFVBQ0EsUUFDQSxTQUE2QjtBQUU3QixVQUFNLFNBQVMsSUFBSSxnQ0FBOEI7QUFDakQsZUFBVyxXQUFXLE9BQU8sVUFBVTtBQUNyQyxhQUFPLGtDQUFrQyxPQUFPOztBQUVsRCxXQUFPLEtBQUssTUFDVixPQUFPLGdDQUNMLFVBQ0EsRUFBRSxHQUFHLFFBQVEsUUFBUSxLQUFJLEdBQ3pCLEVBQUUsR0FBRyxTQUFTLFNBQVMsRUFBRSxHQUFHLFNBQVMsU0FBUyw2QkFBNkIsU0FBUSxFQUFFLENBQUUsQ0FDeEY7QUFFSCxXQUFPO0VBQ1Q7RUFFVSxLQUFLLFVBQTRCO0FBQ3pDLGFBQVEsRUFBRyxLQUFLLE1BQUs7QUFDbkIsV0FBSyxXQUFVO0FBQ2YsV0FBSyxNQUFNLEtBQUs7SUFDbEIsR0FBR0Esd0JBQUEsTUFBSSw2Q0FBQSxHQUFBLENBQWE7RUFDdEI7RUFFVSxrQ0FBa0MsU0FBc0M7QUFDaEYsU0FBSyxTQUFTLEtBQUssT0FBTztFQUM1QjtFQUVVLDZCQUE2QixTQUFtQyxPQUFPLE1BQUk7QUFDbkYsU0FBSyxpQkFBaUIsS0FBSyxPQUFPO0FBQ2xDLFFBQUksTUFBTTtBQUNSLFdBQUssTUFBTSxXQUFXLE9BQU87O0VBRWpDO0VBRVUsTUFBTSxnQ0FDZCxVQUNBLFFBQ0EsU0FBNkI7QUFFN0IsVUFBTSxTQUFTLFNBQVM7QUFDeEIsUUFBSSxRQUFRO0FBQ1YsVUFBSSxPQUFPO0FBQVMsYUFBSyxXQUFXLE1BQUs7QUFDekMsYUFBTyxpQkFBaUIsU0FBUyxNQUFNLEtBQUssV0FBVyxNQUFLLENBQUU7O0FBRWhFLElBQUFBLHdCQUFBLE1BQUksMkNBQUEsS0FBQSw0Q0FBQSxFQUFjLEtBQWxCLElBQUk7QUFDSixVQUFNLFNBQVMsTUFBTSxTQUFTLE9BQzVCLEVBQUUsR0FBRyxRQUFRLFFBQVEsS0FBSSxHQUN6QixFQUFFLEdBQUcsU0FBUyxRQUFRLEtBQUssV0FBVyxPQUFNLENBQUU7QUFFaEQsU0FBSyxXQUFVO0FBQ2YscUJBQWlCLFNBQVMsUUFBUTtBQUNoQyxNQUFBQSx3QkFBQSxNQUFJLDJDQUFBLEtBQUEsOENBQUEsRUFBZ0IsS0FBcEIsTUFBcUIsS0FBSzs7QUFFNUIsUUFBSSxPQUFPLFdBQVcsUUFBUSxTQUFTO0FBQ3JDLFlBQU0sSUFBSSxrQkFBaUI7O0FBRTdCLElBQUFBLHdCQUFBLE1BQUksMkNBQUEsS0FBQSwwQ0FBQSxFQUFZLEtBQWhCLElBQUk7RUFDTjtFQUVVLGFBQVU7QUFDbEIsUUFBSSxLQUFLO0FBQU87QUFDaEIsSUFBQUEsd0JBQUEsTUFBSSx5REFBQSxHQUFBLEVBQXlCLEtBQTdCLElBQUk7QUFDSixTQUFLLE1BQU0sU0FBUztFQUN0QjtFQUVBLElBQUksUUFBSztBQUNQLFdBQU9BLHdCQUFBLE1BQUksdUNBQUEsR0FBQTtFQUNiO0VBRUEsSUFBSSxVQUFPO0FBQ1QsV0FBT0Esd0JBQUEsTUFBSSx5Q0FBQSxHQUFBO0VBQ2I7RUFFQSxJQUFJLFVBQU87QUFDVCxXQUFPQSx3QkFBQSxNQUFJLHlDQUFBLEdBQUE7RUFDYjtFQUVBLFFBQUs7QUFDSCxTQUFLLFdBQVcsTUFBSztFQUN2Qjs7Ozs7Ozs7RUFTQSxHQUNFLE9BQ0EsVUFBcUQ7QUFFckQsVUFBTSxZQUNKQSx3QkFBQSxNQUFJLDJDQUFBLEdBQUEsRUFBWSxLQUFLLE1BQU1BLHdCQUFBLE1BQUksMkNBQUEsR0FBQSxFQUFZLEtBQUssSUFBSSxDQUFBO0FBQ3RELGNBQVUsS0FBSyxFQUFFLFNBQVEsQ0FBRTtBQUMzQixXQUFPO0VBQ1Q7Ozs7Ozs7O0VBU0EsSUFDRSxPQUNBLFVBQXFEO0FBRXJELFVBQU0sWUFBWUEsd0JBQUEsTUFBSSwyQ0FBQSxHQUFBLEVBQVksS0FBSztBQUN2QyxRQUFJLENBQUM7QUFBVyxhQUFPO0FBQ3ZCLFVBQU0sUUFBUSxVQUFVLFVBQVUsQ0FBQyxNQUFNLEVBQUUsYUFBYSxRQUFRO0FBQ2hFLFFBQUksU0FBUztBQUFHLGdCQUFVLE9BQU8sT0FBTyxDQUFDO0FBQ3pDLFdBQU87RUFDVDs7Ozs7O0VBT0EsS0FDRSxPQUNBLFVBQXFEO0FBRXJELFVBQU0sWUFDSkEsd0JBQUEsTUFBSSwyQ0FBQSxHQUFBLEVBQVksS0FBSyxNQUFNQSx3QkFBQSxNQUFJLDJDQUFBLEdBQUEsRUFBWSxLQUFLLElBQUksQ0FBQTtBQUN0RCxjQUFVLEtBQUssRUFBRSxVQUFVLE1BQU0sS0FBSSxDQUFFO0FBQ3ZDLFdBQU87RUFDVDs7Ozs7Ozs7Ozs7O0VBYUEsUUFDRSxPQUFZO0FBTVosV0FBTyxJQUFJLFFBQVEsQ0FBQyxTQUFTLFdBQVU7QUFDckMsTUFBQUQsd0JBQUEsTUFBSSx3REFBMkIsTUFBSSxHQUFBO0FBQ25DLFVBQUksVUFBVTtBQUFTLGFBQUssS0FBSyxTQUFTLE1BQU07QUFDaEQsV0FBSyxLQUFLLE9BQU8sT0FBYztJQUNqQyxDQUFDO0VBQ0g7RUFFQSxNQUFNLE9BQUk7QUFDUixJQUFBQSx3QkFBQSxNQUFJLHdEQUEyQixNQUFJLEdBQUE7QUFDbkMsVUFBTUMsd0JBQUEsTUFBSSw0Q0FBQSxHQUFBO0VBQ1o7RUFFQSxJQUFJLGlCQUFjO0FBQ2hCLFdBQU9BLHdCQUFBLE1BQUksd0RBQUEsR0FBQTtFQUNiOzs7OztFQWVBLE1BQU0sZUFBWTtBQUNoQixVQUFNLEtBQUssS0FBSTtBQUNmLFdBQU9BLHdCQUFBLE1BQUksMkNBQUEsS0FBQSwrQ0FBQSxFQUFpQixLQUFyQixJQUFJO0VBQ2I7Ozs7OztFQXVCQSxNQUFNLFlBQVM7QUFDYixVQUFNLEtBQUssS0FBSTtBQUNmLFdBQU9BLHdCQUFBLE1BQUksMkNBQUEsS0FBQSw0Q0FBQSxFQUFjLEtBQWxCLElBQUk7RUFDYjtFQXVCVSxNQUNSLFVBQ0csTUFBNkQ7QUFHaEUsUUFBSUEsd0JBQUEsTUFBSSx1Q0FBQSxHQUFBO0FBQVM7QUFFakIsUUFBSSxVQUFVLE9BQU87QUFDbkIsTUFBQUQsd0JBQUEsTUFBSSx1Q0FBVSxNQUFJLEdBQUE7QUFDbEIsTUFBQUMsd0JBQUEsTUFBSSxtREFBQSxHQUFBLEVBQW1CLEtBQXZCLElBQUk7O0FBR04sVUFBTSxZQUE2RUEsd0JBQUEsTUFBSSwyQ0FBQSxHQUFBLEVBQVksS0FBSztBQUN4RyxRQUFJLFdBQVc7QUFDYixNQUFBQSx3QkFBQSxNQUFJLDJDQUFBLEdBQUEsRUFBWSxLQUFLLElBQUksVUFBVSxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUUsSUFBSTtBQUN4RCxnQkFBVSxRQUFRLENBQUMsRUFBRSxTQUFRLE1BQVksU0FBUyxHQUFHLElBQUksQ0FBQzs7QUFHNUQsUUFBSSxVQUFVLFNBQVM7QUFDckIsWUFBTSxRQUFRLEtBQUssQ0FBQztBQUNwQixVQUFJLENBQUNBLHdCQUFBLE1BQUksd0RBQUEsR0FBQSxLQUE0QixDQUFDLFdBQVcsUUFBUTtBQUN2RCxnQkFBUSxPQUFPLEtBQUs7O0FBRXRCLE1BQUFBLHdCQUFBLE1BQUksd0RBQUEsR0FBQSxFQUF3QixLQUE1QixNQUE2QixLQUFLO0FBQ2xDLE1BQUFBLHdCQUFBLE1BQUksa0RBQUEsR0FBQSxFQUFrQixLQUF0QixNQUF1QixLQUFLO0FBQzVCLFdBQUssTUFBTSxLQUFLO0FBQ2hCOztBQUdGLFFBQUksVUFBVSxTQUFTO0FBR3JCLFlBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsVUFBSSxDQUFDQSx3QkFBQSxNQUFJLHdEQUFBLEdBQUEsS0FBNEIsQ0FBQyxXQUFXLFFBQVE7QUFPdkQsZ0JBQVEsT0FBTyxLQUFLOztBQUV0QixNQUFBQSx3QkFBQSxNQUFJLHdEQUFBLEdBQUEsRUFBd0IsS0FBNUIsTUFBNkIsS0FBSztBQUNsQyxNQUFBQSx3QkFBQSxNQUFJLGtEQUFBLEdBQUEsRUFBa0IsS0FBdEIsTUFBdUIsS0FBSztBQUM1QixXQUFLLE1BQU0sS0FBSzs7RUFFcEI7RUFFVSxhQUFVO0FBQ2xCLFVBQU0sZ0NBQWdDLEtBQUssaUJBQWlCLEdBQUcsRUFBRTtBQUNqRSxRQUFJLCtCQUErQjtBQUNqQyxXQUFLLE1BQU0saUNBQWlDQSx3QkFBQSxNQUFJLDJDQUFBLEtBQUEsK0NBQUEsRUFBaUIsS0FBckIsSUFBSSxDQUFtQjs7RUFFdkU7RUFxRFUsTUFBTSxvQkFDZCxnQkFDQSxTQUE2QjtBQUU3QixVQUFNLFNBQVMsU0FBUztBQUN4QixRQUFJLFFBQVE7QUFDVixVQUFJLE9BQU87QUFBUyxhQUFLLFdBQVcsTUFBSztBQUN6QyxhQUFPLGlCQUFpQixTQUFTLE1BQU0sS0FBSyxXQUFXLE1BQUssQ0FBRTs7QUFFaEUsSUFBQUEsd0JBQUEsTUFBSSwyQ0FBQSxLQUFBLDRDQUFBLEVBQWMsS0FBbEIsSUFBSTtBQUNKLFNBQUssV0FBVTtBQUNmLFVBQU0sU0FBUyxPQUFPLG1CQUNwQixnQkFDQSxLQUFLLFVBQVU7QUFFakIscUJBQWlCLFNBQVMsUUFBUTtBQUNoQyxNQUFBQSx3QkFBQSxNQUFJLDJDQUFBLEtBQUEsOENBQUEsRUFBZ0IsS0FBcEIsTUFBcUIsS0FBSzs7QUFFNUIsUUFBSSxPQUFPLFdBQVcsUUFBUSxTQUFTO0FBQ3JDLFlBQU0sSUFBSSxrQkFBaUI7O0FBRTdCLElBQUFBLHdCQUFBLE1BQUksMkNBQUEsS0FBQSwwQ0FBQSxFQUFZLEtBQWhCLElBQUk7RUFDTjtFQTREQSxFQUFBLHlEQUFBLG9CQUFBLFFBQUEsR0FBQSxtREFBQSxvQkFBQSxRQUFBLEdBQUEsMERBQUEsb0JBQUEsUUFBQSxHQUFBLHlEQUFBLG9CQUFBLFFBQUEsR0FBQSw2Q0FBQSxvQkFBQSxRQUFBLEdBQUEsb0RBQUEsb0JBQUEsUUFBQSxHQUFBLG1EQUFBLG9CQUFBLFFBQUEsR0FBQSw0Q0FBQSxvQkFBQSxRQUFBLEdBQUEsd0NBQUEsb0JBQUEsUUFBQSxHQUFBLDBDQUFBLG9CQUFBLFFBQUEsR0FBQSwwQ0FBQSxvQkFBQSxRQUFBLEdBQUEseURBQUEsb0JBQUEsUUFBQSxHQUFBLDhDQUFBLG9CQUFBLFFBQUEsR0FBQSw0Q0FBQSxvQkFBQSxRQUFBLEdBQUEsa0RBQUEsU0FBQUMsbURBQUE7QUE1UEUsUUFBSSxLQUFLLGlCQUFpQixXQUFXLEdBQUc7QUFDdEMsWUFBTSxJQUFJLGVBQ1IsK0VBQStFOztBQUduRixXQUFPLEtBQUssaUJBQWlCLEdBQUcsRUFBRTtFQUNwQyxHQUFDLCtDQUFBLFNBQUFDLGdEQUFBO0FBWUMsUUFBSSxLQUFLLGlCQUFpQixXQUFXLEdBQUc7QUFDdEMsWUFBTSxJQUFJLGVBQ1IsK0VBQStFOztBQUduRixVQUFNLGFBQWEsS0FBSyxpQkFDckIsR0FBRyxFQUFFLEVBQ0wsUUFBUSxPQUFPLENBQUMsVUFBOEIsTUFBTSxTQUFTLE1BQU0sRUFDbkUsSUFBSSxDQUFDLFVBQVUsTUFBTSxJQUFJO0FBQzVCLFFBQUksV0FBVyxXQUFXLEdBQUc7QUFDM0IsWUFBTSxJQUFJLGVBQWUsK0RBQStEOztBQUUxRixXQUFPLFdBQVcsS0FBSyxHQUFHO0VBQzVCLEdBQUMsK0NBQUEsU0FBQUMsZ0RBQUE7QUF5RkMsUUFBSSxLQUFLO0FBQU87QUFDaEIsSUFBQUosd0JBQUEsTUFBSSx3REFBMkIsUUFBUyxHQUFBO0VBQzFDLEdBQUMsaURBQUEsU0FBQUssZ0RBQ2UsT0FBNkM7QUFDM0QsUUFBSSxLQUFLO0FBQU87QUFDaEIsVUFBTSxrQkFBa0JKLHdCQUFBLE1BQUksMkNBQUEsS0FBQSxpREFBQSxFQUFtQixLQUF2QixNQUF3QixLQUFLO0FBQ3JELFNBQUssTUFBTSxlQUFlLE9BQU8sZUFBZTtBQUVoRCxZQUFRLE1BQU0sTUFBTTtNQUNsQixLQUFLLHVCQUF1QjtBQUMxQixjQUFNLFVBQVUsZ0JBQWdCLFFBQVEsR0FBRyxFQUFFO0FBQzdDLFlBQUksTUFBTSxNQUFNLFNBQVMsZ0JBQWdCLFFBQVEsU0FBUyxRQUFRO0FBQ2hFLGVBQUssTUFBTSxRQUFRLE1BQU0sTUFBTSxNQUFNLFFBQVEsUUFBUSxFQUFFO21CQUM5QyxNQUFNLE1BQU0sU0FBUyxzQkFBc0IsUUFBUSxTQUFTLFlBQVk7QUFDakYsY0FBSSxRQUFRLE9BQU87QUFDakIsaUJBQUssTUFBTSxhQUFhLE1BQU0sTUFBTSxjQUFjLFFBQVEsS0FBSzs7O0FBR25FOztNQUVGLEtBQUssZ0JBQWdCO0FBQ25CLGFBQUssa0NBQWtDLGVBQWU7QUFDdEQsYUFBSyw2QkFBNkIsaUJBQWlCLElBQUk7QUFDdkQ7O01BRUYsS0FBSyxzQkFBc0I7QUFDekIsYUFBSyxNQUFNLGdCQUFnQixnQkFBZ0IsUUFBUSxHQUFHLEVBQUUsQ0FBRTtBQUMxRDs7TUFFRixLQUFLLGlCQUFpQjtBQUNwQixRQUFBRCx3QkFBQSxNQUFJLHdEQUEyQixpQkFBZSxHQUFBO0FBQzlDOztNQUVGLEtBQUs7TUFDTCxLQUFLO0FBQ0g7O0VBRU4sR0FBQyw2Q0FBQSxTQUFBTSw4Q0FBQTtBQUVDLFFBQUksS0FBSyxPQUFPO0FBQ2QsWUFBTSxJQUFJLGVBQWUseUNBQXlDOztBQUVwRSxVQUFNLFdBQVdMLHdCQUFBLE1BQUksd0RBQUEsR0FBQTtBQUNyQixRQUFJLENBQUMsVUFBVTtBQUNiLFlBQU0sSUFBSSxlQUFlLDBDQUEwQzs7QUFFckUsSUFBQUQsd0JBQUEsTUFBSSx3REFBMkIsUUFBUyxHQUFBO0FBQ3hDLFdBQU87RUFDVCxHQUFDLG9EQUFBLFNBQUFPLG1EQStCa0IsT0FBNkM7QUFDOUQsUUFBSSxXQUFXTix3QkFBQSxNQUFJLHdEQUFBLEdBQUE7QUFFbkIsUUFBSSxNQUFNLFNBQVMsaUJBQWlCO0FBQ2xDLFVBQUksVUFBVTtBQUNaLGNBQU0sSUFBSSxlQUFlLCtCQUErQixNQUFNLElBQUksa0NBQWtDOztBQUV0RyxhQUFPLE1BQU07O0FBR2YsUUFBSSxDQUFDLFVBQVU7QUFDYixZQUFNLElBQUksZUFBZSwrQkFBK0IsTUFBTSxJQUFJLHlCQUF5Qjs7QUFHN0YsWUFBUSxNQUFNLE1BQU07TUFDbEIsS0FBSztBQUNILGVBQU87TUFDVCxLQUFLO0FBQ0gsaUJBQVMsY0FBYyxNQUFNLE1BQU07QUFDbkMsaUJBQVMsZ0JBQWdCLE1BQU0sTUFBTTtBQUNyQyxpQkFBUyxNQUFNLGdCQUFnQixNQUFNLE1BQU07QUFDM0MsZUFBTztNQUNULEtBQUs7QUFDSCxpQkFBUyxRQUFRLEtBQUssTUFBTSxhQUFhO0FBQ3pDLGVBQU87TUFDVCxLQUFLLHVCQUF1QjtBQUMxQixjQUFNLGtCQUFrQixTQUFTLFFBQVEsR0FBRyxNQUFNLEtBQUs7QUFDdkQsWUFBSSxpQkFBaUIsU0FBUyxVQUFVLE1BQU0sTUFBTSxTQUFTLGNBQWM7QUFDekUsMEJBQWdCLFFBQVEsTUFBTSxNQUFNO21CQUMzQixpQkFBaUIsU0FBUyxjQUFjLE1BQU0sTUFBTSxTQUFTLG9CQUFvQjtBQUkxRixjQUFJLFVBQVcsZ0JBQXdCLGlCQUFpQixLQUFLO0FBQzdELHFCQUFXLE1BQU0sTUFBTTtBQUV2QixpQkFBTyxlQUFlLGlCQUFpQixtQkFBbUI7WUFDeEQsT0FBTztZQUNQLFlBQVk7WUFDWixVQUFVO1dBQ1g7QUFFRCxjQUFJLFNBQVM7QUFDWCw0QkFBZ0IsUUFBUSxhQUFhLE9BQU87OztBQUdoRCxlQUFPOztNQUVULEtBQUs7QUFDSCxlQUFPOztFQUViLEdBRUMsT0FBTyxjQUFhLElBQUM7QUFDcEIsVUFBTSxZQUFzRCxDQUFBO0FBQzVELFVBQU0sWUFHQSxDQUFBO0FBQ04sUUFBSSxPQUFPO0FBRVgsU0FBSyxHQUFHLGVBQWUsQ0FBQyxVQUFTO0FBQy9CLFlBQU0sU0FBUyxVQUFVLE1BQUs7QUFDOUIsVUFBSSxRQUFRO0FBQ1YsZUFBTyxRQUFRLEtBQUs7YUFDZjtBQUNMLGtCQUFVLEtBQUssS0FBSzs7SUFFeEIsQ0FBQztBQUVELFNBQUssR0FBRyxPQUFPLE1BQUs7QUFDbEIsYUFBTztBQUNQLGlCQUFXLFVBQVUsV0FBVztBQUM5QixlQUFPLFFBQVEsTUFBUzs7QUFFMUIsZ0JBQVUsU0FBUztJQUNyQixDQUFDO0FBRUQsU0FBSyxHQUFHLFNBQVMsQ0FBQyxRQUFPO0FBQ3ZCLGFBQU87QUFDUCxpQkFBVyxVQUFVLFdBQVc7QUFDOUIsZUFBTyxPQUFPLEdBQUc7O0FBRW5CLGdCQUFVLFNBQVM7SUFDckIsQ0FBQztBQUVELFNBQUssR0FBRyxTQUFTLENBQUMsUUFBTztBQUN2QixhQUFPO0FBQ1AsaUJBQVcsVUFBVSxXQUFXO0FBQzlCLGVBQU8sT0FBTyxHQUFHOztBQUVuQixnQkFBVSxTQUFTO0lBQ3JCLENBQUM7QUFFRCxXQUFPO01BQ0wsTUFBTSxZQUE0RTtBQUNoRixZQUFJLENBQUMsVUFBVSxRQUFRO0FBQ3JCLGNBQUksTUFBTTtBQUNSLG1CQUFPLEVBQUUsT0FBTyxRQUFXLE1BQU0sS0FBSTs7QUFFdkMsaUJBQU8sSUFBSSxRQUE0RCxDQUFDLFNBQVMsV0FDL0UsVUFBVSxLQUFLLEVBQUUsU0FBUyxPQUFNLENBQUUsQ0FBQyxFQUNuQyxLQUFLLENBQUNPLFdBQVdBLFNBQVEsRUFBRSxPQUFPQSxRQUFPLE1BQU0sTUFBSyxJQUFLLEVBQUUsT0FBTyxRQUFXLE1BQU0sS0FBSSxDQUFHOztBQUU5RixjQUFNLFFBQVEsVUFBVSxNQUFLO0FBQzdCLGVBQU8sRUFBRSxPQUFPLE9BQU8sTUFBTSxNQUFLO01BQ3BDO01BQ0EsUUFBUSxZQUFXO0FBQ2pCLGFBQUssTUFBSztBQUNWLGVBQU8sRUFBRSxPQUFPLFFBQVcsTUFBTSxLQUFJO01BQ3ZDOztFQUVKO0VBRUEsbUJBQWdCO0FBQ2QsVUFBTSxTQUFTLElBQUksT0FBTyxLQUFLLE9BQU8sYUFBYSxFQUFFLEtBQUssSUFBSSxHQUFHLEtBQUssVUFBVTtBQUNoRixXQUFPLE9BQU8saUJBQWdCO0VBQ2hDOzs7O0FDdmpCSSxJQUFPLFdBQVAsY0FBd0IsWUFBVztFQXNCdkMsT0FDRSxNQUNBLFNBQTZCO0FBRTdCLFdBQU8sS0FBSyxRQUFRLEtBQUssb0NBQW9DO01BQzNEO01BQ0EsU0FBVSxLQUFLLFFBQWdCLFNBQVMsV0FBVztNQUNuRCxHQUFHO01BQ0gsU0FBUyxFQUFFLGtCQUFrQiw2QkFBNkIsR0FBRyxTQUFTLFFBQU87TUFDN0UsUUFBUSxLQUFLLFVBQVU7S0FDeEI7RUFDSDs7OztFQUtBLE9BQU8sTUFBMkIsU0FBNkI7QUFDN0QsV0FBTywrQkFBK0IsY0FBYyxNQUFNLE1BQU0sT0FBTztFQUN6RTs7QUE0bEJGLDBCQUFpQkMsV0FBUTtBQWV6QixHQWZpQixhQUFBLFdBQVEsQ0FBQSxFQUFBOzs7QUN6b0JuQixJQUFPLGdCQUFQLGNBQTZCLFlBQVc7RUFBOUMsY0FBQTs7QUFDRSxTQUFBLFdBQWlDLElBQWdCLFNBQVMsS0FBSyxPQUFPO0VBQ3hFOztDQUVBLFNBQWlCQyxnQkFBYTtBQUNkLEVBQUFBLGVBQUEsV0FBdUI7QUFldkMsR0FoQmlCLGtCQUFBLGdCQUFhLENBQUEsRUFBQTs7O0FDSnhCLElBQU8sT0FBUCxjQUFvQixZQUFXO0VBQXJDLGNBQUE7O0FBQ0UsU0FBQSxnQkFBZ0QsSUFBcUIsY0FBYyxLQUFLLE9BQU87RUFDakc7O0NBRUEsU0FBaUJDLE9BQUk7QUFDTCxFQUFBQSxNQUFBLGdCQUFpQztBQUNqRCxHQUZpQixTQUFBLE9BQUksQ0FBQSxFQUFBOzs7QUNBZixJQUFPLGNBQVAsY0FBMkIsWUFBVztFQW9CMUMsT0FDRSxNQUNBLFNBQTZCO0FBRTdCLFdBQU8sS0FBSyxRQUFRLEtBQUssZ0JBQWdCO01BQ3ZDO01BQ0EsU0FBVSxLQUFLLFFBQWdCLFNBQVMsV0FBVztNQUNuRCxHQUFHO01BQ0gsUUFBUSxLQUFLLFVBQVU7S0FDeEI7RUFDSDs7QUE0S0YsMEJBQWlCQyxjQUFXO0FBSzVCLEdBTGlCLGdCQUFBLGNBQVcsQ0FBQSxFQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakw1QixJQUFNQyxxQkFBb0I7QUFFcEIsSUFBTyxnQkFBUCxNQUFPLGVBQWE7RUFzQnhCLGNBQUE7O0FBckJBLFNBQUEsV0FBMkIsQ0FBQTtBQUMzQixTQUFBLG1CQUE4QixDQUFBO0FBQzlCLDBDQUFBLElBQUEsTUFBQSxNQUFBO0FBRUEsU0FBQSxhQUE4QixJQUFJLGdCQUFlO0FBRWpELG9DQUFBLElBQUEsTUFBQSxNQUFBO0FBQ0EsMkNBQUEsSUFBQSxNQUF1QyxNQUFLO0lBQUUsQ0FBQztBQUMvQywwQ0FBQSxJQUFBLE1BQTJELE1BQUs7SUFBRSxDQUFDO0FBRW5FLDhCQUFBLElBQUEsTUFBQSxNQUFBO0FBQ0EscUNBQUEsSUFBQSxNQUFpQyxNQUFLO0lBQUUsQ0FBQztBQUN6QyxvQ0FBQSxJQUFBLE1BQXFELE1BQUs7SUFBRSxDQUFDO0FBRTdELDZCQUFBLElBQUEsTUFBNEYsQ0FBQSxDQUFFO0FBRTlGLHlCQUFBLElBQUEsTUFBUyxLQUFLO0FBQ2QsMkJBQUEsSUFBQSxNQUFXLEtBQUs7QUFDaEIsMkJBQUEsSUFBQSxNQUFXLEtBQUs7QUFDaEIsMENBQUEsSUFBQSxNQUEwQixLQUFLO0FBeU8vQiwrQkFBQSxJQUFBLE1BQWUsQ0FBQyxVQUFrQjtBQUNoQyxNQUFBQyx3QkFBQSxNQUFJLHdCQUFZLE1BQUksR0FBQTtBQUNwQixVQUFJLGlCQUFpQixTQUFTLE1BQU0sU0FBUyxjQUFjO0FBQ3pELGdCQUFRLElBQUksa0JBQWlCOztBQUUvQixVQUFJLGlCQUFpQixtQkFBbUI7QUFDdEMsUUFBQUEsd0JBQUEsTUFBSSx3QkFBWSxNQUFJLEdBQUE7QUFDcEIsZUFBTyxLQUFLLE1BQU0sU0FBUyxLQUFLOztBQUVsQyxVQUFJLGlCQUFpQixnQkFBZ0I7QUFDbkMsZUFBTyxLQUFLLE1BQU0sU0FBUyxLQUFLOztBQUVsQyxVQUFJLGlCQUFpQixPQUFPO0FBQzFCLGNBQU0saUJBQWlDLElBQUksZUFBZSxNQUFNLE9BQU87QUFFdkUsdUJBQWUsUUFBUTtBQUN2QixlQUFPLEtBQUssTUFBTSxTQUFTLGNBQWM7O0FBRTNDLGFBQU8sS0FBSyxNQUFNLFNBQVMsSUFBSSxlQUFlLE9BQU8sS0FBSyxDQUFDLENBQUM7SUFDOUQsQ0FBQztBQXpQQyxJQUFBQSx3QkFBQSxNQUFJLGlDQUFxQixJQUFJLFFBQWMsQ0FBQyxTQUFTLFdBQVU7QUFDN0QsTUFBQUEsd0JBQUEsTUFBSSx3Q0FBNEIsU0FBTyxHQUFBO0FBQ3ZDLE1BQUFBLHdCQUFBLE1BQUksdUNBQTJCLFFBQU0sR0FBQTtJQUN2QyxDQUFDLEdBQUMsR0FBQTtBQUVGLElBQUFBLHdCQUFBLE1BQUksMkJBQWUsSUFBSSxRQUFjLENBQUMsU0FBUyxXQUFVO0FBQ3ZELE1BQUFBLHdCQUFBLE1BQUksa0NBQXNCLFNBQU8sR0FBQTtBQUNqQyxNQUFBQSx3QkFBQSxNQUFJLGlDQUFxQixRQUFNLEdBQUE7SUFDakMsQ0FBQyxHQUFDLEdBQUE7QUFNRixJQUFBQyx3QkFBQSxNQUFJLGlDQUFBLEdBQUEsRUFBbUIsTUFBTSxNQUFLO0lBQUUsQ0FBQztBQUNyQyxJQUFBQSx3QkFBQSxNQUFJLDJCQUFBLEdBQUEsRUFBYSxNQUFNLE1BQUs7SUFBRSxDQUFDO0VBQ2pDOzs7Ozs7OztFQVNBLE9BQU8sbUJBQW1CLFFBQXNCO0FBQzlDLFVBQU0sU0FBUyxJQUFJLGVBQWE7QUFDaEMsV0FBTyxLQUFLLE1BQU0sT0FBTyxvQkFBb0IsTUFBTSxDQUFDO0FBQ3BELFdBQU87RUFDVDtFQUVBLE9BQU8sY0FDTCxVQUNBLFFBQ0EsU0FBNkI7QUFFN0IsVUFBTSxTQUFTLElBQUksZUFBYTtBQUNoQyxlQUFXLFdBQVcsT0FBTyxVQUFVO0FBQ3JDLGFBQU8saUJBQWlCLE9BQU87O0FBRWpDLFdBQU8sS0FBSyxNQUNWLE9BQU8sZUFDTCxVQUNBLEVBQUUsR0FBRyxRQUFRLFFBQVEsS0FBSSxHQUN6QixFQUFFLEdBQUcsU0FBUyxTQUFTLEVBQUUsR0FBRyxTQUFTLFNBQVMsNkJBQTZCLFNBQVEsRUFBRSxDQUFFLENBQ3hGO0FBRUgsV0FBTztFQUNUO0VBRVUsS0FBSyxVQUE0QjtBQUN6QyxhQUFRLEVBQUcsS0FBSyxNQUFLO0FBQ25CLFdBQUssV0FBVTtBQUNmLFdBQUssTUFBTSxLQUFLO0lBQ2xCLEdBQUdBLHdCQUFBLE1BQUksNEJBQUEsR0FBQSxDQUFhO0VBQ3RCO0VBRVUsaUJBQWlCLFNBQXFCO0FBQzlDLFNBQUssU0FBUyxLQUFLLE9BQU87RUFDNUI7RUFFVSxZQUFZLFNBQWtCLE9BQU8sTUFBSTtBQUNqRCxTQUFLLGlCQUFpQixLQUFLLE9BQU87QUFDbEMsUUFBSSxNQUFNO0FBQ1IsV0FBSyxNQUFNLFdBQVcsT0FBTzs7RUFFakM7RUFFVSxNQUFNLGVBQ2QsVUFDQSxRQUNBLFNBQTZCO0FBRTdCLFVBQU0sU0FBUyxTQUFTO0FBQ3hCLFFBQUksUUFBUTtBQUNWLFVBQUksT0FBTztBQUFTLGFBQUssV0FBVyxNQUFLO0FBQ3pDLGFBQU8saUJBQWlCLFNBQVMsTUFBTSxLQUFLLFdBQVcsTUFBSyxDQUFFOztBQUVoRSxJQUFBQSx3QkFBQSxNQUFJLDBCQUFBLEtBQUEsMkJBQUEsRUFBYyxLQUFsQixJQUFJO0FBQ0osVUFBTSxTQUFTLE1BQU0sU0FBUyxPQUM1QixFQUFFLEdBQUcsUUFBUSxRQUFRLEtBQUksR0FDekIsRUFBRSxHQUFHLFNBQVMsUUFBUSxLQUFLLFdBQVcsT0FBTSxDQUFFO0FBRWhELFNBQUssV0FBVTtBQUNmLHFCQUFpQixTQUFTLFFBQVE7QUFDaEMsTUFBQUEsd0JBQUEsTUFBSSwwQkFBQSxLQUFBLDZCQUFBLEVBQWdCLEtBQXBCLE1BQXFCLEtBQUs7O0FBRTVCLFFBQUksT0FBTyxXQUFXLFFBQVEsU0FBUztBQUNyQyxZQUFNLElBQUksa0JBQWlCOztBQUU3QixJQUFBQSx3QkFBQSxNQUFJLDBCQUFBLEtBQUEseUJBQUEsRUFBWSxLQUFoQixJQUFJO0VBQ047RUFFVSxhQUFVO0FBQ2xCLFFBQUksS0FBSztBQUFPO0FBQ2hCLElBQUFBLHdCQUFBLE1BQUksd0NBQUEsR0FBQSxFQUF5QixLQUE3QixJQUFJO0FBQ0osU0FBSyxNQUFNLFNBQVM7RUFDdEI7RUFFQSxJQUFJLFFBQUs7QUFDUCxXQUFPQSx3QkFBQSxNQUFJLHNCQUFBLEdBQUE7RUFDYjtFQUVBLElBQUksVUFBTztBQUNULFdBQU9BLHdCQUFBLE1BQUksd0JBQUEsR0FBQTtFQUNiO0VBRUEsSUFBSSxVQUFPO0FBQ1QsV0FBT0Esd0JBQUEsTUFBSSx3QkFBQSxHQUFBO0VBQ2I7RUFFQSxRQUFLO0FBQ0gsU0FBSyxXQUFXLE1BQUs7RUFDdkI7Ozs7Ozs7O0VBU0EsR0FBNEMsT0FBYyxVQUFvQztBQUM1RixVQUFNLFlBQ0pBLHdCQUFBLE1BQUksMEJBQUEsR0FBQSxFQUFZLEtBQUssTUFBTUEsd0JBQUEsTUFBSSwwQkFBQSxHQUFBLEVBQVksS0FBSyxJQUFJLENBQUE7QUFDdEQsY0FBVSxLQUFLLEVBQUUsU0FBUSxDQUFFO0FBQzNCLFdBQU87RUFDVDs7Ozs7Ozs7RUFTQSxJQUE2QyxPQUFjLFVBQW9DO0FBQzdGLFVBQU0sWUFBWUEsd0JBQUEsTUFBSSwwQkFBQSxHQUFBLEVBQVksS0FBSztBQUN2QyxRQUFJLENBQUM7QUFBVyxhQUFPO0FBQ3ZCLFVBQU0sUUFBUSxVQUFVLFVBQVUsQ0FBQyxNQUFNLEVBQUUsYUFBYSxRQUFRO0FBQ2hFLFFBQUksU0FBUztBQUFHLGdCQUFVLE9BQU8sT0FBTyxDQUFDO0FBQ3pDLFdBQU87RUFDVDs7Ozs7O0VBT0EsS0FBOEMsT0FBYyxVQUFvQztBQUM5RixVQUFNLFlBQ0pBLHdCQUFBLE1BQUksMEJBQUEsR0FBQSxFQUFZLEtBQUssTUFBTUEsd0JBQUEsTUFBSSwwQkFBQSxHQUFBLEVBQVksS0FBSyxJQUFJLENBQUE7QUFDdEQsY0FBVSxLQUFLLEVBQUUsVUFBVSxNQUFNLEtBQUksQ0FBRTtBQUN2QyxXQUFPO0VBQ1Q7Ozs7Ozs7Ozs7OztFQWFBLFFBQ0UsT0FBWTtBQU1aLFdBQU8sSUFBSSxRQUFRLENBQUMsU0FBUyxXQUFVO0FBQ3JDLE1BQUFELHdCQUFBLE1BQUksdUNBQTJCLE1BQUksR0FBQTtBQUNuQyxVQUFJLFVBQVU7QUFBUyxhQUFLLEtBQUssU0FBUyxNQUFNO0FBQ2hELFdBQUssS0FBSyxPQUFPLE9BQWM7SUFDakMsQ0FBQztFQUNIO0VBRUEsTUFBTSxPQUFJO0FBQ1IsSUFBQUEsd0JBQUEsTUFBSSx1Q0FBMkIsTUFBSSxHQUFBO0FBQ25DLFVBQU1DLHdCQUFBLE1BQUksMkJBQUEsR0FBQTtFQUNaO0VBRUEsSUFBSSxpQkFBYztBQUNoQixXQUFPQSx3QkFBQSxNQUFJLHVDQUFBLEdBQUE7RUFDYjs7Ozs7RUFhQSxNQUFNLGVBQVk7QUFDaEIsVUFBTSxLQUFLLEtBQUk7QUFDZixXQUFPQSx3QkFBQSxNQUFJLDBCQUFBLEtBQUEsOEJBQUEsRUFBaUIsS0FBckIsSUFBSTtFQUNiOzs7Ozs7RUFxQkEsTUFBTSxZQUFTO0FBQ2IsVUFBTSxLQUFLLEtBQUk7QUFDZixXQUFPQSx3QkFBQSxNQUFJLDBCQUFBLEtBQUEsMkJBQUEsRUFBYyxLQUFsQixJQUFJO0VBQ2I7RUF1QlUsTUFDUixVQUNHLE1BQTRDO0FBRy9DLFFBQUlBLHdCQUFBLE1BQUksc0JBQUEsR0FBQTtBQUFTO0FBRWpCLFFBQUksVUFBVSxPQUFPO0FBQ25CLE1BQUFELHdCQUFBLE1BQUksc0JBQVUsTUFBSSxHQUFBO0FBQ2xCLE1BQUFDLHdCQUFBLE1BQUksa0NBQUEsR0FBQSxFQUFtQixLQUF2QixJQUFJOztBQUdOLFVBQU0sWUFBNERBLHdCQUFBLE1BQUksMEJBQUEsR0FBQSxFQUFZLEtBQUs7QUFDdkYsUUFBSSxXQUFXO0FBQ2IsTUFBQUEsd0JBQUEsTUFBSSwwQkFBQSxHQUFBLEVBQVksS0FBSyxJQUFJLFVBQVUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFLElBQUk7QUFDeEQsZ0JBQVUsUUFBUSxDQUFDLEVBQUUsU0FBUSxNQUFZLFNBQVMsR0FBRyxJQUFJLENBQUM7O0FBRzVELFFBQUksVUFBVSxTQUFTO0FBQ3JCLFlBQU0sUUFBUSxLQUFLLENBQUM7QUFDcEIsVUFBSSxDQUFDQSx3QkFBQSxNQUFJLHVDQUFBLEdBQUEsS0FBNEIsQ0FBQyxXQUFXLFFBQVE7QUFDdkQsZ0JBQVEsT0FBTyxLQUFLOztBQUV0QixNQUFBQSx3QkFBQSxNQUFJLHVDQUFBLEdBQUEsRUFBd0IsS0FBNUIsTUFBNkIsS0FBSztBQUNsQyxNQUFBQSx3QkFBQSxNQUFJLGlDQUFBLEdBQUEsRUFBa0IsS0FBdEIsTUFBdUIsS0FBSztBQUM1QixXQUFLLE1BQU0sS0FBSztBQUNoQjs7QUFHRixRQUFJLFVBQVUsU0FBUztBQUdyQixZQUFNLFFBQVEsS0FBSyxDQUFDO0FBQ3BCLFVBQUksQ0FBQ0Esd0JBQUEsTUFBSSx1Q0FBQSxHQUFBLEtBQTRCLENBQUMsV0FBVyxRQUFRO0FBT3ZELGdCQUFRLE9BQU8sS0FBSzs7QUFFdEIsTUFBQUEsd0JBQUEsTUFBSSx1Q0FBQSxHQUFBLEVBQXdCLEtBQTVCLE1BQTZCLEtBQUs7QUFDbEMsTUFBQUEsd0JBQUEsTUFBSSxpQ0FBQSxHQUFBLEVBQWtCLEtBQXRCLE1BQXVCLEtBQUs7QUFDNUIsV0FBSyxNQUFNLEtBQUs7O0VBRXBCO0VBRVUsYUFBVTtBQUNsQixVQUFNLGVBQWUsS0FBSyxpQkFBaUIsR0FBRyxFQUFFO0FBQ2hELFFBQUksY0FBYztBQUNoQixXQUFLLE1BQU0sZ0JBQWdCQSx3QkFBQSxNQUFJLDBCQUFBLEtBQUEsOEJBQUEsRUFBaUIsS0FBckIsSUFBSSxDQUFtQjs7RUFFdEQ7RUFxRFUsTUFBTSxvQkFDZCxnQkFDQSxTQUE2QjtBQUU3QixVQUFNLFNBQVMsU0FBUztBQUN4QixRQUFJLFFBQVE7QUFDVixVQUFJLE9BQU87QUFBUyxhQUFLLFdBQVcsTUFBSztBQUN6QyxhQUFPLGlCQUFpQixTQUFTLE1BQU0sS0FBSyxXQUFXLE1BQUssQ0FBRTs7QUFFaEUsSUFBQUEsd0JBQUEsTUFBSSwwQkFBQSxLQUFBLDJCQUFBLEVBQWMsS0FBbEIsSUFBSTtBQUNKLFNBQUssV0FBVTtBQUNmLFVBQU0sU0FBUyxPQUFPLG1CQUF1QyxnQkFBZ0IsS0FBSyxVQUFVO0FBQzVGLHFCQUFpQixTQUFTLFFBQVE7QUFDaEMsTUFBQUEsd0JBQUEsTUFBSSwwQkFBQSxLQUFBLDZCQUFBLEVBQWdCLEtBQXBCLE1BQXFCLEtBQUs7O0FBRTVCLFFBQUksT0FBTyxXQUFXLFFBQVEsU0FBUztBQUNyQyxZQUFNLElBQUksa0JBQWlCOztBQUU3QixJQUFBQSx3QkFBQSxNQUFJLDBCQUFBLEtBQUEseUJBQUEsRUFBWSxLQUFoQixJQUFJO0VBQ047RUE0REEsRUFBQSx3Q0FBQSxvQkFBQSxRQUFBLEdBQUEsa0NBQUEsb0JBQUEsUUFBQSxHQUFBLHlDQUFBLG9CQUFBLFFBQUEsR0FBQSx3Q0FBQSxvQkFBQSxRQUFBLEdBQUEsNEJBQUEsb0JBQUEsUUFBQSxHQUFBLG1DQUFBLG9CQUFBLFFBQUEsR0FBQSxrQ0FBQSxvQkFBQSxRQUFBLEdBQUEsMkJBQUEsb0JBQUEsUUFBQSxHQUFBLHVCQUFBLG9CQUFBLFFBQUEsR0FBQSx5QkFBQSxvQkFBQSxRQUFBLEdBQUEseUJBQUEsb0JBQUEsUUFBQSxHQUFBLHdDQUFBLG9CQUFBLFFBQUEsR0FBQSw2QkFBQSxvQkFBQSxRQUFBLEdBQUEsMkJBQUEsb0JBQUEsUUFBQSxHQUFBLGlDQUFBLFNBQUFDLGtDQUFBO0FBclBFLFFBQUksS0FBSyxpQkFBaUIsV0FBVyxHQUFHO0FBQ3RDLFlBQU0sSUFBSSxlQUFlLDhEQUE4RDs7QUFFekYsV0FBTyxLQUFLLGlCQUFpQixHQUFHLEVBQUU7RUFDcEMsR0FBQyw4QkFBQSxTQUFBQywrQkFBQTtBQVlDLFFBQUksS0FBSyxpQkFBaUIsV0FBVyxHQUFHO0FBQ3RDLFlBQU0sSUFBSSxlQUFlLDhEQUE4RDs7QUFFekYsVUFBTSxhQUFhLEtBQUssaUJBQ3JCLEdBQUcsRUFBRSxFQUNMLFFBQVEsT0FBTyxDQUFDLFVBQThCLE1BQU0sU0FBUyxNQUFNLEVBQ25FLElBQUksQ0FBQyxVQUFVLE1BQU0sSUFBSTtBQUM1QixRQUFJLFdBQVcsV0FBVyxHQUFHO0FBQzNCLFlBQU0sSUFBSSxlQUFlLCtEQUErRDs7QUFFMUYsV0FBTyxXQUFXLEtBQUssR0FBRztFQUM1QixHQUFDLDhCQUFBLFNBQUFDLCtCQUFBO0FBeUZDLFFBQUksS0FBSztBQUFPO0FBQ2hCLElBQUFKLHdCQUFBLE1BQUksdUNBQTJCLFFBQVMsR0FBQTtFQUMxQyxHQUFDLGdDQUFBLFNBQUFLLCtCQUNlLE9BQXlCO0FBQ3ZDLFFBQUksS0FBSztBQUFPO0FBQ2hCLFVBQU0sa0JBQWtCSix3QkFBQSxNQUFJLDBCQUFBLEtBQUEsZ0NBQUEsRUFBbUIsS0FBdkIsTUFBd0IsS0FBSztBQUNyRCxTQUFLLE1BQU0sZUFBZSxPQUFPLGVBQWU7QUFFaEQsWUFBUSxNQUFNLE1BQU07TUFDbEIsS0FBSyx1QkFBdUI7QUFDMUIsY0FBTSxVQUFVLGdCQUFnQixRQUFRLEdBQUcsRUFBRTtBQUM3QyxZQUFJLE1BQU0sTUFBTSxTQUFTLGdCQUFnQixRQUFRLFNBQVMsUUFBUTtBQUNoRSxlQUFLLE1BQU0sUUFBUSxNQUFNLE1BQU0sTUFBTSxRQUFRLFFBQVEsRUFBRTttQkFDOUMsTUFBTSxNQUFNLFNBQVMsc0JBQXNCLFFBQVEsU0FBUyxZQUFZO0FBQ2pGLGNBQUksUUFBUSxPQUFPO0FBQ2pCLGlCQUFLLE1BQU0sYUFBYSxNQUFNLE1BQU0sY0FBYyxRQUFRLEtBQUs7OztBQUduRTs7TUFFRixLQUFLLGdCQUFnQjtBQUNuQixhQUFLLGlCQUFpQixlQUFlO0FBQ3JDLGFBQUssWUFBWSxpQkFBaUIsSUFBSTtBQUN0Qzs7TUFFRixLQUFLLHNCQUFzQjtBQUN6QixhQUFLLE1BQU0sZ0JBQWdCLGdCQUFnQixRQUFRLEdBQUcsRUFBRSxDQUFFO0FBQzFEOztNQUVGLEtBQUssaUJBQWlCO0FBQ3BCLFFBQUFELHdCQUFBLE1BQUksdUNBQTJCLGlCQUFlLEdBQUE7QUFDOUM7O01BRUYsS0FBSztNQUNMLEtBQUs7QUFDSDs7RUFFTixHQUFDLDRCQUFBLFNBQUFNLDZCQUFBO0FBRUMsUUFBSSxLQUFLLE9BQU87QUFDZCxZQUFNLElBQUksZUFBZSx5Q0FBeUM7O0FBRXBFLFVBQU0sV0FBV0wsd0JBQUEsTUFBSSx1Q0FBQSxHQUFBO0FBQ3JCLFFBQUksQ0FBQyxVQUFVO0FBQ2IsWUFBTSxJQUFJLGVBQWUsMENBQTBDOztBQUVyRSxJQUFBRCx3QkFBQSxNQUFJLHVDQUEyQixRQUFTLEdBQUE7QUFDeEMsV0FBTztFQUNULEdBQUMsbUNBQUEsU0FBQU8sa0NBNEJrQixPQUF5QjtBQUMxQyxRQUFJLFdBQVdOLHdCQUFBLE1BQUksdUNBQUEsR0FBQTtBQUVuQixRQUFJLE1BQU0sU0FBUyxpQkFBaUI7QUFDbEMsVUFBSSxVQUFVO0FBQ1osY0FBTSxJQUFJLGVBQWUsK0JBQStCLE1BQU0sSUFBSSxrQ0FBa0M7O0FBRXRHLGFBQU8sTUFBTTs7QUFHZixRQUFJLENBQUMsVUFBVTtBQUNiLFlBQU0sSUFBSSxlQUFlLCtCQUErQixNQUFNLElBQUkseUJBQXlCOztBQUc3RixZQUFRLE1BQU0sTUFBTTtNQUNsQixLQUFLO0FBQ0gsZUFBTztNQUNULEtBQUs7QUFDSCxpQkFBUyxjQUFjLE1BQU0sTUFBTTtBQUNuQyxpQkFBUyxnQkFBZ0IsTUFBTSxNQUFNO0FBQ3JDLGlCQUFTLE1BQU0sZ0JBQWdCLE1BQU0sTUFBTTtBQUMzQyxlQUFPO01BQ1QsS0FBSztBQUNILGlCQUFTLFFBQVEsS0FBSyxNQUFNLGFBQWE7QUFDekMsZUFBTztNQUNULEtBQUssdUJBQXVCO0FBQzFCLGNBQU0sa0JBQWtCLFNBQVMsUUFBUSxHQUFHLE1BQU0sS0FBSztBQUN2RCxZQUFJLGlCQUFpQixTQUFTLFVBQVUsTUFBTSxNQUFNLFNBQVMsY0FBYztBQUN6RSwwQkFBZ0IsUUFBUSxNQUFNLE1BQU07bUJBQzNCLGlCQUFpQixTQUFTLGNBQWMsTUFBTSxNQUFNLFNBQVMsb0JBQW9CO0FBSTFGLGNBQUksVUFBVyxnQkFBd0JGLGtCQUFpQixLQUFLO0FBQzdELHFCQUFXLE1BQU0sTUFBTTtBQUV2QixpQkFBTyxlQUFlLGlCQUFpQkEsb0JBQW1CO1lBQ3hELE9BQU87WUFDUCxZQUFZO1lBQ1osVUFBVTtXQUNYO0FBRUQsY0FBSSxTQUFTO0FBQ1gsNEJBQWdCLFFBQVEsYUFBYSxPQUFPOzs7QUFHaEQsZUFBTzs7TUFFVCxLQUFLO0FBQ0gsZUFBTzs7RUFFYixHQUVDLE9BQU8sY0FBYSxJQUFDO0FBQ3BCLFVBQU0sWUFBa0MsQ0FBQTtBQUN4QyxVQUFNLFlBR0EsQ0FBQTtBQUNOLFFBQUksT0FBTztBQUVYLFNBQUssR0FBRyxlQUFlLENBQUMsVUFBUztBQUMvQixZQUFNLFNBQVMsVUFBVSxNQUFLO0FBQzlCLFVBQUksUUFBUTtBQUNWLGVBQU8sUUFBUSxLQUFLO2FBQ2Y7QUFDTCxrQkFBVSxLQUFLLEtBQUs7O0lBRXhCLENBQUM7QUFFRCxTQUFLLEdBQUcsT0FBTyxNQUFLO0FBQ2xCLGFBQU87QUFDUCxpQkFBVyxVQUFVLFdBQVc7QUFDOUIsZUFBTyxRQUFRLE1BQVM7O0FBRTFCLGdCQUFVLFNBQVM7SUFDckIsQ0FBQztBQUVELFNBQUssR0FBRyxTQUFTLENBQUMsUUFBTztBQUN2QixhQUFPO0FBQ1AsaUJBQVcsVUFBVSxXQUFXO0FBQzlCLGVBQU8sT0FBTyxHQUFHOztBQUVuQixnQkFBVSxTQUFTO0lBQ3JCLENBQUM7QUFFRCxTQUFLLEdBQUcsU0FBUyxDQUFDLFFBQU87QUFDdkIsYUFBTztBQUNQLGlCQUFXLFVBQVUsV0FBVztBQUM5QixlQUFPLE9BQU8sR0FBRzs7QUFFbkIsZ0JBQVUsU0FBUztJQUNyQixDQUFDO0FBRUQsV0FBTztNQUNMLE1BQU0sWUFBd0Q7QUFDNUQsWUFBSSxDQUFDLFVBQVUsUUFBUTtBQUNyQixjQUFJLE1BQU07QUFDUixtQkFBTyxFQUFFLE9BQU8sUUFBVyxNQUFNLEtBQUk7O0FBRXZDLGlCQUFPLElBQUksUUFBd0MsQ0FBQyxTQUFTLFdBQzNELFVBQVUsS0FBSyxFQUFFLFNBQVMsT0FBTSxDQUFFLENBQUMsRUFDbkMsS0FBSyxDQUFDUyxXQUFXQSxTQUFRLEVBQUUsT0FBT0EsUUFBTyxNQUFNLE1BQUssSUFBSyxFQUFFLE9BQU8sUUFBVyxNQUFNLEtBQUksQ0FBRzs7QUFFOUYsY0FBTSxRQUFRLFVBQVUsTUFBSztBQUM3QixlQUFPLEVBQUUsT0FBTyxPQUFPLE1BQU0sTUFBSztNQUNwQztNQUNBLFFBQVEsWUFBVztBQUNqQixhQUFLLE1BQUs7QUFDVixlQUFPLEVBQUUsT0FBTyxRQUFXLE1BQU0sS0FBSTtNQUN2Qzs7RUFFSjtFQUVBLG1CQUFnQjtBQUNkLFVBQU0sU0FBUyxJQUFJLE9BQU8sS0FBSyxPQUFPLGFBQWEsRUFBRSxLQUFLLElBQUksR0FBRyxLQUFLLFVBQVU7QUFDaEYsV0FBTyxPQUFPLGlCQUFnQjtFQUNoQzs7OztBQ3BpQkksSUFBT0MsWUFBUCxjQUF3QixZQUFXO0VBbUJ2QyxPQUNFLE1BQ0EsU0FBNkI7QUFFN0IsUUFBSSxLQUFLLFNBQVMsbUJBQW1CO0FBQ25DLGNBQVEsS0FDTixjQUFjLEtBQUssS0FBSyxpREFDdEIsa0JBQWtCLEtBQUssS0FBSyxDQUM5Qjs2SEFBZ0k7O0FBR3BJLFdBQU8sS0FBSyxRQUFRLEtBQUssZ0JBQWdCO01BQ3ZDO01BQ0EsU0FBVSxLQUFLLFFBQWdCLFNBQVMsV0FBVztNQUNuRCxHQUFHO01BQ0gsUUFBUSxLQUFLLFVBQVU7S0FDeEI7RUFDSDs7OztFQUtBLE9BQU8sTUFBMkIsU0FBNkI7QUFDN0QsV0FBTyxjQUFjLGNBQWMsTUFBTSxNQUFNLE9BQU87RUFDeEQ7O0FBb0xGLElBQU0sb0JBQTBDO0VBQzlDLGNBQWM7RUFDZCxtQkFBbUI7RUFDbkIsc0JBQXNCO0VBQ3RCLDJCQUEyQjtFQUMzQixzQkFBc0I7O0FBNGdCeEIsMEJBQWlCQSxXQUFRO0FBbUN6QixHQW5DaUJBLGNBQUFBLFlBQVEsQ0FBQSxFQUFBOzs7O0FDdHFCbkIsSUFBTyxZQUFQLGNBQThCLFVBQVM7Ozs7Ozs7Ozs7Ozs7OztFQW9CM0MsWUFBWSxFQUNWLFVBQWUsUUFBUSxvQkFBb0IsR0FDM0MsU0FBYyxRQUFRLG1CQUFtQixLQUFLLE1BQzlDLFlBQWlCLFFBQVEsc0JBQXNCLEtBQUssTUFDcEQsR0FBRyxLQUFJLElBQ1UsQ0FBQSxHQUFFO0FBQ25CLFVBQU0sVUFBeUI7TUFDN0I7TUFDQTtNQUNBLEdBQUc7TUFDSCxTQUFTLFdBQVc7O0FBR3RCLFFBQUksQ0FBQyxRQUFRLDJCQUFnQyxtQkFBa0IsR0FBSTtBQUNqRSxZQUFNLElBQVcsZUFDZixxWEFBcVg7O0FBSXpYLFVBQU07TUFDSixTQUFTLFFBQVE7TUFDakIsU0FBUyxRQUFRLFdBQVc7TUFDNUIsV0FBVyxRQUFRO01BQ25CLFlBQVksUUFBUTtNQUNwQixPQUFPLFFBQVE7S0FDaEI7QUFRSCxTQUFBLGNBQStCLElBQVEsWUFBWSxJQUFJO0FBQ3ZELFNBQUEsV0FBeUIsSUFBUUMsVUFBUyxJQUFJO0FBQzlDLFNBQUEsT0FBaUIsSUFBUSxLQUFLLElBQUk7QUFSaEMsU0FBSyxXQUFXO0FBRWhCLFNBQUssU0FBUztBQUNkLFNBQUssWUFBWTtFQUNuQjtFQU1tQixlQUFZO0FBQzdCLFdBQU8sS0FBSyxTQUFTO0VBQ3ZCO0VBRW1CLGVBQWUsTUFBOEI7QUFDOUQsV0FBTztNQUNMLEdBQUcsTUFBTSxlQUFlLElBQUk7TUFDNUIsR0FBSSxLQUFLLFNBQVMsMEJBQ2hCLEVBQUUsNkNBQTZDLE9BQU0sSUFDckQ7TUFDRixxQkFBcUI7TUFDckIsR0FBRyxLQUFLLFNBQVM7O0VBRXJCO0VBRW1CLGdCQUFnQixTQUF1QixlQUEyQjtBQUNuRixRQUFJLEtBQUssVUFBVSxRQUFRLFdBQVcsR0FBRztBQUN2Qzs7QUFFRixRQUFJLGNBQWMsV0FBVyxNQUFNLE1BQU07QUFDdkM7O0FBR0YsUUFBSSxLQUFLLGFBQWEsUUFBUSxlQUFlLEdBQUc7QUFDOUM7O0FBRUYsUUFBSSxjQUFjLGVBQWUsTUFBTSxNQUFNO0FBQzNDOztBQUdGLFVBQU0sSUFBSSxNQUNSLDJLQUEySztFQUUvSztFQUVtQixZQUFZLE1BQThCO0FBQzNELFVBQU0sYUFBYSxLQUFLLFdBQVcsSUFBSTtBQUN2QyxVQUFNLGFBQWEsS0FBSyxXQUFXLElBQUk7QUFFdkMsUUFBSSxjQUFjLFFBQVEsQ0FBTSxXQUFXLFVBQVUsR0FBRztBQUN0RCxhQUFPOztBQUdULFFBQUksY0FBYyxRQUFRLENBQU0sV0FBVyxVQUFVLEdBQUc7QUFDdEQsYUFBTzs7QUFFVCxXQUFPLENBQUE7RUFDVDtFQUVVLFdBQVcsTUFBOEI7QUFDakQsUUFBSSxLQUFLLFVBQVUsTUFBTTtBQUN2QixhQUFPLENBQUE7O0FBRVQsV0FBTyxFQUFFLGFBQWEsS0FBSyxPQUFNO0VBQ25DO0VBRVUsV0FBVyxNQUE4QjtBQUNqRCxRQUFJLEtBQUssYUFBYSxNQUFNO0FBQzFCLGFBQU8sQ0FBQTs7QUFFVCxXQUFPLEVBQUUsZUFBZSxVQUFVLEtBQUssU0FBUyxHQUFFO0VBQ3BEOzs7QUFFTyxVQUFBLFlBQVk7QUFDWixVQUFBLGVBQWU7QUFDZixVQUFBLFlBQVk7QUFDWixVQUFBLGtCQUFrQjtBQUVsQixVQUFBLGlCQUF3QjtBQUN4QixVQUFBLFdBQWtCO0FBQ2xCLFVBQUEscUJBQTRCO0FBQzVCLFVBQUEsNEJBQW1DO0FBQ25DLFVBQUEsb0JBQTJCO0FBQzNCLFVBQUEsZ0JBQXVCO0FBQ3ZCLFVBQUEsZ0JBQXVCO0FBQ3ZCLFVBQUEsaUJBQXdCO0FBQ3hCLFVBQUEsa0JBQXlCO0FBQ3pCLFVBQUEsc0JBQTZCO0FBQzdCLFVBQUEsc0JBQTZCO0FBQzdCLFVBQUEsd0JBQStCO0FBQy9CLFVBQUEsMkJBQWtDO0FBRWxDLFVBQUEsU0FBaUI7QUFDakIsVUFBQSxlQUF1QjtBQUd6QixJQUFNLEVBQUUsY0FBYyxVQUFTLElBQUs7QUFFcEMsSUFBTSxFQUNYLGdCQUFBQyxpQkFDQSxVQUFBQyxXQUNBLG9CQUFBQyxxQkFDQSwyQkFBQUMsNEJBQ0EsbUJBQUFDLG9CQUNBLGVBQUFDLGdCQUNBLGVBQUFDLGdCQUNBLGdCQUFBQyxpQkFDQSxpQkFBQUMsa0JBQ0EscUJBQUFDLHNCQUNBLHFCQUFBQyxzQkFDQSx1QkFBQUMsd0JBQ0EsMEJBQUFDLDBCQUF3QixJQUN0QjtDQUtKLFNBQWlCQyxZQUFTO0FBR1YsRUFBQUEsV0FBQSxjQUFrQjtBQU1sQixFQUFBQSxXQUFBLFdBQWVDO0FBbUNmLEVBQUFELFdBQUEsT0FBVztBQUMzQixHQTdDaUIsY0FBQSxZQUFTLENBQUEsRUFBQTs7O0FDelAxQixTQUFTLG9CQUFvQixRQUE2QjtBQUN4RCxNQUFJLFNBQVM7QUFDYixRQUFNLFFBQVEsSUFBSSxXQUFXLE1BQU07QUFDbkMsV0FBUyxJQUFJLEdBQUcsSUFBSSxNQUFNLFlBQVksS0FBSztBQUN6QyxjQUFVLE9BQU8sYUFBYSxNQUFNLENBQUMsQ0FBQztBQUFBLEVBQ3hDO0FBQ0EsU0FBTyxLQUFLLE1BQU07QUFDcEI7QUFFQSxlQUFzQixpQkFBaUIsVUFHcEM7QUFFRCxNQUFJLFNBQVMsV0FBVyxPQUFPLEdBQUc7QUFDaEMsVUFBTSxDQUFDLFFBQVEsSUFBSSxJQUFJLFNBQVMsTUFBTSxHQUFHO0FBQ3pDLFVBQU0sYUFBYSxPQUFPLE1BQU0sR0FBRyxFQUFFLENBQUMsRUFBRSxNQUFNLEdBQUcsRUFBRSxDQUFDO0FBQ3BELFdBQU8sRUFBRSxZQUFZLEtBQUs7QUFBQSxFQUM1QjtBQUVBLFFBQU0sV0FBVyxNQUFNLE1BQU0sUUFBUTtBQUNyQyxRQUFNLGNBQWMsTUFBTSxTQUFTLFlBQVk7QUFFL0MsUUFBTSxTQUFTLG9CQUFvQixXQUFXO0FBQzlDLFNBQU87QUFBQSxJQUNMLFlBQVksU0FBUyxRQUFRLElBQUksY0FBYyxLQUFLO0FBQUEsSUFDcEQsTUFBTTtBQUFBLEVBQ1I7QUFDRjs7O0FwQnZCQSxlQUFlLGdCQUNiLFVBQ3FFO0FBQ3JFLFNBQU8sUUFBUTtBQUFBLElBQ2IsU0FBUyxJQUFJLE9BQU8sT0FBTztBQUN6QixVQUFJLENBQUMsR0FBRyxTQUFTO0FBQ2YsY0FBTSxJQUFJLE1BQU0scUJBQXFCO0FBQUEsTUFDdkM7QUFDQSxVQUFJLENBQUMsR0FBRyxhQUFhO0FBQ25CLGVBQU87QUFBQSxVQUNMLE1BQU0sR0FBRztBQUFBLFVBQ1QsU0FBUyxHQUFHO0FBQUEsUUFDZDtBQUFBLE1BQ0Y7QUFDQSxhQUFPO0FBQUEsUUFDTCxNQUFNLEdBQUc7QUFBQSxRQUNULFNBQVM7QUFBQSxVQUNQO0FBQUEsWUFDRSxNQUFNO0FBQUEsWUFDTixNQUFNLEdBQUc7QUFBQSxVQUNYO0FBQUEsVUFDQSxHQUFJLE1BQU0sUUFBUTtBQUFBLFlBQ2hCLEdBQUcsWUFBWSxJQUFJLE9BQU9FLFFBQU87QUFDL0IscUJBQU87QUFBQSxnQkFDTCxNQUFNO0FBQUEsZ0JBQ04sUUFBUTtBQUFBLGtCQUNOLE1BQU07QUFBQSxrQkFDTixHQUFJLE1BQU0saUJBQWlCQSxJQUFHLEdBQUc7QUFBQSxnQkFDbkM7QUFBQSxjQUNGO0FBQUEsWUFDRixDQUFDO0FBQUEsVUFDSDtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUNGO0FBRUEsU0FBUyxrQkFBa0JDLFFBQXVCO0FBQ2hELE1BQUlBLE9BQU0sV0FBVyxZQUFZLEdBQUc7QUFDbEMsV0FBTztBQUFBLEVBQ1Q7QUFDQSxTQUFPO0FBQ1Q7QUFFQSxlQUFlLFNBQ2IsS0FDQSxRQUM2QztBQUM3QyxTQUFPO0FBQUEsSUFDTCxVQUFVLE1BQU07QUFBQSxNQUNkLElBQUksU0FBUztBQUFBLFFBQU8sQ0FBQyxPQUVqQjtBQUFBLFVBQ0U7QUFBQSxVQUNBO0FBQUEsUUFDRixFQUNBLFNBQVMsR0FBRyxJQUFJO0FBQUEsTUFDcEI7QUFBQSxJQUNGO0FBQUEsSUFDQSxZQUFZLGtCQUFrQixJQUFJLEtBQUs7QUFBQSxJQUN2QztBQUFBLElBQ0EsT0FBTyxJQUFJO0FBQUEsSUFDWCxRQUFRLElBQUksU0FBUyxLQUFLLENBQUMsT0FBTyxHQUFHLFNBQVMsUUFBUSxHQUFHO0FBQUEsRUFDM0Q7QUFDRjtBQUVBLFNBQVMsY0FDUCxNQUN3QjtBQUN4QixNQUFJLEtBQUssUUFBUSxXQUFXLEdBQUc7QUFDN0IsWUFBUSxNQUFNLHdCQUF3QixLQUFLLE9BQU87QUFDbEQsVUFBTSxJQUFJLE1BQU0sc0JBQXNCO0FBQUEsRUFDeEM7QUFDQSxTQUFPO0FBQUEsSUFDTCxTQUFVLEtBQUssUUFBUSxDQUFDLEVBQStCO0FBQUEsRUFDekQ7QUFDRjtBQUVBLGVBQXNCLFNBQVMsU0FBaUM7QUFDOUQsUUFBTSxlQUFlLFlBQVk7QUFDL0IsV0FBTyxJQUFJLFVBQVU7QUFBQSxNQUNuQixRQUFRLE1BQWUsaUJBQVEsSUFBSSxrQkFBa0I7QUFBQSxNQUNyRCxnQkFBZ0I7QUFBQSxRQUNkLDZDQUE2QztBQUFBLE1BQy9DO0FBQUEsSUFDRixDQUFDO0FBQUEsRUFDSDtBQUNBLFFBQWUsZUFBTSxpQkFBaUI7QUFBQSxJQUNwQyxNQUFNO0FBQUEsSUFDTixRQUFRO0FBQUEsTUFDTixFQUFFLElBQUksOEJBQThCLE1BQU0sdUJBQXVCO0FBQUEsTUFDakUsRUFBRSxJQUFJLDhCQUE4QixNQUFNLG9CQUFvQjtBQUFBLE1BQzlELEVBQUUsSUFBSSwwQkFBMEIsTUFBTSxnQkFBZ0I7QUFBQSxNQUN0RCxFQUFFLElBQUksNEJBQTRCLE1BQU0sa0JBQWtCO0FBQUEsTUFDMUQsRUFBRSxJQUFJLDJCQUEyQixNQUFNLGlCQUFpQjtBQUFBLElBQzFEO0FBQUEsSUFDQSxNQUFNLE9BQU8sT0FBTztBQUNsQixZQUFNLFNBQVMsTUFBTSxhQUFhO0FBQ2xDLGFBQU87QUFBQSxRQUNMLE1BQU0sT0FBTyxTQUFTO0FBQUEsVUFDbkIsTUFBTTtBQUFBLFlBQ0w7QUFBQSxZQUNBO0FBQUEsVUFDRjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLElBQ0EsT0FBTyxPQUFPLE9BQU87QUFDbkIsWUFBTSxTQUFTLE1BQU0sYUFBYTtBQUNsQyxZQUFNLFNBQVMsTUFBTSxPQUFPLFNBQVM7QUFBQSxRQUNsQyxNQUFNO0FBQUEsVUFDTDtBQUFBLFVBQ0E7QUFBQSxRQUNGO0FBQUEsTUFDRjtBQUNBLHVCQUFpQixNQUFNLFFBQVE7QUFDN0IsWUFBSSxHQUFHLFNBQVMsdUJBQXVCO0FBQ3JDLGNBQUksR0FBRyxNQUFNLFNBQVMsY0FBYztBQUNsQyxrQkFBTSxJQUFJLE1BQU0sd0JBQXdCO0FBQUEsVUFDMUM7QUFDQSxnQkFBTTtBQUFBLFlBQ0osU0FBUyxHQUFHLE1BQU07QUFBQSxVQUNwQjtBQUFBLFFBQ0Y7QUFBQSxNQUNGO0FBQUEsSUFDRjtBQUFBLEVBQ0YsQ0FBQztBQUNIOyIsCiAgIm5hbWVzIjogWyJmZXRjaCIsICJSZXF1ZXN0IiwgIlJlc3BvbnNlIiwgIkhlYWRlcnMiLCAiRm9ybURhdGEiLCAiQmxvYiIsICJGaWxlIiwgIlJlYWRhYmxlU3RyZWFtIiwgIlJlYWRhYmxlU3RyZWFtIiwgIkZpbGUiLCAicGFyc2VSZXNwb25zZSIsICJmZXRjaCIsICJvcHRzIiwgInJldHJ5TWVzc2FnZSIsICJfX2NsYXNzUHJpdmF0ZUZpZWxkU2V0IiwgIl9fY2xhc3NQcml2YXRlRmllbGRHZXQiLCAiX1Byb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbV9nZXRGaW5hbE1lc3NhZ2UiLCAiX1Byb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbV9nZXRGaW5hbFRleHQiLCAiX1Byb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbV9iZWdpblJlcXVlc3QiLCAiX1Byb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbV9hZGRTdHJlYW1FdmVudCIsICJfUHJvbXB0Q2FjaGluZ0JldGFNZXNzYWdlU3RyZWFtX2VuZFJlcXVlc3QiLCAiX1Byb21wdENhY2hpbmdCZXRhTWVzc2FnZVN0cmVhbV9hY2N1bXVsYXRlTWVzc2FnZSIsICJjaHVuayIsICJNZXNzYWdlcyIsICJQcm9tcHRDYWNoaW5nIiwgIkJldGEiLCAiQ29tcGxldGlvbnMiLCAiSlNPTl9CVUZfUFJPUEVSVFkiLCAiX19jbGFzc1ByaXZhdGVGaWVsZFNldCIsICJfX2NsYXNzUHJpdmF0ZUZpZWxkR2V0IiwgIl9NZXNzYWdlU3RyZWFtX2dldEZpbmFsTWVzc2FnZSIsICJfTWVzc2FnZVN0cmVhbV9nZXRGaW5hbFRleHQiLCAiX01lc3NhZ2VTdHJlYW1fYmVnaW5SZXF1ZXN0IiwgIl9NZXNzYWdlU3RyZWFtX2FkZFN0cmVhbUV2ZW50IiwgIl9NZXNzYWdlU3RyZWFtX2VuZFJlcXVlc3QiLCAiX01lc3NhZ2VTdHJlYW1fYWNjdW11bGF0ZU1lc3NhZ2UiLCAiY2h1bmsiLCAiTWVzc2FnZXMiLCAiTWVzc2FnZXMiLCAiQW50aHJvcGljRXJyb3IiLCAiQVBJRXJyb3IiLCAiQVBJQ29ubmVjdGlvbkVycm9yIiwgIkFQSUNvbm5lY3Rpb25UaW1lb3V0RXJyb3IiLCAiQVBJVXNlckFib3J0RXJyb3IiLCAiTm90Rm91bmRFcnJvciIsICJDb25mbGljdEVycm9yIiwgIlJhdGVMaW1pdEVycm9yIiwgIkJhZFJlcXVlc3RFcnJvciIsICJBdXRoZW50aWNhdGlvbkVycm9yIiwgIkludGVybmFsU2VydmVyRXJyb3IiLCAiUGVybWlzc2lvbkRlbmllZEVycm9yIiwgIlVucHJvY2Vzc2FibGVFbnRpdHlFcnJvciIsICJBbnRocm9waWMiLCAiTWVzc2FnZXMiLCAiaXQiLCAibW9kZWwiXQp9Cg==
